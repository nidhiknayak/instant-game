const express       = require('express');
const bodyParser    = require('body-parser');
const path          = require('path');
const session       = require('express-session');
const MongoStore    = require('connect-mongo');
const cron          = require("node-cron");
const { CTS, bankVerification, checkTransStatus, checkLetsPayTransInternal, updateTransStatusToFailedAfterFiveMin } = require('./src/services/cron');
require('dotenv').config();

const app           = express();
app.use(express.json({ limit: process.env.EXPRESS_LIMIT || '200kb' }));
app.use(express.urlencoded({ extended:true }));

app.use('/uploads', express.static('uploads'));
app.use('/admin/assets', express.static('assets'));
app.use('/admin', express.static('assets'));

const connectToDB = require('./src/db/connection');
connectToDB();
/* app.use(session({
    store: MongoStore.create({
        mongoUrl: process.env.DB_URL,
        mongoOptions: { useNewUrlParser: true, useUnifiedTopology: true }
    }),
    secret: process.env.HASH_SECRET,
    saveUninitialized: true,
    resave: true
})); */

app.set('view engine', 'ejs');
app.locals.adminBaseUrl = process.env.ADMIN_BASE_URL;
app.locals.imgBaseUrl = process.env.IMG_BASE_URL;
app.locals.websiteName = "Instant567";

app.use('/assets', express.static('assets'));

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "*");
    next();
});

require("./src/routes/user")(app);

require("./src/routes/admin")(app);

require('./src/services/seedData').initSeedData();

if(process.env.IS_WITH_CRON == "YES"){
    cron.schedule("*/15 * * * *", function() {
    CTS(); //bankVerification();
    });
}
if(process.env.IS_TRANS_CRON == "YES"){
    const statusCheckEvery = process.env.TRANS_CRON_EVERY || 1;
    cron.schedule("*/"+statusCheckEvery+" * * * *", function() {
        checkTransStatus();
    });
    cron.schedule("* * * * *", function() {
        updateTransStatusToFailedAfterFiveMin();
    });    
}
if(process.env.IS_INTERNAL_TRANS_CRON == "YES"){
    cron.schedule("*/10 * * * * *", function() {
        checkLetsPayTransInternal();
    });
}

const usedPort = process.env.APP_PORT;
let server = app;
if(process.env.MODE !== "LOCAL" && process.env.IS_CREATE_BOTH == "YES"){
    var fs = require('fs');
    var https = require('https');
    const certsPath     = '/var/www/cert/new/';
    /* 
    working: key: `certsPath${key.key}`
    working: cert: `certsPath${cert.pem}`
     */
    var credentials = {
        key:  fs.readFileSync(certsPath + 'privkey.pem', { encoding:'utf-8' }), //privkey.key ca.crt
        cert: fs.readFileSync(certsPath + 'cert.pem', { encoding:'utf-8' }), //cert.pem
        // ca:   fs.readFileSync(certsPath + 'chain.pem'), 
    };
    // console.log("credentials", fs.readFileSync(certsPath + 'privkey.key', { encoding:'utf-8' }));
    server = https.createServer(credentials,app);
    const httpsPort = 3002;
    server.listen(httpsPort, () =>{
        console.log('Https Server Is Running On '+httpsPort+' Port');
    });
}
/* http port */
app.listen(usedPort, () =>{
	console.log('http Server Is Running On '+usedPort+' Port');
});

/* 
app.get('/admin',function(req,res){
    if (req.session.authDet && typeof req.session.authDet.email !== 'undefined' && req.session.authDet.email != '') {
        return res.redirect('dashboard')
    }
    res.render('login')
}); 
*/