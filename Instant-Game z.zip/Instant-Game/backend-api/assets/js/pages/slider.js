if($("#tbl_slider").length > 0){
    ajaxGetSlider();
    
    $('body').on('click', 'ul.pagination.mypagi a', function (event) {
        event.preventDefault();
        $('li').removeClass('active');
        $(this).parent('li').addClass('active');
        var page = $(this).attr('href').split('page=')[1];
        ajaxGetSlider(page);
    });

}
if ($("#tbl_sliderData").length > 0) {
    $("#dataSlider").DataTable();
}

function ajaxGetSlider(page = 0){
    data = { page: page, size:3};
    $.when(ajax_request(baseUrl +'slider/get-table-data', data)).done(function (data) {
        var message = data.message;
        if (data.status == 1) {
            $("#tbl_slider").html(data.html);
            swal_success(message);
        } else {
            swal_error(message);
            //form.prepend('<div class="alert alert-danger" role="alert">'+ message+'</div >')
        }
    });
}
$('#form_add_slider').submit(function (e) {
    form = $('#form_add_slider');
    form.find('div.alert').remove();
    sURL = form.attr('action');
    data = new FormData(form[0]);
    $.when(file_ajax_request(sURL, data)).done(function (data) {
        var message = data.msg;
        if (data.status == 1) {
            swal_success(message);
            //form.prepend('<div class="alert alert-success" role="alert">' + message + '</div >')
            setTimeout(function () {
                redirect(baseUrl + 'slider');
            }, 1200);
        } else {
            swal_error(message);
            //form.prepend('<div class="alert alert-danger" role="alert">'+ message+'</div >')
        }
    });
    return false;
});