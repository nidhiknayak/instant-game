if ($('#dataTable').length > 0) {
    $("#dataTable").DataTable();
}
if ($('input[name="open_bid_time"]').length > 0){

    $('input[name="open_bid_time"]').datetimepicker({
        format: 'yyyy-mm-dd hh:ii',
        autoclose:true,
        todayBtn: true,
        minuteStep: 10
    });
    $('input[name="close_bid_time"]').datetimepicker({
        format: 'yyyy-mm-dd hh:ii',
        autoclose:true,
        todayBtn: true,
        minuteStep: 10
    });
}

$('#form_add_market').submit(function (e) {
    form = $('#form_add_market');
    sURL = form.attr('action');
    //data = new FormData(form[0]);
    data = form.serialize();
    $.when(ajax_request(sURL, data)).done(function (data) {
        var message = data.msg;
        if (data.status == 1) {
            swal_success(message);
            setTimeout(function () {
                redirect(baseUrl + 'market');
            }, 1200);
        } else {
            swal_error(message);
        }
    });
    return false;
});