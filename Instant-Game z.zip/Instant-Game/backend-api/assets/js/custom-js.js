function ajax_request(url, data = {}) {
    return $.ajax({
        type: "POST",
        /* headers: { 'X-CSRF-Token': Laravel.csrfToken }, */
        url: url,
        dataType: 'json',
        data: data
    });
}
function ajaxGetReq(url, data = {}) {
    return $.ajax({
        type: "GET",
        /* headers: { 'X-CSRF-Token': Laravel.csrfToken }, */
        url: url,
        dataType: 'json',
        data: data
    });
}

function file_ajax_request(url, data = {}) {
    return $.ajax({
        url: url,
        type: "POST",
        data: data,
        /* headers: { 'X-CSRF-Token': Laravel.csrfToken }, */
        dataType: "json",
        processData: false,
        contentType: false,
        enctype: 'multipart/form-data',
        encode: true
    });
}

function ajax_fail(jqXHR, status, exception) {
    if (jqXHR.status === 0) {
        error = 'Not connected.\nPlease verify your network connection.';
    } else if (jqXHR.status == 404) {
        error = 'The requested page not found. [404]';
    } else if (jqXHR.status == 500) {
        error = 'Internal Server Error [500].';
    } else if (exception === 'parsererror') {
        error = 'Requested JSON parse failed.';
    } else if (exception === 'timeout') {
        error = 'Time out error.';
    } else if (exception === 'abort') {
        error = 'Ajax request aborted.';
    } else {
        error = 'Uncaught Error.\n' + jqXHR.responseText;
    }
    Swal.fire('Error!', error, 'error');
}

function redirect(url = '') {
    window.location.href = url;
}
function swal_success(msg = 'Saved') {
    Toast.fire({ type: "success", title: msg  });
}

function swal_error(error = 'Error Occured') {
    Toast.fire({ type: "error", title: error });
}

function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

function swal_confirm(title = 'Are you sure to verified it?', text = 'You won\'t be able to revert this!', btn_txt = "Yes, delete it!") {
    return Swal.fire({
        title: title,
        text: text,
        type: 'warning',
        showCancelButton: true,
        confirmButtonText: btn_txt,
        confirmButtonColor: "#3085d6",
        confirmButtonClass: 'btn btn-success',
        cancelButtonText: 'No, cancel!',
        cancelButtonColor: '#d33',
        cancelButtonClass: 'btn btn-danger',
        buttonsStyling: true,
        reverseButtons: true
    });
}
$('body').on('keypress', '.isNumber', function(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode != 46 && charCode != 43 && charCode != 45) {
        return false;
    }
    return true;
});
/* Delete Alert Code 05-10-2021 Start */
$('body').on('click', '.confDelete', function (evt) {
    url = $(this).data('url');
    id = $(this).data('id');
    $("#mdl_delete").find('input#del_url').val(url);
    $("#mdl_delete").find('input#del_id').val(id);
    $("#mdl_delete").modal('show');
});
$('body').on('click', '.doDelete', function (evt) {
    divF = $(this).closest('.modal-content');
    sURL = divF.find('input#del_url').val();
    id = divF.find('input#del_id').val();
    if (typeof sURL == 'undefined' || sURL == ''){
        swal_error('URL Not Provided, Refrash The Page & Try Again');
    } else if (typeof id == 'undefined' || id == ''){
        swal_error('ID Not Provided, Refrash The Page & Try Again');
    } else {
        data = { id: id };
        $.when(ajax_request(baseUrl+sURL, data)).done(function (data) {
            var message = data.msg;
            if (data.status == 1) {
                swal_success(message);
                setTimeout(function () {
                    window.location.reload();
                }, 1200);
            } else {
                swal_error(message);
            }
        });
    }
    return false;
});
/* Delete Alert Code 05-10-2021 End */