module.exports = (body) => {
    var html = `
        <!doctype html>
        <html>
            <head>
                <meta charset="UTF-8">
                <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
                <title>Daily Report</title>
                <style>
                    body{
                        font-size: 14px !important;
                    }
                    .report-info-div {
                        margin-top: 10px !important;
                        width: 100% !important;
                    }
                    .report-info-div table{ width: 100% !important;}
                    .report-info-div tr:nth-child(odd) {background-color: #d4edda !important;}
                    .report-info-div tr:nth-child(even) {background-color: #fff !important;}
                    .report-info-div td{ text-align: left !important; padding:5px 10px !important; height:25px !important;}
                    .report-info-div th{ text-align: left !important; padding:5px 10px !important; letter-spacing: 0.5px !important;}

                    .report-data-div {
                        margin-top: 10px !important;
                        width: 100% !important;
                    }
                    .report-data-table {
                        width: 100% !important;
                        border-color: #343a40 !important;
                        border-spacing: 2px !important;
                        border-collapse: unset !important;
                        color: #000 !important;
                    }
                    .report-data-table td {
                        border: 1px solid #343a40 !important;
                        text-align:center !important;
                        width:40px !important;
                    }
                    .report-data-table > :not(caption) > * > * {
                        padding: 10px 0 !important;
                        background-color: var(--bs-table-bg) !important;
                        box-shadow: inset 0 0 0 9999px var(--bs-table-accent-bg) !important;
                    }

                    .half-full-div{
                        margin-top: 10px !important;
                        width: 100% !important;
                    }

                    .parent-half-div{
                        width: 100% !important;
                    }
                    .parent-half-div .parent-half-table{
                        width: 100% !important;
                        border-color: #343a40 !important;
                        border-spacing: 2px !important;
                        border-collapse: unset !important;
                        color: #000 !important;
                    }
                    .parent-half-div .parent-half-table td{
                        border: 1px solid #343a40 !important;
                        height:10px !important;
                    }
                    .parent-half-div .parent-half-table > :not(caption) > * > * {
                        padding: 5px 0 !important;
                    }

                    .child-half-div{
                        width: 100%;
                    }
                    .table2{ display:inline-table;width:45%; }
                    .table2:first-child{ margin-right:9.6%; }
                    .child-half-div .child-half-table{
                        width: 100% !important;
                        border-color: #343a40 !important;
                        border-spacing: 2px !important;
                        border-collapse: unset !important;
                        color: #000 !important;
                    }
                    .child-half-div .child-half-table td{
                        border: 1px solid #343a40 !important;
                    }
                    .child-half-div .child-half-table > :not(caption) > * > * {
                        padding: 10px 10px !important;
                    }

                    .parent-full-div{
                        width: 100% !important;
                    }
                    .parent-full-div .parent-full-table{
                        width: 100% !important;
                        border-color: #343a40 !important;
                        border-spacing: 2px !important;
                        border-collapse: unset !important;
                        color: #000 !important;
                    }
                    .parent-full-div .parent-full-table td{
                        border: 1px solid #343a40 !important;
                        height:10px !important;
                    }
                    .parent-full-div .parent-full-table > :not(caption) > * > * {
                        padding: 5px 0 !important;
                    }

                    .child-full-div{
                        width: 100% !important;
                    }
                    .child-full-div .child-full-table{
                        width: 100% !important;
                        border-color: #343a40 !important;
                        border-spacing: 2px !important;
                        border-collapse: unset !important;
                        color: #000 !important;
                    }
                    .child-full-div .child-full-table td{
                        border: 1px solid #343a40 !important;
                    }
                    .child-full-div .child-full-table > :not(caption) > * > * {
                        padding: 10px 10px !important;
                    }

                    .bg-dark{
                        background-color: #000000 !important;
                    }
                    .text-danger {
                        color: #f46a6a !important;
                    }
                    .text-center {
                        text-align: center !important;
                    }
                </style>
            </head>
            <body>
                <h3 style="font-weight: bold;text-align: center;color: #579540;">Daily Report</h3>
                <div class="report-info-div">
                    <div class="report-info-div">
                    <table class="table">
                        <tr>
                            <th>Date</th>
                            <th>Market Name</th>
                        </tr>
                        <tr>
                            <td>${body.searchDate}</td>
                            <td>${body.marketName}</td>
                        </tr>
                    </table>
                </div>
                    <table class="table">
                        <tr>
                            <th colspan="3">Winnig Ratio</th>
                        </tr>
                        <tr>
                            <td colspan="3">`;
                            let wrhtm = ``;
                            if (body.gameRatio && body.gameRatio.length > 0){
                                body.gameRatio.forEach(sobj => {
                                    wrhtm += `<span>${sobj.name}</span> = <span>₹${sobj.ratio_per_amount}</span> `;
                                });
                            }
                            html += wrhtm;
                        html += `</td>
                        </tr>
                    </table>
                </div>
                <div class="report-info-div">
                    <table class="table">
                        <tr>
                            <th>Total Collection</th>
                            <th>Amount To Pay</th>
                            <th>Profit/Lose</th>
                        </tr>
                        <tr>
                            <td>${body.totalCollection}</td>
                            <td>${body.amountToPay}</td>
                            <td>${body.isProfit}</td>
                        </tr>
                        <tr>
                            <th>Result</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                        <tr>
                            <td>${body.resultData}</td>
                            <td>${body.resultDataStatus}</td>
                            <td></td>
                        </tr>
                    </table>
                </div>
                <div class="report-data-div">
                    <table class="report-data-table">`;
                        html += `<tbody>${(body.jodi)?body.jodi:''}</tbody>`;
                    html += `</table>
                </div>`;
                if (body.jodiAll != '') {
                    html += `<div style="page-break-after:always;"></div>`;
                    html += `<div class="parent-full-div">
                                <table class="parent-full-table">
                                    <thead>
                                        <tr>
                                            <td colspan="10" class="bg-dark"></td>
                                        </tr>
                                        <tr class="text-center">
                                            <td colspan="10">JODI</td>
                                        </tr>
                                    </thead>
                                    <tbody>${(body.jodiAll) ? body.jodiAll : ''}</tbody>
                                </table>
                        </div>`;
                }
                if(body.isHalfFull==1){
                    html += `<div style="page-break-after:always;"></div>
                        <div class="half-full-div">
                            <div class="parent-half-div">
                                <table class="parent-half-table">
                                    <thead>
                                        <tr>
                                            <td class="bg-dark"></td>
                                        </tr>
                                        <tr class="text-center">
                                            <td>HALF SANGAM</td>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                            <div class="child-half-div">
                                <div class="table2">
                                    <table class="child-half-table">
                                        <thead>
                                            <tr>
                                                <td>Open Digit</td>
                                                <td>Close Panna</td>
                                                <td>Bid Amount</td>
                                            </tr>
                                        </thead>`;
                                        html += `<tbody>${(body.halfOpenClose)?body.halfOpenClose:''}</tbody>`;
                            html += `</table>
                                </div>
                                <div class="table2">
                                    <table class="child-half-table">
                                        <thead>
                                            <tr>
                                                <td>Close Digit</td>
                                                <td>Open Panna</td>
                                                <td>Bid Amount</td>
                                            </tr>
                                        </thead>`;
                                        html += `<tbody>${(body.halfCloseOpen)?body.halfCloseOpen:''}</tbody>`;
                            html += `</table>
                                </div>
                            </div>
                            <div class="parent-full-div">
                                <table class="parent-full-table">
                                    <thead>
                                        <tr>
                                            <td class="bg-dark"></td>
                                        </tr>
                                        <tr class="text-center">
                                            <td>FULL SANGAM</td>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                            <div class="child-full-div">
                                <table class="child-full-table">
                                    <thead>
                                        <tr>
                                            <td>Open Panna</td>
                                            <td>Close Panna</td>
                                            <td>Bid Amount</td>
                                        </tr>
                                    </thead>`;
                                    html += `<tbody>${(body.halfSangam)?body.halfSangam:''}</tbody>`;
                     html += `</table>
                            </div>
                        </div>`;
                }
            html += `</body>
        </html>`;
    return html;
};