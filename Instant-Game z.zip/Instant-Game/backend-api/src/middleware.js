const db = require("./models");
const UserDeviceToken = db.user_device_token;
const User = db.user;

const isvalid = async function checkAuthToken(req, res, next) {
  if(typeof req.headers.authorization !== 'undefined'){
    var auth = req.headers.authorization;
    var parttwo = auth.split(' ');
    if(typeof parttwo[1] !== 'undefined'){
      var token = parttwo[1];
      let condition = { auth_token:token };
      UserDeviceToken.findOne({ where: condition, include: [{
        model: User,
        as :'user',attributes:['id','firstname','lastname'] }]})
        .then(data => {
            if(data === null){
                res.send({status:0,msg:'Invalid Token'});
            } else {
                req.userDet = data.get().user;
                req.authToken = token;
                next();
            }
        })
        .catch(err => {
            res.status(500).send({
                message:
                err.message || "Some error occurred while retrieving."
            });
        });
      
    } else {
      res.send({status:0,msg:'Unauthenticated',data:{}});
    }
  } else {
    res.send({status:0,msg:'Unauthenticated',data:{}});
  }
}
module.exports = isvalid;