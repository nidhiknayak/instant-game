const mongoose = require('mongoose')

mongoose.Promise = global.Promise
const DB_URL = process.env.DB_URL || 'mongodb://localhost:27017/ideal_gamez';

mongoose.connect(DB_URL, { useNewUrlParser: true, useUnifiedTopology: true }).then(
    ()=> {console.log("Database Connected..")},
    err => {console.log("err",err)}
)

mongoose.exports = {mongoose}