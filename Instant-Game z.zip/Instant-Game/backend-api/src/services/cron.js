const { checkTransferStatus, verifyBankAccount, checkPaymentStatus } = require('./Withdraw');
const Withdrawals = require('../models/Withdraw');
const { UserBanks } = require('../models/UserBanks');
const Users = require('../models/Users');
const Transactions = require('../models/Transactions');
const { convertToUTCNew, getDateFormat } = require('./common');
const PaymentGateway = require('../models/PaymentGateway');
const LetspayCreateURLLogs = require('../models/LetspayCreateURLLogs');
const AmezWorldCreateURLLogs = require('../models/AmezWorldCreateURLLogs');
const GeckiopayCreateURLLogs = require('../models/GeckiopayCreateURLLogs');
const GenniePayCreateURLLogs = require('../models/GenniePayCreateURLLogs');
const { addBonusReferalAmount } = require('../controllers/UserProfileController');
const MagicPayCreateURLLogs = require('../models/MagicPayCreateURLLogs');

const CTS = async () => {
	const today = new Date();
	today.setMinutes(today.getMinutes() - 15);
	const dateOne = today;
	const dateTwo = new Date();
	/* console.log("dateOne", dateOne);
	console.log("dateTwo", dateTwo); */
	const where = { 'status': 4, createdAt: { $gte: dateOne, $lte: dateTwo } };
	const allWithdrawls = await Withdrawals.find(where);
  if(allWithdrawls && allWithdrawls.length > 0){
		await Promise.all(allWithdrawls.map(async (row) => {
			let resp = await checkTransferStatus(row._id);
			console.log('12 withdraw response '+new Date(), resp);
		}));
	}
};
const bankVerification = async () => {
  let bankLists = await UserBanks.find({'is_verified':0});
  await Promise.all(bankLists.map(async (row) => {
    let resp = await verifyBankAccount(row.user_id);
    if (resp.status == 1){
      let update2 = { is_verified:1, verified_at:new Date() };
      await UserBanks.updateOne({ _id:row._id},update2);
		/* let user_id = row.user_id;
		let userDet = await Users.findOne({ _id: user_id});
		if (userDet){
			var post_balance = ((userDet.wallet != null) ? userDet.wallet : 0) - 1;
			var updWinningWallet = await Users.updateOne({ _id: user_id }, { wallet: post_balance });
			if (updWinningWallet.modifiedCount > 0) {
				await new Transactions({
					user_id: user_id,
					refe_id: row._id,
					amount: 1,
					charge_amount: 0,
					final_amount: 1,
					post_balance: post_balance,
					tnx_type: 10,//bank valid Deduct
					wallet_type: 2,//wallet 1,//winning wallet
					details: "Bank Verified Deduct",
					entry_type: 2
				}).save(function (err, transaction) {
					return true;
				});
			}
		} */
    }
  }));
};

/* 29-11-2021 */
const checkTransStatus = async () => {
	try {
		let today = new Date();
		let startDt = new Date();
		// today.setMinutes(today.getMinutes() - 60);
		// today.setHours(today.getHours() - 2);

		// today.setMinutes(today.getMinutes() - 30);
		const checkEveryHowManyMinutes = process.env.TRANS_CRON_CHECK_LAST_MIN || 5;
		today.setMinutes(today.getMinutes() - checkEveryHowManyMinutes);
		let endDt = convertToUTCNew(startDt);
		startDt = convertToUTCNew(today);
		//, { createdAt: { $gte: startDt, $lte: endDt } }
		let all_trans = await Transactions.find({ tnx_type: 5, entry_type: 1, wallet_type: 2, check_inno_status: 0, createdAt: { $gte: startDt, $lte: endDt } });
		
		if(all_trans && all_trans.length > 0){
			/* const activeLetsPay = await PaymentGateway.findOne({ code: "ANILEX" });
			const activeSwitchPay = await PaymentGateway.findOne({ code: "SWITCHPAY" });
			const activeAmezWorld = await PaymentGateway.findOne({ code: "AMEZ_WORLD" });
			const activeGeckiopay = await PaymentGateway.findOne({ code: "GECKIOPAY" });
			const activeGenniePay = await PaymentGateway.findOne({ code: "GENNIEPAY" }); */
			let activeLetsPay = null; let activeSwitchPay = null; let activeAmezWorld = null;
			let activeGeckiopay = null; let activeGenniePay = null; let activeMagicPay = null;
			const allGateways = await PaymentGateway.find({});
			for (const gateway of allGateways) {
				if(gateway.code == "ANILEX"){
					activeLetsPay = gateway;
				} else if(gateway.code == "SWITCHPAY"){
					activeSwitchPay = gateway;
				} else if(gateway.code == "AMEZ_WORLD"){
					activeAmezWorld = gateway;
				} else if(gateway.code == "GECKIOPAY"){
					activeGeckiopay = gateway;
				} else if(gateway.code == "GENNIEPAY"){
					activeGenniePay = gateway;
				} else if(gateway.code == "MAGICPAY"){
					activeMagicPay = gateway;
				}
			}
			
			for (const row of all_trans) {
				const tnxStr = row.tnx.toString();
				const firstThree = tnxStr.substring(0,3);
				if(firstThree == "TNX"){
					const resp = await checkPaymentStatus(row.tnx, activeLetsPay);
					await anilexPayCheckTrans(resp, row);
				} else if(firstThree == "swp" && row.order_id){
					const resp = await checkPaymentStatus(row.order_id, activeSwitchPay);
					await switchPayCheckTrans(resp, row);
				} else if(firstThree == "AWD" && row.tnx){
					const resp = await checkPaymentStatus(row.tnx, activeAmezWorld);
					await anilexPayCheckTrans(resp, row);
				} else if(firstThree == "GNP" && row.tnx) {
					const resp = await checkPaymentStatus(row.tnx, activeGenniePay);
					await anilexPayCheckTrans(resp, row);
				} else if(firstThree == "MGC" && row.tnx) {
					const resp = await checkPaymentStatus(row.tnx, activeMagicPay);
					await anilexPayCheckTrans(resp, row);
				} else {
					const resp = await checkPaymentStatus(row.tnx, activeGeckiopay);
					await anilexPayCheckTrans(resp, row);
				}
			}
		}
	} catch (error) {
		console.log("Catch checkTransStatus 120 => ", error);
	}
};
const switchPayCheckTrans = async (resp, row) => {
	if(resp.status == 1){ //captured
		const amount = row.amount;
		const result = await Users.findOneAndUpdate({ _id: row.user_id }, { $inc: { wallet: parseFloat(amount) } } , { new: true });
		const updArr = { check_inno_status: 1, pay_status: 1, post_balance: result.wallet };
		//give bonus to referral user this is first transaction
		await Transactions.updateOne({ _id: row._id }, updArr);
		await addReferalAmount(result, amount, row);
	} else if(resp.status == 3){ //failed
		const updArr = { check_inno_status: 2, pay_status: 2 };
		await Transactions.updateOne({ _id: row._id }, updArr);
	}
};

const addReferalAmount = async (userDet, amount, row) => {
	const totTrans = await Transactions.find({ user_id: row.user_id, tnx_type: { $in: [4,5]}, entry_type: 1, wallet_type: 2, _id: { $ne: row._id } });
	await addBonusReferalAmount(1, amount, userDet, row._id, totTrans);
}

/* 15-04-24 This function is also used for amezworld payment gateway */
const anilexPayCheckTrans = async (resp, row) => {
	if(resp.status == 1){ //SUCCESS
		let updArr = { check_inno_status: 1, pay_status: 1, order_id: resp?.data?.utr || row?.order_id };
		const amount = row.amount;
		const result = await Users.findOneAndUpdate({_id: row.user_id}, { $inc: { wallet: parseFloat(amount) } }, { new: true });
		if(result){
			//give bonus to referral user this is first transaction
			updArr.post_balance = result.wallet;
			await Transactions.updateOne({ _id: row._id }, updArr);
			await addReferalAmount(result, amount, row);
		}
	} else if(resp.status == 3){ //FAILED
		await Transactions.updateOne({ _id: row._id }, { check_inno_status: 2, pay_status: 2, order_id: resp?.data?.utr || row?.order_id });
	}
};
/* 29-11-2021 */
const checkLetsPayTransInternal = async () => {
	try {
		const today = new Date();
		let startDt = new Date();
		// today.setMinutes(today.getMinutes() - 7);
		today.setMinutes(today.getMinutes() - 1);
		let endDt = convertToUTCNew(startDt);
		startDt = convertToUTCNew(today);
		const all_trans = await Transactions.find({ tnx_type: 5, entry_type: 1, wallet_type: 2, pay_status: 0, check_inno_status: 0, createdAt: { $gte: startDt, $lte: endDt } });
		
		if(all_trans && all_trans.length > 0){
			for (const row of all_trans) {
				const tnxStr = row.tnx.toString();
				const firstThree = tnxStr.substring(0,3);
				if(firstThree == "TNX"){/* Letspay  */
					const urlData = await LetspayCreateURLLogs.findOne({ transaction_id: row.tnx, user_id: row.user_id, createdAt: { $gte: startDt, $lte: endDt }});
					if(urlData && urlData.status != "PENDING"){
						const resp = {
							status: urlData.status == "SUCCESS" ? 1 : 3,
							data: { utr: urlData.upi_txn_id }
						};
						await anilexPayCheckTrans(resp, row);
					}
				} else if(firstThree == "AWD"){/* AmezWorld  */
					const urlData = await AmezWorldCreateURLLogs.findOne({ transaction_id: row.tnx, user_id: row.user_id, createdAt: { $gte: startDt, $lte: endDt }});
					if(urlData && urlData.status != "PENDING"){
						const resp = {
							status: urlData.status == "SUCCESS" ? 1 : 3,
							data: { utr: urlData.upi_txn_id }
						};
						await anilexPayCheckTrans(resp, row);
					}
				} else if(firstThree == "GNP"){/* Gennie Pay */
					const urlData = await GenniePayCreateURLLogs.findOne({ transaction_id: row.tnx, user_id: row.user_id, createdAt: { $gte: startDt, $lte: endDt }});
					if(urlData && urlData.status != "PENDING"){
						const resp = {
							status: urlData.status == "SUCCESS" ? 1 : 3,
							data: { utr: urlData.upi_txn_id }
						};
						await anilexPayCheckTrans(resp, row);
					}
				} else if(firstThree == "MGC"){/* Magic Pay 12-08-24 */
					const urlData = await MagicPayCreateURLLogs.findOne({ transaction_id: row.tnx, user_id: row.user_id, createdAt: { $gte: startDt, $lte: endDt }});
					if(urlData && urlData.status != "PENDING"){
						const resp = {
							status: urlData.status == "SUCCESS" ? 1 : 3,
							data: { utr: urlData.upi_txn_id }
						};
						await anilexPayCheckTrans(resp, row);
					}
				} else if(firstThree == "swp"){
					/* const resp = await checkPaymentStatus(row.tnx, activeSwitchPay);
					await switchPayCheckTrans(resp, row); */
				} else {/* Geckiopay 21-05-2024 */
					const urlData = await GeckiopayCreateURLLogs.findOne({ transaction_id: row.tnx, user_id: row.user_id, createdAt: { $gte: startDt, $lte: endDt }});
					if(urlData && urlData.status != "PENDING"){
						const resp = {
							status: urlData.status == "SUCCESS" ? 1 : 3,
							data: { utr: urlData.upi_txn_id }
						};
						await anilexPayCheckTrans(resp, row);
					}
				}
			}
		}
	} catch (error) {
		console.log(95, error);
	}
};
// 24-01-2022
const removeBankInfo = async () => {
	let today = new Date();
	today.setDate(today.getDate() - 1);
	let yesdate = convertToUTCNew(today);
	
	let wh = { is_verified: 0, createdAt:{ $lte: yesdate } };
	let bankLists = await UserBanks.find(wh);
	//return { wh:wh, bankLists,bankLists};
	await Promise.all(bankLists.map(async (row) => {
		await UserBanks.deleteMany({ user_id: row.user_id });
	}));
};
/* 10-06-24 */
const updateTransStatusToFailedAfterFiveMin = async () => {
	try {
		const startTime = new Date();
		const endTime = new Date();
		const checkEveryHowManyMinutes = process.env.TRANS_CRON_CHECK_LAST_MIN || 5;
		startTime.setMinutes(startTime.getMinutes() - checkEveryHowManyMinutes);
		startTime.setSeconds(0);
		const startTimeW = convertToUTCNew(startTime);

		endTime.setMinutes(endTime.getMinutes() - checkEveryHowManyMinutes);
		endTime.setSeconds(59);
		const endTimeW = convertToUTCNew(endTime);
		
		const failedTrans = await Transactions.find({ tnx_type: 5, entry_type: 1, wallet_type: 2, check_inno_status: 0, createdAt: { $gte: startTimeW, $lte: endTimeW } }, '_id');
		if(failedTrans && failedTrans.length > 0){
			for (const row of failedTrans) {
				await Transactions.updateOne({ _id: row._id }, { pay_status: 2, check_inno_status: 2 });
			}
		}
	} catch (error) {
		console.log(194, error);
	}
};

module.exports = {
	CTS, bankVerification, checkTransStatus, removeBankInfo, checkLetsPayTransInternal, updateTransStatusToFailedAfterFiveMin
};