var mongoose = require('mongoose');
const Withdrawals = require('../models/Withdraw');
const Users = require('../models/Users');
const PaymentGateway = require('../models/PaymentGateway');
var { UserBanks } = require('../models/UserBanks');
const { getInnoKey } = require('./common');
const SwitchPay = require('./SwitchPay');
const GenniePay = require('./GenniePay');
const Anilex = require('./Anilex');
const AmezWorld = require('./AmezWorld');
const Geckiopay = require('./Geckiopay');
const MagicPay = require('./MagicPay');
const Crypto = require("crypto");
const Axios = require('axios');
const { SWITCH_ENDPOINT, SWITCH_USER_UUID, SWITCH_TOKEN } = require('./constant');

/* Switch Pay Start */
const getSwitchPayHeaders = () => {
    return {
      headers: {
        Accept: "application/json",
        "content-Type": "application/json",
        "authorization": SWITCH_TOKEN
      },
    };
  };
async function doTransfer(amount, user_id, with_id) {
    try {
        // return { status: 1, message: 'Fund Transfer Successfully', data: {} };
        //amount = 10;
        amount = parseFloat(amount).toFixed(2);
        const userBank = await UserBanks.findOne({ user_id: user_id });
        if (userBank) {
            if (userBank.is_verified == 1) {
                const activeGateway = await PaymentGateway.findOne({ withdraw: true });
                if(!activeGateway){
                    return { status: 0, message: "No payment gateway found", data: {} };
                }
                if(activeGateway.code == "SWITCHPAY"){
                    return await SwitchPay.doTransfer(userBank, amount, user_id, with_id);
                } else if(activeGateway.code == "GENNIEPAY"){
                    return await GenniePay.doTransfer(userBank, amount, user_id, with_id);
                } else if(activeGateway.code == "ANILEX"){
                    return await Anilex.doTransfer(userBank, amount, user_id, with_id);
                } else if(activeGateway.code == "AMEZ_WORLD"){
                    return await AmezWorld.doTransfer(userBank, amount, user_id, with_id);
                } else if(activeGateway.code == "GECKIOPAY"){
                    return await Geckiopay.doTransfer(userBank, amount, user_id, with_id);
                }
            } else {
                return { status: 0, message: 'User Bank Is Not Verified, Not Allowed To Transfer', data: {} };
            }
        } else {
            return { status: 0, message: 'User Bank Not Found, Not Allowed To Transfer', data: {} };
        }
        //return { status: 1, message: 'Fund Transfer Successfully ', data: {} };
    } catch (error) {
        return { status: 0, message: error.message, data: {} };
    }
}
async function verifyBankAccount(user_id) {
    try {
        return { status: 1, message: 'Bank Verified Success', data: {} };
        const userBank = await UserBanks.findOne({ user_id: user_id });
        if (userBank) {
            if (userBank.is_verified == 0) {
                let account_number = userBank.acc_no;//'01234567980';
                let ifsc_code = userBank.ifsc_code;//'SBIN0060471';
                let body = { user_uuid: SWITCH_USER_UUID, account_no: account_number, bank_ifsc: ifsc_code };
                body.url = SWITCH_ENDPOINT;
                body.token = SWITCH_TOKEN;
                
                return await Axios.post(`${SWITCH_ENDPOINT}/api/verifyBankDetails`, body, getSwitchPayHeaders()).
                    then(res => {
                        let resp = res.data;
                        console.log("verify bank resp", resp);
                        if(resp.status == "SUCCESS"){
                            console.log(115,'bank varification response',resp);
                            if(resp.accountStatus == "VALID"){
                                return { status: 1, message: 'Bank Verified Success', data: resp };
                            }
                            return { status: 0, message: 'Invalid Bank Detail', data: resp };
                        } else {
                            return { status: 0, message: resp?.message, data: resp };
                        }
                        
                    }).catch(error => {
                        console.log("verify bank error", error);
                        return { status: 0, message: error.message, data: error };
                    })
            } else {
                return { status: 0, message: 'User Bank Is Already Verified', data: {} };
            }
        } else {
            return { status: 0, message: 'User Bank Not Found', data: {} };
        }
    } catch (error) {
        console.log("exception", error?.message, error);
        return { status: 0, message: error.message,data:error };
    }
}
async function checkTransferStatus(with_id) {
    try {
        // return { status: 1, message: 'Fund Transfer Successfully', data: {} };
        let withData = await Withdrawals.findOne({ _id: with_id });
        if (!withData){
            return { status: 0, message: 'Withdrawal Not Found', data: {} };
        }
        /* let remarks = withData.merchant_ref_no;
        if (!remarks){
            return { status: 0, message: 'Mer Ref No. Not Found', data: {} };
        } */
        /* let order_id = withData.transaction_id;
        if (!order_id && !withData.merchant_ref_no){
            return { status: 0, message: 'Transaction No. Not Found', data: {} };
        } */

        const activeGateway = await PaymentGateway.findOne({ withdraw: true });
        if(!activeGateway){
            return { status: 0, message: "No payment gateway found", data: {} };
        }
        if(activeGateway.code == "SWITCHPAY"){
            return await SwitchPay.checkTransferStatus(withData);
        } else if(activeGateway.code == "GENNIEPAY"){
            return await GenniePay.checkTransferStatus(withData);
        } else if(activeGateway.code == "ANILEX"){
            return await Anilex.checkTransferStatus(withData);
        } else if(activeGateway.code == "AMEZ_WORLD"){
            return await AmezWorld.checkTransferStatus(withData);
        } else if(activeGateway.code == "GECKIOPAY"){
            return await Geckiopay.checkTransferStatus(withData);
        }
        
    } catch (error) {
        return { status: 0, message: error?.message, data: {} }
    }
}
/* Switch Pay End */

async function doTransferInnoPay(amount,user_id,with_id) {
    try {
        //let amount = 2;
        let merchant_reference_number = generateMerRefCode();//'Mr. ABC XYZ PQR';
        //return res.json({ status: 0, message: 'merchant_reference_number', data: merchant_reference_number });
        amount = parseFloat(amount).toFixed(2);
        let transfer_type = 'IMPS';/* IMPS OR NEFT(over 2 lakh) */
        //user_id = req.body.user_id;
        const userBank = await UserBanks.findOne({ user_id: user_id });
        //let withData = await Withdrawals.findOne({ _id: with_id });
        if (userBank) {
            if (userBank.is_verified == 1) {
                let account_name = userBank.user_name.trim();//'Mr. ABC XYZ PQR';
                let account_number = userBank.acc_no;//'01234567980';
                let ifsc_code = userBank.ifsc_code;//'SBIN0060471';
                let bank_name = userBank.bank_name;//'State Bank Of India';
                let bank_branch = userBank.branch;//'Rani Tower Branch';
                let upi_id = '';/* 123456@ybl */

                let api_key = getInnoKey().API_KEY;
                let salt = getInnoKey().SALT;

                let body = { api_key: api_key, merchant_reference_number: merchant_reference_number, amount: amount, account_name: account_name, account_number: account_number, ifsc_code: ifsc_code, bank_name: bank_name, bank_branch: bank_branch, transfer_type: transfer_type };
                // , upi_id: upi_id
                let secure_hash = null;
                let hash_string = salt + '|' + account_name + '|' + account_number + '|' + amount + '|' + api_key + '|' + bank_branch + '|' + bank_name + '|' + ifsc_code + '|' + merchant_reference_number + '|' + transfer_type;
                //return res.json({ status: 1, message: 'Get Bank Successfully', data: body });

                if (hash_string.length > 0) {
                    secure_hash = Crypto.createHash('sha512').update(hash_string).digest('hex').toUpperCase();
                }
                body.hash = secure_hash;
                return await Axios.post('https://api.innopaytech.com/v3/fundtransfer', body).
                    then((resu) => resu.data).
                    then(async resu => {
                        console.log(resu);
                        if (typeof resu.error !== 'undefined' && resu.error.code > 0) {
                            return { status: 0, message: resu.error.message, data: resu };
                        } else if (typeof resu.data !== 'undefined') {
                            if (resu.data.status == "SUCCESS") {
                                let merRefNo = resu.data.merchant_reference_number;
                                let transaction_id = resu.data.transaction_id;
                                let params = { merRefNo: merRefNo, transaction_id: transaction_id };
                                let update2 = { merchant_ref_no: merRefNo, transaction_id: transaction_id,status:1 };
                                await Withdrawals.updateOne({ _id: with_id },update2);
                                return { status: 1, message: 'Fund Transfer Successfully', data: { result: resu, params: params } };
                            } else if (resu.data.status == "PROCESSING") {
                                /* merrefeno :: DYU47ZHRDJZVB4T, trxid :: IMPS728720211111174933460613 */
                                let merRefNo = resu.data.merchant_reference_number;
                                let transaction_id = resu.data.transaction_id;
                                let params = { merRefNo: merRefNo, transaction_id: transaction_id };
                                let update2 = { merchant_ref_no: merRefNo, transaction_id: transaction_id, status: 4 };
                                await Withdrawals.updateOne({ _id: with_id }, update2);
                                return { status: 1, message: 'Fund Transfer Processing', data: { result: resu, params: params } };
                            }
                        } else {
                            return { status: 0, message: "Something Went Wrong, Try Again", data: {} };
                        }
                    }).catch(error => {
                        console.log(62,error);
                        return { status: 0, message: error.message, data: {} };
                    })
            } else {
                return { status: 0, message: 'User Bank Is Not Verified, Not Allowed To Transfer', data: {} };
            }
        } else {
            return { status: 0, message: 'User Bank Not Found, Not Allowed To Transfer', data: {} };
        }
        //return { status: 1, message: 'Fund Transfer Successfully ', data: {} };
    } catch (error) {
        console.log(73, error);
        return { status: 0, message: error.message, data: {} };
    }
}
async function verifyBankAccountInnoPay(user_id) {
    try {
        const userBank = await UserBanks.findOne({ user_id: user_id });
        if (userBank) {
            if (userBank.is_verified == 0) {
                let account_name = userBank.user_name.trim();//'Mr. ABC XYZ PQR';
                let account_number = userBank.acc_no;//'01234567980';
                let ifsc_code = userBank.ifsc_code;//'SBIN0060471';
                //return { status: 1, message: 'Bank Verified Success', data: {} };
                /* let account_name = 'Mr. ABC XYZ PQR';
                let account_number = '01234567980';
                let ifsc_code = 'SBIN0060471'; */

                let api_key = getInnoKey().API_KEY;
                let salt = getInnoKey().SALT;
                
                let secure_hash = null;
                let hash_string = salt + '|' + account_name + '|' + account_number + '|' + api_key + '|' + ifsc_code;
                if (hash_string.length > 0) {
                    secure_hash = Crypto.createHash('sha512').update(hash_string).digest('hex').toUpperCase();
                }
                let body = { api_key: api_key, account_name: account_name, account_number: account_number, ifsc_code: ifsc_code, hash: secure_hash };
                /* body = {
                    "api_key": "1c62f141-4be4-4671-9552-9b6f8e58ddfc",
                    "account_name": "Mr. ABC XYZ PQR",
                    "account_number": "01234567980",
                    "ifsc_code": "SBIN06154",
                    "hash": "B5464ECF2C5E9E22D2C04B86B5D211139A8E4702D46CEB9AEAF3CA67985C95B31C2607A21FBB5ABF90EEE2774E00A4CA76BCC230302B330D34EF653D395E1217"
                }; */
                return await Axios.post('https://api.innopaytech.com/v2/fundtransfer/validateaccount', body).
                    then(res => {
                        let resp = res.data;
                        console.log(115,'bank varification response',resp);
                        if (typeof resp.error !== 'undefined' && resp.error.code > 0) {
                            return { status: 0, message: resp.error.message, data: { resp:resp, body:body } };
                        } else if (typeof resp.data !== 'undefined') {
                            console.log(119,'bank varification data',resp.data);
                            return { status: 1, message: 'Bank Verified Success', data: resp };
                        }
                    }).catch(error => {
                        return { status: 0, message: error.message, data: error };
                    })
            } else {
                return { status: 0, message: 'User Bank Is Already Verified', data: {} };
            }
        } else {
            return { status: 0, message: 'User Bank Not Found', data: {} };
        }
    } catch (error) {
        return { status: 0, message: error.message,data:error };
    }
}
async function checkTransferStatusInnoPay(with_id) {
    try {
        let withData = await Withdrawals.findOne({ _id: with_id });
        if (!withData){
            return { status: 0, message: 'Withdrawal Not Found', data: {} };
        }
        let merchant_reference_number = withData.merchant_ref_no;
        if (!merchant_reference_number){
            return { status: 0, message: 'Mer Ref No. Not Found', data: {} };
        }
        let api_key = getInnoKey().API_KEY;
        let salt = getInnoKey().SALT;

        let body = { api_key: api_key, merchant_reference_number: merchant_reference_number };
        let secure_hash = null;
        let hash_string = salt + '|' + api_key + '|' + merchant_reference_number;

        if (hash_string.length > 0) {
            secure_hash = Crypto.createHash('sha512').update(hash_string).digest('hex').toUpperCase();
        }
        body.hash = secure_hash;
        return await Axios.post('https://api.innopaytech.com/v3/fundtransferstatus', body).
            then((resu) => resu.data).
            then(async resu => {
                //return resu;
                console.log(resu);
                if (typeof resu.error !== 'undefined' && resu.error.code > 0) {
                    return { status: 0, message: resu.error.message, data: resu.error };
                } else if (typeof resu.data !== 'undefined') {
                    //return resu.data;
                    let merRefNo = resu.data.merchant_reference_number;
                    let transaction_id = resu.data.transaction_id;
                    let params = { merRefNo: merRefNo, transaction_id: transaction_id };
                    if (resu.data.status == "SUCCESS") {
                        let update2 = { status: 1 };
                        await Withdrawals.updateOne({ _id: with_id }, update2);
                        return { status: 1, message: 'Fund Transfer Successfully', data: { result: resu, params: params } };
                    } else if (resu.data.status == "PROCESSING") {
                        /* merrefeno :: DYU47ZHRDJZVB4T, trxid :: IMPS728720211111174933460613 */
                        return { status: 1, message: 'Fund Transfer Processing', data: { result: resu, params: params } };
                        //return res.json({ status: 2, message: 'Fund Transfer Processing', data: { result: resu, params: params } });
                    }
                } else {
                    return { status: 0, message: 'Something Went Wrong', data: resu };
                }
            }).catch(error => {
                return { status: 0, message: error.message, data: {} };
            });
    } catch (error) {
        return { status: 0, message: error, data: {} }
    }
}
async function getBalance() {
    try {
        
        let api_key = getInnoKey().API_KEY;
        let salt = getInnoKey().SALT;
        let body = { api_key: api_key };
        let secure_hash = null;
        let hash_string = salt + '|' + api_key;
        if (hash_string.length > 0) {
            secure_hash = Crypto.createHash('sha512').update(hash_string).digest('hex').toUpperCase();
        }
        body.hash = secure_hash;
        return await Axios.post('https://api.innopaytech.com/v3/fundtransfer/getbalance', body).
            then((resu) => resu.data).
            then(async resu => {
                return { status: 1, message: "Get Balance Successfully", data: resu };
            }).catch(error => {
                return { status: 0, message: error.message, data: error };
            });
    } catch (error) {
        return { status: 0, message: error, data: {} }
    }
}
async function checkPaymentStatus(transaction_id = '', gatewayDet = null) {
    try {
        let activeGateway = gatewayDet;
        if(!gatewayDet){
            activeGateway = await PaymentGateway.findOne({ status: true });
        }
        
        if(!activeGateway){
            return { status: 0, message: "No payment gateway found", data: {} };
        }
        if(activeGateway.code == "SWITCHPAY"){
            return await SwitchPay.checkPaymentStatus(transaction_id);
            // return { status: 1, message: "Get Payment Status Successfully", data: transaction_id };
        } else if(activeGateway.code == "GENNIEPAY"){
            // return { status: 1, message: "Get Payment Status Successfully", data: transaction_id };
            return await GenniePay.checkPaymentStatus(transaction_id);
        } else if(activeGateway.code == "ANILEX"){
            return await Anilex.checkPaymentStatus(transaction_id);
        } else if(activeGateway.code == "AMEZ_WORLD"){
            return await AmezWorld.checkPaymentStatus(transaction_id);
        } else if(activeGateway.code == "GECKIOPAY"){
            return await Geckiopay.checkPaymentStatus(transaction_id);
        } else if(activeGateway.code == "MAGICPAY"){
            return await MagicPay.checkPaymentStatus(transaction_id);
        }
        return { status: 1, message: "Get Payment Status Successfully", data: transaction_id };
    } catch (error) {
        return { status: 0, message: error.message, data: error }
    }
}
async function createHashMobilePayment(inputs) {
    try {
        let api_key = getInnoKey().API_KEY;
        let salt = getInnoKey().SALT;

        const order_id = inputs.order_id;
        const amount = inputs.amount;
        const currency = inputs.currency;
        const description = inputs.description;
        const name = inputs.name;
        const email = inputs.email;
        const phone = inputs.phone;
        const city = inputs.city;
        const state = inputs.state;
        const zip_code = inputs.zip_code;
        const country = inputs.country;
        const return_url = inputs.return_url ? inputs.return_url : "http://api.win14bet.com:3001/api/user/innopay-callback";
        // let hash_string = salt + '|' + account_name + '|' + account_number + '|' + amount + '|' + api_key + '|' + bank_branch + '|' + bank_name + '|' + ifsc_code + '|' + merchant_reference_number + '|' + transfer_type;
        /* prev used */
        // const hash_string = salt + '|' + amount + '|' + api_key + '|'+ city + '|' + currency + '|' +country+ '|' + description + '|' + email + '|' + name+ '|' + order_id + '|' + phone + '|' + return_url + '|' + state + '|' + zip_code;

        const hash_string = salt + '|' + amount + '|' + api_key + '|'+ city + '|' +country + '|' + currency+ '|' + description + '|' + email + '|' + name+ '|' + order_id + '|' + phone + '|' + return_url + '|' + state + '|' + zip_code;
        //return res.json({ status: 1, message: 'Get Bank Successfully', data: body });

        secure_hash = Crypto.createHash('sha512').update(hash_string).digest('hex').toUpperCase();
        return secure_hash;//{secure_hash, hash_string};
    } catch (error) {
        console.log("Hash error", error);
        return ""
    }
}
function generateMerRefCode(length = 15) {
    var text = "";
    possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (var i = 0; i < length; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text.toUpperCase();
}
module.exports = {
    doTransfer, verifyBankAccount, checkTransferStatus, getBalance, checkPaymentStatus, createHashMobilePayment
};