const Withdrawals = require("../models/Withdraw");
var { UserBanks } = require("../models/UserBanks");
const { generateMerRefCode, getDateFormat, getTimeFormatAmPm } = require("./common");
const Axios = require("axios");
const { SWITCH_ENDPOINT, SWITCH_USER_UUID, SWITCH_TOKEN, } = require("./constant");
const { webhookLog } = require('./JsonOpr');
/* Switch Pay Start */
const getSwitchPayHeaders = () => {
  return {
    headers: {
      Accept: "application/json",
      "content-Type": "application/json",
      authorization: SWITCH_TOKEN,
    },
  };
};
async function doTransfer(userBank, amount, user_id, with_id) {
  try {
    // return { status: 1, message: 'Fund Transfer Successfully', data: {} };
    //amount = 10;
    let merchant_reference_number = generateMerRefCode(); //'Mr. ABC XYZ PQR';
    amount = parseFloat(amount).toFixed(2);
    
    const account_name = userBank.user_name.trim(); //'Mr. ABC XYZ PQR';
    const account_number = userBank.acc_no; //'01234567980';
    const ifsc_code = userBank.ifsc_code; //'SBIN0060471';

    const body = {
      user_uuid: SWITCH_USER_UUID,
      payee_name: account_name,
      payee_account_no: account_number,
      payee_ifsc: ifsc_code,
      transfer_amount: amount,
      account_name: account_name,
      remarks: merchant_reference_number,
    };
    // return { status: 0, message: "Function called", data: body };
    return await Axios.post(`${SWITCH_ENDPOINT}/api/initiatePayout`, body, getSwitchPayHeaders())
      .then((resu) => resu.data)
      .then(async (resu) => {
        console.log("resu", resu);
        if (typeof resu?.Error !== "undefined") {
          return { status: 0, message: resu?.Error, data: resu };
        } else if (resu?.status == "ERROR") {
          return { status: 0, message: resu?.message, data: resu };
        } else if (resu?.status == "SUCCESS") {
          const transaction_id = resu?.order_id;
          const merRefNo = transaction_id;
          const params = {
            merRefNo: merRefNo,
            transaction_id: transaction_id,
          };
          const update2 = {
            merchant_ref_no: merRefNo,
            transaction_id: transaction_id,
            status: 1,
          };
          await Withdrawals.updateOne({ _id: with_id }, update2);
          return {
            status: 1,
            message: "Fund Transfer Successfully",
            data: { result: resu, params: params },
          };
        } else if (resu?.status == "IN-PROCESS") {
          let transaction_id = resu?.order_id;
          const merRefNo = transaction_id;
          let params = {
            merRefNo: merRefNo,
            transaction_id: transaction_id,
          };
          let update2 = {
            merchant_ref_no: merRefNo,
            transaction_id: transaction_id,
            status: 4,
          };
          await Withdrawals.updateOne({ _id: with_id }, update2);
          return {
            status: 1,
            message: "Fund Transfer Processing",
            data: { result: resu, params: params },
          };
        } else {
          return {
            status: 0,
            message: "Something Went Wrong, Try Again",
            data: {},
          };
        }
      })
      .catch((error) => {
        console.log(62, error);
        return { status: 0, message: error.message, data: {} };
      });
    //return { status: 1, message: 'Fund Transfer Successfully ', data: {} };
  } catch (error) {
    console.log(73, error);
    return { status: 0, message: error.message, data: {} };
  }
}
async function verifyBankAccount(user_id) {
  try {
    return { status: 1, message: "Bank Verified Success", data: {} };
    const userBank = await UserBanks.findOne({ user_id: user_id });
    if (userBank) {
      if (userBank.is_verified == 0) {
        let account_number = userBank.acc_no; //'01234567980';
        let ifsc_code = userBank.ifsc_code; //'SBIN0060471';
        let body = {
          user_uuid: SWITCH_USER_UUID,
          account_no: account_number,
          bank_ifsc: ifsc_code,
        };
        body.url = SWITCH_ENDPOINT;
        body.token = SWITCH_TOKEN;

        return await Axios.post(
          `${SWITCH_ENDPOINT}/api/verifyBankDetails`,
          body,
          getSwitchPayHeaders()
        )
          .then((res) => {
            let resp = res.data;
            console.log("verify bank resp", resp);
            if (resp.status == "SUCCESS") {
              console.log(115, "bank varification response", resp);
              if (resp.accountStatus == "VALID") {
                return {
                  status: 1,
                  message: "Bank Verified Success",
                  data: resp,
                };
              }
              return { status: 0, message: "Invalid Bank Detail", data: resp };
            } else {
              return { status: 0, message: resp?.message, data: resp };
            }
          })
          .catch((error) => {
            console.log("verify bank error", error);
            return { status: 0, message: error.message, data: error };
          });
      } else {
        return {
          status: 0,
          message: "User Bank Is Already Verified",
          data: {},
        };
      }
    } else {
      return { status: 0, message: "User Bank Not Found", data: {} };
    }
  } catch (error) {
    console.log("exception", error?.message, error);
    return { status: 0, message: error.message, data: error };
  }
}
async function checkTransferStatus(withData) {
  try {
    // return { status: 1, message: 'Fund Transfer Successfully', data: {} };
    const with_id = withData?._id;
    let order_id = withData.transaction_id;
    if (!order_id) {
      return { status: 0, message: "Transaction No. Not Found", data: {} };
    }

    const body = {
      user_uuid: SWITCH_USER_UUID,
      order_id: order_id,
    };
    const log = {
      time: getDateFormat() + ' ' + getTimeFormatAmPm(),
      dateTime: new Date(),
      body: body
    }
    let logFileName = 'switch-pay-payout-status-check';
    return await Axios.post(`${SWITCH_ENDPOINT}/api/getPayoutStatus`, body, getSwitchPayHeaders())
      .then((resu) => resu.data)
      .then(async (resu) => {
        log.responseTime = new Date();
        log.responseType = "Then";
        log.response = resu;
        webhookLog(JSON.stringify(log), "pay-out", logFileName);
        //return resu;
        console.log("resu", resu);
        if (typeof resu?.Error !== "undefined") {
          return { status: 0, message: resu?.Error, data: resu };
        } else if (resu.status !== "FAILED") {
          //return resu.data;
          let merRefNo = resu.order_id;
          let transaction_id = resu.order_id;
          let params = { merRefNo: merRefNo, transaction_id: transaction_id };
          if (resu.status == "SUCCESS") {
            let update2 = { status: 1 };
            await Withdrawals.updateOne({ _id: with_id }, update2);
            return {
              status: 1,
              message: "Fund Transfer Successfully",
              data: { result: resu, params: params },
            };
          } else if (resu.status == "IN-PROCESS") {
            /* merrefeno :: DYU47ZHRDJZVB4T, trxid :: IMPS728720211111174933460613 */
            return {
              status: 1,
              message: "Fund Transfer Processing",
              data: { result: resu, params: params },
            };
            //return res.json({ status: 2, message: 'Fund Transfer Processing', data: { result: resu, params: params } });
          }
        } else {
          return { status: 0, message: "Something Went Wrong", data: resu };
        }
      })
      .catch((error) => {
        log.responseTime = new Date();
        log.responseType = "Catch";
        log.response = error?.message;
        log.responseData = error?.response?.data || {};
        webhookLog(JSON.stringify(log), "pay-out", logFileName);
        return { status: 0, message: error.message, data: {} };
      });
  } catch (error) {
    return { status: 0, message: error?.message, data: {} };
  }
}
async function checkPaymentStatus(order_id) {
  try {
    // return { status: 1, message: 'Fund Transfer Successfully', data: {} };
    // const order_id = row.order_id;
    if (!order_id) {
      return { status: 0, message: "Transaction No. Not Found", data: {} };
    }

    const body = {
      user_uuid: SWITCH_USER_UUID,
      order_id: order_id,
    };

    return await Axios.post(`${SWITCH_ENDPOINT}/api/getTransactionStatus`, body, getSwitchPayHeaders())
      .then((resu) => resu.data)
      .then(async (resu) => {
        console.log("resu switchpay checkPaymentStatus ==> ", resu);
        if (typeof resu?.Error !== "undefined") {
          return { status: 0, message: resu?.Error, data: resu };
        } else if (resu.status !== "error") {
          if (resu.status == "captured") {
            return { status: 1, message: "Payment Successfully", data: resu };
          } else if (resu.status == "in-process") {
            return { status: 2, message: "Payment Processing", data: resu };
          } else if (resu.status == "failed") {
            return { status: 3, message: "Payment Failed", data: resu };
          }
        } else {
          return { status: 0, message: resu?.message || "Something Went Wrong", data: resu };
        }
      })
      .catch((error) => {
        return { status: 0, message: error.message, data: {} };
      });
  } catch (error) {
    return { status: 0, message: error?.message, data: {} };
  }
}
/* Switch Pay End */

module.exports = {
  doTransfer,
  verifyBankAccount,
  checkTransferStatus,
  checkPaymentStatus,
};
