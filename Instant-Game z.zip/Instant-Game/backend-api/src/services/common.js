const { sendFcmMessage } = require('./firebase');

const getPagination = (page, size) => {
    const limit = size ? +size : 3;
    const offset = page ? page * limit : 0;
    return { limit, offset };
};
const getRespPagi = (respo, message) => {
    let page = respo.page; let per_page = respo.limit;
    let total = respo.totalDocs; let total_pages = respo.totalPages;
    return { status: 1, message: message, data: respo, page: page, per_page: per_page, total: total, total_pages: total_pages }
};
const getDateFormat = (date = '') => {
    let ddd = date;
    if (date == ''){
        ddd = new Date();
    }
    var m = (ddd.getMonth() + 1);;
    var dy = ddd.getDate();
    m = (m <= 9) ? '0' + m : m;
    dy = (dy <= 9) ? '0' + dy : dy;
    var cdate = ddd.getFullYear() + '-' + m + '-' + dy;
    return cdate;
};
const getWeekDay = (date = '') => {
    let ddd = date;
    if (date == ''){
        ddd = new Date();
    }
    return ddd.getDay();
};
const isAllowToPlaceBid = (resData, game_type_id) => {
    game_type_id = parseInt(game_type_id);
    /* Open Digit */
    if (resData.digit_1 != null){
        let dig1Assoc = [0,2,10];
        if (dig1Assoc.indexOf(game_type_id) > -1){
            return false;
        }
    }
    if (resData.digit_2 != null) {/* Close Digit */
        let dig2Assoc = [1,2,9];
        if (dig2Assoc.indexOf(game_type_id) > -1){
            return false;
        }
    }
    if (resData.op_1 != null || resData.op_2 != null || resData.op_3 != null) {/* Open Panna */
        let openAssoc = [3,4,5,9,11];
        if (openAssoc.indexOf(game_type_id) > -1) {
            return false;
        }
    }
    if (resData.cp_1 != null || resData.cp_2 != null || resData.cp_3 != null) {/* Close Panna */
        let closeAssoc = [6,7,8,10,11];
        if (closeAssoc.indexOf(game_type_id) > -1) {
            return false;
        }
    }
    return true;
};
const convertToUTC = (date) => {
    var momentTz = require('moment-timezone');
    return momentTz.tz(date, "YYYY-MM-DD HH:mm:ss", 'Asia/Kolkata').toISOString();
};
const convertToUTCNew = (date) => {
    return new Date(new Date(date).toISOString());
};
const getGameDet = (gametype = '') => {
    var typesArr = [
        { type:0, name:"Single", text:"Single Open" },
        { type:1, name:"Single", text:"Single Close" },
        { type:2, name:"Jodi", text:"Jodi" },
        { type:3, name:"Single", text:"Open Panna" },
        { type:4, name:"Double", text:"Open Panna" },
        { type:5, name:"Triple", text:"Open Panna" },
        { type: 6, name: "Single", text: "Close Panna" },
        { type: 7, name: "Double", text: "Close Panna" },
        { type: 8, name: "Triple", text: "Close Panna" },
        { type: 9, name: "Half Sangam", text: "Open Panna", text2: "Close Digit" },
        { type: 10, name: "Half Sangam", text: "Close Panna", text2: "Open Digit" },
        { type: 11, name: "Full Sangam", text: "Open Panna", text2: "Close Panna" }
    ];
    let newArrInd = typesArr.findIndex(getIndexByVal);
    function getIndexByVal(itm) {
        return itm.type === parseInt(gametype);
    }
    if (newArrInd != ''){
        return typesArr[newArrInd];
    }
    return typesArr[0];
};

const allowPlaceBid = (open_time,close_time, isclose = false) => {
    let openStr = open_time.split(':');
    let closeStr = close_time.split(':');
    var today = new Date();
    var time2 = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    //time2 = "00:40:00";
    console.log(99, time2);

    let currentStr = time2.split(':');
    
    let openSeconds = parseInt(openStr[0]) * 3600 + parseInt(openStr[1]) * 60 + ((openStr.length == 3) ? parseInt(openStr[2]) : 0);
    let closeSeconds = parseInt(closeStr[0]) * 3600 + parseInt(closeStr[1]) * 60 + ((closeStr.length == 3) ? parseInt(closeStr[2]) : 0);
    let currentSeconds = parseInt(currentStr[0]) * 3600 + parseInt(currentStr[1]) * 60 + ((currentStr.length == 3) ? parseInt(currentStr[2]) : 0);
    let threeAmSeconds = parseInt(3) * 3600 + 0 + 0;
    if (openSeconds > closeSeconds){
        if (isclose) {
            if (currentSeconds < openSeconds && currentSeconds > closeSeconds && currentSeconds < threeAmSeconds){
                return false;
            } else if (currentSeconds > closeSeconds && currentSeconds < threeAmSeconds){
                return false;
            }
        } else {
            if (currentSeconds > openSeconds) {
                return false;
            } else if (currentSeconds < openSeconds && currentSeconds < closeSeconds){
                return false;
            } else if (currentSeconds < openSeconds && currentSeconds < threeAmSeconds) {
                return false;
            }
        }
    } else {
        if (isclose){
            if (currentSeconds > closeSeconds) {
                return false;
            } else if (currentSeconds < threeAmSeconds) {
                return false;
            }
        } else {
            if (currentSeconds > openSeconds){
                return false;
            } else if (currentSeconds < threeAmSeconds){
                return false;
            }
        }
    }
    return true;
};

const allowPlaceBid2 = (time1, game_type_id, isclose = false,open_time = '') => {
    let str1 = time1.split(':');
    var today = new Date();
    var time2 = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    console.log(91, time2);
    time2 = "00:10:00";
    /* 03-11-2021 */
    /*var momentTz = require('moment-timezone');
    let utcCutoff = new Date();
    var displayCutoff = momentTz.tz(utcCutoff, 'HH:mm:ss', 'Asia/Kolkata');
    time2 = displayCutoff.format('HH:mm:ss');*/
    /* 03-11-2021 End */

    let str2 = time2.split(':');

    /* timeSeconds1 => (Bid Open Time OR Bid Open Time), timeSeconds2=Current Time */
    let timeSeconds1 = parseInt(str1[0]) * 3600 + parseInt(str1[1]) * 60 + ((str1.length == 3)?parseInt(str1[2]):0);
    let timeSeconds2 = parseInt(str2[0]) * 3600 + parseInt(str2[1]) * 60 + ((str2.length == 3)?parseInt(str2[2]):0);
    if (timeSeconds2 > timeSeconds1){
        let openGames = getGameArray();
        if (isclose){
            openGames = getGameArray(true);
            if (openGames.indexOf(game_type_id) > -1) {
                let openStr = open_time.split(':');
                let openSeconds = parseInt(openStr[0]) * 3600 + parseInt(openStr[1]) * 60 + ((openStr.length == 3) ? parseInt(openStr[2]) : 0);

                if (timeSeconds1 < openSeconds){
                    //12:15 < 18:58 && 18:58 < 23:30
                    //close < current && current < open
                    if (timeSeconds1 < timeSeconds2 && timeSeconds2 < openSeconds) {
                        return false;
                    } else if (timeSeconds2 < timeSeconds1){
                        return false;
                    }
                }
                return true;
            }
        } else {
            if (openGames.indexOf(game_type_id) > -1) {
                return false;
            }
        }
    }
    return true;
};

const getReportDate = (openTime, closeTime) => {
    /* openTime = "10:15:00"; closeTime = "01:30:00"; */
    openTime = openTime.split(':');
    closeTime = closeTime.split(':');
    var today = new Date();
    var time2 = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    let str2 = time2.split(':');
    // str2 = "01:17:00";
    // str2 = str2.split(':');

    /* timeSeconds1 => Bid Open Time, timeSeconds2=Bid Close Time */
    let timeSeconds1 = parseInt(openTime[0]) * 3600 + parseInt(openTime[1]) * 60 + ((openTime.length == 3) ? parseInt(openTime[2]) : 0);
    let timeSeconds2 = parseInt(closeTime[0]) * 3600 + parseInt(closeTime[1]) * 60 + ((closeTime.length == 3) ? parseInt(closeTime[2]) : 0);
    let currentTime = parseInt(str2[0]) * 3600 + parseInt(str2[1]) * 60 + ((str2.length == 3) ? parseInt(str2[2]) : 0);
    let threeamTime = parseInt(3) * 3600 + 0 + 0;

    if (timeSeconds1 > timeSeconds2) {
        if (currentTime <= timeSeconds2) {
            if (currentTime <= threeamTime) {
                today.setDate(today.getDate() - 1);
                return getDateFormat(today);
            }
            return getDateFormat(today);
        } else {
            if (currentTime <= threeamTime) {
                today.setDate(today.getDate() - 1);
                return getDateFormat(today);
            }
            return getDateFormat(today);
        }
    }
    return getDateFormat(today);
};
const getDayNameArr = () => {
    return ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
};
const allowPublishRes = (open_time, close_time, isclose = false) => {
    let open = open_time.split(':');
    let close = close_time.split(':');
    var today = new Date();
    var time2 = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();

    /* 03-11-2021 */
    /*var momentTz = require('moment-timezone');
    let utcCutoff = new Date();
    var displayCutoff = momentTz.tz(utcCutoff, 'HH:mm:ss', 'Asia/Kolkata');
    time2 = displayCutoff.format('HH:mm:ss');*/
    /* 03-11-2021 End */

    let current = time2.split(':');
    
    let openSeconds = parseInt(open[0]) * 3600 + parseInt(open[1]) * 60 + ((open.length == 3) ? parseInt(open[2]) : 0);
    let closeSeconds = parseInt(close[0]) * 3600 + parseInt(close[1]) * 60 + ((close.length == 3) ? parseInt(close[2]) : 0);
    let currentSeconds = parseInt(current[0]) * 3600 + parseInt(current[1]) * 60 + ((current.length == 3) ? parseInt(current[2]) : 0);

    let maxTime = parseInt(23) * 3600 + parseInt(23) * 60 + 59;
    let sweek = 1; let eweek = 2;
    if (currentSeconds > openSeconds && currentSeconds <= maxTime){
        //eweek = 1;
    }

    if(isclose){
        if (openSeconds > closeSeconds){
            //11:30:00 > 11:35:00 && 00:30 <= 11:30
            if (closeSeconds < currentSeconds && currentSeconds < openSeconds){
                return true;
            }
            return false;
        } else if (closeSeconds > currentSeconds){
            return false;
        }
    } else {
        //console.log(time2, currentSeconds, openSeconds, (currentSeconds > openSeconds));

        if (openSeconds > closeSeconds) {
            //10:15 PM - 01:30 AM, now 11:30 PM
            console.log((openSeconds < currentSeconds && sweek < eweek), (closeSeconds > currentSeconds && eweek == eweek), ((openSeconds < currentSeconds && sweek < eweek) || (closeSeconds > currentSeconds && eweek == eweek)));
            if ((openSeconds < currentSeconds && sweek < eweek) || (closeSeconds > currentSeconds && eweek == 2)){
                return true;
            }
            return false;
        } else if (currentSeconds < openSeconds) {
            console.log('175',currentSeconds,openSeconds, (currentSeconds < openSeconds));
            return false;
        }

        /* if (openSeconds > closeSeconds) {
            //10:15 PM - 01:30 AM, now 11:30 PM
            console.log(163, (closeSeconds <= currentSeconds), (openSeconds > currentSeconds));
            if (closeSeconds <= currentSeconds && openSeconds > currentSeconds) {
                return false;
            }
        } else if (currentSeconds < openSeconds){
            return false;
        } */
    }
    return true;
};
const sendAndroid = (registration_ids=[], data={}) => {
    if(process.env.IS_SENT_NOTI == "NO"){
        return false;
    }
    if ((typeof registration_ids !== 'undefined' && registration_ids.length > 0) && (typeof data !== 'undefined' && Object.keys(data).length !== 0)) {
        
        const sendData = {
            'message': {
              'topic': "instant567", //"instant567", instant567Dev
              'notification': {
                'title': data.title,
                'body': data.body,
                'image': data.image
              }
            }
        };
        return sendFcmMessage(sendData);
    }
};
const getGameArray = (isclose = false) => {
    let gameArr = [0, 2, 3, 4, 5, 9, 10, 11];
    if (isclose) {
        gameArr = [1, 6, 7, 8, 9, 10, 11];
        //gameArr = [1, 2, 6, 7, 8, 9, 10, 11];
    }
    return gameArr;
};
const getInnoKey = () => {
    const { INNOPAY_API_KEY, INNOPAY_SALT } = require('./constant');
    return {
        API_KEY: INNOPAY_API_KEY,
        SALT: INNOPAY_SALT
    }
    return arr;
};
const getPlaceBidStatus = (time1, time2, isclose = false) => {
    let str1 = time1.split(':');
    let close = time2.split(':');
    var today = new Date();
    var currtime = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    let str2 = currtime.split(':');
    /* timeSeconds1 => (Bid Open Time), timeSeconds2=Current Time */
    let timeSeconds1 = parseInt(str1[0]) * 3600 + parseInt(str1[1]) * 60 + ((str1.length == 3) ? parseInt(str1[2]) : 0);
    let timeSeconds2 = parseInt(str2[0]) * 3600 + parseInt(str2[1]) * 60 + ((str2.length == 3) ? parseInt(str2[2]) : 0);
    let closeSeconds2 = parseInt(close[0]) * 3600 + parseInt(close[1]) * 60 + ((close.length == 3) ? parseInt(close[2]) : 0);
    if (isclose){
        //console.log(256, 'close :: ',close, 'current :: ',str2, (timeSeconds2 > closeSeconds2));
        if (timeSeconds1 > closeSeconds2){
            return true;
        } else if (timeSeconds2 > closeSeconds2){
            return false;
        }
    } else {
        if (timeSeconds1 > closeSeconds2) {
            if ((timeSeconds2 > timeSeconds1) || (timeSeconds2 < closeSeconds2)){
                return false;
            }
        } else if (timeSeconds2 > timeSeconds1) {
            return false;
        }
    }
    return true;
};
const getLastIntTransNo = async () => {
    var Transactions = require('../models/Transactions');
    let wh2 = { wallet_type: 2, tnx_type:5};
    let lastTrans = await Transactions.find(wh2).sort({ internal_tnx: -1 }).limit(1);
    // console.log(373, lastTrans, lastTrans.length, (lastTrans && lastTrans.length > 0));
    if (lastTrans && lastTrans.length > 0){
        return (lastTrans[0].internal_tnx)?lastTrans[0].internal_tnx + 1:1;
    } else {
        return 1;
    }
};
const getMinusOneDayDate = (passeddate,openTime, closeTime,isShow = false) => {
    openTime = openTime.split(':');
    closeTime = closeTime.split(':');
    var today = new Date(passeddate);
    let todayDt = new Date();
    var time2 = todayDt.getHours() + ":" + todayDt.getMinutes() + ":" + todayDt.getSeconds();
    //time2 = "02:00:00";
    let currTime = time2.split(':');
    let openSeconds = parseInt(openTime[0]) * 3600 + parseInt(openTime[1]) * 60 + ((openTime.length == 3) ? parseInt(openTime[2]) : 0);
    let closeSeconds = parseInt(closeTime[0]) * 3600 + parseInt(closeTime[1]) * 60 + ((closeTime.length == 3) ? parseInt(closeTime[2]) : 0);
    let currentTime = parseInt(currTime[0]) * 3600 + parseInt(currTime[1]) * 60 + ((currTime.length == 3) ? parseInt(currTime[2]) : 0);
    let threeamTime = parseInt(3) * 3600 + 0 + 0;
    if (isShow){
        if (currentTime <= threeamTime) {
            today.setDate(today.getDate() - 1);
            return getDateFormat(today);
        }
        return passeddate;
    } else {
        if (openSeconds > closeSeconds) {
            if (currentTime <= threeamTime) {
                today.setDate(today.getDate() - 1);
                return getDateFormat(today);
            }
            return passeddate;
        } else {
            if (currentTime <= threeamTime) {
                today.setDate(today.getDate() - 1);
                return getDateFormat(today);
            }
            return passeddate;
        }
    }
};
const getWeekDayResult = (passeddate) => {
    const days = getDayNameArr();
    var today = new Date(passeddate);
    const currentDate = new Date();
    var time2 = currentDate.getHours() + ":" + currentDate.getMinutes() + ":" + currentDate.getSeconds();
    const currTime = time2.split(':');
    
    const currentTime = parseInt(currTime[0]) * 3600 + parseInt(currTime[1]) * 60 + ((currTime.length == 3) ? parseInt(currTime[2]) : 0);
    const threeamTime = parseInt(3) * 3600 + 0 + 0;
    if (currentTime <= threeamTime) {
        today.setDate(today.getDate() - 1);
    }
    const week_day = today.getDay();
    return { week_day_name: days[week_day], week_day };
};
const getTimeFormat = (datetime = '') => {
    var moment = require('moment');
    let ddd = datetime;
    if (datetime == '') {
        ddd = new Date();
    }
    return moment(ddd).format('hh:mm:ss');
};
const getTimeFormatAmPm = (datetime = '') => {
    var moment = require('moment');
    let ddd = datetime;
    if (datetime == '') {
        ddd = new Date();
    }
    return moment(ddd).format('hh:mm A');
};
const getGameDetTrans = (gametype = 0) => {
    var typesArr = [
        "Single Open Digit", "Single Close Digit", "Jodi",
        "Single Open Panna", "Double Open Panna", "Triple Open Panna",
        "Single Close Panna", "Double Close Panna", "Triple Close Panna",
        "Half Sangam Open Panna Close Digit", "Half Sangam Close Panna Open Digit", "Full Sangam Open Panna Close Panna"
    ];
    return typesArr[gametype];
};
const generateMerRefCode = (length = 15) => {
    var text = "";
    possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (var i = 0; i < length; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text.toUpperCase();
}
const generateMerRefCodeNumeric = (length = 10) => {
    let text = "";
    possible = "0123456789";
    for (let i = 0; i < length; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text.toUpperCase();
}
module.exports = {
    getPagination, getRespPagi, getDateFormat, getWeekDay, isAllowToPlaceBid, convertToUTC, convertToUTCNew, getGameDet, allowPlaceBid, getReportDate, getDayNameArr, allowPublishRes, getGameArray, sendAndroid, getInnoKey, getPlaceBidStatus, getLastIntTransNo, getMinusOneDayDate, getTimeFormat, getTimeFormatAmPm, getGameDetTrans, getWeekDayResult, generateMerRefCode, generateMerRefCodeNumeric
};