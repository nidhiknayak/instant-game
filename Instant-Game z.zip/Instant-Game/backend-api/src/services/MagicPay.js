
const Axios = require('axios');
const { PAYMAGIC_PAYIN_ENDPOINT, PAYMAGIC_STATUS_CHECK_ENDPOINT, PAYMAGIC_CLIENT_ID, PAYMAGIC_SECRET_KEY } = require('./constant');
const { generateMerRefCode, getDateFormat, getTimeFormatAmPm, getLastIntTransNo } = require('./common');
const MagicPayCreateURLLogs = require('../models/MagicPayCreateURLLogs');
const { webhookLog } = require('./JsonOpr');
const Users = require('../models/Users');
const Transactions = require('../models/Transactions');
const { addBonusReferalAmount } = require('../controllers/UserProfileController');

const getPayHeaders = (orderId = null) => {
  const headers = {
    headers: {
      "content-Type": "application/json",
      "secret-key": PAYMAGIC_SECRET_KEY,
      "client-id": PAYMAGIC_CLIENT_ID
    },
  };
  if(orderId){
    headers.headers["order-id"] = orderId;
  }
  return headers;
};

const generatePaymentIntent = async (amount, user_id = null, mobile_no = '', firstname = '') => {
  try {
    const merRefNoGen = generateMerRefCode();
    const transaction_id = `MGCP${merRefNoGen}`;
    const returnurl = `${process.env.MAGIC_PAY_WEB}payment/magic-pay/redirect?orderId=${transaction_id}`
    const body = {
      orderId: transaction_id,
      // amount: parseFloat(amount).toFixed(2),
      amount: amount,
      // name: `${mobile_no}${firstname ? `_${firstname}` : ``}`,
      returnurl
    };
    const insert = { amount, transaction_id, user_id, requestBody: body };
    return await Axios.post(`${PAYMAGIC_PAYIN_ENDPOINT}`, body, getPayHeaders()).
      then((resu) => resu.data).
      then(async resu => {
        insert.message = resu?.message || "Generated";
        insert.is_created = resu?.statusCode == 200 ? true : false;
        insert.resp = resu;
        MagicPayCreateURLLogs.create(insert);
        if(resu?.statusCode == 200){
          return { status: 1, message: "Payment intent generated Success", data: resu };
        } else {
          return { status: 0, message: resu?.message || "Error while generate intent", data: resu };
        }
      }).catch(error => {
        console.log("error?.response?.data", error?.response?.data);
        insert.is_created = false;
        insert.message = error?.response?.data?.message || error?.message;
        if(error?.response?.data){
          insert.resp = error?.response?.data;
        }
        MagicPayCreateURLLogs.create(insert);
        return { status: 0, message: error?.message, data: error?.response?.data };
      });
  } catch (error) {
    return { status: 0, message: error.message, data: error }
  }
}

const checkPaymentStatus = async (transaction_id = '', order_id = '') => {
   try {
    //return { status: 1, message: "Get Payment Status Successfully", data: transaction_id };
    const body = { "order-id": transaction_id };
    const headers = getPayHeaders(transaction_id);
    const log = {
      time: getDateFormat() + ' ' + getTimeFormatAmPm(),
      dateTime: new Date(),
      body: body,
      headers: headers?.headers,
    };
    
    return await Axios.get(`${PAYMAGIC_STATUS_CHECK_ENDPOINT}`, headers).
      then((resu) => resu.data).
      then(async resu => {
        log.responseTime = new Date();
        log.responseType = "Then";
        log.response = resu;
        webhookLog(JSON.stringify(log), "pay-in", 'magic-pay-check');
        
        if(resu.statusCode == 200){
          const resp = resu.data;
          if(resp.txnStatus == "Approved"){
            return { status: 1, message: "Payment Is Success", data: { ...resp, utr: resp?.utr || null } };
          } else if(resp.txnStatus == "Pending" || resp.txnStatus == "Initiated"){
            return { status: 2, message: "Payment Is In Progress", data: { ...resp, utr: resp?.utr || null } };
          } else if(resp.txnStatus == "Rejected"){
            return { status: 3, message: "Payment Is Failed", data: { ...resp, utr: resp?.utr || null } };
          }
        } else {
          return { status: 0, message: resu.message, data: resu };
        }
      }).catch(error => {
        log.responseTime = new Date();
        log.responseType = "Catch";
        log.response = error?.response?.data || error?.message;
        webhookLog(JSON.stringify(log), "pay-in", 'magic-pay-check');
        
        if(error?.response?.data?.message == "UPI_TRANSACTION_NOT_FOUND"){
          const resp = error?.response?.data;
          return { status: 2, message: "Payment Is In Progress", data: { ...resp, utr: resp?.transactionRefId || null } };
        }
        return { status: 0, message: error.message, data: error?.response?.data };
      });
  } catch (error) {
    const log = {
      time: getDateFormat() + ' ' + getTimeFormatAmPm(),
      dateTime: new Date(),
      body: body,
      responseTime: new Date(),
      responseType: "Try Catch Exception",
      response: error.message,
    };
    webhookLog(JSON.stringify(log), "pay-in", 'magic-pay-check');
    return { status: 0, message: error.message, data: error }
  }
}

const createTransaction = async (row, status, utr, fromRedirect = false) => {
  const amount = row.amount;
  const internal_tnx = await getLastIntTransNo();
  const user = await Users.findOne({ _id: row.user_id });
  const post_balance = user.wallet + parseFloat(amount);
  const orderId = row.transaction_id;
  
  const insTrans = {
    user_id: row?.user_id,
    tnx: orderId,
    amount: amount,
    final_amount: amount,
    post_balance: post_balance,
    tnx_type: 5,//added by self
    wallet_type: 2,//simple wallet
    details: "Added",
    entry_type: 1,//credit entry
    internal_tnx: internal_tnx,
    payment_type: "",
    // order_id: order_id,
    pay_status: 0,
    check_inno_status: 0,
    created_by: user._id
  };
  const webhook_resp = { txnStatus: status, orderId, utr, fromRedirect: true };
  const existTrans = await Transactions.findOne({ tnx: orderId, user_id: row.user_id, tnx_type: { $in: [4,5] }, entry_type: 1, wallet_type: 2 });
  if(status == "Approved"){
      const update = { status: "SUCCESS", upi_txn_id: utr || null };
      if(fromRedirect){
        update.webhook_resp = webhook_resp;
      }
      await MagicPayCreateURLLogs.updateOne({ _id: row._id }, update);

      insTrans.check_inno_status = 1;
      insTrans.pay_status = 1;
      insTrans.order_id = utr || "";

      const totTrans = await Transactions.find({ user_id: row.user_id, tnx_type: { $in: [4,5] }, entry_type: 1, wallet_type: 2 });
      let transaction;
      if(existTrans){
        transaction = existTrans;
        const updateTrans = { check_inno_status: 1, pay_status: 1, order_id: utr || "" };
        await Transactions.updateOne({ _id: existTrans._id }, updateTrans);
      } else {
        transaction = await Transactions.create(insTrans);
      }
      if(transaction){
        const result = await Users.findOneAndUpdate({_id: row.user_id }, { $inc: { wallet: parseFloat(amount) } }, { new: true });
        await addBonusReferalAmount(1, amount, result, row._id, totTrans);
      }
  } else if(status == "Rejected"){
    insTrans.check_inno_status = 2;
    insTrans.pay_status = 2;
    if(existTrans){
      const updateTrans = { check_inno_status: 2, pay_status: 2, order_id: utr || "" };
      await Transactions.updateOne({ _id: existTrans._id }, updateTrans);
    } else {
      await Transactions.create(insTrans);
    }
    const update = { status: "FAILED", upi_txn_id: utr || null };
    if(fromRedirect){
      update.webhook_resp = webhook_resp;
    }
    await MagicPayCreateURLLogs.updateOne({ _id: row._id }, update);
  } else {
    insTrans.check_inno_status = 0;
    insTrans.pay_status = 0;
    if(existTrans){
      const updateTrans = { check_inno_status: 0, pay_status: 0, order_id: utr || "" };
      await Transactions.updateOne({ _id: existTrans._id }, updateTrans);
    } else {
      await Transactions.create(insTrans);
    }
    const update = { status: "PENDING", upi_txn_id: utr || null };
    if(fromRedirect){
      update.webhook_resp = webhook_resp;
    }
    await MagicPayCreateURLLogs.updateOne({ _id: row._id }, update);
  }
};
module.exports.generatePaymentIntent = generatePaymentIntent;
module.exports.checkPaymentStatus = checkPaymentStatus;
module.exports.createTransaction = createTransaction;
