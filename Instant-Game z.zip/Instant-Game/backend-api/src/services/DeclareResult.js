/* game_type_id = 2 */
const declareJodi = (bid, result) => {
    const jodi = bid.panna_1;
    const gvnRes = result.digit_1 + '' + result.digit_2;
    console.log('5',jodi, gvnRes);
    if (parseInt(jodi) == parseInt(gvnRes)){
        return true;
    }
    return false;
};
/* game_type_id = 0,1 */
const declareSingleOpenCloseDigit = (bid, result,close=false) => {
    const panna_1 = bid.panna_1;
    let gvnRes = result.digit_1;
    if (close){
        gvnRes = result.digit_2;
    }
    console.log('18',panna_1, gvnRes);
    if (panna_1 == gvnRes){
        return true;
    }
    return false;
};
/* game_type_id = 3,6 */
const declareSingleOpenClosePanna = (bid, result, close = false) => {
    const panna_1 = bid.panna_1;
    let gvnRes = result.op_1+''+result.op_2+''+result.op_3;
    if (close) {
        gvnRes = result.cp_1+''+result.cp_2+''+result.cp_3;
    }
    if (parseInt(gvnRes) == parseInt(panna_1)){
        return true;
    }
    return false;
    /* let gvnRes = [result.op_1, result.op_2, result.op_3];
    if(close){
        gvnRes = [result.cp_1, result.cp_2, result.cp_3];
    } */
        /* Element Present More Then One */
            /* let newArr = gvnRes.filter(checkLength);
            function checkLength(elm) {
                return elm == panna_1;
            }
            if (newArr.length == 1){
                return true;
            }
            return false; */
    //console.log('31',panna_1, gvnRes);
    /* if (gvnRes.indexOf(panna_1) > -1){
        return true;
    } 
    return false;*/
};
/* game_type_id = 5,8 */
const declareTripleOpenClosePanna = (bid, result, close = false) => {
    const panna_1 = bid.panna_1;
    let gvnRes = result.op_1+''+ result.op_2+''+ result.op_3;
    if (close){
        gvnRes = result.cp_1+''+ result.cp_2+''+ result.cp_3;
    }
    console.log('61',panna_1, gvnRes);
    console.log('62', (panna_1 == parseInt(gvnRes)));
    if (panna_1 == parseInt(gvnRes)){
        return true;
    }
    return false;
};
/* game_type_id = 4,7 */
const declareDoubleOpenClosePanna = (bid, result, close = false) => {
    let panna_1 = bid.panna_1;
    var cmpPanna_1 = panna_1.toString();
    let gvnRes = result.op_1 + '' + result.op_2 + '' + result.op_3;
    if (close) {
        cmpPanna_1 = panna_1.toString();
        gvnRes = result.cp_1 + '' + result.cp_2 + '' + result.cp_3;
    }
    if (parseInt(panna_1) == parseInt(gvnRes)) {
        return true;
    }
    return false;
    /* let panna_1 = bid.panna_1;
    var cmpPanna_1 = panna_1.toString();
    cmpPanna_1 = cmpPanna_1.slice(0, 2);
    console.log(54, panna_1,cmpPanna_1);
    let gvnRes = result.op_1+''+ result.op_2;
    console.log('76 Open', cmpPanna_1, gvnRes);
    if (close){
        cmpPanna_1 = panna_1.toString();
        cmpPanna_1 = cmpPanna_1.slice(1, 3);
        gvnRes = result.cp_2+''+ result.cp_3;
        //gvnRes = gvnRes.slice(-1, 2);
        console.log('82 Close', cmpPanna_1, gvnRes);
    }
    panna_1 = parseInt(cmpPanna_1);
    console.log('74', panna_1, gvnRes);
    if (panna_1 == parseInt(gvnRes)){
        return true;
    }
    return false; */
};
/* game_type_id = 9,10 */
const declareHalfSangam = (bid, result, close = false) => {
    const panna = bid.panna_1; const digit = bid.panna_2;
    let gvnRes_panna = result.op_1 + '' + result.op_2 + '' + result.op_3;
    let gvnRes_digit = result.digit_2;
    if (close) {/* ClosePannaOpenDigit */
        gvnRes_panna = result.cp_1 + '' + result.cp_2 + '' + result.cp_3;
        gvnRes_digit = result.digit_1;
    }
    console.log(98, panna, digit)
    console.log(99, gvnRes_panna, gvnRes_digit)
    if (panna == parseInt(gvnRes_panna) && digit == parseInt(gvnRes_digit)){
        return true;
    }
    return false;
};
/* game_type_id = 11 */
const declareFullSangam = (bid, result) => {
    const openPanna = bid.panna_1; const closePanna = bid.panna_2;
    let Res_Opanna = result.op_1 + '' + result.op_2 + '' + result.op_3;
    let Res_Cpanna = result.cp_1 + '' + result.cp_2 + '' + result.cp_3;
    
    console.log('100',openPanna, closePanna, Res_Opanna, Res_Cpanna);
    if (openPanna == parseInt(Res_Opanna) && closePanna == parseInt(Res_Cpanna)){
        return true;
    }
    return false;
};
const declareResult = (bid, result, game_type_id) => {
    game_type_id = parseInt(game_type_id);
    switch (game_type_id) {
        case 0:
            return declareSingleOpenCloseDigit(bid, result);
        case 1:
            return declareSingleOpenCloseDigit(bid, result, true);
        case 2:
            return declareJodi(bid, result);
        case 3:
            return declareSingleOpenClosePanna(bid, result);
        case 6:
            return declareSingleOpenClosePanna(bid, result, true);
        case 4:
            return declareDoubleOpenClosePanna(bid, result);
        case 7:
            return declareDoubleOpenClosePanna(bid, result, true);
        case 5:
            return declareTripleOpenClosePanna(bid, result);
        case 8:
            return declareTripleOpenClosePanna(bid, result, true);
        case 9:
            return declareHalfSangam(bid, result);
        case 10:
            return declareHalfSangam(bid, result, true);
        case 11:
            return declareFullSangam(bid, result);
        default:
            return false;
    }
    return false;
};

module.exports = {
    declareResult
};