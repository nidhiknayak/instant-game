var fs = require('fs');
const { getDateFormat, getTimeFormatAmPm, getTimeFormat } = require('./common');
const filePath = 'src/api_call/addWalletAmount.json';
const addContent = async (req) => {
    var obj = [];
    let params = req.body;
    let date = getDateFormat() + ' ' + getTimeFormatAmPm();
    var fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    let pushArr = { date: date, user_id: req.userDet.id, mobile_no: req.userDet.mobile_no, params: params, api_url: fullUrl };
    if (fs.existsSync(filePath)) {
        fs.readFile(filePath, 'utf-8', function (err, data) {
            obj = JSON.parse(data);
            obj.push(pushArr);
            json = JSON.stringify(obj);
            return fs.writeFileSync(filePath, json, 'utf8', function (err) {
                if (err) { return err; }
            });
        });
    } else {
        obj.push(pushArr);
        json = JSON.stringify(obj);
        return await fs.appendFile(filePath, json, 'utf8',function (err) {
            if (err) { return err; }
        });
    }
};

const appendContent = async (req) => {
    let params = req.body;
    const filePath2 = 'src/api_call/wallet_call.txt';
    let date = getDateFormat() + ' ' + getTimeFormatAmPm();
    var fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    let pushStr = 'UserID :: ' + req.userDet.id + ', Mobile :: ' + req.userDet.mobile_no+', Date :: ' + date + ' ==> Data :: ' + JSON.stringify(params)+ ' ==> Headers :: ' + JSON.stringify(req.headers) +'\n';
    return await fs.appendFile(filePath2, pushStr, 'utf8', function (err) {
        if (err) { return err; }
    });
};

const addBidTransUser = async (file_name, insData) => {
    let filePath = 'src/api_call/'+file_name+'.json';
    if (fs.existsSync(filePath)) {
        fs.readFile(filePath, 'utf-8', function (err, data) {
            let json = JSON.stringify(insData);
            return fs.writeFileSync(filePath, json, 'utf8', function (err) {
                if (err) { return err; }
            });
        });
    } else {
        json = JSON.stringify(insData);
        return await fs.appendFile(filePath, json, 'utf8', function (err) {
            if (err) { return err; }
        });
    }
};

/* 23-02-2022 */
const logDrawProcess = async (data) => {
    const filePath2 = 'src/api_call/draw_log.txt';
    let date = getDateFormat() + ' ' + getTimeFormat();
    let pushStr = 'Date :: ' + date + ' ==> Data :: ' + JSON.stringify(data) + '\n';
    return await fs.appendFile(filePath2, pushStr, 'utf8', function (err) {
        if (err) { return err; }
    });
};
const logDrawProcessFound = async (data) => {
    const filePath2 = 'src/api_call/draw_log.txt';
    let date = getDateFormat() + ' ' + getTimeFormat();
    let pushStr = 'FOUND ==> Draw_no :: '+data.draw_no+' Date :: ' + date + ' ==> Data :: ' + JSON.stringify(data) + '\n';
    return await fs.appendFile(filePath2, pushStr, 'utf8', function (err) {
        if (err) { return err; }
    });
};
/* 05-08-2022 */
const addLeadingZero = async (num, size = 10) => {
    num = num.toString();
    while (num.length < size) num = "0" + num;
    return num;
}
const addGetTransID = async (type = 'trans_id', noToAppend = '') => {
    let fileTransNo = "src/api_call/trans_id.txt";
    if(type == 'internal_id'){
        fileTransNo = "src/api_call/internal_id.txt";
    }
    if (fs.existsSync(fileTransNo)) {
        return new Promise(async (resolve, reject)=>{
            if(noToAppend != ''){
              json = await addLeadingZero(noToAppend);
              fs.writeFileSync(fileTransNo, json, function (err) {
                  if (err) { return err; }
              });
              resolve(json);
            } else {
              fs.readFile(fileTransNo, async function (err, data) {
                  let json = parseInt(data) + 1;
                  json = await addLeadingZero(json);
                  fs.writeFileSync(fileTransNo, json, function (err) {
                      if (err) { return err; }
                  });
                  resolve(data);
              });
            }
        });
    } else {
        let json = "0000000001";
        return new Promise((resolve, reject)=>{
            fs.appendFile(fileTransNo, json,function (err) {
                if (err) { return err; }
            });
            resolve(json);
        });
    }
};

const webhookLog = async (content, gateway = "pay-in", type = 'letspay') => {
    const target = `src/api_call/${gateway}/`;
    const fileName = `${type}-${getDateFormat()}.log`;
    if (!fs.existsSync(target)){
        fs.mkdirSync(target, { recursive: true });
    }
    const fullUrl = `${target}${fileName}`;
    if (fs.existsSync(fullUrl)) {
        fs.readFile(fullUrl, 'utf-8', function (err, data) {
            const json = `${data}\n${content}`;
            return fs.writeFileSync(fullUrl, json, 'utf8', function (err) {
                if (err) { return err; }
            });
        });
    } else {
        return fs.appendFile(fullUrl, content, 'utf8', function (err) {
            if (err) { return err; }
        });
    }
}

module.exports = { addContent, appendContent, addBidTransUser, logDrawProcess, logDrawProcessFound, addGetTransID, addLeadingZero, webhookLog };