const isValid = (value) => {
  return new Promise(async function (resolve, reject) {
      if (value != '' && value != null && value != undefined) {
          resolve(true);
      } else {
          resolve(false);
      }
  });
};

module.exports = {
  isValid
};