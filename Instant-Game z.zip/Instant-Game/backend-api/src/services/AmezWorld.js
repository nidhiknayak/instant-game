const Withdrawals = require("../models/Withdraw");
var { UserBanks } = require("../models/UserBanks");
const Users = require('../models/Users');
const AmezWorldCreateURLLogs = require('../models/AmezWorldCreateURLLogs');
const { generateMerRefCode } = require("./common");
const Axios = require("axios");
const { AMEZ_WORLD_ENDPOINT, AMEZ_WORLD_TOKEN } = require("./constant");
/* AmezWorld Start */
const getHeaders = () => {
  return {
    headers: {
      Accept: "application/json",
      "content-Type": "application/json"
    },
  };
};
async function doTransfer(userBank, amount, user_id, with_id) {
  try {
    // return { status: 1, message: 'Fund Transfer Successfully', data: {} };
    //amount = 10;
    const userDetail = await Users.findOne({ _id: user_id });

    const merchantReferenceMumber = `AWT${generateMerRefCode()}`; //'Mr. ABC XYZ PQR';
    amount = parseFloat(amount).toFixed(2);
    
    const account_name = userBank.user_name.trim(); //'Mr. ABC XYZ PQR';
    const bank_name = userBank.bank_name.trim(); //State Bank Of India;
    const account_number = userBank.acc_no; //'01234567980';
    const ifsc_code = userBank.ifsc_code; //'SBIN0060471';

    const body = {
      token: AMEZ_WORLD_TOKEN,
      mobile: userDetail?.mobile_no || "9876543210",
      account: account_number,
      bank: bank_name,
      mode: "IMPS",
      ifsc: ifsc_code,
      name: account_name,
      amount: amount,
      apitxnid: merchantReferenceMumber,
      longitude : "27.4443",
      latitude : "23.8887"
    };
    // return { status: 0, message: "Function called", data: body };
    return await Axios.post(`${AMEZ_WORLD_ENDPOINT}/api/payout/order/create`, body, getHeaders())
      .then((resu) => resu.data)
      .then(async (resu) => {
        console.log("resu", resu);
        if (typeof resu?.Error !== "undefined") {
          return { status: 0, message: resu?.Error, data: resu };
        } else if (resu?.status == "ERROR") {
          return { status: 0, message: resu?.message, data: resu };
        }
        if (resu?.statuscode == "TXN") {
          if (resu?.status == "success") {
            const transaction_id = resu?.refno;
            const merRefNo = resu?.apitxnid;
            const params = { merRefNo: merRefNo, transaction_id: transaction_id };
            const update2 = { merchant_ref_no: merRefNo, transaction_id: transaction_id, status: 1 };
            await Withdrawals.updateOne({ _id: with_id }, update2);
            return { status: 1, message: "Fund Transfer Successfully", data: { result: resu, params: params } };
          } else if (resu?.status == "pending" || resu?.status == "failed") {
            const transaction_id = resu?.refno;
            const merRefNo = resu?.apitxnid;
            const params = { merRefNo: merRefNo, transaction_id: transaction_id };
            const update2 = { merchant_ref_no: merRefNo, transaction_id: transaction_id, status: resu?.status == "pending" ? 4 : 3 };
            await Withdrawals.updateOne({ _id: with_id }, update2);
            return { status: 1, message: "Fund Transfer Processing", data: { result: resu, params: params } };
          } else {
            return { status: 0, message: "Something Went Wrong, Try Again", data: {} };
          }
        }
      })
      .catch((error) => {
        console.log(62, error);
        return { status: 0, message: error.message, data: {} };
      });
    //return { status: 1, message: 'Fund Transfer Successfully ', data: {} };
  } catch (error) {
    console.log(73, error);
    return { status: 0, message: error.message, data: {} };
  }
}

async function checkTransferStatus(withData) {
  try {
    // return { status: 1, message: 'Fund Transfer Successfully', data: {} };
    const with_id = withData?._id;
    const order_id = withData.merchant_ref_no;
    if (!order_id) {
      return { status: 0, message: "Transaction No. Not Found", data: {} };
    }

    const body = { token: AMEZ_WORLD_TOKEN, apitxnid: order_id };

    return await Axios.post(`${AMEZ_WORLD_ENDPOINT}/api/payout/order/status`, body, getHeaders())
      .then((resu) => resu.data)
      .then(async (resu) => {
        if (resu.statuscode == "TXN") {
          const merRefNo = resu.order_id;
          const transaction_id = resu.utr_ref;
          const params = { merRefNo: merRefNo, transaction_id: transaction_id };
          if (resu.status == "success") {
            const update2 = { status: 1 };
            await Withdrawals.updateOne({ _id: with_id }, update2);
            return { status: 1, message: "Fund Transfer Successfully", data: { result: resu, params: params } };
          } else if (resu.status == "failed") {
            const update2 = { status: 3 };
            await Withdrawals.updateOne({ _id: with_id }, update2);
            return { status: 0, message: "Fund Transfer Failed", data: { result: resu, params: params } };
          } else if (resu.status == "pending") {
            return { status: 1, message: "Fund Transfer Processing", data: { result: resu, params: params } };
          }
        } else {
          return { status: 0, message: "Something Went Wrong", data: resu };
        }
      })
      .catch((error) => {
        return { status: 0, message: error.message, data: {} };
      });
  } catch (error) {
    return { status: 0, message: error?.message, data: {} };
  }
}

const generatePaymentIntent = async (amount, user_id = null, mobile_no = '', firstname = '') => {
  try {
    //return { status: 1, message: "Get Payment Status Successfully", data: transaction_id };
    const merRefNoGen = generateMerRefCode(16);
    const transaction_id = `AWDPAY${merRefNoGen}`;//'Mr. ABC XYZ PQR';
    const body = {
      token: AMEZ_WORLD_TOKEN,
      apitxnid: transaction_id,
      amount: amount,
      users_mobile: mobile_no,
      users_name: `${firstname ? `${firstname}` :  `Instant567 ${mobile_no}`}`,
      discription: `Payment of INR ${amount}`,
      remark: `Transaction ID ${transaction_id}`,
    };
    const insert = { amount, transaction_id, user_id };
    return await Axios.post(`${AMEZ_WORLD_ENDPOINT}/api/payin/order/create`, body, getHeaders()).
      then((resu) => resu.data).
      then(async resu => {
        console.log("response upiQrGenerateAuth resu", resu);
        insert.message = resu?.message || "Generated";
        insert.is_created = resu?.statuscode == "TXN" ? true : false;
        insert.resp = resu;
        AmezWorldCreateURLLogs.create(insert);
        if(resu?.statuscode == "TXN"){
          return { status: 1, message: "Payment intent generated Success", data: resu };
        } else {
          return { status: 0, message: resu?.message || "Error while generate intent", data: resu };
        }
      }).catch(error => {
        insert.is_created = false;
        insert.message = error?.message;
        AmezWorldCreateURLLogs.create(insert);
        return { status: 0, message: error?.message, data: error };
      });
  } catch (error) {
    return { status: 0, message: error.message, data: error }
  }
}
async function checkPaymentStatus(tnxId) {
  try {
    // return { status: 1, message: 'Fund Transfer Successfully', data: {} };
    // const order_id = row.order_id;
    if (!tnxId) {
      return { status: 0, message: "Transaction No. Not Found", data: {} };
    }
    
    const body = { token: AMEZ_WORLD_TOKEN, apitxnid: tnxId };
    return await Axios.post(`${AMEZ_WORLD_ENDPOINT}/api/payin/order/status`, body, getHeaders())
      .then((resu) => resu.data)
      .then(async (resu) => {
        console.log("resu Amezworld checkPaymentStatus ==> ", resu);
        if (resu.statuscode == "TXN") {
          if (resu.status == "success") {
            return { status: 1, message: "Payment Successfully", data: resu };
          } else if (resu.status == "pending") {
            return { status: 2, message: "Payment Processing", data: resu };
          } else if (resu.status == "failed") {
            return { status: 3, message: "Payment Failed", data: resu };
          }
        } else {
          return { status: 0, message: resu?.message || "Something Went Wrong", data: resu };
        }
      })
      .catch((error) => {
        return { status: 0, message: error.message, data: {} };
      });
  } catch (error) {
    return { status: 0, message: error?.message, data: {} };
  }
}
/* AmezWorld End */

module.exports = { doTransfer, checkTransferStatus, generatePaymentIntent, checkPaymentStatus };
