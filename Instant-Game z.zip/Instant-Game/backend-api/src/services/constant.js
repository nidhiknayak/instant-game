module.exports = {
    CURR_SMBL:"₹",
    MIN_DEPO_AMT :300,
    DEPO_BONUS_AMT :50,
    REG_BONUS_AMT :29,
    MIN_WITH_AMT :1000,
    MIN_WINN_WLT_AMT : 500,
    WITH_REQ_PER_DAY:3,
    INNOPAY_API_KEY: "489d50ae-a966-460e-abd8-233af5c372c4",
    INNOPAY_SALT: "a09524b8f1ef827f5181b56d545f806c7dacb967",
    COLOR_NO_OF_RAND_NUM:4,
    SWITCH_ENDPOINT: "https://www.switchpay.in",
    SWITCH_USER_UUID: "swp_sm_284a39b6-3fee-4a91-b75e-19f9cda4414e",
    SWITCH_TOKEN: "Bearer 266|YwrPumvpaBoifDkKj8rhNNi17T0sh8XYWFz4Fzwu",
    GENNIEPAY_ENDPOINT: "https://gcds.genniepay.com/gcds-payin-svc",
    GENNIEPAY_ENDPOINT_PAYOUT: "https://gcds.genniepay.com/gcds-payout-paycoon-svc",
    /* GENNIEPAY_CLIENT_ID: "ed88e519-40e4-416d-b013-cbaac63fffb8",
    GENNIEPAY_SECRET_KEY: "1198908f-52a4-4bcc-a6c4-1497f1a701c7", */
    GENNIEPAY_CLIENT_ID: "9f24612b-45e8-4f6f-aaf2-c8ad578f8046",
    GENNIEPAY_SECRET_KEY: "0ba868ab-5936-46e7-b415-9e22230caf98",
    ANILEX_ENDPOINT: "https://letspaywallet.in",
    ANILEX_TOKEN: "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhZXBzX2tleSI6IjYzMjMwZTc5OGM0MjM3NzJlNTExZDZkNSIsImFlcHNfaXYiOiI3NjEzNmExYmYwZDMyYzg4NTBhYzViZjlmNDBkIn0.f8OrkWgZ_gx0IH9GjY3QiFnApN6nb-1IOnIom80mmPM",
    REFERRAL_BONUS_AMOUNT: 101,
    ADDED_AMOUNT_FOR_FIVE_PERCENT_BONUS: 1000,
    AMEZ_WORLD_ENDPOINT: "https://gateway.upibot.com/connect",
    AMEZ_WORLD_TOKEN: "gFHq8y7yBPTaAAYUqPeSrzF28RopLrucnBGk7VSg",
    GECKIOPAY_ENDPOINT: "https://dashboard.geckiopay.in/api/v1/upi",
    GECKIOPAY_API_KEY: "GPKEY23a6fda5108857c84365f6a0",//GPKEY7f25fb31524375f9f5b25b5f
    GECKIOPAY_API_TOKEN: "GPTKN69e4e0ca8ad069f880143b3d819b",//GPTKN231bcd32c80a27010882867e72c0
    // PAYMAGIC_PAYIN_ENDPOINT: "https://api.paymagic.co/p2p-svc/",
    PAYMAGIC_PAYIN_ENDPOINT: "https://api.paymagic.co/p2p-svc-v3.0/api/v3/transaction/ext/utr/initiate",
    PAYMAGIC_STATUS_CHECK_ENDPOINT: "https://api.paymagic.co/p2p-svc/api/v2/transaction/ext/im/status-check",
    PAYMAGIC_CLIENT_ID: "92163539-7aef-47d0-9a5a-29571076817d", //6998dd0d-3eba-46ba-8677-1d8a46d37b73
    PAYMAGIC_SECRET_KEY: "c38e1375-ec11-4081-803e-cc3dae1e5fe8", //0e197eb1-7c05-41aa-93cd-70736580010f
};