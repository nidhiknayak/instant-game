var { UserDeviceTokens } = require('../models/UserDeviceTokens');
var AdminDeviceTokens = require('../models/AdminDeviceTokens');

const check_token = async function checkAuthToken(req, res, next) {
  if(typeof req.headers.authorization !== 'undefined'){
    var auth = req.headers.authorization;
    var parttwo = auth.split(' ');
    if(typeof parttwo[1] !== 'undefined'){
      var token = parttwo[1];
      let condition = { auth_token:token };
      var user_token = await UserDeviceTokens.where(condition).findOne().populate({path:'user_id'});
      if(user_token === null){
        return res.send({status:0,message:'Invalid Token'});
      }else{
        req.userDet = user_token.user_id;
        if (req.userDet.status == 0){
          return res.status(501).send({ status: 0, message: 'User Is InActive, Not Allowed To Procced Further', data: {} });
        }
        req.authToken = token;
        next();
      }
    } else {
        return res.send({status:0,message:'Unauthenticated',data:{}});
    }
  } else {
    return res.send({status:0,message:'Unauthenticated',data:{}});
  }
}
const check_token_admin = async function checkAuthToken(req, res, next) {
  if(typeof req.headers.authorization !== 'undefined'){
    var auth = req.headers.authorization;
    var parttwo = auth.split(' ');
    if(typeof parttwo[1] !== 'undefined'){
      var token = parttwo[1];
      let condition = { auth_token:token };
      var user_token = await AdminDeviceTokens.where(condition).findOne().populate({path:'admin_id'});
      if(user_token === null){
        return res.send({status:0,message:'Invalid Token'});
      }else{
        req.userDet = user_token.admin_id;
        req.authToken = token;
        next();
      }
    } else {
        return res.send({status:0,message:'Unauthenticated',data:{}});
    }
  } else {
    return res.send({status:0,message:'Unauthenticated',data:{}});
  }
}
module.exports = {check_token,check_token_admin};