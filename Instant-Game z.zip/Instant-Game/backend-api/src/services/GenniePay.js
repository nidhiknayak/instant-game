
const Withdrawals = require('../models/Withdraw');
const Axios = require('axios');
const { GENNIEPAY_ENDPOINT, GENNIEPAY_ENDPOINT_PAYOUT, GENNIEPAY_CLIENT_ID, GENNIEPAY_SECRET_KEY } = require('./constant');
const { generateMerRefCode, getDateFormat, getTimeFormatAmPm } = require('./common');
const Users = require('../models/Users');
const GenniePayCreateURLLogs = require('../models/GenniePayCreateURLLogs');
const { webhookLog } = require('./JsonOpr');
/* GenniePay Start */
const getPayHeaders = () => {
    return {
      headers: {
        "Accept": "application/json",
        "content-Type": "application/json",
        "secret-key": GENNIEPAY_SECRET_KEY,
        "client-id": GENNIEPAY_CLIENT_ID
      },
    };
  };
async function doTransfer(userBank, amount, user_id, with_id) {
    try {
        // return { status: 1, message: 'Fund Transfer Successfully', data: {} };
        //amount = 10;
        const userDetail = await Users.findOne({ _id: user_id });
        let merchant_reference_number = `GNPU${generateMerRefCode()}`;
        amount = parseFloat(amount).toFixed(2);
        const account_name = userBank.user_name.trim();//'Mr. ABC XYZ PQR';
        const account_number = userBank.acc_no;//'01234567980';
        const ifsc_code = userBank.ifsc_code;//'SBIN0060471';
        
        const customerMobile = userDetail?.mobile_no || "9876543210";
        const body = {
          orderId: merchant_reference_number,
          customerMobile: customerMobile,
          beneIfscCode: ifsc_code,
          beneAccNo: account_number,
          amount: parseFloat(amount).toFixed(2),
          customerName: account_name,
          txnMode: "IMPS",
          remarks: `Payment ${merchant_reference_number} Of Customer ${customerMobile}`
        };
        // return { status: 0, message: "Function called", data: body };
        const log = {
          time: getDateFormat() + ' ' + getTimeFormatAmPm(),
          dateTime: new Date(),
          body: body
        }
        return await Axios.post(`${GENNIEPAY_ENDPOINT_PAYOUT}/api/v1/transaction/ext/initiate`, body, getPayHeaders()).
            then((resu) => resu.data).
            then(async resu => {
              log.responseTime = new Date();
              log.responseType = "Then";
              log.response = resu;
              webhookLog(JSON.stringify(log), "pay-out", 'gennie-pay-payout-initiate');
                console.log("resu", resu);
                if(typeof resu?.Error !== 'undefined'){
                    return { status: 0, message: resu?.Error, data: resu };
                } else if (resu?.status == "ERROR") {
                    return { status: 0, message: resu?.message, data: resu };
                } else if (resu?.status == "OK") {
                    const transaction_id = resu?.data?.txnid || resu?.data?.txnId;
                    const tnx = resu?.data?.utr || null;
                    const merRefNo = merchant_reference_number;
                    const params = { merRefNo: merRefNo, transaction_id: transaction_id };
                    const update2 = { merchant_ref_no: merRefNo, transaction_id: transaction_id, tnx: tnx };
                    if (resu?.data?.txnStatus == "SUCCESS") {
                      update2.status = 1;
                      await Withdrawals.updateOne({ _id: with_id },update2);
                      return { status: 1, message: 'Fund Transfer Successfully', data: { result: resu, params: params } };
                    } else if (resu?.data?.txnStatus == "INITIATED" || resu?.data?.txnStatus == "PENDING"){
                      update2.status = 4;
                      await Withdrawals.updateOne({ _id: with_id }, update2);
                      return { status: 1, message: 'Fund Transfer Processing', data: { result: resu, params: params } };
                    } else {
                      update2.status = 3;
                      await Withdrawals.updateOne({ _id: with_id }, update2);
                      return { status: 1, message: 'Fund Transfer Failed', data: { result: resu, params: params } };
                    }
                } else {
                    return { status: 0, message: "Something Went Wrong, Try Again", data: {} };
                }
            }).catch(error => {
              log.responseTime = new Date();
              log.responseType = "Catch";
              log.response = error?.message;
              webhookLog(JSON.stringify(log), "pay-out", 'gennie-pay-payout-initiate');
              console.log(62,error);
              return { status: 0, message: error.message, data: {} };
            })
            
        //return { status: 1, message: 'Fund Transfer Successfully ', data: {} };
    } catch (error) {
        console.log(73, error);
        return { status: 0, message: error.message, data: {} };
    }
}
async function checkTransferStatus(withData) {
  try {
      const with_id = withData?._id;
      let order_id = withData.merchant_ref_no;//.transaction_id;
      if (!order_id){
        return { status: 0, message: 'Transaction No. Not Found', data: {} };
      }
      
      const body = {
        orderId: order_id
      };
      const log = {
        time: getDateFormat() + ' ' + getTimeFormatAmPm(),
        dateTime: new Date(),
        body: body
      }
      return await Axios.post(`${GENNIEPAY_ENDPOINT_PAYOUT}/api/v1/transaction/ext/status-check`, body, getPayHeaders()).
        then((resu) => resu.data).
        then(async resu => {
          log.responseTime = new Date();
          log.responseType = "Then";
          log.response = resu;
          webhookLog(JSON.stringify(log), "pay-out", 'gennie-pay-payout-status-check');
            if (typeof resu?.Error !== 'undefined') {
                return { status: 0, message: resu?.Error, data: resu };
            } else if (resu.success && resu.status == "OK") {
                const merRefNo = resu.data.orderId;
                const transaction_id = resu?.data?.txnid || resu?.data?.txnId;
                const utr = resu?.data?.utr;
                const params = { merRefNo: merRefNo, transaction_id: transaction_id, utr: utr };
                if (resu.data.txnStatus == "SUCCESS") {
                  const update2 = { status: 1 };
                  if(!withData?.transaction_id){
                    update2.transaction_id = transaction_id;
                  }
                  if(!withData?.tnx){
                    update2.tnx = utr;
                  }
                  await Withdrawals.updateOne({ _id: with_id }, update2);
                  return { status: 1, message: 'Fund Transfer Successfully', data: { result: resu, params: params } };
                } else if (resu.data.txnStatus == "PENDING") {
                  return { status: 1, message: 'Fund Transfer Processing', data: { result: resu, params: params } };
                } else if (resu.data.txnStatus == "FAILED") {
                  const update2 = { status: 3 };
                  await Withdrawals.updateOne({ _id: with_id }, update2);
                  return { status: 1, message: 'Fund Transfer Failed', data: { result: resu, params: params } };
                }
            } else {
                return { status: 0, message: 'Something Went Wrong', data: resu };
            }
        }).catch(error => {
          log.responseTime = new Date();
          log.responseType = "Catch";
          log.response = error?.message;
          webhookLog(JSON.stringify(log), "pay-out", 'gennie-pay-payout-status-check');
          return { status: 0, message: error.message, data: {} };
        });
  } catch (error) {
      return { status: 0, message: error?.message, data: {} }
  }
}
/* GenniePay End */

const generatePaymentIntent = async (amount, user_id = null, mobile_no = '', firstname = '', upi_id = '') => {
  try {
    //return { status: 1, message: "Get Payment Status Successfully", data: transaction_id };
    const merRefNoGen = generateMerRefCode();
    const transaction_id = `GNPI${merRefNoGen}`;
    const body = {
      orderId: transaction_id,
      amount: parseFloat(amount).toFixed(2)
    };
    const used_method = upi_id ? "COLLECT" : "INTENT";
    let apiUrl = "api/v1/payin/ext/txn/initiate";
    if(used_method == "COLLECT"){
      apiUrl = "api/v1/payin/ext/txn/initiate/collect";
      body.customerName = firstname;
      body.upiId = upi_id;
      body.remarks = mobile_no;
    }
    const insert = { amount, transaction_id, user_id, requestBody: body, upi_id: upi_id || null, used_method };
    return await Axios.post(`${GENNIEPAY_ENDPOINT}/${apiUrl}`, body, getPayHeaders()).
      then((resu) => resu.data).
      then(async resu => {
        console.log("response "+apiUrl+" resu", resu);
        insert.message = resu?.message || "Generated";
        insert.is_created = resu?.statusCode == 200 ? true : false;
        insert.resp = resu;
        GenniePayCreateURLLogs.create(insert);
        if(resu?.statusCode == 200){
          if(resu?.data?.paymentUrl){
            resu.data.paymentUrl = `${resu.data.paymentUrl}&tn=${transaction_id}`;
          }
          return { status: 1, message: "Payment intent generated Success", data: resu };
        } else {
          return { status: 0, message: resu?.message || "Error while generate intent", data: resu };
        }
      }).catch(error => {
        console.log("generatePaymentIntent catch error", error?.response?.data);
        insert.is_created = false;
        insert.message = error?.response?.data?.message || error?.message;
        if(error?.response?.data){
          insert.resp = error?.response?.data;
        }
        GenniePayCreateURLLogs.create(insert);
        return { status: 0, message: error?.message, data: error };
      });
  } catch (error) {
    return { status: 0, message: error.message, data: error }
  }
}
const checkPaymentStatus = async (transaction_id = '', order_id = '') => {
   try {
    //return { status: 1, message: "Get Payment Status Successfully", data: transaction_id };
    const body = { orderId: transaction_id };
    return await Axios.post(`${GENNIEPAY_ENDPOINT}/api/v1/payin/ext/txn/status`, body, getPayHeaders()).
      then((resu) => resu.data).
      then(async resu => {
        console.log("checkPaymentStatus GENNIEPAY resu", resu);
        if(resu.success){
          const resp = resu.data;
          if(resp.status == "Success"){
            return { status: 1, message: "Payment Is Success", data: { ...resp, utr: resp?.transactionRefId || null } };
          } else if(resp.status == "Pending" || resp.status == "Initiated"){
            return { status: 2, message: "Payment Is In Progress", data: { ...resp, utr: resp?.transactionRefId || null } };
          } else if(resp.status == "Failed"){
            return { status: 3, message: "Payment Is Failed", data: { ...resp, utr: resp?.transactionRefId || null } };
          }
        } else {
          return { status: 0, message: resu.message, data: resu };
        }
        
      }).catch(error => {
        console.log("catch error", error?.response?.data);
        if(error?.response?.data?.message == "UPI_TRANSACTION_NOT_FOUND"){
          const resp = error?.response?.data;
          return { status: 2, message: "Payment Is In Progress", data: { ...resp, utr: resp?.transactionRefId || null } };
        }
        return { status: 0, message: error.message, data: error };
      });
  } catch (error) {
    return { status: 0, message: error.message, data: error }
  }
}
module.exports = { doTransfer, checkTransferStatus, generatePaymentIntent, checkPaymentStatus };