
const Axios = require('axios');
const FormData = require('form-data');
const Withdrawals = require('../models/Withdraw');
const { ANILEX_ENDPOINT, ANILEX_TOKEN } = require('./constant');
const { generateMerRefCode } = require('./common');
const LetspayCreateURLLogs = require('../models/LetspayCreateURLLogs');
const Users = require('../models/Users');
/* GenniePay Start */
const getPayHeaders = (formData) => {
    return {
      headers: {
        ...formData.getHeaders(),
        "Token": ANILEX_TOKEN
      },
    };
  };
async function doTransfer(userBank, amount, user_id, with_id) {
  try {
    // return { status: 1, message: 'Fund Transfer Successfully', data: {} };
    //amount = 10;
    const userDetail = await Users.findOne({ _id: user_id });
    const merRefNoGen = generateMerRefCode(17);
    let merchant_reference_number = `TNX${merRefNoGen}`;//'Mr. ABC XYZ PQR';
    amount = parseFloat(amount).toFixed(2);
    const account_name = userBank.user_name.trim();//'Mr. ABC XYZ PQR';
    const bank_name = userBank.bank_name.trim();//ICICI;
    const account_number = userBank.acc_no;//'01234567980';
    const ifsc_code = userBank.ifsc_code;//'SBIN0060471';
    
    let formData = new FormData();
    formData.append('transaction_id', merchant_reference_number);
    formData.append('account_holder_name', account_name);
    formData.append('bank_name', bank_name);
    formData.append('account_number', account_number);
    formData.append('ifsc_code', ifsc_code);
    formData.append('mobile_number', userDetail?.mobile_no || "9876543210");
    formData.append('email', "payment@test.com");
    formData.append('amount', amount);
    
    return await Axios.post(`${ANILEX_ENDPOINT}/api/v1/upi/upiPayoutAuth`, formData, getPayHeaders(formData)).
      then((resu) => resu.data).
      then(async resu => {
        console.log("upiPayoutAuth resu before", resu);
        // resu = JSON.parse(resu);
        // console.log("upiPayoutAuth resu after", resu);
        if(typeof resu?.Error !== 'undefined'){
          return { status: 0, message: resu?.Error, data: resu };
        } else if (resu?.txn_status == "ERROR") {
          return { status: 0, message: resu?.message, data: resu };
        } else if (resu?.txn_status) {
          const transaction_id = resu?.utr;
          const merRefNo = merchant_reference_number;
          const params = { merRefNo: merRefNo, transaction_id: transaction_id };
          const update2 = { merchant_ref_no: merRefNo, transaction_id: transaction_id };
          if (resu?.txn_status == "SUCCESS") {
            update2.status = 1;
            await Withdrawals.updateOne({ _id: with_id },update2);
            return { status: 1, message: 'Fund Transfer Successfully', data: { result: resu, params: params } };
          } else if (resu?.txn_status == "FAILED") {
            // update2.status = 3;
            await Withdrawals.updateOne({ _id: with_id }, { status: 3 });
            return { status: 1, message: 'Fund Transfer Failed', data: { result: resu, params: params } };
          } else {
            update2.status = 4;
            await Withdrawals.updateOne({ _id: with_id }, update2);
            return { status: 1, message: 'Fund Transfer Processing', data: { result: resu, params: params } };
          }
        } else {
          return { status: 0, message: "Something Went Wrong, Try Again", data: {} };
        }
      }).catch(error => {
        console.log("upiPayoutAuth error 69 ::", error?.message, error);
        return { status: 0, message: error.message, data: {} };
      })
  } catch (error) {
    console.log(72, error);
    return { status: 0, message: error.message, data: {} };
  }
}
async function checkTransferStatus(withData) {
  try {
    const with_id = withData?._id;
    let order_id = withData.merchant_ref_no;//.transaction_id;
    if (!order_id){
      return { status: 0, message: 'Transaction No. Not Found', data: {} };
    }
    
    let formData = new FormData();
    formData.append('transaction_id', order_id);
    console.log("ANILEX_ENDPOINT", `${ANILEX_ENDPOINT}/api/v1/upi/upiPayoutTxnCheck`);
    return await Axios.post(`${ANILEX_ENDPOINT}/api/v1/upi/upiPayoutTxnCheck`, formData, getPayHeaders(formData)).
      then((resu) => resu.data).
      then(async resu => {
        console.log("upiPayoutTxnCheck response", resu);
        // resu = JSON.parse(resu);
        if (typeof resu?.Error !== 'undefined') {
            return { status: 0, message: resu?.Error, data: resu };
        } else if (resu?.txn_status) {
          const merRefNo = resu.transaction_id;
          const transaction_id = resu.utr;
          const params = { merRefNo: merRefNo, transaction_id: transaction_id };
          if (resu.txn_status == "SUCCESS") {
            const update2 = { status: 1 };
            await Withdrawals.updateOne({ _id: with_id }, update2);
            return { status: 1, message: 'Fund Transfer Successfully', data: { result: resu, params: params } };
          } else if (resu.txn_status == "FAILED") {
            const update2 = { status: 3 };
            await Withdrawals.updateOne({ _id: with_id }, update2);
            return { status: 1, message: 'Fund Transfer Failed', data: { result: resu, params: params } };
          } else {
            return { status: 1, message: 'Fund Transfer Processing', data: { result: resu, params: params } };
          }
        } else {
          return { status: 0, message: 'Something Went Wrong', data: resu };
        }
      }).catch(error => {
        return { status: 0, message: error.message, data: {} };
      });
  } catch (error) {
    return { status: 0, message: error?.message, data: {} }
  }
}
/* GenniePay End */

const generatePaymentIntent = async (amount, user_id = null) => {
  try {
    //return { status: 1, message: "Get Payment Status Successfully", data: transaction_id };

    const merRefNoGen = generateMerRefCode(16);
    const transaction_id = `TNX${merRefNoGen}`;//'Mr. ABC XYZ PQR';
    let formData = new FormData();
    formData.append('transaction_id', transaction_id);
    formData.append('name', "Test User");
    formData.append('email', "payment@test.com");
    formData.append('mobile', "9876543210");
    formData.append('amount', amount);
    // console.log("formData", formData);
    // console.log("getPayHeaders", getPayHeaders());
    // console.log("ANILEX_ENDPOINT", `${ANILEX_ENDPOINT}/api/v1/upi/upiQrGenerateAuth`);
    const insert = {
      amount,
      transaction_id,
      user_id
    };
    return await Axios.post(`${ANILEX_ENDPOINT}/api/v1/upi/upiQrGenerateAuth`, formData, getPayHeaders(formData)).
      then((resu) => resu.data).
      then(async resu => {
        console.log("response upiQrGenerateAuth resu", resu);
        insert.message = resu?.status_msg || "Generated";
        insert.is_created = resu?.status_code == 1 ? true : false;
        insert.resp = resu;
        LetspayCreateURLLogs.create(insert);
        // resu = JSON.parse(resu);
        if(resu?.status_code == 1){
          return { status: 1, message: "Payment intent generated Success", data: resu };
        } else {
          return { status: 0, message: resu?.status_msg || "Error while generate intent", data: resu };
        }
      }).catch(error => {
        insert.is_created = false;
        insert.message = error?.message;
        LetspayCreateURLLogs.create(insert);
        return { status: 0, message: error?.message, data: error };
      });
  } catch (error) {
    return { status: 0, message: error.message, data: error }
  }
}
const checkPaymentStatus = async (transaction_id = '') => {
  try {
    //return { status: 1, message: "Get Payment Status Successfully", data: transaction_id };
    let formData = new FormData();
    formData.append('transaction_id', transaction_id);
    return await Axios.post(`${ANILEX_ENDPOINT}/api/v1/upi/upiTxnStatusCheck`, formData, getPayHeaders(formData)).
      then((resu) => resu.data).
      then(async resu => {
        // resu = JSON.parse(resu);
        if(resu?.status_code == 1){
          if(resu.txn_status == "SUCCESS"){
            return { status: 1, message: "Payment Is Success", data: resu };
          } else if(resu.txn_status == "PENDING" || resu.txn_status == "PROCESSING"){
            return { status: 2, message: "Payment Is In Progress", data: resu };
          } else if(resu.txn_status == "FAILED"){
            return { status: 3, message: "Payment Is Failed", data: resu };
          }
        } else {
          return { status: 0, message: resu.message, data: resu };
        }
      }).catch(error => {
        return { status: 0, message: error.message, data: error };
      });
  } catch (error) {
    return { status: 0, message: error.message, data: error }
  }
}
module.exports = {
  doTransfer,
  checkTransferStatus,
  generatePaymentIntent,
  checkPaymentStatus,
};