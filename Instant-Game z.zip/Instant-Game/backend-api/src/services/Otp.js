const Axios = require('axios');
function getOtpConfig() {
    /* api_key: 'ins2h3ekgNM27KSui4fB0JhpuqsxgHfL290KL2v4',
        sender_id: 'NCVSOL',
        te_id: '1507163913178810309', */
    /* let confArr = {
        api_key: 'Bc42n9v9fi01iYWNF0MjZN4uRlkJOh9VYCI08OxP',
        sender_id: 'LPETPS',
        te_id: '1507166313056655296',
    }; */
    //https://app.a2zsms.in/api/v1/send-sms?api-key=X5MoV0N3KXM49Tb7mKND4ENxs8MzASV3IgTMtK8K&sender-id=SRICHW&sms-type=1&mobile=8431086185&te_id=1207170133662693931&message=Your
    return {
        api_key: 'X5MoV0N3KXM49Tb7mKND4ENxs8MzASV3IgTMtK8K',
        sender_id: 'SRICHW',
        te_id: '1207170133662693931',
    };
}
function msgOtp(otp, signature = "") {
    return 'Your INSTANT OTP is: '+otp+' *Note: Please DO NOT SHARE this OTP with anyone. SRICHW technologies'; // '+signature
}
async function sentOtp(mobile_no, msg) {
    try {
        // return { status: 1, message: 'OTP Sent Successfully', data: { msg_id: "1234" } };
        let config = getOtpConfig();
        let api_key = config.api_key;
        let sender_id = config.sender_id;
        let te_id = config.te_id;
        let message = msg;

        let body = { 'api-key': api_key, 'sender-id': sender_id, 'sms-type': 1, 'mobile': mobile_no, 'te_id': te_id, 'message': message };
        //return { status: 1, message: 'OTP Successfully', data: { body: body } };
        let sUrl = 'https://app.a2zsms.in/api/v1/send-sms?api-key=' + api_key + '&sender-id=' + sender_id + '&sms-type=1&mobile=' + mobile_no + '&te_id=' + te_id + '&message=' + message;
        return await Axios.get(sUrl).
            then((resu) => resu.data).
            then(async resu => {
                console.log("send otp :: ",resu);
                return { status: 1, message: 'OTP Sent Successfully', data: {msg_id:resu} };
                if (typeof resu.error !== 'undefined' && resu.error.code > 0) {
                    return { status: 0, message: resu.error.message, data: resu };
                } else if (typeof resu.data !== 'undefined') {
                    if (resu.data.status == "SUCCESS") {
                        let params = {  };
                        return { status: 1, message: 'OTP Sent Successfully', data: { result: resu, params: params } };
                    } else if (resu.data.status == "PROCESSING") {
                        let params = {  };
                        return { status: 1, message: 'OTP Processing', data: { result: resu, params: params } };
                    }
                } else {
                    return { status: 0, message: "Something Went Wrong, Try Again", data: {} };
                }
            }).catch(error => {
                console.log("send otp error :: ", 55, error);
                return { status: 0, message: error.message, data: {} };
            })
            
        //return { status: 1, message: 'Fund Transfer Successfully ', data: {} };
    } catch (error) {
        console.log(73, error);
        return { status: 0, message: error.message, data: {} };
    }
}
module.exports = {
    sentOtp, msgOtp
};