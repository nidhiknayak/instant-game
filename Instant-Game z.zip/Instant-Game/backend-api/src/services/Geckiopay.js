const FormData = require('form-data');
const Withdrawals = require("../models/Withdraw");
var { UserBanks } = require("../models/UserBanks");
const Users = require('../models/Users');
const GeckiopayCreateURLLogs = require('../models/GeckiopayCreateURLLogs');
const { generateMerRefCodeNumeric } = require("./common");
const Axios = require("axios");
const { GECKIOPAY_ENDPOINT, GECKIOPAY_API_KEY, GECKIOPAY_API_TOKEN } = require("./constant");

const getHeaders = (formData) => {
  return {
    headers: {
      ...formData.getHeaders(),
      /* Accept: "application/json",
      "content-Type": "application/json", */
      "Apikey": GECKIOPAY_API_KEY,
      "Apitoken": GECKIOPAY_API_TOKEN
    },
  };
};
async function doTransfer(userBank, amount, user_id, with_id) {
  try {
    // return { status: 1, message: 'Fund Transfer Successfully', data: {} };
    //amount = 10;
    const userDetail = await Users.findOne({ _id: user_id });

    // const merchantReferenceMumber = `GCKPT${generateMerRefCodeNumeric()}`;
    const merchantReferenceMumber = generateMerRefCodeNumeric();
    amount = parseFloat(amount).toFixed(2);
    
    const account_name = userBank.user_name.trim(); //'Mr. ABC XYZ PQR';
    const bank_name = userBank.bank_name.trim(); //State Bank Of India;
    const account_number = userBank.acc_no; //'01234567980';
    const ifsc_code = userBank.ifsc_code; //'SBIN0060471';

    const body = {
      reference_no: merchantReferenceMumber,
      customer_name: `${userDetail?.mobile_no} ${account_name}`,
      bank_name: bank_name,
      account_number: account_number,
      ifsc_code: ifsc_code,
      customer_number: userDetail?.mobile_no || "9876543210",
      customer_email : "test@test.com",
      amount: amount /* (Minimum 100) */
    };
    let formData = new FormData();
    for (const [key, value] of Object.entries(body)) {
      formData.append(key, value);
    }
    /* formData.append('reference_no', merchantReferenceMumber);
    formData.append('customer_name', account_name);
    formData.append('bank_name', bank_name);
    formData.append('account_number', account_number);
    formData.append('ifsc_code', ifsc_code);
    formData.append('customer_number', userDetail?.mobile_no || "9876543210");
    formData.append('customer_email', "test@test.com");
    formData.append('amount', amount); */
    // return { status: 0, message: "Function called", data: body };
    return await Axios.post(`${GECKIOPAY_ENDPOINT}/payoutRequestAuth`, formData, getHeaders(formData))
      .then((resu) => resu.data)
      .then(async (resu) => {
        console.log("resu", resu);
        if (resu?.response_code == 401) {
          return { status: 0, message: resu?.response_msg || "Error occured while withdrawal", data: resu };
        }
        if (resu?.response_code == 200) {
          if (resu?.txn_status == "SUCCESS") {
            const transaction_id = resu?.rrn_no;
            const merRefNo = resu?.reference_no;
            const params = { merRefNo: merRefNo, transaction_id: transaction_id };
            const update2 = { merchant_ref_no: merRefNo, transaction_id: transaction_id, status: 1 };
            await Withdrawals.updateOne({ _id: with_id }, update2);
            return { status: 1, message: "Fund Transfer Successfully", data: { result: resu, params: params } };
          } else if (resu?.txn_status == "PENDING" || resu?.txn_status == "FAILED") {
            const transaction_id = resu?.rrn_no;
            const merRefNo = resu?.reference_no;
            const params = { merRefNo: merRefNo, transaction_id: transaction_id };
            const update2 = { merchant_ref_no: merRefNo, transaction_id: transaction_id, status: resu?.txn_status == "PENDING" ? 4 : 3 };
            await Withdrawals.updateOne({ _id: with_id }, update2);
            return { status: 1, message: "Fund Transfer Processing", data: { result: resu, params: params } };
          } else {
            return { status: 0, message: "Something Went Wrong, Try Again", data: {} };
          }
        }
      })
      .catch((error) => {
        console.log("payoutRequestAuth 75 => ", error);
        return { status: 0, message: error.message, data: {} };
      });
    //return { status: 1, message: 'Fund Transfer Successfully ', data: {} };
  } catch (error) {
    console.log(73, error);
    return { status: 0, message: error.message, data: {} };
  }
}

async function checkTransferStatus(withData) {
  try {
    // return { status: 1, message: 'Fund Transfer Successfully', data: {} };
    const with_id = withData?._id;
    const reference_no = withData.merchant_ref_no;
    if (!reference_no) {
      return { status: 0, message: "Transaction No. Not Found", data: {} };
    }

    const body = { reference_no: reference_no };
    let formData = new FormData();
    for (const [key, value] of Object.entries(body)) {
      formData.append(key, value);
    }
    // formData.append('reference_no', reference_no);

    return await Axios.post(`${GECKIOPAY_ENDPOINT}/payoutCheckStatus`, formData, getHeaders(formData))
      .then((resu) => resu.data)
      .then(async (resu) => {
        if (resu.response_code == 200) {
          const merRefNo = resu.reference_no;
          const transaction_id = resu?.rrn_no;
          const params = { merRefNo: merRefNo, transaction_id: transaction_id };
          if (resu.txn_status == "SUCCESS") {
            const update2 = { status: 1, tnx: transaction_id };
            await Withdrawals.updateOne({ _id: with_id }, update2);
            return { status: 1, message: "Fund Transfer Successfully", data: { result: resu, params: params } };
          } else if (resu.txn_status == "FAILED") {
            const update2 = { status: 3, tnx: transaction_id };
            await Withdrawals.updateOne({ _id: with_id }, update2);
            return { status: 0, message: "Fund Transfer Failed", data: { result: resu, params: params } };
          } else if (resu.txn_status == "PENDING") {
            return { status: 1, message: "Fund Transfer Processing", data: { result: resu, params: params } };
          }
        } else {
          return { status: 0, message: "Something Went Wrong", data: resu };
        }
      })
      .catch((error) => {
        return { status: 0, message: error.message, data: {} };
      });
  } catch (error) {
    return { status: 0, message: error?.message, data: {} };
  }
}

const generatePaymentIntent = async (amount, user_id = null, mobile_no = '', firstname = '') => {
  try {
    //return { status: 1, message: "Get Payment Status Successfully", data: transaction_id };
    const merRefNoGen = generateMerRefCodeNumeric();
    // const transaction_id = `GCKPAY${merRefNoGen}`;
    const transaction_id = merRefNoGen;
    const body = {
      reference_no: transaction_id,
      // name: `${firstname ? `${firstname}` :  `Instant ${mobile_no}`}`,
      name: "InstantUser",
      email: "test@test.com",
      mobile: mobile_no,
      amount: amount /* (Minimum 40) */
    };
    let formData = new FormData();
    for (const [key, value] of Object.entries(body)) {
      formData.append(key, value);
    }
    /* formData.append('reference_no', transaction_id);
    // formData.append('name', `${firstname ? `${firstname}` :  `Instant User`}`);
    formData.append('name', "InstantUser");
    formData.append('email', "test@test.com");
    formData.append('mobile', mobile_no);
    formData.append('amount', amount); */
    const insert = { amount, transaction_id, user_id, requestBody: body };
    return await Axios.post(`${GECKIOPAY_ENDPOINT}/payinOrderGenerate`, formData, getHeaders(formData)).
      then((resu) => resu.data).
      then(async resu => {
        console.log("response payinOrderGenerate resu", resu);
        insert.message = resu?.response_msg || "Generated";
        insert.is_created = resu?.response_code == 200 ? true : false;
        insert.resp = resu;
        GeckiopayCreateURLLogs.create(insert);
        if(resu?.response_code == 200){
          return { status: 1, message: "Payment intent generated Success", data: resu };
        } else {
          return { status: 0, message: resu?.response_msg || "Error while generate intent", data: resu };
        }
      }).catch(error => {
        insert.is_created = false;
        insert.message = error?.message;
        GeckiopayCreateURLLogs.create(insert);
        return { status: 0, message: error?.message, data: error };
      });
  } catch (error) {
    return { status: 0, message: error.message, data: error }
  }
}
async function checkPaymentStatus(tnxId) {
  try {
    // return { status: 1, message: 'Fund Transfer Successfully', data: {} };
    if (!tnxId) {
      return { status: 0, message: "Transaction No. Not Found", data: {} };
    }
    
    const body = { reference_no: tnxId };
    let formData = new FormData();
    for (const [key, value] of Object.entries(body)) {
      formData.append(key, value);
    }
    // formData.append('reference_no', tnxId);
    return await Axios.post(`${GECKIOPAY_ENDPOINT}/payinOrderCheckStatus`, formData, getHeaders(formData))
      .then((resu) => resu.data)
      .then(async (resu) => {
        console.log("resu Geckiopay checkPaymentStatus ==> ", resu);
        if (resu.response_code == 200) {
          if (resu.txn_status == "SUCCESS") {
            return { status: 1, message: "Payment Successfully", data: { ...resu, utr: resu?.rrn_no || null } };
          } else if (resu.txn_status == "PENDING") {
            return { status: 2, message: "Payment Processing", data: { ...resu, utr: resu?.rrn_no || null } };
          } else if (resu.txn_status == "FAILED") {
            return { status: 3, message: "Payment Failed", data: { ...resu, utr: resu?.rrn_no || null } };
          }
        } else {
          return { status: 0, message: resu?.response_msg || "Something Went Wrong", data: resu };
        }
      })
      .catch((error) => {
        return { status: 0, message: error.message, data: {} };
      });
  } catch (error) {
    return { status: 0, message: error?.message, data: {} };
  }
}

module.exports = { doTransfer, checkTransferStatus, generatePaymentIntent, checkPaymentStatus };
