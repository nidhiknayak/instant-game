/**
 * npm i googleapis "googleapis": "^144.0.0",
 * Firebase Cloud Messaging (FCM) can be used to send messages to clients on Android
 */
/* 
const { sendFcmMessage } = require('./firebase');

const sendData = {
            'message': {
              'topic': "instant567Dev", //"instant567",
              'notification': {
                'title': data.title,
                'body': data.body,
                'image': data.image
              }
            }
        };
        return sendFcmMessage(sendData);
*/
const Axios = require('axios');
const { google } = require('googleapis');
const accountDetail = require('../service-account.json');

const PROJECT_ID = accountDetail.project_id;
const HOST = 'fcm.googleapis.com';
const PATH = '/v1/projects/' + PROJECT_ID + '/messages:send';
const MESSAGING_SCOPE = 'https://www.googleapis.com/auth/firebase.messaging';
const SCOPES = [MESSAGING_SCOPE];

/**
 * Get a valid access token.
 */
// [START retrieve_access_token]
function getAccessToken() {
  return new Promise(function(resolve, reject) {
    const key = accountDetail;
    const jwtClient = new google.auth.JWT(
      key.client_email,
      null,
      key.private_key,
      SCOPES,
      null
    );
    jwtClient.authorize(function(err, tokens) {
      if (err) {
        reject(err);
        return;
      }
      resolve(tokens.access_token);
    });
  });
}
// [END retrieve_access_token]

/**
 * Send HTTP request to FCM with given message.
 *
 * @param {object} fcmMessage will make up the body of the request.
 * fcmMessage = {
    'message': {
      'topic': "instant567Dev", //"instant567",
      'notification': {
        'title': data.title,
        'body': data.body,
        'image': data.image
      }
    }
  }
 */
async function sendFcmMessage(fcmMessage) {
  console.log("fcmMessage", fcmMessage);
  return await getAccessToken().then(async function(accessToken) {
    console.log("accessToken", accessToken);
    const headers = {
      headers: {
        "Accept": "application/json",
        "content-Type": "application/json",
        'Authorization': `Bearer ${accessToken}`
      },
    };
    return await Axios.post(`https://${HOST}${PATH}`, fcmMessage, headers)
      .then((result) => result.data)
      .then(async data => {
        console.log('Message sent to Firebase for delivery, response:');
        console.log("Notification response", data);
        return { status: 1, message: 'Message sent to Firebase for delivery', data };
      })
      .catch(error => {
        console.log('Error while sending notification', error?.message);
        return { status: 0, message: error?.message || "Notification not sent", data: {} };
      })
  })
  .catch((err)=>{
    console.log('Error while generate token', err);
    return { status: 0, message: err?.message || "Error while generate token", data: {} };
  });
}

module.exports = { sendFcmMessage };