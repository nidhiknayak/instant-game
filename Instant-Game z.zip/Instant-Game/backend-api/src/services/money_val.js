var Settings = require('../models/Settings');

const getMoneyList = async () => {
    let DEPO_BONUS_AMT = 50;
    let MIN_DEPO_AMT   = 300;
    let REG_BONUS_AMT  = 100;
    let MIN_WITH_AMT   = 1000;
    let REFERRAL_BONUS_AMOUNT  = 101;
    let MIN_DEPO_AMT_FOR_BONUS  = 1000;
    const setting = await Settings.findOne();
    if (setting) {
        DEPO_BONUS_AMT = setting.deposit_bonus_amount;
        MIN_DEPO_AMT = setting.minimum_deposit_amount;
        REG_BONUS_AMT = setting.bonus_amount;
        MIN_WITH_AMT = setting.auto_withd_min_amount;
        REFERRAL_BONUS_AMOUNT = setting.referral_bonus_amount;
        MIN_DEPO_AMT_FOR_BONUS = setting.min_deposit_amount_for_bonus;
        return {
            MIN_DEPO_AMT: MIN_DEPO_AMT,
            DEPO_BONUS_AMT: DEPO_BONUS_AMT,
            REG_BONUS_AMT: REG_BONUS_AMT,
            MIN_WITH_AMT: MIN_WITH_AMT,
            REFERRAL_BONUS_AMOUNT: REFERRAL_BONUS_AMOUNT,
            MIN_DEPO_AMT_FOR_BONUS: MIN_DEPO_AMT_FOR_BONUS,
        };
    }
};
module.exports = {
    getMoneyList
};