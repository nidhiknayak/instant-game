// const db = require("../models");
var mongoose = require('mongoose');
const crypto = require("crypto");
const TokenGenerator = require('uuid-token-generator');
const Axios = require('axios');
// const UserModal = db.user;
var Users = require('../models/Users');
var { UserDeviceTokens } = require('../models/UserDeviceTokens');
var tokgenGenerator = new TokenGenerator(256, TokenGenerator.BASE62);
const { isValid } = require('../services/validation');
const Withdrawals = require('../models/Withdraw');
const Transactions = require('../models/Transactions');
const { convertToUTCNew, getDateFormat } = require('../services/common');
const Settings = require('../models/Settings');
const InnoPay = require('../models/InnoPay');

var { getMoneyList } = require('../services/money_val');
var { sentOtp, msgOtp } = require('../services/Otp');
var moment = require('moment');  
const { checkPaymentStatus } = require('../services/Withdraw');
const { UserBanks } = require('../models/UserBanks');
const { SWITCH_USER_UUID, SWITCH_TOKEN, SWITCH_ENDPOINT } = require('../services/constant');
const PaymentGateway = require('../models/PaymentGateway');
// const UserDeviceToken = db.user_device_token;
// const Item = db.item;
// const Op = db.Sequelize.Op;

exports.login = (req, res) =>{
	(async () => {
		try {
			if (!await isValid(req.body.mobile)) {
				return res.json({ status: 0, message: 'mobile is required' });
			}
			if (!await isValid(req.body.country_code)) {
				return res.json({ status: 0, message: 'country_code is required' });
			}
			const mobile = req.body.mobile;
			let country_code = req.body.country_code;
			var referral_code = req.body.referral_code ? req.body.referral_code : null;
			var device_token = req.body.token ? req.body.token : null;
			// const userQuery = Users.where();
			var user = await Users.findOne({ mobile_no: mobile });/* country_code:country_code,  */
			if(user){
				await UserDeviceTokens.deleteMany({ user_id: user.id });
				if(user.status == 0){
					return res.json({ status: 2, message: 'Your account is inactive. Not allow to login.'});
				}
				let auth_token = tokgenGenerator.generate();
				return new UserDeviceTokens({
					user_id: user._id,
					auth_token: auth_token,
					device_token: device_token
				}).save(async function(err, token){
					if (err) return res.json({ status: 0,message: err.message || "Cannot Login" });
					user.auth_token = auth_token;
					let resopnse = {
						_id : user._id,
						mobile_no : user.mobile_no,
						country_code : user.country_code,
						referral_code : user.referral_code,
						refer_by : user.refer_by,
						status : user.status,
						created_by : user.created_by,
						updated_by : user.updated_by,
						deleted_by : user.deleted_by,
						deleted : user.deleted,
						createdAt : user.createdAt,
						updatedAt : user.updatedAt,
						auth_token : auth_token,
					};
					return res.json({ status: 1, message: 'User Login Successfully', data: resopnse });
				})
			}else{
				var my_ref_code = generateCode(6);
				let exist_code = Users.findOne({referral_code:my_ref_code});
				if(exist_code){
					my_ref_code = generateCode(6);
				}
				let refeUser = await Users.findOne({ referral_code: referral_code });
				country_code = (typeof country_code == 'string' && country_code.slice(0, 1) == '+') ? country_code.substring(1): country_code;
				return new Users({
					country_code: country_code,
					mobile_no: mobile,
					refer_by: ((refeUser) ? refeUser._id:null),
					referral_code: my_ref_code/* ,
					email:null */ 
				}).save(async function(err, newuser){
					if (err) return res.json({ status: 0,message: err.message || "Cannot Register" });
					let auth_token = tokgenGenerator.generate();
					return new UserDeviceTokens({
						user_id: newuser._id,
						auth_token: auth_token,
						device_token: device_token
					}).save(async function(err, token){
						if (err) return res.json({ status: 0,message: err.message || "Cannot Login" });
						
						let resopnse = {
							_id: newuser._id,
							mobile_no: newuser.mobile_no,
							country_code: newuser.country_code,
							referral_code: newuser.referral_code,
							refer_by: newuser.refer_by,
							status: newuser.status,
							created_by: newuser.created_by,
							updated_by: newuser.updated_by,
							deleted_by: newuser.deleted_by,
							deleted: newuser.deleted,
							createdAt: newuser.createdAt,
							updatedAt: newuser.updatedAt,
							auth_token: auth_token,
						};
						/* if (refeUser){ */
							let settingDet = await getMoneyList();
							let REG_BONUS_AMT = settingDet.REG_BONUS_AMT;
							let bonus_amount = REG_BONUS_AMT;
							await new Transactions({
								user_id: newuser._id,
								amount: bonus_amount,
								final_amount: bonus_amount,
								post_balance: bonus_amount,
								tnx_type: 3,//added by self
								wallet_type: 2,//simple wallet
								details: "Bonus Credited",
								entry_type: 1,//credit entry
								created_by: newuser._id
							}).save(async function (err, transaction) {
								if (err) return res.json({ status: 0, message: err.message });
								console.log(99, 'Bonus Credited ' + newuser._id);
								await Users.updateOne({ _id: newuser._id }, { wallet: bonus_amount });
								return res.json({ status: 1, message: 'User Register Successfully', data: resopnse });
							});
							
						/* } else {
							return res.json({ status: 1, message: 'User Register Successfully', data: resopnse });
						} */
					})
				});
			}
		} catch (error) {
			console.log(132, error);
			return res.json({ status: 0, message: error.message,data:error });
		}
	})();
}
exports.logout = (req, res) =>{
	(async () => {
		try {
			var auth_token = req.authToken;
			var user= await UserDeviceTokens.findOne({ auth_token: auth_token});
			if (user) {
				await UserDeviceTokens.deleteMany({ auth_token: auth_token });
				res.json({ status: 1, message: "Logout Successfully", data: {} });
			} else {
				res.json({ status: 0, message: "Token Not Found", data: {} });
			}
		} catch (error) {
			console.log(error);
			return res.json({ status: 0, message: error });
		}
	})();
}
exports.verifyOtpOld = (req, res) =>{
	const mobile = req.body.mobile;
	const country_code = req.body.country_code;
	const otp = req.body.otp;
	var referral_code = referral_code ? referral_code : null;
	
	let condition = { country_code:country_code, mobile_no:mobile };
	UserModal.findOne({ where: condition})
	.then(data => {
		if(data === null){
      		res.send({status:0,msg:'User Not Found',data:{}});
		} else {
			let response = data.get();
			if(response.otp == otp){
				UserModal.update({otp:null, otp_sent_at:null},{where:{id:response.id}}).then(otpData=>{
					let auth_token = new TokenGenerator(256,TokenGenerator.BASE62);
					auth_token = auth_token.generate();
					var tokResp = UserDeviceToken.create({ user_id:response.id,auth_token:auth_token })
					.then(data2 => {
						response.auth_token = auth_token;
						response.otp = null;
						response.otp_sent_at = null;
						res.send({status:1,msg:'User Login Successfully',data:response});
					});
				}).catch(err => {
					res.status(500).send({
						message:
						err.message || "Cannot Set OTP"
					});
				});
			} else {
				res.send({status:0,msg:'Invalid OTP',data:{}});
			}
		}
	})
	.catch(err => {
		res.status(500).send({
			message:
			err.message || "Some error occurred while retrieving."
		});
	});
}
exports.getOtp = (req, res) => {
	(async () => {
		try {
			if (!await isValid(req.body.mobile)) {
				return res.json({ status: 0, message: 'mobile is required', data:{} });
			}
			if (!await isValid(req.body.country_code)) {
				return res.json({ status: 0, message: 'country_code is required', data:{} });
			}
			if (req.body.mobile.length < 10) {
				return res.json({ status: 0, message: 'mobile must have 10 digit', data:{} });
			}
			let mobile = req.body.mobile;
			const signature = req?.body?.signature;
			
			mobile = mobile.replace(/[^0-9]/g, '');
			if (mobile.length != 10){
				return res.json({ status: 0, message: 'invalid mobile no', data: { mobile: mobile } });
			}
			
			let country_code = req.body.country_code;
			var referral_code = req.body.referral_code ? req.body.referral_code : null;
			var is_new = req.body.is_new ? parseInt(req.body.is_new) : 0;
			var is_resend = req.body.is_resend ? parseInt(req.body.is_resend) : 0;
			var user = await Users.findOne({ mobile_no: mobile });/* country_code:country_code,  */
			let otp = await generateCode(4);
			// let otp = "1234";
			let msg = msgOtp(otp, signature);
			
			let otp_time = new Date();
			otp_time.setMinutes(otp_time.getMinutes() + 10);
			if (user) {
				if (user.status == 0) {
					return res.json({ status: 2, message: 'Your account is inactive. Not allow to login.' });
				}
				let isSent = await sentOtp(mobile,msg);
				
				// let msg_id = await generateCode(12);
				// let isSent = { status: 1, message: 'OTP Sent Successfully', data: { msg_id:msg_id } };
				
				// let isSent = { status: 1, message: 'OTP Sent Successfully', data: { otp: otp } };
				if (isSent.status == 1){
					let update = { otp: otp, otp_time: otp_time };
					await Users.updateOne({_id:user._id},update);
					isSent.data.is_new = 0;
					if (is_resend == 1){
						isSent.data.is_new = is_new;
					}
					if (user.is_otp_verified == 0){
						isSent.data.is_new = 1;
					}
					return res.json(isSent);
				} else {
					isSent.data.is_new = 0;
					if (is_resend == 1) {
						isSent.data.is_new = is_new;
					}
					if (user.is_otp_verified == 0) {
						isSent.data.is_new = 1;
					}
					return res.json(isSent);
				}
			} else {
				var my_ref_code = generateCode(6);
				let exist_code = await Users.findOne({ referral_code: my_ref_code });
				if (exist_code) {
					my_ref_code = generateCode(6);
				}
				let refeUser = null;
				if(referral_code){
					refeUser = await Users.findOne({ referral_code: referral_code });
				}
				
				country_code = (typeof country_code == 'string' && country_code.slice(0, 1) == '+') ? country_code.substring(1) : country_code;
				return new Users({
					country_code: country_code,
					mobile_no: mobile,
					refer_by: ((refeUser) ? refeUser._id : null),
					referral_code: my_ref_code,
					otp: otp,
					otp_time: otp_time
				}).save(async function (err, newuser) {
					if (err) return res.json({ status: 0, message: err.message || "Cannot Register",data:error });
					let isSent = await sentOtp(mobile, msg);
					// let msg_id = await generateCode(12);
					// let isSent = { status: 1, message: 'OTP Sent Successfully', data: { msg_id:msg_id } };


					//let isSent = { status: 1, message: 'OTP Sent Successfully', data: { otp: otp } };
					isSent.data.is_new = 1;
					return res.json(isSent);
				});
			}
		} catch (error) {
			console.log(206, error);
			return res.json({ status: 0, message: error.message, data: error });
		}
	})();
}
exports.verifyOtp = (req, res) => {
	(async () => {
		try {
			if (!await isValid(req.body.mobile)) {
				return res.json({ status: 0, message: 'mobile is required' });
			}
			if (!await isValid(req.body.country_code)) {
				return res.json({ status: 0, message: 'country_code is required' });
			}
			if (!await isValid(req.body.is_new)) {
				return res.json({ status: 0, message: 'is new is required' });
			}
			if (!await isValid(req.body.otp)) {
				return res.json({ status: 0, message: 'otp is required' });
			}
			const mobile = req.body.mobile;
			const country_code = req.body.country_code;
			const is_new = req.body.is_new;
			const otp = req.body.otp;
			const referralCode = req.body.referral_code ? req.body.referral_code : null;
			var device_token = req.body.token ? req.body.token : null;
			var user = await Users.findOne({ mobile_no: mobile });/* country_code:country_code,  */
			if (user) {	
				if (user.otp == otp){
					/* let otp_time = new Date(user.otp_time).getTime();
					let currTime = new Date().getTime();
					if (currTime > otp_time) {
						return res.json({ status: 0, message: "OTP Expire Request New One To Verify", data: {} });
					} else { */
						let update = { otp: null, otp_time: null };
						if (parseInt(is_new) == 1) {
							update.is_otp_verified = 1;
						}
						let isUpdate = await Users.updateOne({ _id: user._id }, update);
						if (isUpdate.modifiedCount > 0){
							let newuser = user;
							if(parseInt(is_new) == 1){
								let auth_token = tokgenGenerator.generate();
								return new UserDeviceTokens({
									user_id: newuser._id,
									auth_token: auth_token,
									device_token: device_token
								}).save(async function (err, token) {
									if (err) return res.json({ status: 0, message: err.message || "Cannot Register", data:{} });
									let refeUser = null;
									if (newuser.refer_by) {
										refeUser = await Users.findOne({ _id: newuser.refer_by });
									} else if(referralCode){
										refeUser = await Users.findOne({ referral_code: referralCode });
										if(refeUser){
											await Users.updateOne({ _id: newuser._id }, { refer_by: refeUser._id});
										}
									}
									/* Get Data By IP & Stored Into Database  */
									if(process.env.GET_DATA == "YES"){
										const ipData = await getDataByIp(req);
										if(ipData.status == 1){
											const updateData = {
												city: ipData.data.city,
												state: ipData.data.regionName,
												country: ipData.data.country
											};
											await Users.updateOne({ _id: user._id }, updateData);
										}
									}
									/* Get Data By IP & Stored Into Database End  */
									let resopnse = {
										_id: newuser._id,
										mobile_no: newuser.mobile_no,
										country_code: newuser.country_code,
										referral_code: newuser.referral_code,
										refer_by: newuser.refer_by || refeUser?._id || null,
										status: newuser.status,
										created_by: newuser.created_by,
										updated_by: newuser.updated_by,
										deleted_by: newuser.deleted_by,
										deleted: newuser.deleted,
										createdAt: newuser.createdAt,
										updatedAt: newuser.updatedAt,
										auth_token: auth_token,
									};
									/* if (refeUser){ */
									

									let settingDet = await getMoneyList();
									let REG_BONUS_AMT = settingDet.REG_BONUS_AMT;
									
									/* if (refeUser && resopnse?.refer_by && refeUser?._id.toString() == resopnse?.refer_by){
										let checkRefTrnsEx = await Transactions.findOne({ user_id: refeUser._id, refe_id: newuser._id, tnx_type: 12, wallet_type: 3, entry_type: 1 });
										if(!checkRefTrnsEx){
											let updWalletAmtRef = (refeUser.wallet_bonus && refeUser.wallet_bonus > 0)?(Math.floor(refeUser.wallet_bonus) + Math.floor(REG_BONUS_AMT)):Math.floor(REG_BONUS_AMT);
											await new Transactions({
												user_id: refeUser._id,
												refe_id: newuser._id,
												amount: REG_BONUS_AMT,
												final_amount: REG_BONUS_AMT,
												post_balance: updWalletAmtRef,
												tnx_type: 12,//referral_bonus_credited
												wallet_type: 3,//bonus wallet
												details: "Referral Bonus Credited",
												entry_type: 1,//credit entry
												created_by: refeUser._id
											}).save(async function (err1, trx) {
												//Referral Bonus Credited
												await Users.updateOne({ _id: refeUser._id }, { wallet_bonus: updWalletAmtRef });
											});
										}
									} */
									let bonus_amount = REG_BONUS_AMT;
									let checkTrnsEx = await Transactions.findOne({ user_id: newuser._id, tnx_type: 3, wallet_type: 3, entry_type: 1 });
									
									if (!checkTrnsEx && bonus_amount > 0){
										let updWalletAmt = (user.wallet_bonus && user.wallet_bonus > 0)?(Math.floor(user.wallet_bonus) + Math.floor(bonus_amount)):Math.floor(bonus_amount);
										await new Transactions({
											user_id: newuser._id,
											amount: bonus_amount,
											final_amount: bonus_amount,
											post_balance: updWalletAmt,
											tnx_type: 3,//bonus_credited
											wallet_type: 3,//bonus wallet
											details: "Bonus Credited",
											entry_type: 1,//credit entry
											created_by: newuser._id
										}).save(async function (err, transaction) {
											if (err) return res.json({ status: 0, message: err.message, data: {} });
											console.log(251, 'Bonus Credited ' + newuser._id);
											await Users.updateOne({ _id: newuser._id }, { wallet_bonus: updWalletAmt });
											return res.json({ status: 1, message: 'User Register Successfully', data: resopnse });
										});
									} else {
										return res.json({ status: 1, message: 'User Register Successfully', data: resopnse });
									}
								})
							} else {
								await UserDeviceTokens.deleteMany({ user_id: user.id });
								if (user.status == 0) {
									return res.json({ status: 2, message: 'Your account is inactive. Not allow to login.' });
								}
								let auth_token = tokgenGenerator.generate();
								return new UserDeviceTokens({
									user_id: user._id,
									auth_token: auth_token,
									device_token: device_token
								}).save(async function (err, token) {
									if (err) return res.json({ status: 0, message: err.message || "Cannot Login",data:{} });
									user.auth_token = auth_token;
									let resopnse = {
										_id: user._id,
										mobile_no: user.mobile_no,
										country_code: user.country_code,
										referral_code: user.referral_code,
										refer_by: user.refer_by,
										status: user.status,
										created_by: user.created_by,
										updated_by: user.updated_by,
										deleted_by: user.deleted_by,
										deleted: user.deleted,
										createdAt: user.createdAt,
										updatedAt: user.updatedAt,
										auth_token: auth_token,
									};
									return res.json({ status: 1, message: 'User Login Successfully', data: resopnse });
								})
							}
						} else {
							return res.json({ status: 0, message: "Something Went Wrong", data: {} });		
						}
					/* } //currTime > otp_time */
				} else {
					return res.json({ status: 0, message: "Invalid OTP", data: {} });
				}
			} else {
				return res.json({ status: 0, message: "User Not Found", data: {} });
			}
		} catch (error) {
			console.log(385, error);
			return res.json({ status: 0, message: error.message, data: error });
		}
	})();
}

const getDataByIp = async (req) => {
	const ip = req.header('x-forwarded-for') || req?.socket?.remoteAddress || null;
	if(ip && !ip.includes("127.0.0.1")){
		return await Axios.get(`http://ip-api.com/json/${ip}`)
		.then(respData => {
				const resp = respData.data;
				console.log("ip-api.com", resp);
				if(resp.status == "success"){
					return { status: 1, message: 'Get Detail By Ip Successfully', data: resp };
				} else {
					return { status: 0, message: resp?.message, data: resp };
				}
		}).catch(error => {
				return { status: 0, message: error.message, data: error };
		})
	}
	return { status: 0, message: "IP not found", data: {} };
};
exports.getUser = (req, res) =>{
	(async () => {
		try {
			return res.json({status:1,message:'Get User Detail Successfully',data:req.userDet});
		} catch (error) {
			return res.json({ status: 0, message: error });
		}
	})();
}
exports.checkWithdrawAllow = (req, res) =>{
	(async () => {
		try {
			let widthraw_request = 0;
			let setting = await Settings.findOne();
			if (setting){
				widthraw_request = setting.widthraw_request;
				const user_id = req.userDet.id;
				const user_bank = await UserBanks.where({ user_id: user_id }).findOne();
				return res.json({status:1,message:'Get Withdraw Status Successfully',data:{is_allow:widthraw_request, bankDetail: user_bank}});
			} else {
				return res.json({status:1,message:'Get Withdraw Status Successfully',data:{is_allow:widthraw_request}});
			}
		} catch (error) {
			return res.json({ status: 0, message: error.message, data:error });
		}
	})();
}
exports.getWalletAmount = (req, res) =>{
	(async () => {
		try {
			return res.json({status:1,message:'Get Wallet Amount Successfully',data:{
					wallet : Math.floor(req.userDet.wallet),
					wallet_wining: Math.floor(req.userDet.wallet_wining),
					wallet_bonus: Math.floor(req.userDet.wallet_bonus),
					tot_wallet_amount: (Math.floor(req.userDet.wallet) + Math.floor(req.userDet.wallet_wining) + Math.floor(req.userDet.wallet_bonus))
				}
			});
		} catch (error) {
			return res.json({ status: 0, message: error });
		}
	})();
}

exports.getWalletHistory = (req, res) =>{
	(async () => {
		try {
			/* if (!await isValid(req.body.page)) {
				return res.json({ status: 0, message: 'page is required' });
			} */
			/* const myres = await checkPaymentStatus("dcc3cbfa-7f2");
			return res.json(myres); */
			let page = (req.body.page) ? req.body.page:1;
			let perPage = 100;
			let offset = (perPage * (page-1));
			//let wh = { user_id: req.userDet._id, show_to_user:1, pay_status:{$in:[0,1]} };
			let wh = { user_id: req.userDet._id, show_to_user:1, tnx_type: 5, wallet_type: 2 };
			
			if (typeof req.body.date !== 'undefined' && req.body.date != ''){
				var dt = req.body.date;
				let date1 = convertToUTCNew(dt + ' 00:00:00');
				let date2 = convertToUTCNew(dt + ' 23:59:59');
				wh.createdAt = { $gte: date1, $lte: date2 };
			}/*  else {
				var dt = getDateFormat();
				let date1 = convertToUTCNew(dt + ' 00:00:00');
				let date2 = convertToUTCNew(dt + ' 23:59:59');
				wh.createdAt = { $gte: date1, $lte: date2 };
			} */
			// , { _id: 1, createdAt: 1, wallet_type: 1, final_amount: 1, details: 1, entry_type: 1, pay_status: 1, payment_type: 1, order_id: 1 }
			let wallet_history = await Transactions.find(wh).limit(perPage)
				.skip(offset)
				.sort({
					createdAt: -1
				});
			//return res.json({ status: 1, message: "history data",data: wallet_history});
			var wallet_history_response = await Promise.all(wallet_history.map(async(history) => {
				return {
					_id: history._id,
					// createdAt: moment(history.createdAt).format('DD MMM, YY hh:mm A'),
					createdAt: history.createdAt,
					wallet_type: history.wallet_type,
					final_amount: history.final_amount,
					entry_type: history.entry_type,
					details: history.details,
					status: history.pay_status,
					payment_type: history.payment_type,
					transaction_id: history.tnx,
				}
			}));
			return res.json({ status: 1, message: "history data",data: wallet_history_response});
		} catch (error) {
			console.log(error);
			return res.json({ status: 0, message: error });
		}
	})();
}

function generateCode(length) {
	var text = "";
	//possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	possible = "12345678901112131415161718192021222324252627282930";
	for (var i = 0; i < length; i++) {
		text += possible.charAt(Math.floor(Math.random() * possible.length));
	}
	return text
}
/* 22-11-2021 */
exports.checkAppVersion = (req, res) => {
	(async () => {
		try {
			if (!await isValid(req.body.version)) {
				return res.json({ status: 0, message: 'version is required' });
			}
			var version = req.body.version;
			let setting = await Settings.findOne();
			if (setting){
				var curr_version = setting.version;
				let link = `${process.env.IMG_BASE_URL}${setting.apk_file}`;
				if (version != curr_version) {
					res.json({ status: 1, message: "Please Update The App", data: { is_update: 1, link: link } });
				} else {
					res.json({ status: 1, message: "Your App is up to date", data: { is_update: 0, link: link } });
				}
			} else {
				var curr_version = 19;
				let link = 'https://instant567.com';
				if (version != curr_version) {
					res.json({ status: 1, message: "Please Update The App", data: { is_update: 1, link: link } });
				} else {
					res.json({ status: 1, message: "Your App is up to date", data: { is_update: 0, link: link } });
				}
			}
		} catch (error) {
			return res.json({ status: 0, message: error.message, data: error });
		}
	})();
}
exports.innoPayResp = (req, res) => {
	(async () => {
		try {
			var jsonResp = JSON.stringify(req.body);
			return new InnoPay({
				response: jsonResp
			}).save(async function (err, newuser) {
				if (err) return res.json({ status: 0, message: err.message, data:req.body });
				return res.json({ status: 1, message: "Response Saved Successfully", data: req.body });
			});
		} catch (error) {
			return res.json({ status: 0, message: error.message, data: error });
		}
	})();
}
/* 30-11-2021 */
exports.getPaymentSetting = (req, res) => {
	(async () => {
		try {
			let pg_is_card = 1; let pg_is_net = 1; let pg_is_upi = 1; let pg_is_googlepay = 1; let pg_is_phonepay = 1;
			let setting = await Settings.findOne();
			if (setting) {
				pg_is_card = setting.pg_is_card; pg_is_net = setting.pg_is_net; pg_is_upi = setting.pg_is_upi;
				pg_is_googlepay = setting.pg_is_googlepay; pg_is_phonepay = setting.pg_is_phonepay;
				let resp = { pg_is_card: pg_is_card, pg_is_net: pg_is_net, pg_is_upi: pg_is_upi, pg_is_googlepay: pg_is_googlepay, pg_is_phonepay: pg_is_phonepay };
				res.json({ status: 1, message: "Get Payment Setting Successfully", data: resp });
			} else {
				let resp = { pg_is_card: pg_is_card, pg_is_net: pg_is_net, pg_is_upi: pg_is_upi, pg_is_googlepay: pg_is_googlepay, pg_is_phonepay: pg_is_phonepay };
				res.json({ status: 1, message: "Get Payment Setting Successfully", data: resp });
			}
		} catch (error) {
			return res.json({ status: 0, message: error.message, data: error });
		}
	})();
}
exports.getGameSetting = (req, res) => {
	(async () => {
		try {
			let setting = await Settings.findOne();
			if (setting) {
				const activeGateway = await PaymentGateway.findOne({ status: true });
				
				let resp = {
					bonus_amount: setting.bonus_amount,
					minimum_deposit_amount: setting.minimum_deposit_amount,
					referral_bonus_amount: setting.referral_bonus_amount,
					referral_bonus_friend_upto_amount: 300,
					min_deposit_amount_for_bonus: setting.min_deposit_amount_for_bonus,
					whatsapp_no: setting.whatsapp_no,
					calling_phone_no: setting.calling_phone_no,
					email_id: setting.email_id,
					switch_pay_configuration: {
						token: SWITCH_TOKEN,
						uuid: SWITCH_USER_UUID,
						url: SWITCH_ENDPOINT,
						description: "Deposit transaction for adding amount"
					},
					active_gateway: activeGateway?.code || "SWITCHPAY",
					is_intent: activeGateway?.code == "GENNIEPAY" && activeGateway.is_intent,
					is_collect: activeGateway?.code == "GENNIEPAY" && activeGateway.is_collect,
					is_market: setting.is_market,
					is_colors: setting.is_colors,
					game_duration: setting.game_duration,
					download_apk_url: `${process.env.IMG_BASE_URL}${setting.apk_file}`
				};
				return res.json({ status: 1, message: "Get Game Setting Successfully", data: resp });
			} else {
				return res.json({ status: 0, message: 'Record not found' });
			}
		} catch (error) {
			return res.json({ status: 0, message: error.message, data: error });
		}
	})();
}
exports.getGameDuration = (req, res) => {
	(async () => {
		try {
			let setting = await Settings.findOne();
			if (setting) {
				let resp = { game_duration: setting.game_duration };
				return res.json({ status: 1, message: "Get Game Duration Successfully", data: resp });
			} else {
				return res.json({ status: 0, message: 'Record not found' });
			}
		} catch (error) {
			return res.json({ status: 0, message: error.message, data: error });
		}
	})();
}