
const AmezWorldCreateURLLogs = require('../models/AmezWorldCreateURLLogs');
const LetspayCreateURLLogs = require('../models/LetspayCreateURLLogs');
const GeckiopayCreateURLLogs = require('../models/GeckiopayCreateURLLogs');
const GenniePayCreateURLLogs = require('../models/GenniePayCreateURLLogs');
const MagicPayCreateURLLogs = require('../models/MagicPayCreateURLLogs');
const Transactions = require('../models/Transactions');
const Users = require('../models/Users');
const Withdrawals = require('../models/Withdraw');
const { webhookLog } = require('../services/JsonOpr');
const { getDateFormat, getTimeFormatAmPm } = require('../services/common');
const { addBonusReferalAmount } = require('./UserProfileController');
const { createTransaction } = require('../services/MagicPay');

exports.letspayPayin = async (req, res) => {
  const log = {
    time: getDateFormat() + ' ' + getTimeFormatAmPm(),
    dateTime: new Date(),
    body: req.body
  };
  webhookLog(JSON.stringify(log), "pay-in", type = 'letspay-requests');
  try {
    const { status: status_code, message, amount, refid, upi_txn_id, customer_virtual_address, customer_account_name } = req.body;
    //check in log first
    let isUpdateInURL = true;
    const urlData = await LetspayCreateURLLogs.findOne({ transaction_id: refid });
    const update = { status: status_code, upi_txn_id, webhook_resp: req.body };
    if(urlData){
      await LetspayCreateURLLogs.updateOne({ _id: urlData._id }, update);
      isUpdateInURL = false;
    }

    const row = await Transactions.findOne({ tnx: refid, tnx_type: 5, entry_type: 1, wallet_type: 2 });
    if(row){
      log.transactionId = row._id;
      log.userId = row.user_id;
      if(row.pay_status != 0){
        log.message = "Transaction Was Already "+(row.pay_status == 1 ? "Success" : "Failed");
        webhookLog(JSON.stringify(log));
        return res.status(200).json({ status: true, message: message, data: {} });
      }
      if(status_code == "SUCCESS"){
        const updArr = { check_inno_status: 1, pay_status: 1, order_id: upi_txn_id || row?.order_id };
        const result = await Users.findOneAndUpdate({_id: row.user_id }, { $inc: { wallet: parseFloat(amount) } }, { new: true });
        if(result){
          updArr.post_balance = result.wallet;
          await Transactions.updateOne({ _id: row._id }, updArr);
        }
        const totTrans = await Transactions.find({ user_id: row.user_id, tnx_type: { $in: [4,5]}, entry_type: 1, wallet_type: 2 });
        await addBonusReferalAmount(1, amount, result, row._id, totTrans);
        log.message = "Transaction Was Success";
        webhookLog(JSON.stringify(log));
        return res.status(200).json({ status: true, message: message, data: {} });
      } else if(status_code == "FAILED"){
        await Transactions.updateOne({ _id: row._id }, { check_inno_status: 2, pay_status: 2, order_id: upi_txn_id || row?.order_id });
        log.message = "Transaction Was Failed";
        webhookLog(JSON.stringify(log));
        return res.status(200).json({ status: true, message: message, data: {} });
      } else {
        log.message = "Transaction Status Was Pending State";
        webhookLog(JSON.stringify(log));
        return res.status(200).json({ status: true, message: message, data: {} });
      }
    } else {
      if(urlData){
        log.message = "Transaction Success In Log But  Not Found In Transaction Table";
        if(isUpdateInURL){
          await LetspayCreateURLLogs.updateOne({ _id: urlData._id }, update);
        }
      } else {
        log.message = "Transaction Not Found";
      }
      webhookLog(JSON.stringify(log));
      return res.status(200).json({ status: true, message: message, data: {} });
    }
  } catch (error) {
    console.log("error payin letspay", error);
    log.message = error?.message || "Exception Occured";
    webhookLog(JSON.stringify(log));
    return res.status(200).json({ status: false, message: "Failed", data: {} });
  }
};
exports.letspayPayout = async (req, res) => {
  const log = {
    time: getDateFormat() + ' ' + getTimeFormatAmPm(),
    dateTime: new Date(),
    body: req.body
  }
  try {
    const { status_code, txn_status, status, status_msg, transaction_id, utr } = req.body;
    const where = { merchant_ref_no: transaction_id }; //status: 4, 
	  const row = await Withdrawals.findOne(where);
    
    if(row){
      const with_id = row._id;
      log.withdrawId = with_id;
      log.userId = row.user_id;
      if(row.status != 4){
        log.message = "Withdraw Was Already "+(row.status == 1 ? "Success" : "Failed");
        webhookLog(JSON.stringify(log), "pay-out");
        return res.status(200).json({ status: true, message: message, data: {} });
      }
      if(txn_status == "SUCCESS" || status == "SUCCESS"){
        const update2 = { status: 1 };
        await Withdrawals.updateOne({ _id: with_id }, update2);
        const transaction = await Transactions.findOne({ refe_id: with_id });
        if(transaction){
          log.transactionId = transaction._id;
        }
        /* const result = 
        if(result){
          await Transactions.updateOne({ _id: row._id }, updArr);
        } */
        log.message = "Withdraw Was Success";
        webhookLog(JSON.stringify(log), "pay-out");
        return res.status(200).json({ status: true, message: status_msg, data: {} });
      } else if(txn_status == "FAILED" || status == "FAILED"){
        const update2 = { status: 3 };
        await Withdrawals.updateOne({ _id: with_id }, update2);
        log.message = "Withdraw Was Failed";
        webhookLog(JSON.stringify(log), "pay-out");
        return res.status(200).json({ status: true, message: status_msg, data: {} });
      } else {
        log.message = "Withdraw Was In Pending State";
        webhookLog(JSON.stringify(log), "pay-out");
        return res.status(200).json({ status: true, message: status_msg, data: {} });
      }
    } else {
      log.message = "Withdraw Not Found";
      webhookLog(JSON.stringify(log), "pay-out");
      return res.status(200).json({ status: true, message: status_msg, data: {} });
    }
  } catch (error) {
    console.log("error payout letspay", error);
    log.message = error?.message || "Exception Occured";
    webhookLog(JSON.stringify(log), "pay-out");
    return res.status(200).json({ status: false, message: "Failed", data: {} });
  }
};
/* 15-04-24 */
exports.amezWorldPayin = async (req, res) => {
  const log = {
    time: getDateFormat() + ' ' + getTimeFormatAmPm(),
    dateTime: new Date(),
    body: req.body
  };
  webhookLog(JSON.stringify(log), "pay-in", type = 'amez-world-requests');
  try {
    // const { statuscode: status_code, amount, status, apitxnid, utr } = req.body;
    const jsonData = JSON.parse(req.body);
    const { statuscode: status_code, amount, status, apitxnid, utr } = jsonData;
    //check in log first
    let isUpdateInURL = true;
    const urlData = await AmezWorldCreateURLLogs.findOne({ transaction_id: apitxnid });
    const update = { status: status.toUpperCase(), upi_txn_id: utr, webhook_resp: req.body };
    if(urlData){
      await AmezWorldCreateURLLogs.updateOne({ _id: urlData._id }, update);
      isUpdateInURL = false;
    }

    const row = await Transactions.findOne({ tnx: apitxnid, tnx_type: 5, entry_type: 1, wallet_type: 2 });
    if(row){
      log.transactionId = row._id;
      log.userId = row.user_id;
      if(row.pay_status != 0){
        log.message = "Transaction Was Already "+(row.pay_status == 1 ? "Success" : "Failed");
        const message = log.message;
        webhookLog(JSON.stringify(log), "pay-in", "amez-world");
        return res.status(200).json({ status: true, message: message, data: {} });
      }
      if(status.toUpperCase() == "SUCCESS"){
        const updArr = { check_inno_status: 1, pay_status: 1, order_id: utr || row?.order_id };
        const result = await Users.findOneAndUpdate({_id: row.user_id }, { $inc: { wallet: parseFloat(amount) } }, { new: true });
        if(result){
          updArr.post_balance = result.wallet;
          await Transactions.updateOne({ _id: row._id }, updArr);
        }
        const totTrans = await Transactions.find({ user_id: row.user_id, tnx_type: { $in: [4,5]}, entry_type: 1, wallet_type: 2 });
        await addBonusReferalAmount(1, amount, result, row._id, totTrans);
        log.message = "Transaction Was Success";
        const message = log.message;
        webhookLog(JSON.stringify(log), "pay-in", "amez-world");
        return res.status(200).json({ status: true, message: message, data: {} });
      } else if(status.toUpperCase() == "FAILED"){
        await Transactions.updateOne({ _id: row._id }, { check_inno_status: 2, pay_status: 2, order_id: utr || row?.order_id });
        log.message = "Transaction Was Failed";
        const message = log.message;
        webhookLog(JSON.stringify(log), "pay-in", "amez-world");
        return res.status(200).json({ status: true, message: message, data: {} });
      } else {
        log.message = "Transaction Status Was Pending State";
        const message = log.message;
        webhookLog(JSON.stringify(log), "pay-in", "amez-world");
        return res.status(200).json({ status: true, message: message, data: {} });
      }
    } else {
      if(urlData){
        log.message = "Transaction Success In Log But  Not Found In Transaction Table";
        if(isUpdateInURL){
          await AmezWorldCreateURLLogs.updateOne({ _id: urlData._id }, update);
        }
      } else {
        log.message = "Transaction Not Found";
      }
      const message = log.message;
      webhookLog(JSON.stringify(log), "pay-in", "amez-world");
      return res.status(200).json({ status: true, message: message, data: {} });
    }
  } catch (error) {
    console.log("error payin letspay", error);
    log.message = error?.message || "Exception Occured";
    webhookLog(JSON.stringify(log), "pay-in", "amez-world");
    return res.status(200).json({ status: false, message: "Failed", data: {} });
  }
};
exports.amezWorldPayout = async (req, res) => {
  const log = {
    time: getDateFormat() + ' ' + getTimeFormatAmPm(),
    dateTime: new Date(),
    body: req.body
  }
  try {
    // const { statuscode, status, amount, apitxnid, transaction_id, utr } = req.body;
    const jsonData = JSON.parse(req.body);
    const { statuscode, status, amount, apitxnid, transaction_id, utr } = jsonData;
    const where = { merchant_ref_no: apitxnid }; //status: 4, 
	  const row = await Withdrawals.findOne(where);
    
    if(row){
      const with_id = row._id;
      log.withdrawId = with_id;
      log.userId = row.user_id;
      if(row.status != 4){
        log.message = "Withdraw Was Already "+(row.status == 1 ? "Success" : "Failed");
        webhookLog(JSON.stringify(log), "pay-out", "amez-world");
        return res.status(200).json({ status: true, message: log.message, data: {} });
      }
      if(statuscode != "TXN"){
        log.message = "Withdraw Was Failed From Webhook";
        webhookLog(JSON.stringify(log), "pay-out", "amez-world");
        return res.status(200).json({ status: true, message: log.message, data: {} });
      }
      if(status.toUpperCase() == "SUCCESS"){
        const update2 = { status: 1 };
        await Withdrawals.updateOne({ _id: with_id }, update2);
        const transaction = await Transactions.findOne({ refe_id: with_id });
        if(transaction){
          log.transactionId = transaction._id;
        }
        /* const result = 
        if(result){
          await Transactions.updateOne({ _id: row._id }, updArr);
        } */
        log.message = "Withdraw Was Success";
        webhookLog(JSON.stringify(log), "pay-out", "amez-world");
        return res.status(200).json({ status: true, message: log.message, data: {} });
      } else if(status.toUpperCase() == "FAILED"){
        const update2 = { status: 3 };
        await Withdrawals.updateOne({ _id: with_id }, update2);
        log.message = "Withdraw Was Failed";
        webhookLog(JSON.stringify(log), "pay-out", "amez-world");
        return res.status(200).json({ status: true, message: log.message, data: {} });
      } else {
        log.message = "Withdraw Was In Pending State";
        webhookLog(JSON.stringify(log), "pay-out", "amez-world");
        return res.status(200).json({ status: true, message: log.message, data: {} });
      }
    } else {
      log.message = "Withdraw Not Found";
      webhookLog(JSON.stringify(log), "pay-out", "amez-world");
      return res.status(200).json({ status: true, message: log.message, data: {} });
    }
  } catch (error) {
    console.log("error payout letspay", error);
    log.message = error?.message || "Exception Occured";
    webhookLog(JSON.stringify(log), "pay-out", "amez-world");
    return res.status(200).json({ status: false, message: "Failed", data: {} });
  }
};
/* 21-05-24 */
exports.geckioPayin = async (req, res) => {
  const log = {
    time: getDateFormat() + ' ' + getTimeFormatAmPm(),
    dateTime: new Date(),
    body: req.body || req.query
  };
  webhookLog(JSON.stringify(log), "pay-in", type = 'geckio-pay-requests');
  try {
    const { status, amount, refernce_no: apitxnid, rrn_no: utr } = req.query;
    const response_code = status;
    const response_msg = response_code == 200 ? "Transaction Success" : "Transaction Failed";
    //check in log first
    let isUpdateInURL = true;
    const urlData = await GeckiopayCreateURLLogs.findOne({ transaction_id: apitxnid });
    const update = { status: status.toUpperCase(), upi_txn_id: utr, webhook_resp: req.body };
    if(urlData){
      await GeckiopayCreateURLLogs.updateOne({ _id: urlData._id }, update);
      isUpdateInURL = false;
    }
    if(response_code == 401){
      log.message = response_msg;
      const message = log.message;
      webhookLog(JSON.stringify(log), "pay-in", "geckio-pay");
      return res.status(200).json({ status: true, message: message, data: {} });
    }
    const row = await Transactions.findOne({ tnx: apitxnid, tnx_type: 5, entry_type: 1, wallet_type: 2 });
    if(row){
      log.transactionId = row._id;
      log.userId = row.user_id;
      if(row.pay_status != 0){
        log.message = "Transaction Was Already "+(row.pay_status == 1 ? "Success" : "Failed");
        const message = log.message;
        webhookLog(JSON.stringify(log), "pay-in", "geckio-pay");
        return res.status(200).json({ status: true, message: message, data: {} });
      }
      // if(status.toUpperCase() == "SUCCESS"){
      if(status == 200){
        const updArr = { check_inno_status: 1, pay_status: 1, order_id: utr || row?.order_id };
        const result = await Users.findOneAndUpdate({_id: row.user_id }, { $inc: { wallet: parseFloat(amount) } }, { new: true });
        if(result){
          updArr.post_balance = result.wallet;
          await Transactions.updateOne({ _id: row._id }, updArr);
        }
        const totTrans = await Transactions.find({ user_id: row.user_id, tnx_type: { $in: [4,5]}, entry_type: 1, wallet_type: 2 });
        await addBonusReferalAmount(1, amount, result, row._id, totTrans);
        log.message = "Transaction Was Success";
        const message = log.message;
        webhookLog(JSON.stringify(log), "pay-in", "geckio-pay");
        return res.status(200).json({ status: true, message: message, data: {} });
      } else if(status != 200){/* status.toUpperCase() == "FAILED" */
        await Transactions.updateOne({ _id: row._id }, { check_inno_status: 2, pay_status: 2, order_id: utr || row?.order_id });
        log.message = "Transaction Was Failed";
        const message = log.message;
        webhookLog(JSON.stringify(log), "pay-in", "geckio-pay");
        return res.status(200).json({ status: true, message: message, data: {} });
      } else {
        log.message = "Transaction Status Was Pending State";
        const message = log.message;
        webhookLog(JSON.stringify(log), "pay-in", "geckio-pay");
        return res.status(401).json({ status: true, message: message, data: {} });
      }
    } else {
      if(urlData){
        log.message = "Transaction Success In Log But  Not Found In Transaction Table";
        if(isUpdateInURL){
          await GeckiopayCreateURLLogs.updateOne({ _id: urlData._id }, update);
        }
      } else {
        log.message = "Transaction Not Found";
      }
      const message = log.message;
      webhookLog(JSON.stringify(log), "pay-in", "geckio-pay");
      return res.status(200).json({ status: true, message: message, data: {} });
    }
  } catch (error) {
    console.log("error payin geckioPay", error);
    log.message = error?.message || "Exception Occured";
    webhookLog(JSON.stringify(log), "pay-in", "geckio-pay");
    return res.status(401).json({ status: false, message: "Failed", data: {} });
  }
};
exports.geckioPayout = async (req, res) => {
  const log = {
    time: getDateFormat() + ' ' + getTimeFormatAmPm(),
    dateTime: new Date(),
    body: req.body || req.query
  }
  try {
    const { status, amount, refernce_no: reference_no, rrn_no } = req.query;
    const response_code = status;
    const response_msg = response_code == 200 ? "Withdrawal Success" : "Withdrawal Failed";
    const where = { merchant_ref_no: reference_no }; //status: 4,
	  const row = await Withdrawals.findOne(where);
    
    if(row){
      const with_id = row._id;
      log.withdrawId = with_id;
      log.userId = row.user_id;
      log.amount = amount;
      if(row.status != 4){
        log.message = "Withdraw Was Already "+(row.status == 1 ? "Success" : "Failed");
        webhookLog(JSON.stringify(log), "pay-out", "geckio-pay");
        return res.status(200).json({ status: true, message: log.message, data: {} });
      }
      if(response_code != 200){
        log.message = response_msg || "Withdraw Was Failed From Webhook";
        webhookLog(JSON.stringify(log), "pay-out", "geckio-pay");
        return res.status(401).json({ status: true, message: log.message, data: {} });
      }
      if(status == 200){/* status.toUpperCase() == "SUCCESS" */
        const update2 = { status: 1 };
        if(row?.transaction_id == null){
          update2.transaction_id = rrn_no;
        }
        await Withdrawals.updateOne({ _id: with_id }, update2);
        const transaction = await Transactions.findOne({ refe_id: with_id });
        if(transaction){
          log.transactionId = transaction._id;
        }
        /* const result =
        if(result){
          await Transactions.updateOne({ _id: row._id }, updArr);
        } */
        log.message = "Withdraw Was Success";
        webhookLog(JSON.stringify(log), "pay-out", "geckio-pay");
        return res.status(200).json({ status: true, message: log.message, data: {} });
      } else if(status != 200){/* status.toUpperCase() == "FAILED" */
        const update2 = { status: 3 };
        await Withdrawals.updateOne({ _id: with_id }, update2);
        log.message = "Withdraw Was Failed";
        webhookLog(JSON.stringify(log), "pay-out", "geckio-pay");
        return res.status(200).json({ status: true, message: log.message, data: {} });
      } else {
        log.message = "Withdraw Was In Pending State";
        webhookLog(JSON.stringify(log), "pay-out", "geckio-pay");
        return res.status(200).json({ status: true, message: log.message, data: {} });
      }
    } else {
      log.message = "Withdraw Not Found";
      webhookLog(JSON.stringify(log), "pay-out", "geckio-pay");
      return res.status(401).json({ status: true, message: log.message, data: {} });
    }
  } catch (error) {
    console.log("error payout geckio", error);
    log.message = error?.message || "Exception Occured";
    webhookLog(JSON.stringify(log), "pay-out", "geckio-pay");
    return res.status(401).json({ status: false, message: "Failed", data: {} });
  }
};
/* 23-05-24 */
exports.genniePayin = async (req, res) => {
  const log = {
    time: getDateFormat() + ' ' + getTimeFormatAmPm(),
    dateTime: new Date(),
    body: req.body
  };
  webhookLog(JSON.stringify(log), "pay-in", type = 'gennie-pay-requests');
  try {
    const { status, orderId: apitxnid, transactionRefId, utr } = req.body;

    const response_msg = status?.toUpperCase() == "Success" ? "Transaction Success" : (status?.toUpperCase() == "Pending" ? "Transaction processing" : "Transaction Failed");
    //check in log first
    let isUpdateInURL = true;
    const urlData = await GenniePayCreateURLLogs.findOne({ transaction_id: apitxnid });
    const update = { status: status?.toUpperCase(), upi_txn_id: utr, webhook_resp: req.body };
    if(urlData){
      await GenniePayCreateURLLogs.updateOne({ _id: urlData._id }, update);
      isUpdateInURL = false;
    }
    /* if(response_code == 401){
      log.message = response_msg;
      const message = log.message;
      webhookLog(JSON.stringify(log), "pay-in", "gennie-pay");
      return res.status(200).json({ status: true, message: message, data: {} });
    } */
    const row = await Transactions.findOne({ tnx: apitxnid, tnx_type: 5, entry_type: 1, wallet_type: 2 });
    if(row){
      const amount = row.amount;
      log.transactionId = row._id;
      log.userId = row.user_id;
      if(row.pay_status != 0){
        log.message = "Transaction Was Already "+(row.pay_status == 1 ? "Success" : "Failed");
        const message = log.message;
        webhookLog(JSON.stringify(log), "pay-in", "gennie-pay");
        return res.status(200).json({ status: true, message: message, data: {} });
      }
      if(status?.toUpperCase() == "SUCCESS"){
        const updArr = { check_inno_status: 1, pay_status: 1, order_id: utr || row?.order_id, tnx_id: transactionRefId || null };
        const result = await Users.findOneAndUpdate({_id: row.user_id }, { $inc: { wallet: parseFloat(amount) } }, { new: true });
        if(result){
          updArr.post_balance = result.wallet;
          await Transactions.updateOne({ _id: row._id }, updArr);
        }
        const totTrans = await Transactions.find({ _id: { $ne: row._id }, user_id: row.user_id, tnx_type: { $in: [4,5]}, entry_type: 1, wallet_type: 2 });
        await addBonusReferalAmount(1, amount, result, row._id, totTrans);
        log.message = "Transaction Was Success";
        const message = log.message;
        webhookLog(JSON.stringify(log), "pay-in", "gennie-pay");
        return res.status(200).json({ status: true, message: message, data: {} });
      } else if(status?.toUpperCase() == "FAILED"){
        await Transactions.updateOne({ _id: row._id }, { check_inno_status: 2, pay_status: 2, order_id: utr || row?.order_id, tnx_id: transactionRefId || null });
        log.message = "Transaction Was Failed";
        const message = log.message;
        webhookLog(JSON.stringify(log), "pay-in", "gennie-pay");
        return res.status(200).json({ status: true, message: message, data: {} });
      } else {
        log.message = "Transaction Status Was Pending State";
        const message = log.message;
        webhookLog(JSON.stringify(log), "pay-in", "gennie-pay");
        return res.status(401).json({ status: true, message: message, data: {} });
      }
    } else {
      if(urlData){
        log.message = "Transaction Success In Log But  Not Found In Transaction Table";
        if(isUpdateInURL){
          await GenniePayCreateURLLogs.updateOne({ _id: urlData._id }, update);
        }
        /* If transaction not found then create new transaction */
        if(urlData?.used_method == "COLLECT"){
          let passStatus = "Pending";
          if(status?.toUpperCase() == "SUCCESS"){
            passStatus = "Approved";
          } else if(status?.toUpperCase() == "FAILED"){
            passStatus = "Rejected";
          }
          await createTransaction(urlData, passStatus, utr);
        }
        /* If transaction not found then create new transaction end */

      } else {
        log.message = "Transaction Not Found";
      }
      const message = log.message;
      webhookLog(JSON.stringify(log), "pay-in", "gennie-pay");
      return res.status(200).json({ status: true, message: message, data: {} });
    }
  } catch (error) {
    console.log("error payin geckioPay", error);
    log.message = error?.message || "Exception Occured";
    webhookLog(JSON.stringify(log), "pay-in", "gennie-pay");
    return res.status(401).json({ status: false, message: "Failed", data: {} });
  }
};
exports.genniePayout = async (req, res) => {
  const log = {
    time: getDateFormat() + ' ' + getTimeFormatAmPm(),
    dateTime: new Date(),
    body: req.body
  }
  webhookLog(JSON.stringify(log), "pay-out", 'gennie-pay-requests');
  try {
    const { txnStatus: status, amount, message, orderId: reference_no, txnid, txnId, utr } = req.body;
    const where = { merchant_ref_no: reference_no }; //status: 4,
	  const row = await Withdrawals.findOne(where);
    
    if(row){
      const with_id = row._id;
      log.withdrawId = with_id;
      log.userId = row.user_id;
      log.amount = amount;
      if(row.status != 4){
        log.message = "Withdraw Was Already "+(row.status == 1 ? "Success" : "Failed");
        webhookLog(JSON.stringify(log), "pay-out", "gennie-pay");
        return res.status(200).json({ status: true, message: log.message, data: {} });
      }
      if(status != "SUCCESS"){
        log.message = message || "Withdraw Was Failed From Webhook";
        webhookLog(JSON.stringify(log), "pay-out", "gennie-pay");
        return res.status(401).json({ status: true, message: log.message, data: {} });
      }
      if(status == "SUCCESS"){/* status.toUpperCase() == "SUCCESS" */
        const update2 = { status: 1 };
        if(row?.transaction_id == null){
          update2.transaction_id = txnid || txnId;
        }
        if(row?.tnx == null){
          update2.tnx = utr;
        }
        await Withdrawals.updateOne({ _id: with_id }, update2);
        const transaction = await Transactions.findOne({ refe_id: with_id });
        if(transaction){
          log.transactionId = transaction._id;
        }
        /* const result =
        if(result){
          await Transactions.updateOne({ _id: row._id }, updArr);
        } */
        log.message = "Withdraw Was Success";
        webhookLog(JSON.stringify(log), "pay-out", "gennie-pay");
        return res.status(200).json({ status: true, message: log.message, data: {} });
      } else if(status != 200){/* status.toUpperCase() == "FAILED" */
        const update2 = { status: 3 };
        await Withdrawals.updateOne({ _id: with_id }, update2);
        log.message = "Withdraw Was Failed";
        webhookLog(JSON.stringify(log), "pay-out", "gennie-pay");
        return res.status(200).json({ status: true, message: log.message, data: {} });
      } else {
        log.message = "Withdraw Was In Pending State";
        webhookLog(JSON.stringify(log), "pay-out", "gennie-pay");
        return res.status(200).json({ status: true, message: log.message, data: {} });
      }
    } else {
      log.message = "Withdraw Not Found";
      webhookLog(JSON.stringify(log), "pay-out", "gennie-pay");
      return res.status(401).json({ status: true, message: log.message, data: {} });
    }
  } catch (error) {
    console.log("error payout geckio", error);
    log.message = error?.message || "Exception Occured";
    webhookLog(JSON.stringify(log), "pay-out", "gennie-pay");
    return res.status(401).json({ status: false, message: "Failed", data: {} });
  }
};
/* 05-08-24 */
exports.magicPayin = async (req, res) => {
  const log = {
    time: getDateFormat() + ' ' + getTimeFormatAmPm(),
    dateTime: new Date(),
    body: req.body
  };
  webhookLog(JSON.stringify(log), "pay-in", type = 'magic-pay-requests');
  try {
    const { txnStatus: status, orderId: apitxnid, utr, amount } = req.body;

    //check in log first
    let isUpdateInURL = true;
    const urlData = await MagicPayCreateURLLogs.findOne({ transaction_id: apitxnid });
    const update = { status: status?.toUpperCase() == "APPROVED" ? "SUCCESS" : status?.toUpperCase(), upi_txn_id: utr, webhook_resp: req.body };
    if(urlData){
      await MagicPayCreateURLLogs.updateOne({ _id: urlData._id }, update);
      isUpdateInURL = false;
    }
    
    const row = await Transactions.findOne({ tnx: apitxnid, tnx_type: 5, entry_type: 1, wallet_type: 2 });
    if(row){
      const amount = row.amount;
      log.transactionId = row._id;
      log.userId = row.user_id;
      if(row.pay_status != 0){
        log.message = "Transaction Was Already "+(row.pay_status == 1 ? "Success" : "Failed");
        const message = log.message;
        webhookLog(JSON.stringify(log), "pay-in", "magic-pay");
        return res.status(200).json({ status: true, message: message, data: {} });
      }
      if(status?.toUpperCase() == "APPROVED"){
        const updArr = { check_inno_status: 1, pay_status: 1, order_id: utr || row?.order_id };
        const result = await Users.findOneAndUpdate({_id: row.user_id }, { $inc: { wallet: parseFloat(amount) } }, { new: true });
        if(result){
          updArr.post_balance = result.wallet;
          await Transactions.updateOne({ _id: row._id }, updArr);
        }
        const totTrans = await Transactions.find({ _id: { $ne: row._id }, user_id: row.user_id, tnx_type: { $in: [4,5]}, entry_type: 1, wallet_type: 2 });
        await addBonusReferalAmount(1, amount, result, row._id, totTrans);
        log.message = "Transaction Was Success";
        const message = log.message;
        webhookLog(JSON.stringify(log), "pay-in", "magic-pay");
        return res.status(200).json({ status: true, message: message, data: {} });
      } else if(status?.toUpperCase() == "REJECTED"){
        await Transactions.updateOne({ _id: row._id }, { check_inno_status: 2, pay_status: 2, order_id: utr || row?.order_id });
        log.message = "Transaction Was Failed";
        const message = log.message;
        webhookLog(JSON.stringify(log), "pay-in", "magic-pay");
        return res.status(200).json({ status: true, message: message, data: {} });
      } else {
        log.message = "Transaction Status Was Pending State";
        const message = log.message;
        webhookLog(JSON.stringify(log), "pay-in", "magic-pay");
        return res.status(401).json({ status: true, message: message, data: {} });
      }
    } else {
      if(urlData){
        /* If transaction not found then create new transaction */
        await createTransaction(urlData, status, utr);
        /* If transaction not found then create new transaction end */
        log.message = "Transaction Success In Log But  Not Found In Transaction Table";
        if(isUpdateInURL){
          await MagicPayCreateURLLogs.updateOne({ _id: urlData._id }, update);
        }
      } else {
        log.message = "Transaction Not Found";
      }
      const message = log.message;
      webhookLog(JSON.stringify(log), "pay-in", "magic-pay");
      return res.status(200).json({ status: true, message: message, data: {} });
    }
  } catch (error) {
    console.log("error payin magicPay", error);
    log.message = error?.message || "Exception Occured";
    webhookLog(JSON.stringify(log), "pay-in", "magic-pay");
    return res.status(401).json({ status: false, message: "Failed", data: {} });
  }
};