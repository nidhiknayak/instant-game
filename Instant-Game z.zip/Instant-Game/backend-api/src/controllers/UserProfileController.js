var { UserBanks } = require('../models/UserBanks');
var Users = require('../models/Users');
var mongoose = require('mongoose');
var Transactions = require('../models/Transactions');
var Withdrawals = require('../models/Withdraw');
var GameRatios = require('../models/GameRatios');
var NoticeBoard = require('../models/NoticeBoard');
var Settings = require('../models/Settings');
var GameRatioColors = require('../models/GameRatioColors');
const { Markets } = require('../models/Markets');
const MarketResults = require('../models/MarketResults');
var MarketBids = require('../models/MarketBids');
const { isValid } = require('../services/validation');
//const { DEPO_BONUS_AMT } = require('../services/constant');
var { CURR_SMBL, MIN_WINN_WLT_AMT, WITH_REQ_PER_DAY } = require('../services/constant');
var {getMoneyList} = require('../services/money_val');
var { getDateFormat, convertToUTCNew, getLastIntTransNo, convertToUTC, getGameDet } = require('../services/common');
const { verifyBankAccount, createHashMobilePayment, doTransfer, checkTransferStatus } = require('../services/Withdraw');
const { addContent, appendContent, addGetTransID } = require('../services/JsonOpr');
var moment = require('moment');  
const { generatePaymentIntent, checkPaymentStatus } = require('../services/Anilex');
const AmezWorld = require('../services/AmezWorld');
const Geckiopay = require('../services/Geckiopay');
const GenniePay = require('../services/GenniePay');
const MagicPay  = require('../services/MagicPay');
const PaymentGateway = require('../models/PaymentGateway');
const LetspayCreateURLLogs = require('../models/LetspayCreateURLLogs');
const AmezWorldCreateURLLogs = require('../models/AmezWorldCreateURLLogs');
const GeckiopayCreateURLLogs = require('../models/GeckiopayCreateURLLogs');
const GenniePayCreateURLLogs = require('../models/GenniePayCreateURLLogs');
// const Op = db.Sequelize.Op;

exports.addBank = (req, res) =>{
	(async () => {
		try {
			if (!await isValid(req.body.bank_name)) {
				return res.json({ status: 0, message: 'bank_name is required' });
			}
			if (!await isValid(req.body.user_name)) {
				return res.json({ status: 0, message: 'user_name is required' });
			}
			if (!await isValid(req.body.acc_no)) {
				return res.json({ status: 0, message: 'acc_no is required' });
			}
			if (!await isValid(req.body.ifsc_code)) {
				return res.json({ status: 0, message: 'ifsc_code is required' });
			}
			if (!await isValid(req.body.branch)) {
				return res.json({ status: 0, message: 'branch is required' });
			}
			if (!await isValid(req.body.city)) {
				return res.json({ status: 0, message: 'city is required' });
			}
			const { bank_name, user_name, acc_no, ifsc_code, branch, city} = req.body;
			
			const user_id = req.userDet.id;
			let insert = { user_id: req.userDet._id,user_name: user_name, bank_name: bank_name, acc_no: acc_no, ifsc_code: ifsc_code, branch: branch, city: city };
			const user_bank = await UserBanks.findOne({ user_id: user_id });
			if(user_bank){
				if (typeof req.body.isChange !== 'undefined' && req.body.isChange == 1){
					insert.isChange = req.body.isChange;
					/* insert.is_verified = 0;
					insert.verified_at = null; */
				}
				insert.is_verified = 1;
				insert.verified_at = new Date();
				const { wallet, wallet_wining } = req.userDet;
				const bankDeductCharge = 10;
				if(bankDeductCharge > wallet || bankDeductCharge > wallet_wining){
					if(bankDeductCharge > wallet && bankDeductCharge > wallet_wining){
						return res.json({ status: 0, message: 'Insufficient Amount, not allow to update bank detail', data: {} });
					}
				}
				
				let wallet_type = 1;
				let post_balance = wallet_wining;
				if(wallet > bankDeductCharge){
					post_balance = wallet - bankDeductCharge;
					wallet_type = 2;
				} else {
					post_balance = wallet_wining - bankDeductCharge;
					wallet_type = 1;
				}
				const insTrans = {
					user_id: user_id,
					refe_id: user_bank._id,
					amount: bankDeductCharge,
					charge_amount: 0,
					final_amount: bankDeductCharge,
					post_balance: post_balance,
					tnx_type: 13,//bank change penalty
					wallet_type: wallet_type,//wallet 1,//winning wallet
					details: "Update Bank Detail Deduct",
					entry_type: 2//1
				}
				await Transactions.create(insTrans);

				const update_user_bank = await UserBanks.updateOne({ user_id: user_id }, insert);
				if (update_user_bank.modifiedCount > 0) {
					const updated_bank_details = await UserBanks.findOne({ user_id: user_id });
					const updateUser = { firstname: user_name };
					if(wallet_type == 2){
						updateUser.wallet = post_balance;
					} else {
						updateUser.wallet_wining = post_balance;
					}
					await Users.updateOne({ _id: user_id }, updateUser);
					return res.json({ status: 1, message: 'Bank Detail Updated Successfully', data: updated_bank_details });
				}
				return res.json({ status: 0, message: 'Please try again', data: {} });
			}else{
				insert.is_verified = 1;
				insert.verified_at = new Date();
				return new UserBanks(insert).save(async function(err, user_bank){
					if (err) return res.json({ status: 0,message: err.message, data: {}});

					let resp = await verifyBankAccount(user_id);
					if (resp.status == 1) {
						let update2 = { is_verified: 1, verified_at: new Date() };
						await UserBanks.updateOne({ _id: user_bank._id }, update2);
						await Users.updateOne({ _id: user_id }, { firstname: user_name });
						return res.json({ status: 1, message: 'Bank Detail Added Successfully', data: user_bank });
						/* let userDet = await Users.findOne({ _id: user_id });
						if (userDet) {
							var post_balance = ((userDet.wallet != null) ? userDet.wallet : 0) - 1;
							var updWinningWallet = await Users.updateOne({ _id: user_id }, { firstname: user_name, wallet: post_balance });
							if (updWinningWallet.modifiedCount > 0) {
								await new Transactions({
									user_id: user_id,
									refe_id: user_bank._id,
									amount: 1,
									charge_amount: 0,
									final_amount: 1,
									post_balance: post_balance,
									tnx_type: 10,//bank valid bonus
									wallet_type: 2,//wallet 1,//winning wallet
									details: "Bank Verified Deduct",
									entry_type: 2//1
								}).save(function (err, transaction) {
									return res.json({ status: 1, message: 'Bank Detail Added Successfully', data: user_bank });
								});
							}
						} else {
							return res.json({ status: 1, message: 'Bank Detail Added Successfully', data: user_bank });
						} */
					} else {
						await Users.updateOne({ _id: user_id }, { firstname: user_name });
						return res.json({ status: 1, message: 'Bank Detail Added Successfully', data: user_bank });
					}
				});
			}
		} catch (error) {
			return res.json({ status: 0, message: error?.message, data: {} });
		}
	})();
}

exports.getBank = (req, res) =>{
	(async () => {
		try {
			
			var user_id = req.userDet.id;

			/* // const resp = await verifyBankAccount(user_id);
			const with_id = "64006d5ebd4f08210ddf38f7";
			//const resp = await doTransfer(14.7, user_id, with_id);
			const resp = await checkTransferStatus(with_id);
			return res.json(resp); */
			var user_bank = await UserBanks.where({ user_id: user_id }).findOne();
			if(user_bank){
				return res.json({status:1,message:'Get Bank Detail Successfully',data:user_bank});
			}
			return res.json({status:0,message:'No Bank Detail Found'});
		} catch (error) {
			return res.json({ status: 0, message: error?.message });
		}
	})();
}
exports.uploadImage = (req, res) =>{
	var formidable = require('formidable');
	var fs = require('fs');
	var form = new formidable.IncomingForm();
	form.parse(req, function(err,fields,files){
		var oldpath = files.image.path;

		var path = require('path');
		var fileName = files.image.name;
		var ext = path.extname(fileName);
		var OnlyName = fileName.toString();
		
		OnlyName = path.basename(OnlyName, ext);
		var newName = OnlyName + "-" + Date.now()+ext;
		
		var newpath = 'uploads/images/'+newName;
		fs.rename(oldpath,newpath,function(err){
			if(err){
				throw err;
			}
			res.send({status:1,msg:'image updated Successfully',data:'http://localhost:3001/'+newpath});
		});
	});
}

exports.add_wallet_amount = (req, res) =>{
	(async () => {
		try {
			if (!await isValid(req.body.amount)) {
				return res.json({ status: 0, message: 'amount is required' });
			}
			if (!await isValid(req.body.txnId)) {
				return res.json({ status: 0, message: 'txnId is required' });
			}
			//return res.json({ status: 0, message: 'txnId is required', data: {} });
			let txnId = req.body.txnId;

			/* let respData = await addContent(req);
			let respData2 = await appendContent(req);
			return res.json({ status: 0, message: 'Wallet check', data: { respData: respData, respData2: respData2} }); */

			let order_id = (typeof req.body.order_id != 'undefined' && req.body.order_id != null) ? req.body.order_id:null;
			let pay_status = (typeof req.body.status != 'undefined' && req.body.status != null) ? req.body.status:0;
			let payment_type = (typeof req.body.payment_type != 'undefined' && req.body.payment_type != null) ? req.body.payment_type:"";
			let check_inno_status = 0;
			if (parseInt(pay_status) == 1){
				check_inno_status = 0;
				if (payment_type == "PHONE_PE") {
					pay_status = 0;
				}
			} else if(parseInt(pay_status) == 2){
				check_inno_status = 2;
			}
			const checkDuplicate = await Transactions.countDocuments({ tnx_type: { $in: [4,5]}, entry_type: 1, wallet_type: 2, $or: [{ order_id: order_id }, { tnx: txnId }] });
			if(checkDuplicate > 0){
				return res.json({ status: 0, message: 'Not allow to add', data: {} });
			}
			var user_id = req.userDet.id;
			/* If letspay selected then check trasaction using webhook 23-02-24 */
			const activeGateway = await PaymentGateway.findOne({ status: true });
			if(activeGateway){
				pay_status = 0;
				if(activeGateway?.code == "ANILEX"){
					//check transaction in log table  27-02-24
					const urlData = await LetspayCreateURLLogs.findOne({ transaction_id: txnId, user_id: user_id });
					if(urlData && urlData.status == "SUCCESS"){
						pay_status = 1;
						check_inno_status = 1;
						order_id = urlData.upi_txn_id;
					}
				} else if(activeGateway?.code == "AMEZ_WORLD"){
					//check transaction in log table  15-04-24
					const urlData = await AmezWorldCreateURLLogs.findOne({ transaction_id: txnId, user_id: user_id });
					if(urlData && urlData.status == "SUCCESS"){
						pay_status = 1;
						check_inno_status = 1;
						order_id = urlData.upi_txn_id;
					}
				} else if(activeGateway?.code == "GECKIOPAY"){
					//check transaction in log table 21-05-24
					const urlData = await GeckiopayCreateURLLogs.findOne({ transaction_id: txnId, user_id: user_id });
					if(urlData && urlData.status == "SUCCESS"){
						pay_status = 1;
						check_inno_status = 1;
						order_id = urlData.upi_txn_id;
					}
				} else if(activeGateway?.code == "GENNIEPAY"){
					//check transaction in log table 03-06-24
					const urlData = await GenniePayCreateURLLogs.findOne({ transaction_id: txnId, user_id: user_id });
					if(urlData && urlData.status == "SUCCESS"){
						pay_status = 1;
						check_inno_status = 1;
						order_id = urlData.upi_txn_id;
					}
				}
			}
			/* If letspay selected then check trasaction using webhook end */
			
			
			let settingDet = await getMoneyList();
			let MIN_DEPO_AMT = settingDet.MIN_DEPO_AMT;
			if(parseInt(req.body.amount) < MIN_DEPO_AMT){
				return res.json({ status: 0, message: 'Minimum Deposit Amount Is ' + CURR_SMBL + MIN_DEPO_AMT,data:{} });
			}
			let internal_tnx = await getLastIntTransNo();
			//return res.json({ status: 0, message: 'Minimum', data: internal_tnx });
			/* const add_wallet = await Users.updateOne({ _id: user_id },{$inc:{wallet:parseInt(req.body.amount)}});
			if(add_wallet.modifiedCount > 0){ */
				/* let userDet = await Users.findOne({ _id: user_id });
				if (userDet){ */
					let post_balance = req.userDet.wallet;
					if (parseInt(pay_status) == 1) {
						post_balance = post_balance + parseFloat(req.body.amount);
					}
					let totTrans = await Transactions.find({ user_id: user_id, tnx_type: { $in: [4,5]}, entry_type: 1, wallet_type: 2 });
					return new Transactions({
						user_id: user_id,
						tnx: txnId,
						amount: req.body.amount,
						final_amount: req.body.amount,
						post_balance: post_balance,
						tnx_type: 5,//added by self
						wallet_type: 2,//simple wallet
						details: "Added",
						entry_type: 1,//credit entry
						internal_tnx: internal_tnx,
						payment_type: payment_type,
						order_id: order_id,
						pay_status: pay_status,
						check_inno_status: check_inno_status,
						created_by: req.userDet._id
					}).save(async function (err, transaction) {
						if (err) return res.json({ status: 0, message: err.message });

						/* 30-11-2022 If success in mobile add amount to users wallet start */
						if (parseInt(pay_status) == 1) {
							await Users.findOneAndUpdate({ _id: user_id }, { $inc: { wallet: parseFloat(req.body.amount) } });
						}
						/* 30-11-2022 If success in mobile add amount to users wallet end */

						/* Add 5% amount to bonus wallet 16-08-2022 start */
						await addBonusReferalAmount(pay_status, req.body.amount, req.userDet, transaction._id, totTrans);
						appendContent(req);
						return res.json({ status: 1, message: parseInt(pay_status) == 1 ? 'Amount added to wallet successfully.' : "Check transaction status in Wallet", data:{} });
					});
				/* } else {
					return res.json({ status: 0, message: 'User Not Found', data:{} });
				}	 */	
			//}
		} catch (error) {
			return res.json({ status: 0, message: error.message,data:error });
		}
	})();
}

/* Withdraw 13-10-2021 */
exports.addWithdraw = (req, res) => {
	(async () => {
		try {
			if (!await isValid(req.body.amount)) {
				return res.json({ status: 0, message: 'amount is required' });
			}
			if (!await isValid(req.body.charge)) {
				return res.json({ status: 0, message: 'charge percentage is required' });
			}
			if (!await isValid(req.body.charge_amount)) {
				return res.json({ status: 0, message: 'charge amount is required' });
			}
			if (!await isValid(req.body.final_amount)) {
				return res.json({ status: 0, message: 'final amount is required' });
			}
			var amount = req.body.amount;
			var charge = req.body.charge;
			var charge_amount = req.body.charge_amount;
			var final_amount = req.body.final_amount;
			var user_id = req.userDet.id;
			var winAmount = req.userDet.wallet_wining;
			var newAmount = parseFloat(req.userDet.wallet_wining) - MIN_WINN_WLT_AMT;
			let pendingWithdrawAmount = 0;

			let today = getDateFormat();
			let date1 = convertToUTCNew(today + ' 00:00:00');
			let date2 = convertToUTCNew(today + ' 23:59:59');

			const userBank = await UserBanks.where({ user_id: user_id }).findOne();
			if (!userBank || userBank.is_verified != 1){
				return res.json({ status: 0, message: 'Your Bank Detail Not Verified Not Allow To Place Withdraw Request', data: {} });
			}
			// Last 24 Hour
			
			const startDate = new Date(new Date(). getTime() - (24 * 60 * 60 * 1000));
			const endDt = convertToUTCNew(new Date());
			const startDt = convertToUTCNew(startDate);
			const penWh = { user_id: user_id, status: 2, createdAt: { $gte: startDt, $lte: endDt } };//status:2, 
			const penReq = await Withdrawals.find(penWh);
			if(penReq.length > 0){
				for (const vvv of penReq) {
					pendingWithdrawAmount += vvv.final_amount;
				}
			}
			
			let tdWh = { user_id: user_id, createdAt: { $gte: date1, $lte: date2 } };//status:2, 
			let todayReq = await Withdrawals.find(tdWh);
			
			if(todayReq.length > 0){
				let pendingWithCount = 0;
				for (const vvv of todayReq) {
					if(vvv.status == 2){
						pendingWithCount++;
						// pendingWithdrawAmount += vvv.final_amount;
					}
				}
				if(pendingWithCount > 0){
					return res.json({ status: 0, message: 'You have one pending withdraw request today, not allowed to place withdraw request', data: {} });
				}
			}
			
			if (todayReq.length >= WITH_REQ_PER_DAY){
				return res.json({ status: 0, message: 'You Have Already requested ' + WITH_REQ_PER_DAY+' time today, not allowed to place withdraw request', data: {} });
			}
			
			let settingDet   = await getMoneyList();
			let MIN_WITH_AMT = settingDet.MIN_WITH_AMT;
			if (parseFloat(amount) < MIN_WITH_AMT){
				return res.json({ status: 0, message: 'Minimum Withdraw Amount Is ' + CURR_SMBL + MIN_WITH_AMT, data: {} });
			}
			const currentAmountToWithdraw = winAmount - pendingWithdrawAmount;
			if (currentAmountToWithdraw >= amount){
				/* if (newAmount < amount) {
					return res.json({ status: 0, message: 'Its Compulsory To Maintain Atleast ' + CURR_SMBL + MIN_WINN_WLT_AMT+' In Winning Wallet', data: {} });
				} */
				return new Withdrawals({
					user_id: user_id,
					amount: amount,
					charge: charge,
					charge_amount: charge_amount,
					final_amount: final_amount,
					status: 2
				}).save(async function (err, withdrw) {
					if (err) return res.json({ status: 0, message: err.message, data: {} });
					var refe_id = withdrw._id;
					return res.json({ status: 1, message: 'Withdrawal Request Sent Successfully.', data: { post_balance: winAmount } });
					/* var post_balance = winAmount - amount;
					await Users.updateOne({ _id: user_id }, { wallet_wining: post_balance });

					await new Transactions({
						user_id: user_id,
						refe_id: refe_id,
						amount: final_amount,
						charge_amount: charge_amount,
						final_amount: amount,
						post_balance: post_balance,
						tnx_type: 6,//withdraw
						wallet_type: 1,//winning wallet
						details: "Winnings Withdraw",
						entry_type: 2,//debit entry
						created_by: req.userDet._id
					}).save(function (err, transaction) {
						if (err) return res.json({ status: 0, message: err.message, data: {} });
						return res.json({ status: 1, message: 'Withdrawal Request Sent Successfully.', data: { post_balance: post_balance} });
					}); */
				});
			} else {
				return res.json({ status: 0, message: 'insufficient Amount In Wallet, Not Allwed To Withdraw.', data: {} });
			}
		} catch (error) {
			return res.json({ status: 0, message: error.message, data: {} });
		}
	})();
}
/* 27-11-2023 */
exports.checkReferralCode = async (req, res) => {
	try {
		if (!await isValid(req.body.referral_code)) {
			return res.json({ status: 0, message: 'referral code is required', data: {} });
		}
		const { referral_code } = req.body;
		const foundUser = await Users.findOne({ referral_code: referral_code });
		if (foundUser){
			return res.json({ status: 1, message: 'Referral Code Exist', data: {}});
		} else {
			return res.json({ status: 0, message: 'No User Found For Given Referral Code', data: {}});
		}
	} catch (error) {
		return res.json({ status: 0, message: error.message });
	}
}
/* 21-10-2021 */
exports.applyReferralCode = (req, res) => {
	(async () => {
		try {
			if (!await isValid(req.body.referral_code)) {
				return res.json({ status: 0, message: 'referral code is required' });
			}
			
			let referral_code = req.body.referral_code;
			var user_id = req.userDet.id;
			const foundUser = await Users.findOne({ referral_code: referral_code });
			if (foundUser){
				if (user_id == foundUser._id){
					return res.json({ status: 0, message: 'You Can Not Use Your Own Referral Code', data: {} });
				} else {
					const applied = await Users.updateOne({ _id: user_id }, { refer_by: foundUser._id });
					if (applied.modifiedCount > 0){
						return res.json({ status: 1, message: 'Referral Code Applied Successfully', data:{}});
					} else {
						return res.json({ status: 0, message: 'Something Wrong', data:{}});
					}
				}
			} else {
				return res.json({ status: 0, message: 'No User Found For Given Referral Code' ,data:{}});
			}
			return res.json({ status: 0, message: 'Please try again' });
		} catch (error) {
			return res.json({ status: 0, message: error.message });
		}
	})();
}
/* 22-10-2021 */
exports.getGameRatio = (req, res) => {
	(async () => {
		try {
			let data = await GameRatios.find({}).select('_id name ratio_per ratio_per_amount');
			if (data) {
				return res.json({ status: 1, message: 'Game Ratios Found Successfully', data: data });
			} else {
				return res.json({ status: 0, message: "Game Ratios Not Found", data: {} });
			}
		} catch (error) {
			return res.json({ status: 0, message: error.message || "Something Went Wrong", data: {} });
		}
	})();
}

exports.getNoticeBoardList = (req, res) => {
	(async () => {
		try {
			let data = await NoticeBoard.find({status:1}).select('_id title description');
			if (data) {
				return res.json({ status: 1, message: 'Notice Board Found Successfully', data: data });
			} else {
				return res.json({ status: 0, message: "Notice Board Not Found", data: {} });
			}
		} catch (error) {
			return res.json({ status: 0, message: error.message || "Something Went Wrong", data: {} });
		}
	})();
}

exports.getColorGameRatio = (req, res) => {
	(async () => {
		try {
			let data = await GameRatioColors.find({}).select('_id name setting type');
			if (data) {
				return res.json({ status: 1, message: 'Game Ratios Found Successfully', data: data });
			} else {
				return res.json({ status: 0, message: "Game Ratios Not Found", data: {} });
			}
		} catch (error) {
			return res.json({ status: 0, message: error.message || "Something Went Wrong", data: {} });
		}
	})();
}
/* 20-10-2021 */
exports.withdrawHistory = async (req, res) => {
	(async () => {
		try {
			var { date, type, page } = req.body;
			let user_id = req.userDet._id;
			var condition = { user_id: user_id };
			condition = {};
			type = (typeof type !== 'undefined' && type != '') ? type : null;
			if (date != '') {
				let date1 = convertToUTC(date + ' 00:00:00');
				let date2 = convertToUTC(date + ' 23:59:59');
				condition.createdAt = { $gte: new Date(date1), $lte: new Date(date2) };
			}
			page = (page) ? page : 1;
			let perPage = 20;
			let offset = (perPage * (page - 1));

			await Withdrawals.aggregate([
				{ $match: condition },
				{ $sort: { "createdAt": -1 } },
				{ $limit: offset + perPage},
				{ $skip: offset},
				{$project:{
					_id:1,
					amount:1,
					charge:1,
					charge_amount:1,
					final_amount:1,
					status:1,
					createdAt:1,
					"status_txt":{
						$switch:{
							branches:[
								{ case:{ $eq:["$status",1] },then:'Success' },
								{ case:{ $eq:["$status",2] },then:'Pending' },
								{ case:{ $eq:["$status",3] },then:'Cancel' },
								{ case:{ $eq:["$status",4] },then:'Processing' },
							],
							default: "-"
						}
					}
				}}
			]).then(async (history) => {
				return res.json({ status: 1, message: 'Withdraw history get successfully.', data: history });
			});
		} catch (error) {
			console.log(error);
			return res.json({ status: 0, message: error.message, data: error });
		}
	})();
};
/* 04-08-2022 */
exports.updateNotification = (req, res) =>{
	(async () => {
		try {
			let user_id = req.userDet._id;
			let userDet = await Users.findOne({ _id: user_id });
			
			if (userDet){
				/* let nextNo = await addGetTransID();
				let nextNoInternal = await addGetTransID('internal_id');
				return res.json({ status: 1, message: 'Notification Setting Updated Successfully', data:{ nextNo: nextNo, nextNoInternal: nextNoInternal } }); */
				
				let noti_status = (userDet.noti_status == 1)?0:1;
				let update = { noti_status: noti_status };
				await Users.updateOne({ _id: user_id }, update);
				return res.json({ status: 1, message: 'Notification Setting Updated Successfully', data:{} });
			} else {
				return res.json({ status: 0, message: 'User Not Found', data:{} });
			}
		} catch (error) {
			return res.json({ status: 0, message: error.message,data:error });
		}
	})();
}
/* 16-08-2022 */
exports.getBonusWalletHistory = (req, res) =>{
	(async () => {
		try {
			let page = (req.body.page) ? req.body.page:1;
			let perPage = 10;
			let skip = (perPage * (page-1));
			let wh = { user_id: req.userDet._id, tnx_type: {$in: [12]}, wallet_type: 3, entry_type: 1 };
			
			if (typeof req.body.date !== 'undefined' && req.body.date != ''){
				var dt = req.body.date;
				let date1 = convertToUTCNew(dt + ' 00:00:00');
				let date2 = convertToUTCNew(dt + ' 23:59:59');
				wh.createdAt = { $gte: date1, $lte: date2 };
			}
			var whAggre = [
				{
					$match: wh
				},
				{
					$lookup: {
						from: "users",
						let: { 'refe_id': '$refe_id' },
						pipeline: [
							{
								"$match": {
									"$expr": { "$eq": ["$_id", "$$refe_id"] },
								},
							},
							{ $project: { _id: 1, mobile_no: 1, country_code: 1 } }
						],
						as: "user_det"
					}
				},
				{ $sort: { createdAt: -1 } },
				// { $project: { date: '$_id', market_id:1, _id: 1, createdAt:1 } },
				{ $limit: skip + perPage },
				{ $skip: skip },
			];
				
			let bonusHist = await Transactions.aggregate(whAggre);
			var bonusHistResp = await Promise.all(bonusHist.map(async(history) => {
				let userDet = '-';
				if(history.user_det && history.user_det.length > 0){
					let country_code = (typeof history.user_det[0].country_code == 'string' && history.user_det[0].country_code.slice(0, 1) == '+') ? history.user_det[0].country_code : '+'+history.user_det[0].country_code;
					userDet = country_code+history.user_det[0].mobile_no;
				}
				return {
					_id: history._id,
					// createdAt: moment(history.createdAt).format('DD MMM YYYY hh:mmA'),
					createdAt: history.createdAt,
					wallet_type: history.wallet_type,
					final_amount: history.final_amount,
					entry_type: history.entry_type,
					details: history.details,
					user: userDet,
				}
			}));
			return res.json({ status: 1, message: "Bonus history data",data: bonusHistResp});
		} catch (error) {
			console.log(error);
			return res.json({ status: 0, message: error });
		}
	})();
}
/* 02-11-2022 Start */
exports.getPassbookHistory = (req, res) =>{
	(async () => {
		try {
			/* if (!await isValid(req.body.page)) {
				return res.json({ status: 0, message: 'page is required' });
			} */
			let page = (req.body.page) ? req.body.page:1;
			let perPage = 20;
			let offset = (perPage * (page-1));
			//let wh = { user_id: req.userDet._id, show_to_user:1, pay_status:{$in:[0,1]} };
			let wh = { user_id: req.userDet._id, show_to_user:1 };
			
			if (typeof req.body.date !== 'undefined' && req.body.date != ''){
				var dt = req.body.date;
				let date1 = convertToUTCNew(dt + ' 00:00:00');
				let date2 = convertToUTCNew(dt + ' 23:59:59');
				wh.createdAt = { $gte: date1, $lte: date2 };
			}/*  else {
				var dt = getDateFormat();
				let date1 = convertToUTCNew(dt + ' 00:00:00');
				let date2 = convertToUTCNew(dt + ' 23:59:59');
				wh.createdAt = { $gte: date1, $lte: date2 };
			} */
			let wallet_history = await Transactions.find(wh)
				.limit(perPage)
				.skip(offset)
				.sort({
					createdAt: -1
				});
			//return res.json({ status: 1, message: "Passbook data get successfully",data: wallet_history});
				/* 1=place_bid 7=winning_credited */
			const allMarkets = await Markets.find({ status: 1 },"_id name");
			//let resp = [];
			const placeBidWinning = [], refundedBids = [];
			const resp = await Promise.all(wallet_history.map(async(itm) => {
				let itmObj = {
					_id: itm._id,
					// createdAt: moment(itm.createdAt).format('DD MMM, YY hh:mm A'),
					createdAt: itm.createdAt,
					wallet_type: itm.wallet_type,
					final_amount: itm.final_amount,
					entry_type: itm.entry_type,
					tnx_type: itm.tnx_type,
					details: itm.details,
					payment_type: itm.payment_type,
					title: itm.details,
					status_msg: "",
					status: itm.pay_status,
					bid_det: null,
					reference_id: ""
				};
				if(itm.tnx_type == 7){/* winning_credited */
					placeBidWinning.push(itm.refe_id.toString());
					const bidObj = await MarketBids.findOne({ _id: itm.refe_id });
					const bidData = await getBidResultDet(bidObj, allMarkets);
					itmObj.title = bidData.marketName;
					itmObj.status_msg = bidData.res_msg;
					itmObj.reference_id = bidObj.tnx_id;
					itmObj.bid_det = bidData;
					//placeBidWinning.push(itmObj);
					return itmObj;
				} else if (itm.tnx_type == 1 || itm.tnx_type == 2){/* 1=place_bid,2=refund */
					if(itm.tnx_type == 1 && placeBidWinning.indexOf(itm.refe_id.toString()) == -1){
						refundedBids.push(itm.refe_id.toString());
						const bidObj = await MarketBids.findOne({ _id: itm.refe_id });
						const bidData = await getBidResultDet(bidObj, allMarkets);
						itmObj.title = bidData.marketName;
						itmObj.status_msg = bidData.res_msg;
						itmObj.reference_id = bidObj.tnx_id;
						itmObj.bid_det = bidData;
						// console.log("itmObj", itmObj);
						//placeBidWinning.push(itmObj);
						return itmObj;
					} else if (itm.tnx_type == 2 && refundedBids.indexOf(itm.refe_id.toString()) == -1) {
						const bidObj = await MarketBids.findOne({ _id: itm.refe_id });
						const bidData = await getBidResultDet(bidObj, allMarkets);
						itmObj.title = bidData.marketName;
						itmObj.status_msg = bidData.res_msg;
						itmObj.reference_id = bidObj.tnx_id;
						itmObj.bid_det = bidData;
						//placeBidWinning.push(itmObj);
						return itmObj;
					}
				} else if (itm.tnx_type == 3){
					itmObj.title = "Bonus";
					//placeBidWinning.push(itmObj);
					return itmObj;
				} else if (itm.tnx_type == 4){
					itmObj.title = "Wallet";
					//placeBidWinning.push(itmObj);
					return itmObj;
				} else if (itm.tnx_type == 5){/* added_by_self */
					itmObj.title = "Wallet";
					itmObj.reference_id= itm.internal_tnx;
					itmObj.status_msg = "Success";
					if (itm.pay_status == 0) {
						itmObj.status_msg = "Pending";
					} else if (itm.pay_status == 2) {
						itmObj.status_msg = "Failed";
					}
					//placeBidWinning.push(itmObj);
					return itmObj;
				} else if (itm.tnx_type == 6){/* winning_withdraw */
					itmObj.title = "Withdraw";
					itmObj.status_msg = "Pending";
					const withObj = await Withdrawals.findOne({ itmObj: itm.refe_id });
					if(withObj){
						withObj.reference_id= withObj.transaction_id;
						if (withObj.status == 1) {
							itmObj.status_msg = "Processing";
						} else if (withObj.status == 2) {
							itmObj.status_msg = "Pending";
						} else if (withObj.status == 3) {
							itmObj.status_msg = "Cancel";
						}
					}
					//placeBidWinning.push(itmObj);
					return itmObj;
				} else if (itm.tnx_type == 8){/* deduct_by_admin */
					itmObj.title = "Wallet";
					itmObj.status_msg = "Deduct";
					//placeBidWinning.push(itmObj);
					return itmObj;
				} else if (itm.tnx_type == 9){/* deposit_bonus_credited */
					itmObj.title = "Wallet";
					itmObj.status_msg = "Deposit";
					return itmObj;
				} else if (itm.tnx_type == 10){/* bank valid bonus */
					itmObj.title = "Wallet";
					itmObj.status_msg = "";
					//placeBidWinning.push(itmObj);
					return itmObj;
				} else if (itm.tnx_type == 11){/* result rollback */
					itmObj.title = (itm.wallet_type == 1)?"Winning Wallet":"Wallet";
					itmObj.status_msg = "Rollback";
					const bidObj = await MarketBids.findOne({ _id: itm.refe_id });
					const bidData = await getBidResultDet(bidObj, allMarkets);
					itmObj.title = bidData.marketName;
					itmObj.reference_id = bidObj.tnx_id;
					itmObj.bid_det = bidData;
					//placeBidWinning.push(itmObj);
					return itmObj;
				} else if (itm.tnx_type == 12){/* referral_bonus_credited */
					itmObj.title = "Bonus Wallet";
					itmObj.status_msg = "";
					//placeBidWinning.push(itmObj);
					return itmObj;
				} else {
					//placeBidWinning.push(itmObj);
					return itmObj;
				}
				
			}));
			const response = resp.filter(function (el) {
			return el != null;
			});
			let res_data = []; let last_date = "";
			await Promise.all(response.map(async(itm) => {
				let bidRecDate = moment(new Date(itm.createdAt)).format('YYYY-MM-DD');
				if (last_date != bidRecDate) {
					res_data.push({
						'info': {
							"date": moment(new Date(itm.createdAt)).format('YYYY-MM-DD')
						},
						'data': [itm]
					});
					last_date = moment(new Date(itm.createdAt)).format('YYYY-MM-DD');
				} else {
					let newArrInd = await res_data.findIndex((v) => {
						return v.info.date == bidRecDate;
					});
					if (res_data[newArrInd]) {
						res_data[newArrInd].data.push(itm);
					}
				}
			}));
			return res.json({ status: 1, message: "Passbook data get successfully",data: res_data});
		} catch (error) {
			console.log("getPassbookHistory Error", error);
			return res.json({ status: 0, message: error?.message, data:error });
		}
	})();
}
/* 20-12-2023 Return Only Array */
exports.getPassbookHistoryV2 = (req, res) =>{
	(async () => {
		try {
			const page = (req.body.page) ? req.body.page:1;
			const perPage = 20;
			const offset = (perPage * (page-1));
			const wh = { user_id: req.userDet._id, show_to_user:1 };
			if (typeof req.body.date !== 'undefined' && req.body.date != ''){
				var dt = req.body.date;
				const date1 = convertToUTCNew(dt + ' 00:00:00');
				const date2 = convertToUTCNew(dt + ' 23:59:59');
				wh.createdAt = { $gte: date1, $lte: date2 };
			}
			const walletHistory = await Transactions.find(wh)
				.limit(perPage)
				.skip(offset)
				.sort({
					createdAt: -1
				});
				/* 1=place_bid 7=winning_credited */
			const allMarkets = await Markets.find({ status: 1 },"_id name");
			const resp = [];
			const placeBidWinning = [], refundedBids = [];
			for (const itm of walletHistory) {
				let itmObj = {
					_id: itm._id,
					// createdAt: moment(itm.createdAt).format('DD MMM, YY hh:mm A'),
					createdAt: itm.createdAt,
					wallet_type: itm.wallet_type,
					final_amount: itm.final_amount,
					entry_type: itm.entry_type,
					tnx_type: itm.tnx_type,
					details: itm.details,
					payment_type: itm.payment_type,
					title: itm.details,
					status_msg: "",
					status: itm.pay_status,
					bid_det: null,
					reference_id: ""
				};
				if(itm.tnx_type == 7){/* winning_credited */
					placeBidWinning.push(itm.refe_id.toString());
					const bidObj = await MarketBids.findOne({ _id: itm.refe_id });
					const bidData = await getBidResultDet(bidObj, allMarkets);
					itmObj.title = bidData.marketName;
					itmObj.status_msg = bidData.res_msg;
					itmObj.reference_id = bidObj.tnx_id;
					itmObj.bid_det = bidData;
				} else if (itm.tnx_type == 1 || itm.tnx_type == 2){/* 1=place_bid,2=refund */
					if(itm.tnx_type == 1 && placeBidWinning.indexOf(itm.refe_id.toString()) == -1){
						refundedBids.push(itm.refe_id.toString());
						const bidObj = await MarketBids.findOne({ _id: itm.refe_id });
						const bidData = await getBidResultDet(bidObj, allMarkets);
						itmObj.title = bidData.marketName;
						itmObj.status_msg = bidData.res_msg;
						itmObj.reference_id = bidObj.tnx_id;
						itmObj.bid_det = bidData;
					} else if (itm.tnx_type == 2 && refundedBids.indexOf(itm.refe_id.toString()) == -1) {
						const bidObj = await MarketBids.findOne({ _id: itm.refe_id });
						const bidData = await getBidResultDet(bidObj, allMarkets);
						itmObj.title = bidData.marketName;
						itmObj.status_msg = bidData.res_msg;
						itmObj.reference_id = bidObj.tnx_id;
						itmObj.bid_det = bidData;
					}
				} else if (itm.tnx_type == 3){
					itmObj.title = "Bonus";
				} else if (itm.tnx_type == 4){
					itmObj.title = "Wallet";
				} else if (itm.tnx_type == 5){/* added_by_self */
					itmObj.title = "Wallet";
					itmObj.reference_id= itm.internal_tnx;
					itmObj.status_msg = "Success";
					if (itm.pay_status == 0) {
						itmObj.status_msg = "Pending";
					} else if (itm.pay_status == 2) {
						itmObj.status_msg = "Failed";
					}
				} else if (itm.tnx_type == 6){/* winning_withdraw */
					itmObj.title = "Withdraw";
					itmObj.status_msg = "Pending";
					const withObj = await Withdrawals.findOne({ _id: itm.refe_id });
					if(withObj){
						withObj.reference_id= withObj.transaction_id;
						if (withObj.status == 1) {
							itmObj.status_msg = "Success";
						} else if (withObj.status == 2) {
							itmObj.status_msg = "Pending";
						} else if (withObj.status == 3) {
							itmObj.status_msg = "Cancel";
						} else if (withObj.status == 4) {
							itmObj.status_msg = "Processing";
						}
					}
				} else if (itm.tnx_type == 8){/* deduct_by_admin */
					itmObj.title = "Wallet";
					itmObj.status_msg = "Deduct";
				} else if (itm.tnx_type == 9){/* deposit_bonus_credited */
					itmObj.title = "Wallet";
					itmObj.status_msg = "Deposit";
				} else if (itm.tnx_type == 10){/* bank valid bonus */
					itmObj.title = "Wallet";
					itmObj.status_msg = "";
				} else if (itm.tnx_type == 11){/* result rollback */
					itmObj.title = (itm.wallet_type == 1)?"Winning Wallet":"Wallet";
					itmObj.status_msg = "Rollback";
					const bidObj = await MarketBids.findOne({ _id: itm.refe_id });
					const bidData = await getBidResultDet(bidObj, allMarkets);
					itmObj.title = bidData.marketName;
					itmObj.reference_id = bidObj.tnx_id;
					itmObj.bid_det = bidData;
				} else if (itm.tnx_type == 12){/* referral_bonus_credited */
					itmObj.title = "Bonus Wallet";
					itmObj.status_msg = "";
				} else if (itm.tnx_type == 13){/* bank change penalty */
					itmObj.title = "Wallet";
					itmObj.status_msg = "";
				}
				resp.push(itmObj);
			}
			const response = resp;
			return res.json({ status: 1, message: "Passbook data get successfully",data: response});
		} catch (error) {
			console.log("getPassbookHistory v2 Error", error);
			return res.json({ status: 0, message: error?.message, data:error });
		}
	})();
}
const getBidResultDet = async (bidObj, allMarkets) => {
	const bidMarket = allMarkets.filter((item) => {
		return item._id.toString() == bidObj.market_id.toString();
	});
	const marketName = bidMarket.length ? bidMarket[0].name : "";
	var res_msg = 'Place Bid', win_amt = "";
	if (bidObj.is_win == 1) {
		res_msg = 'Won';
	} else if (bidObj.is_win == 2) {
		res_msg = 'Lost';
		win_amt = bidObj.win_amount;
	} else if (bidObj.is_win == 3) {
		res_msg = 'Refund';
	}
	let game_name = '', game_text2 = '';
	let gameDet = getGameDet(bidObj.game_type_id);
	let game_det = '', bid_det = '';
	if (gameDet != '') {
		game_name = gameDet.name;
		game_det = gameDet.name;
		game_det += ', ' + gameDet.text;
		if ([9, 10, 11].indexOf(bidObj.game_type_id) > -1) {
			game_text2 = gameDet.text2;
			game_det += ' + ' + game_text2;
		}
		game_text2 = game_text2;
	}
	bid_det = bidObj.panna_1;
	if (game_text2 != '') {
		bid_det += '-' + bidObj.panna_2;
	}
	const legend = await getResultLegend(bidObj);
	return { game_det: game_det, bid_det: bid_det, res_msg: res_msg, marketName:marketName, legend: legend, win_amt: win_amt };
};
const getResultLegend = async (bidObj) => {
	var wh = {};
	if (bidObj.result_id){
		wh = { _id:bidObj.result_id };
	} else {
		let dateNew = convertToUTC(moment(bidObj.createdAt).format('YYYY-MM-DD') + ' 00:00:00');
		let dateNew2 = convertToUTC(moment(bidObj.createdAt).format('YYYY-MM-DD') + ' 23:59:59');
		var weekType = (new Date(bidObj.createdAt)).getDay();
		wh = {
			week_day_type: weekType, 
			market_id: bidObj.market_id, 
			declared_date: { $gte: new Date(dateNew), $lte: new Date(dateNew2) }
		};
	}
	
	return await MarketResults.findOne(wh)
	.then(function (marRes) {
		if (marRes) {
			let legend = '';
			legend = (marRes.is_open_published == 1 && marRes.op_1 != null) ? legend + marRes.op_1 : legend + '*';
			legend = (marRes.is_open_published == 1 && marRes.op_2 != null) ? legend + marRes.op_2 : legend + '*';
			legend = (marRes.is_open_published == 1 && marRes.op_3 != null) ? legend + marRes.op_3 + '-' : legend + '*-';
			legend = (marRes.is_open_published == 1 && marRes.digit_1 != null) ? legend + marRes.digit_1 : legend + '*';
			legend = (marRes.is_published == 1 && marRes.digit_2 != null) ? legend + marRes.digit_2 + '-' : legend + '*-';
			legend = (marRes.is_published == 1 && marRes.cp_1 != null) ? legend + marRes.cp_1 : legend + '*';
			legend = (marRes.is_published == 1 && marRes.cp_2 != null) ? legend + marRes.cp_2 : legend + '*';
			legend = (marRes.is_published == 1 && marRes.cp_3 != null) ? legend + marRes.cp_3 : legend;
			return legend;
		} else {
			return '***-**-***';
		}
	})
	.catch(function (error) {
		return '***-**-***';
	});
};
/* 02-11-2022 End */
/* 21-11-2022 Start */
exports.getHashString = (req, res) =>{
	(async () => {
		try {
			const inputs = req.body;
			const secure_hash = await createHashMobilePayment(inputs);
			const res_data = {hash_string: secure_hash};
			return res.json({ status: 1, message: "Get hashtring successfully",data: res_data});
		} catch (error) {
			console.log(error);
			return res.json({ status: 0, message: error });
		}
	})();
}
/* 21-11-2022 End */

/* 12-12-2023 Start */
exports.getAllMarketResultByDate = (req, res) =>{
	(async () => {
		try {
			const { date } = req.query;
			const resultDate = date ? new Date(date): new Date();
			const wh = { result_date: resultDate };
			const results = await MarketResults.find(wh).populate('market_id', '_id name');
			const items = [];
			for (const itm of results) {
				const result = getResultString(itm);
				// const ttt = JSON.parse(JSON.stringify(itm));
				items.push({
					id: itm?.market_id?._id,
					name: itm?.market_id?.name,
					legend: result
				});
			}
			return res.json({ status: 1, message: "Get result successfully", data: items});
		} catch (error) {
			console.log(error);
			return res.json({ status: 0, message: error });
		}
	})();
}
const getResultString = (marRes) => {
	if (marRes) {
		let legend = '';
		legend = (marRes.is_open_published == 1 && marRes.op_1 != null) ? legend + marRes.op_1 : legend + '*';
		legend = (marRes.is_open_published == 1 && marRes.op_2 != null) ? legend + marRes.op_2 : legend + '*';
		legend = (marRes.is_open_published == 1 && marRes.op_3 != null) ? legend + marRes.op_3 + '-' : legend + '*-';
		legend = (marRes.is_open_published == 1 && marRes.digit_1 != null) ? legend + marRes.digit_1 : legend + '*';
		legend = (marRes.is_published == 1 && marRes.digit_2 != null) ? legend + marRes.digit_2 + '-' : legend + '*-';
		legend = (marRes.is_published == 1 && marRes.cp_1 != null) ? legend + marRes.cp_1 : legend + '*';
		legend = (marRes.is_published == 1 && marRes.cp_2 != null) ? legend + marRes.cp_2 : legend + '*';
		legend = (marRes.is_published == 1 && marRes.cp_3 != null) ? legend + marRes.cp_3 : legend;
		return legend;
	} else {
		return '***-**-***';
	}
};
/* 12-12-2023 End */
/* 14-02-2024 Start */
exports.getAnilexPaymentURL = (req, res) =>{
	(async () => {
		try {
			const { amount } = req.body;
			const { id: user_id } = req.userDet;
			const resp = await generatePaymentIntent(amount, user_id);
			return res.json(resp);
		} catch (error) {
			console.log("ERROR getAnilexPaymentURL :: ", error);
			return res.json({ status: 0, message: error?.message, data: {} });
		}
	})();
}
exports.getAnilexPaymentStatus = (req, res) =>{
	(async () => {
		try {
			const { transaction_id } = req.body;
			const resp = await checkPaymentStatus(transaction_id);
			return res.json(resp);
		} catch (error) {
			console.log("ERROR getAnilexPaymentStatus :: ", error);
			return res.json({ status: 0, message: error?.message, data: {} });
		}
	})();
}
/* 14-02-2024 End */
/* 
	23-02-2024 Start
	If pay status 1 then add 5% bonus & refered user will get referral bonus
*/
const addBonusReferalAmount = async (pay_status, amount, userDet, transaction_id, totTrans) => {
	const user_id = userDet._id;
	/* Add 5% amount to bonus wallet 16-08-2022 start */
	const settingDet = await getMoneyList();
	const minDepoAmtForBonus = settingDet.MIN_DEPO_AMT_FOR_BONUS;
	const referralBonusAmount = settingDet.REFERRAL_BONUS_AMOUNT;
	if(parseInt(pay_status) == 1){
		if(parseInt(amount) >= minDepoAmtForBonus){
			let fivePerBonus = (amount * 5/100);
			fivePerBonus = Math.floor(fivePerBonus);
			const updBnsWalletAmt = (userDet.wallet_bonus && userDet.wallet_bonus > 0)?(Math.floor(userDet.wallet_bonus) + fivePerBonus):fivePerBonus;
			await new Transactions({
				user_id: user_id,
				refe_id: transaction_id,
				amount: fivePerBonus,
				final_amount: fivePerBonus,
				post_balance: updBnsWalletAmt,
				tnx_type: 9,//deposit_bonus_credited
				wallet_type: 3,//bonus wallet
				details: "Deposit Bonus Credited",
				entry_type: 1,//credit entry
				created_by: user_id
			}).save(async function (err1, trx) {
				//5% Bonus Credited
				await Users.updateOne({ _id: user_id }, { wallet_bonus: updBnsWalletAmt });
			});
		}
	}
	if (parseInt(pay_status) == 1 && totTrans && totTrans.length == 0 && userDet.refer_by) {
		const refeUser = await Users.findOne({ _id: userDet.refer_by });
		if (refeUser) {
			const depobamt = referralBonusAmount;//settingDet.DEPO_BONUS_AMT;
			const post_balance2 = (refeUser.wallet_bonus && refeUser.wallet_bonus > 0)?(Math.floor(refeUser.wallet_bonus) + Math.floor(depobamt)):Math.floor(depobamt);
			await new Transactions({
				user_id: refeUser._id,
				refe_id: user_id,
				amount: depobamt,
				final_amount: depobamt,
				post_balance: post_balance2,
				tnx_type: 12,//referral_bonus_credited
				wallet_type: 3,//bonus wallet
				details: "Referral Bonus Credited",
				entry_type: 1,//credit entry
				created_by: userDet._id
			}).save(async function (err, transaction) {
				if (err) console.log("err 1192", err);
				await Users.updateOne({ _id: refeUser._id }, { wallet_bonus: post_balance2 });
			});
		}
	}
	return true;
};
exports.addBonusReferalAmount = addBonusReferalAmount;
/* 23-02-2024 End */

/* 12-04-2024 Amez World Start */
exports.getAmezWorldPaymentURL = (req, res) =>{
	(async () => {
		try {
			const { amount, type = "AMEZ_WORLD", upi_id } = req.body;

			const { id: user_id, mobile_no, firstname } = req.userDet;
			if(type == "AMEZ_WORLD"){
				const resp = await AmezWorld.generatePaymentIntent(amount, user_id, mobile_no, firstname);
				return res.json(resp);
			} else if(type == "GECKIOPAY"){
				const resp = await Geckiopay.generatePaymentIntent(amount, user_id, mobile_no, firstname);
				return res.json(resp);
			} else if(type == "GENNIEPAY"){
				const resp = await GenniePay.generatePaymentIntent(amount, user_id, mobile_no, firstname, upi_id);
				/* Create Pending Transaction For GENNIEPAY Start */
				if(resp?.status == 1){
					const user = req.userDet;
					const post_balance = user.wallet + parseFloat(amount);
					const orderId = resp?.data?.data?.orderId;
					const internal_tnx = await getLastIntTransNo();
					const insTrans = {
							user_id: user_id,
							tnx: orderId,
							amount: amount,
							final_amount: amount,
							post_balance: post_balance,
							tnx_type: 5,//added by self
							wallet_type: 2,//simple wallet
							details: "Added",
							entry_type: 1,//credit entry
							internal_tnx: internal_tnx,
							payment_type: "",
							// order_id: order_id,
							pay_status: 0,
							check_inno_status: 0,
							created_by: user_id
						};
					await Transactions.create(insTrans);
				}
				/* Create Pending Transaction For GENNIEPAY End */

				return res.json(resp);
			} else if(type == "MAGICPAY"){
				const resp = await MagicPay.generatePaymentIntent(amount, user_id, mobile_no, firstname);
				return res.json(resp);
			}
		} catch (error) {
			console.log("ERROR getAmezWorldPaymentURL :: ", error);
			return res.json({ status: 0, message: error?.message, data: {} });
		}
	})();
}

exports.getAmezWorldPaymentStatus = (req, res) =>{
	(async () => {
		try {
			const { transaction_id, type = "AMEZ_WORLD" } = req.body;
			if(type == "AMEZ_WORLD"){
				const resp = await AmezWorld.checkPaymentStatus(transaction_id);
				return res.json(resp);
			} else if(type == "GECKIOPAY"){
				const resp = await Geckiopay.checkPaymentStatus(transaction_id);
				return res.json(resp);
			} else if(type == "GENNIEPAY"){
				const resp = await GenniePay.checkPaymentStatus(transaction_id);
				return res.json(resp);
			} else if(type == "MAGICPAY"){
				const resp = await MagicPay.checkPaymentStatus(transaction_id);
				return res.json(resp);
			}
		} catch (error) {
			console.log("ERROR getAmezWorldPaymentStatus :: ", error);
			return res.json({ status: 0, message: error?.message, data: {} });
		}
	})();
}
/* 12-04-2024 End */