var mongoose = require('mongoose');
var MarketBids = require('../models/MarketBids');
const { convertToUTC, getGameDet, getWeekDay, getDateFormat, convertToUTCNew } = require('../services/common');

const { Markets } = require('../models/Markets');
const MarketResults = require('../models/MarketResults');
const Transactions = require('../models/Transactions');
const Notification = require('../models/Notification');
// var dateFormat = require('dateformat');
var moment = require('moment');
/* 20-10-2021 */
exports.getUserBidHist = async (req, res) => {
  (async () => {
    try {
      var { is_filter, date, is_win, is_loss, market_ids } = req.body;
      //await MarketBids.updateMany({ market_id:'61979185e7f6d94a5435a2e3',user_id:'6198b7689957601bb780d817' }, { is_win: 0 });
      let user_id = req.userDet._id;
      var condition = { user_id: user_id };
      if (is_filter == 1) {
        if (is_win == 1 && is_loss == 1) {
          condition.is_win = { $in: [1, 2] };
        } else {
          if (is_win == 1) {
            condition.is_win = 1;
          } else if (is_loss == 1) {
            condition.is_win = 2;
          }
        }
        if (date != '') {
          let date1 = convertToUTC(date + ' 00:00:00');
          let date2 = convertToUTC(date + ' 23:59:59');
          //condition.createdAt = { $gte: date1, $lte: date2 };
          condition.createdAt = { $gte: new Date(date1), $lte: new Date(date2) };
          //condition.createdAt = { $gte: new Date(date + ' 00:00:00'), $lte: new Date(date + ' 23:59:59') };
        }
        if (market_ids != '') {
          market_ids = market_ids.toString().split(',');
          if (market_ids.length > 0) {
            market_ids = await Promise.all(market_ids.map(async (sinmar) => {
              return mongoose.Types.ObjectId(sinmar)
            }));
            condition.market_id = { $in: market_ids };
          }
        }
      }
      console.log(condition);
      //await MarketBids.find(condition).populate({ path: 'market_id', select: "_id name" }).then((users) => {
      await MarketBids.aggregate([
        {
          $match: condition
        },
        {
          $lookup:
          {
            from: "markets",
            /* localField: "market_id",
            foreignField: "_id", */
            let: { 'market_id': '$market_id' },
            pipeline: [
              {
                "$match": {
                  "$expr": { "$eq": ["$_id", "$$market_id"] },
                },
              },
              { $project: { _id: 1, name: 1 } }
            ],
            as: "market_det"
          }
        },

        /* {
            $group: {
                _id: {
                    "marketID": "$market_id",
                    "createdAtID": { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } },
                    "marketDet": "$market_det"
                }
            }
        },
        {
            $group: {
                "_id": "$_id.marketID",
                "dates": {
                    "$push": {
                        "date": "$_id.createdAtID",
                        "m_id": "$_id.marketID",
                        "marketDet": "$_id.marketDet",
                    },
                }
            }
        }, */

        /* { $group: { _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } }, markets: { $push: '$market_id' } } },
         */
        { $group: { _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } }, markets: { $addToSet: { "$arrayElemAt": ["$market_det", 0] } } } },
        // { $sort: { _id: -1 } },
        { $sort: { _id: -1 } },
        { $project: { date: '$_id', 'markets._id': 1, 'markets.name': 1, _id: 0, createdAt: 1 } },

        /* {
            $group: {
                _id: '$_id',
                market_ids: { $first: '$markets' }
            }
        }, */


      ]).then(async (markets) => {
        let myResp = []; let myResp_r = [];

        if (markets.length > 0) {
          //return res.json({ status: 1, message: 'data', data: markets });
          myResp = await Promise.all(markets.map(async (row) => {
            if (row.markets.length > 0) {
              let marketByDates = row.markets;
              return await Promise.all(marketByDates.map(async (sinMar) => {
                //let cond2 = { user_id: user_id, createdAt: { $dateToString: { format: "%Y-%m-%d", date: "'" + dates[k] + "'" }} };

                let date12 = await convertToUTC(row.date + ' 00:00:00');
                let date22 = await convertToUTC(row.date + ' 23:59:59');
                // , user_id: user_id
                let cond2 = { market_id: sinMar._id, user_id: user_id, createdAt: { $gte: new Date(date12), $lte: new Date(date22) } };
                if (is_filter == 1) {
                  if (is_win == 1 && is_loss == 1) {
                    cond2.is_win = { $in: [1, 2] };
                  } else {
                    if (is_win == 1) {
                      cond2.is_win = 1;
                    } else if (is_loss == 1) {
                      cond2.is_win = 2;
                    }
                  }
                }

                var users = await MarketBids.find(cond2).sort({ createdAt: -1 });
                var weekType = await getWeekDay(new Date(row.date));
                weekType = (weekType == 0) ? 7 : weekType;

                let dateNew = await convertToUTC(row.date + ' 00:00:00');
                let dateNew2 = await convertToUTC(row.date + ' 23:59:59');

                var marRes = await MarketResults.findOne({ week_day_type: weekType, market_id: sinMar._id, declared_date: { $gte: new Date(dateNew), $lte: new Date(dateNew2) } });
                if (users.length > 0) {
                  let vdata = await Promise.all(users.map(async (dObj) => {
                    let win_msg = '';
                    if (dObj.is_win == 1) {
                      win_msg = 'You won!!!';
                    }
                    let game_name = ''; let game_text1 = ''; let game_text2 = '';
                    let gameDet = await getGameDet(dObj.game_type_id);
                    if (gameDet != '') {
                      game_name = gameDet.name;
                      game_text1 = gameDet.text;
                      if ([9, 10, 11].indexOf(dObj.game_type_id) > -1) {
                        game_text2 = gameDet.text2;
                      }
                      game_text2 = game_text2;
                    }
                    let subDet = [
                      { text: game_text1, value: dObj.panna_1 }
                    ];
                    if (game_text2 != '') {
                      subDet.push({ text: game_text2, value: dObj.panna_2 });
                    }
                    subDet.push({ text: 'Bid Value', value: dObj.amount });
                    if (win_msg != '') {
                      subDet.push({ text: win_msg, value: dObj.win_amount });
                    } else if (dObj.is_win == 2) {
                      subDet.push({ text: 'You loose!!!', value: dObj.amount });
                    }
                    return {
                      _id: dObj._id,
                      market_id: dObj.market_id.name,
                      game_type_id: dObj.game_type_id,
                      amount: dObj.amount,
                      is_win: dObj.is_win,
                      win_amount: dObj.win_amount,
                      game_name: game_name,
                      sub_det: subDet,
                      createdAt: dObj.createdAt,
                    };
                  }));
                  var legend = '***-**-***';
                  if (marRes) {
                    legend = '';
                    legend = (marRes.is_open_published == 1 && marRes.op_1 != null) ? legend + marRes.op_1 : legend + '*';
                    legend = (marRes.is_open_published == 1 && marRes.op_2 != null) ? legend + marRes.op_2 : legend + '*';
                    legend = (marRes.is_open_published == 1 && marRes.op_3 != null) ? legend + marRes.op_3 + '-' : legend + '*-';
                    legend = (marRes.is_open_published == 1 && marRes.digit_1 != null) ? legend + marRes.digit_1 : legend + '*';
                    /*legend = (marRes.op_1 != null) ? legend + marRes.op_1 : legend + '*';
                    legend = (marRes.op_2 != null) ? legend + marRes.op_2 : legend + '*';
                    legend = (marRes.op_3 != null) ? legend + marRes.op_3 + '-' : legend + '*-';
                    legend = (marRes.digit_1 != null) ? legend + marRes.digit_1 : legend;*/
                    legend = (marRes.is_published == 1 && marRes.digit_2 != null) ? legend + marRes.digit_2 + '-' : legend + '*-';
                    legend = (marRes.is_published == 1 && marRes.cp_1 != null) ? legend + marRes.cp_1 : legend + '*';
                    legend = (marRes.is_published == 1 && marRes.cp_2 != null) ? legend + marRes.cp_2 : legend + '*';
                    legend = (marRes.is_published == 1 && marRes.cp_3 != null) ? legend + marRes.cp_3 : legend;
                  }
                  return {
                    info: {
                      market: (sinMar ? sinMar.name : '-'),
                      legend: legend,
                      //legendArr: marRes,
                      date: row.date
                    },
                    bids: vdata
                  }
                }/* users.length */
              }));
            }
          }));/* for market */
          return res.json({ status: 1, message: 'User bid data get successfully.', data: myResp });
        } else {
          return res.json({ status: 1, message: 'User bid data get successfully.', data: myResp });
        }
      });
    } catch (error) {
      console.log(error);
      return res.json({ status: 0, message: error, data: {} });
    }
  })();
};
/* 22-11-2021 */
exports.getUserBidHistV2 = async (req, res) => {
  (async () => {
    try {
      var { is_filter, date, is_win, is_loss, market_ids } = req.body;

      let user_id = req.userDet._id;
      var condition = { user_id: user_id };

      var tdyDate = getDateFormat();
      var aggrLimit = { $limit: 50 };
      if (is_filter == 1) {
        if (is_win == 1 && is_loss == 1) {
          condition.is_win = { $in: [1, 2] };
        } else {
          if (is_win == 1) {
            condition.is_win = 1;
          } else if (is_loss == 1) {
            condition.is_win = 2;
          }
        }
        if (date != '') {
          aggrLimit = '';
          let date1 = convertToUTC(date + ' 00:00:00');
          let date2 = convertToUTC(date + ' 23:59:59');
          condition.createdAt = { $gte: new Date(date1), $lte: new Date(date2) };
        } else {
          let date1 = convertToUTC(tdyDate + ' 00:00:00');
          let date2 = convertToUTC(tdyDate + ' 23:59:59');
          condition.createdAt = { $gte: new Date(date1), $lte: new Date(date2) };
          let todayBids = await MarketBids.where(condition).countDocuments();
          if (todayBids > 50) {
            aggrLimit = '';
          } else {
            if (todayBids == 0) {
              delete condition.createdAt;
            }
          }
        }
        if (market_ids != '') {
          market_ids = market_ids.toString().split(',');
          if (market_ids.length > 0) {
            market_ids = await Promise.all(market_ids.map(async (sinmar) => {
              return mongoose.Types.ObjectId(sinmar)
            }));
            condition.market_id = { $in: market_ids };
          }
        }
      } else {
        let date1 = convertToUTC(tdyDate + ' 00:00:00');
        let date2 = convertToUTC(tdyDate + ' 23:59:59');
        condition.createdAt = { $gte: new Date(date1), $lte: new Date(date2) };
        let todayBids = await MarketBids.where(condition).countDocuments();
        if (todayBids > 50) {
          aggrLimit = '';
        } else {
          if (todayBids == 0) {
            delete condition.createdAt;
          }
        }
      }
      /* let dateToday = getDateFormat();
      let date1 = convertToUTCNew(dateToday + ' 00:00:00');
      let date2 = convertToUTCNew(dateToday + ' 23:59:59');
      var condition = { user_id: user_id, createdAt: { $gte: date1, $lte: date2 } }; */
      //console.log(condition);
      var whAggre = [
        {
          $match: condition
        },
        {
          $lookup: {
            from: "markets",
            let: { 'market_id': '$market_id' },
            pipeline: [
              {
                "$match": {
                  "$expr": { "$eq": ["$_id", "$$market_id"] },
                },
              },
              { $project: { _id: 1, name: 1 } }
            ],
            as: "market_det"
          }
        },
        { $sort: { createdAt: -1 } },
        // { $project: { date: '$_id', market_id:1, _id: 1, createdAt:1 } },
      ];
      if (aggrLimit != '') {
        whAggre.push(aggrLimit);
      }
      let markets = await MarketBids.aggregate(whAggre);

      let res_data = [];
      let last_market_id = "";
      await Promise.all(markets.map(async (m) => {
        let win_msg = (m.is_win == 1) ? 'You won!!!' : '';
        let game_name = '';
        let game_text1 = '';
        let game_text2 = '';
        let gameDet = getGameDet(m.game_type_id);
        if (gameDet != '') {
          game_name = gameDet.name;
          game_text1 = gameDet.text;
          if ([9, 10, 11].indexOf(m.game_type_id) > -1) {
            game_text2 = gameDet.text2;
          }
          game_text2 = game_text2;
        }
        let subDet = [{ text: game_text1, value: m.panna_1 }];
        if (game_text2 != '') {
          subDet.push({ text: game_text2, value: m.panna_2 });
        }
        subDet.push({ text: 'Bid Value', value: parseInt(m.amount) });
        if (win_msg != '') {
          subDet.push({ text: win_msg, value: parseInt(m.win_amount) });
        } else if (m.is_win == 2) {
          subDet.push({ text: 'You loose!!!', value: parseInt(m.amount) });
        }
        let dateNew = convertToUTC(moment(m.createdAt).format('YYYY-MM-DD') + ' 00:00:00');
        let dateNew2 = convertToUTC(moment(m.createdAt).format('YYYY-MM-DD') + ' 23:59:59');

        var weekType = (new Date(m.createdAt)).getDay();
        await MarketResults.findOne({ week_day_type: weekType, market_id: m.market_id, declared_date: { $gte: new Date(dateNew), $lte: new Date(dateNew2) } }).then(function (marRes) {
          if (last_market_id != m.market_id.toString()) {
            var legend = '***-**-***';
            if (marRes) {
              legend = '';
              legend = (marRes.is_open_published == 1 && marRes.op_1 != null) ? legend + marRes.op_1 : legend + '*';
              legend = (marRes.is_open_published == 1 && marRes.op_2 != null) ? legend + marRes.op_2 : legend + '*';
              legend = (marRes.is_open_published == 1 && marRes.op_3 != null) ? legend + marRes.op_3 + '-' : legend + '*-';
              legend = (marRes.is_open_published == 1 && marRes.digit_1 != null) ? legend + marRes.digit_1 : legend + '*';
              legend = (marRes.is_published == 1 && marRes.digit_2 != null) ? legend + marRes.digit_2 + '-' : legend + '*-';
              legend = (marRes.is_published == 1 && marRes.cp_1 != null) ? legend + marRes.cp_1 : legend + '*';
              legend = (marRes.is_published == 1 && marRes.cp_2 != null) ? legend + marRes.cp_2 : legend + '*';
              legend = (marRes.is_published == 1 && marRes.cp_3 != null) ? legend + marRes.cp_3 : legend;
            }
            //console.log({ week_day_type: weekType, market_id: m.market_id, declared_date: { $gte: new Date(dateNew), $lte: new Date(dateNew2) } });
            res_data.push({
              'info': {
                "market": m.market_det[0].name,
                "legend": legend,
                "date": moment(m.createdAt).format('YYYY-MM-DD')
              },
              'data': [{
                _id: m._id,
                market_id: m.market_det[0].name,
                game_type_id: m.game_type_id,
                amount: m.amount,
                is_win: m.is_win,
                win_amount: ((m.win_amount) ? parseInt(m.win_amount) : null),
                game_name: game_name,
                sub_det: subDet,
                createdAt: m.createdAt
              }]
            });
            last_market_id = m.market_id.toString();
            // console.log(m.market_det[0].name);
          }
          else {
            if (res_data[res_data.length - 1]) {
              res_data[res_data.length - 1].data.push({
                _id: m._id,
                market_id: m.market_det[0].name,
                game_type_id: m.game_type_id,
                amount: m.amount,
                is_win: m.is_win,
                win_amount: ((m.win_amount) ? parseInt(m.win_amount) : null),
                game_name: game_name,
                sub_det: subDet,
                createdAt: m.createdAt
              });
            }
          }
        });
      }));
      return res.json({ status: 1, message: 'User bid data get successfully.', data: res_data });
      console.log(res_data);
      // old logic below BY MHNDR
      //await MarketBids.find(condition).populate({ path: 'market_id', select: "_id name" }).then((users) => {
      await MarketBids.aggregate([
        {
          $match: condition
        },
        {
          $lookup:
          {
            from: "markets",
            /* localField: "market_id",
            foreignField: "_id", */
            let: { 'market_id': '$market_id' },
            pipeline: [
              {
                "$match": {
                  "$expr": { "$eq": ["$_id", "$$market_id"] },
                },
              },
              { $project: { _id: 1, name: 1 } }
            ],
            as: "market_det"
          }
        },

        /* {
            $group: {
                _id: {
                    "marketID": "$market_id",
                    "createdAtID": { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } },
                    "marketDet": "$market_det"
                }
            }
        },
        {
            $group: {
                "_id": "$_id.marketID",
                "dates": {
                    "$push": {
                        "date": "$_id.createdAtID",
                        "m_id": "$_id.marketID",
                        "marketDet": "$_id.marketDet",
                    },
                }
            }
        }, */

        /* { $group: { _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } }, markets: { $push: '$market_id' } } },
         */
        { $group: { _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } }, markets: { $addToSet: { "$arrayElemAt": ["$market_det", 0] } } } },
        // { $sort: { _id: -1 } },
        { $sort: { _id: -1 } },
        { $project: { date: '$_id', 'markets._id': 1, 'markets.name': 1, _id: 0, createdAt: 1 } },

        /* {
            $group: {
                _id: '$_id',
                market_ids: { $first: '$markets' }
            }
        }, */


      ]).then(async (markets) => {
        let myResp = []; let myResp_r = [];

        if (markets.length > 0) {
          //return res.json({ status: 1, message: 'data', data: markets });
          myResp = await Promise.all(markets.map(async (row) => {
            if (row.markets.length > 0) {
              let marketByDates = row.markets;
              return await Promise.all(marketByDates.map(async (sinMar) => {
                //let cond2 = { user_id: user_id, createdAt: { $dateToString: { format: "%Y-%m-%d", date: "'" + dates[k] + "'" }} };

                let date12 = await convertToUTC(row.date + ' 00:00:00');
                let date22 = await convertToUTC(row.date + ' 23:59:59');
                // , user_id: user_id
                let cond2 = { market_id: sinMar._id, user_id: user_id, createdAt: { $gte: new Date(date12), $lte: new Date(date22) } };
                if (is_filter == 1) {
                  if (is_win == 1 && is_loss == 1) {
                    cond2.is_win = { $in: [1, 2] };
                  } else {
                    if (is_win == 1) {
                      cond2.is_win = 1;
                    } else if (is_loss == 1) {
                      cond2.is_win = 2;
                    }
                  }
                }

                var users = await MarketBids.find(cond2).sort({ createdAt: -1 });
                var weekType = await getWeekDay(new Date(row.date));

                let dateNew = await convertToUTC(row.date + ' 00:00:00');
                let dateNew2 = await convertToUTC(row.date + ' 23:59:59');

                var marRes = await MarketResults.findOne({ week_day_type: weekType, market_id: sinMar._id, declared_date: { $gte: new Date(dateNew), $lte: new Date(dateNew2) } });
                if (users.length > 0) {
                  let vdata = await Promise.all(users.map(async (dObj) => {
                    let win_msg = '';
                    if (dObj.is_win == 1) {
                      win_msg = 'You won!!!';
                    }
                    let game_name = ''; let game_text1 = ''; let game_text2 = '';
                    let gameDet = await getGameDet(dObj.game_type_id);
                    if (gameDet != '') {
                      game_name = gameDet.name;
                      game_text1 = gameDet.text;
                      if ([9, 10, 11].indexOf(dObj.game_type_id) > -1) {
                        game_text2 = gameDet.text2;
                      }
                      game_text2 = game_text2;
                    }
                    let subDet = [
                      { text: game_text1, value: dObj.panna_1 }
                    ];
                    if (game_text2 != '') {
                      subDet.push({ text: game_text2, value: dObj.panna_2 });
                    }
                    subDet.push({ text: 'Bid Value', value: dObj.amount });
                    if (win_msg != '') {
                      subDet.push({ text: win_msg, value: dObj.win_amount });
                    } else if (dObj.is_win == 2) {
                      subDet.push({ text: 'You lost!!', value: dObj.amount });
                    }
                    return {
                      _id: dObj._id,
                      market_id: dObj.market_id.name,
                      game_type_id: dObj.game_type_id,
                      amount: dObj.amount,
                      is_win: dObj.is_win,
                      win_amount: dObj.win_amount,
                      game_name: game_name,
                      sub_det: subDet,
                      createdAt: dObj.createdAt,
                    };
                  }));
                  var legend = '***-**-***';
                  if (marRes) {
                    legend = '';
                    legend = (marRes.op_1 != null) ? legend + marRes.op_1 : legend + '*';
                    legend = (marRes.op_2 != null) ? legend + marRes.op_2 : legend + '*';
                    legend = (marRes.op_3 != null) ? legend + marRes.op_3 + '-' : legend + '*-';
                    legend = (marRes.is_published == 1 && marRes.digit_1 != null) ? legend + marRes.digit_1 : legend;
                    legend = (marRes.is_published == 1 && marRes.digit_2 != null) ? legend + marRes.digit_2 + '-' : legend + '*-';
                    legend = (marRes.is_published == 1 && marRes.cp_1 != null) ? legend + marRes.cp_1 : legend + '*';
                    legend = (marRes.is_published == 1 && marRes.cp_2 != null) ? legend + marRes.cp_2 : legend + '*';
                    legend = (marRes.is_published == 1 && marRes.cp_3 != null) ? legend + marRes.cp_3 : legend;
                  }
                  return {
                    info: {
                      market: (sinMar ? sinMar.name : '-'),
                      legend: legend,
                      //legendArr: marRes,
                      date: row.date
                    },
                    bids: vdata
                  }
                }/* users.length */
              }));
            }
          }));/* for market */
          return res.json({ status: 1, message: 'User bid data get successfully.', data: myResp });
        } else {
          return res.json({ status: 1, message: 'User bid data get successfully.', data: myResp });
        }
      });
    } catch (error) {
      console.log(error);
      return res.json({ status: 0, message: error, data: {} });
    }
  })();
};
/* 22-11-2021 End */
/* 02-08-2022 */
exports.getUserBidHistV3 = async (req, res) => {
  (async () => {
    try {
      var { is_filter, date, is_win, is_loss, is_refund, market_ids } = req.body;

      let user_id = req.userDet._id;
      var condition = { user_id: user_id };

      var tdyDate = getDateFormat();
      var aggrLimit = { $limit: 50 };
      if (is_filter == 1) {
        if (is_win == 1 && is_loss == 1) {
          condition.is_win = { $in: [1, 2] };
        } else {
          if (is_win == 1) {
            condition.is_win = 1;
          } else if (is_loss == 1) {
            condition.is_win = 2;
          } else if (is_refund == 1) {
            condition.is_win = 3;
          }
        }
        if (date != '') {
          aggrLimit = '';
          let date1 = convertToUTC(date + ' 00:00:00');
          let date2 = convertToUTC(date + ' 23:59:59');
          condition.createdAt = { $gte: new Date(date1), $lte: new Date(date2) };
        } else {
          let date1 = convertToUTC(tdyDate + ' 00:00:00');
          let date2 = convertToUTC(tdyDate + ' 23:59:59');
          condition.createdAt = { $gte: new Date(date1), $lte: new Date(date2) };
          let todayBids = await MarketBids.where(condition).countDocuments();
          if (todayBids > 50) {
            aggrLimit = '';
          } else {
            if (todayBids == 0) {
              delete condition.createdAt;
            }
          }
        }
        if (market_ids != '') {
          market_ids = market_ids.toString().split(',');
          if (market_ids.length > 0) {
            market_ids = await Promise.all(market_ids.map(async (sinmar) => {
              return mongoose.Types.ObjectId(sinmar)
            }));
            condition.market_id = { $in: market_ids };
          }
        }
      } else {
        let date1 = convertToUTC(tdyDate + ' 00:00:00');
        let date2 = convertToUTC(tdyDate + ' 23:59:59');
        condition.createdAt = { $gte: new Date(date1), $lte: new Date(date2) };
        let todayBids = await MarketBids.where(condition).countDocuments();
        if (todayBids > 50) {
          aggrLimit = '';
        } else {
          if (todayBids == 0) {
            delete condition.createdAt;
          }
        }
      }
      /* let dateToday = getDateFormat();
      let date1 = convertToUTCNew(dateToday + ' 00:00:00');
      let date2 = convertToUTCNew(dateToday + ' 23:59:59');
      var condition = { user_id: user_id, createdAt: { $gte: date1, $lte: date2 } }; */
      //console.log(condition);
      let page = (req.body.page) ? req.body.page : 1;
      let perPage = 20;
      let skip = (perPage * (page - 1));
      var whAggre = [
        {
          $match: condition
        },
        {
          $lookup: {
            from: "markets",
            let: { 'market_id': '$market_id' },
            pipeline: [
              {
                "$match": {
                  "$expr": { "$eq": ["$_id", "$$market_id"] },
                },
              },
              { $project: { _id: 1, name: 1 } }
            ],
            as: "market_det"
          }
        },
        { $sort: { createdAt: -1 } },
        // { $project: { date: '$_id', market_id:1, _id: 1, createdAt:1 } },
        { $limit: skip + perPage },
        { $skip: skip },
      ];
      /* if (aggrLimit != ''){
          whAggre.push(aggrLimit);
      } */


      //{ $limit: skip + perPage }, { $skip: skip },

      let markets = await MarketBids.aggregate(whAggre);

      let res_data = [];
      let last_market_id = "";
      await Promise.all(markets.map(async (m) => {
        var res_msg = '-';
        if (m.is_win == 1) {
          res_msg = 'Won';
        } else if (m.is_win == 2) {
          res_msg = 'Lost';
        } else if (m.is_win == 3) {
          res_msg = 'Refund';
        }
        let is_refund = (m.is_win == 3) ? 1 : 0;
        let game_name = '', game_text2 = '';
        let gameDet = getGameDet(m.game_type_id);
        let game_det = '', bid_det = '';
        if (gameDet != '') {
          game_name = gameDet.name;
          game_det = gameDet.name;
          game_det += ', ' + gameDet.text;
          if ([9, 10, 11].indexOf(m.game_type_id) > -1) {
            game_text2 = gameDet.text2;
            game_det += ' + ' + game_text2;
          }
          game_text2 = game_text2;
        }
        bid_det = m.panna_1;
        if (game_text2 != '') {
          bid_det += '-' + m.panna_2;
        }
        let dateNew = convertToUTC(moment(m.createdAt).format('YYYY-MM-DD') + ' 00:00:00');
        let dateNew2 = convertToUTC(moment(m.createdAt).format('YYYY-MM-DD') + ' 23:59:59');

        var weekType = (new Date(m.createdAt)).getDay();
        let whMar = {
          week_day_type: weekType,
          market_id: m.market_id,
          declared_date: { $gte: new Date(dateNew), $lte: new Date(dateNew2) }
        };
        await MarketResults.findOne(whMar).then(function (marRes) {
          var legend = '***-**-***';
          if (marRes) {
            legend = '';
            legend = (marRes.is_open_published == 1 && marRes.op_1 != null) ? legend + marRes.op_1 : legend + '*';
            legend = (marRes.is_open_published == 1 && marRes.op_2 != null) ? legend + marRes.op_2 : legend + '*';
            legend = (marRes.is_open_published == 1 && marRes.op_3 != null) ? legend + marRes.op_3 + '-' : legend + '*-';
            legend = (marRes.is_open_published == 1 && marRes.digit_1 != null) ? legend + marRes.digit_1 : legend + '*';
            legend = (marRes.is_published == 1 && marRes.digit_2 != null) ? legend + marRes.digit_2 + '-' : legend + '*-';
            legend = (marRes.is_published == 1 && marRes.cp_1 != null) ? legend + marRes.cp_1 : legend + '*';
            legend = (marRes.is_published == 1 && marRes.cp_2 != null) ? legend + marRes.cp_2 : legend + '*';
            legend = (marRes.is_published == 1 && marRes.cp_3 != null) ? legend + marRes.cp_3 : legend;
          }
          res_data.push({
            _id: m._id,
            market: m.market_det[0].name,
            legend: legend,
            market_id: m.market_det[0].name,
            game_type_id: m.game_type_id,
            amount: m.amount,
            is_win: m.is_win,
            is_refund: is_refund,
            win_amount: ((m.win_amount) ? parseInt(m.win_amount) : null),
            game_name: game_name,
            game_det: game_det,
            bid_det: bid_det,
            res_msg: res_msg,
            bid_date: moment(m.createdAt).format('YYYY-MM-DD'),
            createdAt: m.createdAt
          });
        });
      }));
      return res.json({ status: 1, message: 'User bid data get successfully.', data: res_data });
    } catch (error) {
      console.log(error);
      return res.json({ status: 0, message: error, data: {} });
    }
  })();
};
/* 02-08-2022 End */

/* 08-08-2020 */
exports.getUserBidHistV4 = async (req, res) => {
  (async () => {
    try {
      var { is_filter, date, is_win, is_loss, market_ids } = req.body;

      let user_id = req.userDet._id;
      var condition = { user_id: user_id };

      var tdyDate = getDateFormat();
      var aggrLimit = { $limit: 50 };
      if (is_filter == 1) {
        if (is_win == 1 && is_loss == 1) {
          condition.is_win = { $in: [1, 2] };
        } else {
          if (is_win == 1) {
            condition.is_win = 1;
          } else if (is_loss == 1) {
            condition.is_win = 2;
          }
        }
        if (date != '') {
          aggrLimit = '';
          let date1 = convertToUTC(date + ' 00:00:00');
          let date2 = convertToUTC(date + ' 23:59:59');
          condition.createdAt = { $gte: new Date(date1), $lte: new Date(date2) };
        } else {
          let date1 = convertToUTC(tdyDate + ' 00:00:00');
          let date2 = convertToUTC(tdyDate + ' 23:59:59');
          condition.createdAt = { $gte: new Date(date1), $lte: new Date(date2) };
          let todayBids = await MarketBids.where(condition).countDocuments();
          if (todayBids > 50) {
            aggrLimit = '';
          } else {
            if (todayBids == 0) {
              delete condition.createdAt;
            }
          }
        }
        if (market_ids != '') {
          market_ids = market_ids.toString().split(',');
          if (market_ids.length > 0) {
            market_ids = await Promise.all(market_ids.map(async (sinmar) => {
              return mongoose.Types.ObjectId(sinmar)
            }));
            condition.market_id = { $in: market_ids };
          }
        }
      } else {
        let date1 = convertToUTC(tdyDate + ' 00:00:00');
        let date2 = convertToUTC(tdyDate + ' 23:59:59');
        condition.createdAt = { $gte: new Date(date1), $lte: new Date(date2) };
        let todayBids = await MarketBids.where(condition).countDocuments();
        if (todayBids > 50) {
          aggrLimit = '';
        } else {
          if (todayBids == 0) {
            delete condition.createdAt;
          }
        }
      }
      /* let dateToday = getDateFormat();
      let date1 = convertToUTCNew(dateToday + ' 00:00:00');
      let date2 = convertToUTCNew(dateToday + ' 23:59:59');
      var condition = { user_id: user_id, createdAt: { $gte: date1, $lte: date2 } }; */
      //console.log(condition);
      let page = (req.body.page) ? req.body.page : 1;
      let perPage = 20;
      let skip = (perPage * (page - 1));

      var whAggre = [
        {
          $match: condition
        },
        {
          $lookup: {
            from: "markets",
            let: { 'market_id': '$market_id' },
            pipeline: [
              {
                "$match": {
                  "$expr": { "$eq": ["$_id", "$$market_id"] },
                },
              },
              { $project: { _id: 1, name: 1 } }
            ],
            as: "market_det"
          }
        },
        { $sort: { createdAt: -1 } },
        // { $project: { date: '$_id', market_id:1, _id: 1, createdAt:1 } },
        { $limit: skip + perPage },
        { $skip: skip },
      ];
      if (aggrLimit != '') {
        whAggre.push(aggrLimit);
      }
      let markets = await MarketBids.aggregate(whAggre);

      let res_data = [];
      let last_date = "";
      await Promise.all(markets.map(async (m) => {
        var res_msg = '-';
        if (m.is_win == 1) {
          res_msg = 'Won';
        } else if (m.is_win == 2) {
          res_msg = 'Lost';
        } else if (m.is_win == 3) {
          res_msg = 'Refund';
        }
        let is_refund = (m.is_win == 3) ? 1 : 0;
        let game_name = '', game_text2 = '';
        let gameDet = getGameDet(m.game_type_id);
        let game_det = '', bid_det = '';
        if (gameDet != '') {
          game_name = gameDet.name;
          game_det = gameDet.name;
          game_det += ', ' + gameDet.text;
          if ([9, 10, 11].indexOf(m.game_type_id) > -1) {
            game_text2 = gameDet.text2;
            game_det += ' + ' + game_text2;
          }
          game_text2 = game_text2;
        }
        bid_det = m.panna_1;
        if (game_text2 != '') {
          bid_det += '-' + m.panna_2;
        }
        let dateNew = convertToUTC(moment(m.createdAt).format('YYYY-MM-DD') + ' 00:00:00');
        let dateNew2 = convertToUTC(moment(m.createdAt).format('YYYY-MM-DD') + ' 23:59:59');

        var weekType = (new Date(m.createdAt)).getDay();
        await MarketResults.findOne({ week_day_type: weekType, market_id: m.market_id, declared_date: { $gte: new Date(dateNew), $lte: new Date(dateNew2) } }).then(async function (marRes) {
          
          var legend = '***-**-***';
          if (marRes) {
            legend = '';
            legend = (marRes.is_open_published == 1 && marRes.op_1 != null) ? legend + marRes.op_1 : legend + '*';
            legend = (marRes.is_open_published == 1 && marRes.op_2 != null) ? legend + marRes.op_2 : legend + '*';
            legend = (marRes.is_open_published == 1 && marRes.op_3 != null) ? legend + marRes.op_3 + '-' : legend + '*-';
            legend = (marRes.is_open_published == 1 && marRes.digit_1 != null) ? legend + marRes.digit_1 : legend + '*';
            legend = (marRes.is_published == 1 && marRes.digit_2 != null) ? legend + marRes.digit_2 + '-' : legend + '*-';
            legend = (marRes.is_published == 1 && marRes.cp_1 != null) ? legend + marRes.cp_1 : legend + '*';
            legend = (marRes.is_published == 1 && marRes.cp_2 != null) ? legend + marRes.cp_2 : legend + '*';
            legend = (marRes.is_published == 1 && marRes.cp_3 != null) ? legend + marRes.cp_3 : legend;
          }
          //console.log({ week_day_type: weekType, market_id: m.market_id, declared_date: { $gte: new Date(dateNew), $lte: new Date(dateNew2) } });
          let bidRecDate = moment(m.createdAt).format('YYYY-MM-DD');
          if (last_date != bidRecDate) {
            res_data.push({
              'info': {
                "date": moment(m.createdAt).format('YYYY-MM-DD')
              },
              'data': [{
                _id: m._id,
                market: m.market_det[0].name,
                legend: legend,
                market_id: m.market_det[0].name,
                game_type_id: m.game_type_id,
                amount: m.amount,
                is_win: m.is_win,
                is_refund: is_refund,
                win_amount: ((m.win_amount) ? parseInt(m.win_amount) : null),
                game_name: game_name,
                game_det: game_det,
                bid_det: bid_det,
                res_msg: res_msg,
                tnx_id: (m.tnx_id)?m.tnx_id:'',
                bid_date: moment(m.createdAt).format('YYYY-MM-DD'),
                createdAt: m.createdAt
              }]
            });
            last_date = moment(m.createdAt).format('YYYY-MM-DD');
            // console.log(m.market_det[0].name);
          } else {
            let newArrInd = await res_data.findIndex((itm) => {
              return itm.info.date == bidRecDate;
            });
            
            if (res_data[newArrInd]) {
              res_data[newArrInd].data.push({
                _id: m._id,
                market: m.market_det[0].name,
                legend: legend,
                market_id: m.market_det[0].name,
                game_type_id: m.game_type_id,
                amount: m.amount,
                is_win: m.is_win,
                is_refund: is_refund,
                win_amount: ((m.win_amount) ? parseInt(m.win_amount) : null),
                game_name: game_name,
                game_det: game_det,
                bid_det: bid_det,
                res_msg: res_msg,
                tnx_id: (m.tnx_id)?m.tnx_id:'',
                bid_date: moment(m.createdAt).format('YYYY-MM-DD'),
                createdAt: m.createdAt
              });
            }
          }
        });
      }));
      return res.json({ status: 1, message: 'User bid data get successfully.', data: res_data });
    } catch (error) {
      console.log(error);
      return res.json({ status: 0, message: error, data: {} });
    }
  })();
};
/* 08-08-2020 End */
/* 20-23-2020 */
exports.getUserBidHistV4New = async (req, res) => {
  (async () => {
    try {
      var { is_filter, date, is_win, is_loss, market_ids } = req.body;

      let user_id = req.userDet._id;
      var condition = { user_id: user_id };

      if (is_filter == 1) {
        if (is_win == 1 && is_loss == 1) {
          condition.is_win = { $in: [1, 2] };
        } else {
          if (is_win == 1) {
            condition.is_win = 1;
          } else if (is_loss == 1) {
            condition.is_win = 2;
          }
        }
        if (date != '') {
          let date1 = convertToUTC(date + ' 00:00:00');
          let date2 = convertToUTC(date + ' 23:59:59');
          condition.createdAt = { $gte: new Date(date1), $lte: new Date(date2) };
        }
        if (market_ids != '') {
          market_ids = market_ids.toString().split(',');
          if (market_ids.length > 0) {
            market_ids = await Promise.all(market_ids.map(async (sinmar) => {
              return mongoose.Types.ObjectId(sinmar)
            }));
            condition.market_id = { $in: market_ids };
          }
        }
      }
      
      const page = (req.body.page) ? req.body.page : 1;
      const perPage = 20;
      const skip = (perPage * (page - 1));

      const whAggre = [
        {
          $match: condition
        },
        {
          $lookup: {
            from: "markets",
            let: { 'market_id': '$market_id' },
            pipeline: [
              {
                "$match": {
                  "$expr": { "$eq": ["$_id", "$$market_id"] },
                },
              },
              { $project: { _id: 1, name: 1 } }
            ],
            as: "market_det"
          }
        },
        { $sort: { createdAt: -1 } },
        // { $project: { date: '$_id', market_id:1, _id: 1, createdAt:1 } },
        { $limit: skip + perPage },
        { $skip: skip },
      ];
      
      const markets = await MarketBids.aggregate(whAggre);

      const res_data = [];
      for (const m of markets) {
        var res_msg = '-';
        if (m.is_win == 1) {
          res_msg = 'Won';
        } else if (m.is_win == 2) {
          res_msg = 'Lost';
        } else if (m.is_win == 3) {
          res_msg = 'Refund';
        }
        let is_refund = (m.is_win == 3) ? 1 : 0;
        let game_name = '', game_text2 = '';
        let gameDet = getGameDet(m.game_type_id);
        let game_det = '', bid_det = '';
        if (gameDet != '') {
          game_name = gameDet.name;
          game_det = gameDet.name;
          game_det += ', ' + gameDet.text;
          if ([9, 10, 11].indexOf(m.game_type_id) > -1) {
            game_text2 = gameDet.text2;
            game_det += ' + ' + game_text2;
          }
          game_text2 = game_text2;
        }
        bid_det = m.panna_1;
        if (game_text2 != '') {
          bid_det += '-' + m.panna_2;
        }
        let dateNew = convertToUTC(moment(m.createdAt).format('YYYY-MM-DD') + ' 00:00:00');
        let dateNew2 = convertToUTC(moment(m.createdAt).format('YYYY-MM-DD') + ' 23:59:59');

        var weekType = (new Date(m.createdAt)).getDay();
        await MarketResults.findOne({ week_day_type: weekType, market_id: m.market_id, declared_date: { $gte: new Date(dateNew), $lte: new Date(dateNew2) } }).then(async function (marRes) {
          
          var legend = '***-**-***';
          if (marRes) {
            legend = '';
            legend = (marRes.is_open_published == 1 && marRes.op_1 != null) ? legend + marRes.op_1 : legend + '*';
            legend = (marRes.is_open_published == 1 && marRes.op_2 != null) ? legend + marRes.op_2 : legend + '*';
            legend = (marRes.is_open_published == 1 && marRes.op_3 != null) ? legend + marRes.op_3 + '-' : legend + '*-';
            legend = (marRes.is_open_published == 1 && marRes.digit_1 != null) ? legend + marRes.digit_1 : legend + '*';
            legend = (marRes.is_published == 1 && marRes.digit_2 != null) ? legend + marRes.digit_2 + '-' : legend + '*-';
            legend = (marRes.is_published == 1 && marRes.cp_1 != null) ? legend + marRes.cp_1 : legend + '*';
            legend = (marRes.is_published == 1 && marRes.cp_2 != null) ? legend + marRes.cp_2 : legend + '*';
            legend = (marRes.is_published == 1 && marRes.cp_3 != null) ? legend + marRes.cp_3 : legend;
          }
          
          res_data.push({
            _id: m._id,
            market: m.market_det[0].name,
            legend: legend,
            market_id: m.market_det[0].name,
            game_type_id: m.game_type_id,
            amount: m.amount,
            is_win: m.is_win,
            is_refund: is_refund,
            win_amount: ((m.win_amount) ? parseInt(m.win_amount) : null),
            game_name: game_name,
            game_det: game_det,
            bid_det: bid_det,
            res_msg: res_msg,
            tnx_id: (m.tnx_id)?m.tnx_id:'',
            bid_date: moment(m.createdAt).format('YYYY-MM-DD'),
            createdAt: m.createdAt
          });
        });
      }
      return res.json({ status: 1, message: 'User bid data get successfully.', data: res_data });
    } catch (error) {
      console.log(error);
      return res.json({ status: 0, message: error, data: {} });
    }
  })();
};
/* 20-23-2020 End */

/* 20-10-2021 */
exports.getWinningHistory = async (req, res) => {
  (async () => {
    try {
      var { is_filter, date, type } = req.body;

      let user_id = req.userDet._id;
      var condition = { user_id: user_id };
      type = (typeof type !== 'undefined' && type != '') ? type : null;
      if (is_filter == 1) {
        if (type != null && type != '') {
          if (type == 1) {
            condition.tnx_type = 7;//7=winning_credited
          } else if (type == 2) {
            condition.tnx_type = 6;//6=winning_withdraw
          } else {
            condition.tnx_type = { $in: [6, 7] };
          }
        } else {
          condition.tnx_type = { $in: [6, 7] };
        }
        if (date != '') {
          let date1 = convertToUTC(date + ' 00:00:00');
          let date2 = convertToUTC(date + ' 23:59:59');
          condition.createdAt = { $gte: new Date(date1), $lte: new Date(date2) };
          //condition.createdAt = new Date(date);
        }
      } else {
        condition.tnx_type = { $in: [6, 7] };
        let dateToday = getDateFormat();
        let date1 = convertToUTCNew(dateToday + ' 00:00:00');
        let date2 = convertToUTCNew(dateToday + ' 23:59:59');
        condition.createdAt = { $gte: date1, $lte: date2 };
      }
      console.log(243, condition);
      //await MarketBids.find(condition).populate({ path: 'market_id', select: "_id name" }).then((users) => {
      let page = (req.body.page) ? req.body.page : 1;
      let perPage = 6;
      let skip = (perPage * (page - 1));
      //{ $limit: skip + perPage }, { $skip: skip },
      await Transactions.aggregate([
        {
          $match: condition
        },
        {
          $group: {
            _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } }
          }
        },
        {
          $sort: { "_id": -1 }
        }
      ]).then(async (history) => {
        let myResp = []; let myResp_r = [];

        if (history.length > 0) {
          //return res.json({ status: 1, message: 'data', data: history });
          myResp = await Promise.all(history.map(async (sin) => {
            let date12 = convertToUTC(sin._id + ' 00:00:00');
            let date22 = convertToUTC(sin._id + ' 23:59:59');
            // , user_id: user_id
            let cond2 = { createdAt: { $gte: new Date(date12), $lte: new Date(date22) }, user_id: user_id };
            if (is_filter == 1) {
              if (type != null && type != '') {
                if (type == 1) {
                  cond2.tnx_type = 7;
                } else if (type == 2) {
                  cond2.tnx_type = 6;
                } else {
                  cond2.tnx_type = { $in: [6, 7] };
                }
              } else {
                cond2.tnx_type = { $in: [6, 7] };
              }
            } else {
              cond2.tnx_type = { $in: [6, 7] };
            }
            let transList = await Transactions.find(cond2).sort({ createdAt: -1 }).select('_id amount charge_amount final_amount tnx_type details entry_type createdAt');

            return {
              date: sin._id,
              transList: transList
            };
          }));/* for market */
        }
        console.log(myResp.length);
        return res.json({ status: 1, message: 'Winning history get successfully.', data: myResp });
      });
    } catch (error) {
      console.log(error);
      return res.json({ status: 0, message: error, data: {} });
    }
  })();
};

/* 16-11-2021 */
exports.getNotificationList = async (req, res) => {
  (async () => {
    try {
      let page = (req.body.page) ? req.body.page : 1;
      let perPage = 10;
      let offset = (perPage * (page - 1));
      let wh = { deleted: false };
      if (typeof req.body.date !== 'undefined' && req.body.date != '') {
        var dt = req.body.date;
        let date1 = convertToUTCNew(dt + ' 00:00:00');
        let date2 = convertToUTCNew(dt + ' 23:59:59');
        wh.createdAt = { $gte: date1, $lte: date2 };
      }
      let weekDate = new Date();
      weekDate.setDate(weekDate.getDate() - 7);
      weekDate = getDateFormat(weekDate);
      let today = getDateFormat();

      let date1 = convertToUTCNew(weekDate + ' 00:00:00');
      let date2 = convertToUTCNew(today + ' 23:59:59');
      if (typeof req.body.older !== 'undefined' && req.body.older != '' && req.body.older == 1) {
        wh.createdAt = { $lte: date1 };
      } else {/* new */
        wh.createdAt = { $gte: date1, $lte: date2 };
      }
      //return res.json({ status: 1, message: 'data', data: wh });
      console.log(wh);
      let myResp = await Notification.find(wh, {
        _id: 1, title: 1, message: 1, image_url: 1, createdAt: 1
      }).limit(perPage)
        .skip(offset)
        .sort({ createdAt: -1 });
      return res.json({ status: 1, message: 'Notification get successfully.', data: myResp });
    } catch (error) {
      console.log(error);
      return res.json({ status: 0, message: error, data: {} });
    }
  })();
};