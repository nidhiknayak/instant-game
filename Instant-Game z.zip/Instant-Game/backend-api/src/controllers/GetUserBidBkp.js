exports.getUserBidHist = async (req, res) => {
    (async () => {
        try {
            var { is_filter, date, is_win, is_loss, market_ids } = req.body;

            let user_id = req.userDet._id;
            var condition = { user_id: user_id };
            if (is_filter == 1) {
                if (is_win == 1 && is_loss == 1){
                    condition.is_win = { $in:[1,2] };
                } else {
                    if (is_win == 1) {
                        condition.is_win = 1;
                    } else if (is_loss == 1) {
                        condition.is_win = 2;
                    }
                }
                if (date != '') {
                    let date1 = convertToUTC(date + ' 00:00:00');
                    let date2 = convertToUTC(date + ' 23:59:59');
                    //condition.createdAt = { $gte: date1, $lte: date2 };
                    condition.createdAt = { $gte: new Date(date1), $lte: new Date(date2) };
                    //condition.createdAt = { $gte: new Date(date + ' 00:00:00'), $lte: new Date(date + ' 23:59:59') };
                }
                if (market_ids != '') {
                    market_ids = market_ids.toString().split(',');
                    if (market_ids.length > 0){
                        market_ids = await Promise.all(market_ids.map(async (sinmar) => {
                            return mongoose.Types.ObjectId(sinmar)
                        }));
                        condition.market_id = { $in: market_ids };
                    }
                }
            }
            console.log(condition);
            let markets = await MarketBids.aggregate([
              {
                $match: condition
              },
              {
                $lookup:{
                  from: "markets",
                  let: { 'market_id': '$market_id' },
                  pipeline: [
                    {
                      "$match": {
                        "$expr": { "$eq": ["$_id", "$$market_id"] },
                      },
                    },
                    { $project: { _id: 1, name: 1 } }
                  ],
                  as: "market_det"
                }
              },
              { $sort: { createdAt: -1 } },
              // { $project: { date: '$_id', market_id:1, _id: 1, createdAt:1 } },
            ]);
            let res_data = [];
            let last_market_id = "";
            await Promise.all(markets.map(async (m)=>{
              let win_msg = (m.is_win == 1)?'You won!!!':'';
              let game_name = '';
              let game_text1 = '';
              let game_text2 = '';
              let gameDet = getGameDet(m.game_type_id);
              if (gameDet != '') {
                  game_name = gameDet.name;
                  game_text1 = gameDet.text;
                  if ([9, 10, 11].indexOf(m.game_type_id) > -1) {
                      game_text2 = gameDet.text2;
                  }
                  game_text2 = game_text2;
              }
              let subDet = [ { text: game_text1, value: m.panna_1 } ];
              if (game_text2 != '') {
                  subDet.push({ text: game_text2, value: m.panna_2 });
              }
              subDet.push({ text: 'Bid Value', value: m.amount });
              if (win_msg != '') {
                  subDet.push({ text: win_msg, value: m.win_amount });
              } else if (m.is_win == 2) {
                  subDet.push({ text: 'You loose!!!', value: m.amount });
              }
              let dateNew = convertToUTC(moment(m.createdAt).format('YYYY-MM-DD') + ' 00:00:00');
              let dateNew2 = convertToUTC(moment(m.createdAt).format('YYYY-MM-DD') + ' 23:59:59');
              
              var weekType = (new Date(m.createdAt)).getDay();
              await MarketResults.findOne({ week_day_type: weekType, market_id: m.market_id, declared_date: { $gte: new Date(dateNew), $lte: new Date(dateNew2) } }).then(function(marRes){
                if(last_market_id!=m.market_id.toString()){
                  var legend = '***-**-***';
                  if (marRes) {
                      legend = '';
                      legend = (marRes.op_1 != null) ? legend + marRes.op_1 : legend + '*';
                      legend = (marRes.op_2 != null) ? legend + marRes.op_2 : legend + '*';
                      legend = (marRes.op_3 != null) ? legend + marRes.op_3 + '-' : legend + '*-';
                      legend = (marRes.is_published == 1 && marRes.digit_1 != null) ? legend + marRes.digit_1 : legend;
                      legend = (marRes.is_published == 1 && marRes.digit_2 != null) ? legend + marRes.digit_2 + '-' : legend + '*-';
                      legend = (marRes.is_published == 1 && marRes.cp_1 != null) ? legend + marRes.cp_1 : legend + '*';
                      legend = (marRes.is_published == 1 && marRes.cp_2 != null) ? legend + marRes.cp_2 : legend + '*';
                      legend = (marRes.is_published == 1 && marRes.cp_3 != null) ? legend + marRes.cp_3 : legend;
                  }
                  console.log({ week_day_type: weekType, market_id: m.market_id, declared_date: { $gte: new Date(dateNew), $lte: new Date(dateNew2) } });
                  res_data.push({
                    'info':{
                      "market":m.market_det[0].name,
                      "legend": legend,
                      "date": moment(m.createdAt).format('YYYY-MM-DD')
                    },
                    'data':[{
                      _id: m._id,
                      market_id: m.market_det[0].name,
                      game_type_id: m.game_type_id,
                      amount: m.amount,
                      is_win: m.is_win,
                      win_amount: m.win_amount,
                      game_name: game_name,
                      sub_det: subDet,
                      createdAt: m.createdAt
                    }]
                  });
                  last_market_id = m.market_id.toString();
                  // console.log(m.market_det[0].name);
                }
                else{
                  if(res_data[res_data.length-1]){
                    res_data[res_data.length-1].data.push({
                      _id: m._id,
                      market_id: m.market_det[0].name,
                      game_type_id: m.game_type_id,
                      amount: m.amount,
                      is_win: m.is_win,
                      win_amount: m.win_amount,
                      game_name: game_name,
                      sub_det: subDet,
                      createdAt: m.createdAt
                    });
                  }
                }
              });
            }));
            return res.json({ status: 1, message: 'User bid data get successfully.', data: res_data });
            console.log(res_data);
            // old logic below BY MHNDR
            //await MarketBids.find(condition).populate({ path: 'market_id', select: "_id name" }).then((users) => {
            await MarketBids.aggregate([
                {
                    $match: condition
                },
                {
                    $lookup:
                    {
                        from: "markets",
                        /* localField: "market_id",
                        foreignField: "_id", */
                        let: { 'market_id': '$market_id' },
                        pipeline: [
                            {
                                "$match": {
                                    "$expr": { "$eq": ["$_id", "$$market_id"] },
                                },
                            },
                            { $project: { _id: 1, name: 1 } }
                        ],
                        as: "market_det"
                    }
                },

                /* {
                    $group: {
                        _id: {
                            "marketID": "$market_id",
                            "createdAtID": { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } },
                            "marketDet": "$market_det"
                        }
                    }
                },
                {
                    $group: {
                        "_id": "$_id.marketID",
                        "dates": {
                            "$push": {
                                "date": "$_id.createdAtID",
                                "m_id": "$_id.marketID",
                                "marketDet": "$_id.marketDet",
                            },
                        }
                    }
                }, */
                
                /* { $group: { _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } }, markets: { $push: '$market_id' } } },
                 */
                { $group: { _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } }, markets: { $addToSet: { "$arrayElemAt": ["$market_det", 0] } } } },
                // { $sort: { _id: -1 } },
                { $sort: { _id: -1 } },
                { $project: { date: '$_id', 'markets._id': 1, 'markets.name': 1, _id: 0, createdAt:1 } },
                
                /* {
                    $group: {
                        _id: '$_id',
                        market_ids: { $first: '$markets' }
                    }
                }, */
                
                
            ]).then(async (markets) => {
                let myResp = []; let myResp_r = [];

                if (markets.length > 0) {
                    //return res.json({ status: 1, message: 'data', data: markets });
                    myResp = await Promise.all(markets.map(async (row) => {
                        if (row.markets.length > 0) {
                            let marketByDates = row.markets;
                            return await Promise.all(marketByDates.map(async (sinMar) => {
                                //let cond2 = { user_id: user_id, createdAt: { $dateToString: { format: "%Y-%m-%d", date: "'" + dates[k] + "'" }} };

                                let date12 = await convertToUTC(row.date + ' 00:00:00');
                                let date22 = await convertToUTC(row.date + ' 23:59:59');
                                // , user_id: user_id
                                let cond2 = { market_id: sinMar._id, user_id: user_id, createdAt: { $gte: new Date(date12), $lte: new Date(date22) } };
                                if (is_filter == 1) {
                                    if (is_win == 1 && is_loss == 1) {
                                        cond2.is_win = { $in: [1, 2] };
                                    } else {
                                        if (is_win == 1) {
                                            cond2.is_win = 1;
                                        } else if (is_loss == 1) {
                                            cond2.is_win = 2;
                                        }
                                    }
                                }
                                
                                var users = await MarketBids.find(cond2).sort({ createdAt: -1 });
                                var weekType = await getWeekDay(new Date(row.date));

                                let dateNew = await convertToUTC(row.date + ' 00:00:00');
                                let dateNew2 = await convertToUTC(row.date + ' 23:59:59');

                                var marRes = await MarketResults.findOne({ week_day_type: weekType, market_id: sinMar._id, declared_date: { $gte: new Date(dateNew), $lte: new Date(dateNew2) } });
                                if (users.length > 0) {
                                    let vdata = await Promise.all(users.map(async (dObj) => {
                                        let win_msg = '';
                                        if (dObj.is_win == 1) {
                                            win_msg = 'You won!!!';
                                        }
                                        let game_name = ''; let game_text1 = ''; let game_text2 = '';
                                        let gameDet = await getGameDet(dObj.game_type_id);
                                        if (gameDet != '') {
                                            game_name = gameDet.name;
                                            game_text1 = gameDet.text;
                                            if ([9, 10, 11].indexOf(dObj.game_type_id) > -1) {
                                                game_text2 = gameDet.text2;
                                            }
                                            game_text2 = game_text2;
                                        }
                                        let subDet = [
                                            { text: game_text1, value: dObj.panna_1 }
                                        ];
                                        if (game_text2 != '') {
                                            subDet.push({ text: game_text2, value: dObj.panna_2 });
                                        }
                                        subDet.push({ text: 'Bid Value', value: dObj.amount });
                                        if (win_msg != '') {
                                            subDet.push({ text: win_msg, value: dObj.win_amount });
                                        } else if (dObj.is_win == 2) {
                                            subDet.push({ text: 'You loose!!!', value: dObj.amount });
                                        }
                                        return {
                                            _id: dObj._id,
                                            market_id: dObj.market_id.name,
                                            game_type_id: dObj.game_type_id,
                                            amount: dObj.amount,
                                            is_win: dObj.is_win,
                                            win_amount: dObj.win_amount,
                                            game_name: game_name,
                                            sub_det: subDet,
                                            createdAt: dObj.createdAt,
                                        };
                                    }));
                                    var legend = '***-**-***';
                                    if (marRes) {
                                        legend = '';
                                        legend = (marRes.op_1 != null) ? legend + marRes.op_1 : legend + '*';
                                        legend = (marRes.op_2 != null) ? legend + marRes.op_2 : legend + '*';
                                        legend = (marRes.op_3 != null) ? legend + marRes.op_3 + '-' : legend + '*-';
                                        legend = (marRes.is_published == 1 && marRes.digit_1 != null) ? legend + marRes.digit_1 : legend;
                                        legend = (marRes.is_published == 1 && marRes.digit_2 != null) ? legend + marRes.digit_2 + '-' : legend + '*-';
                                        legend = (marRes.is_published == 1 && marRes.cp_1 != null) ? legend + marRes.cp_1 : legend + '*';
                                        legend = (marRes.is_published == 1 && marRes.cp_2 != null) ? legend + marRes.cp_2 : legend + '*';
                                        legend = (marRes.is_published == 1 && marRes.cp_3 != null) ? legend + marRes.cp_3 : legend;
                                    }
                                    return {
                                        info: {
                                            market: (sinMar ? sinMar.name : '-'),
                                            legend: legend,
                                            //legendArr: marRes,
                                            date: row.date
                                        },
                                        bids: vdata
                                    }
                                }/* users.length */
                            }));
                        }
                    }));/* for market */
                    return res.json({ status: 1, message: 'User bid data get successfully.', data: myResp });
                } else {
                    return res.json({ status: 1, message: 'User bid data get successfully.', data: myResp });
                }
            });
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error, data: {} });
        }
    })();
};