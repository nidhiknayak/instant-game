var mongoose        = require('mongoose');
const path          = require('path');
const pdf           = require('html-pdf');
const Withdrawals   = require('../../models/Withdraw');
const Transactions  = require('../../models/Transactions');
const Settings      = require('../../models/Settings');
const Users         = require('../../models/Users');
var { UserBanks }   = require('../../models/UserBanks');
const { isValid }   = require('../../services/validation');
const { getPagination, getRespPagi, getInnoKey, convertToUTCNew } = require('../../services/common');
const { doTransfer, verifyBankAccount, getBalance, checkPaymentStatus, checkTransferStatus } = require('../../services/Withdraw');
const pdfTemplate = require('../../view/pdf/transaction');

const Crypto        = require("crypto");
const Axios         = require('axios');
const multer        = require('multer');
const { addBonusReferalAmount } = require('../UserProfileController');

exports.getWithdrawList = (req, res) => {
    (async () => {
        try {
            var { page, size, search } = req.body;
            var condition_lookup = {
                "$expr": {
                    "$and" : [
                        {
                            "$eq": [ "$_id", "$$user_id" ]
                        }
                    ]
                },
            }
            if(search){
                /* condition_lookup = {
                    "$expr": {
                        "$and" : [
                            {
                                "$eq": [ "$_id", "$$user_id" ]
                            },
                            {
                                "$eq": [ "$mobile_no", search ]
                            },
                        ]
                    },
                } */
                //condition_lookup = { "users.mobile_no": { $regex: new RegExp(search), $options: "i" }};
            }
            // var condition_lookup = search ? {
            //     "$match": {
            //      mobile_no: { $regex: new RegExp(search), $options: "i" } }
            // } : {
            //     "$match": {
            //         "$expr": { "$eq": [ "$user_id", "$$user_id" ] },
            //     }
            //     };
            // console.log({ "$eq": [ "$user_id", "$$user_id" ] }, { $regex: new RegExp(search), $options: "i" });
            var condition = { deleted: false, status: { $ne: 0 } };
            //var condition = { status: { $ne: 0 } };//, tnx_type: { $in: [4,5] }
            
            if(search){
                //condition.amount = { $regex: new RegExp(search), $options: "i" };
            }
            var user_info = {};
            var user_id = req.body.user_id ? req.body.user_id : null;
            if (user_id != null){
                condition = { user_id: mongoose.Types.ObjectId(user_id), status: { $ne: 0 } };
                user_info = await Users.aggregate([
                    {$match:{ _id: mongoose.Types.ObjectId(user_id) }},
                    {$lookup: {
                        from: 'user_banks',
                        let:{'user_id':'$_id'},
                        pipeline:[
                            {
                                "$match": {
                                "$expr": { "$eq": [ "$user_id", "$$user_id" ] },
                                },
                            },
                            { $project : { _id:1,user_name:1 } }
                        ],
                        as: 'BankDetails',
                    }},
                    {$project:{"_id":1,"mobile_no":1,"BankDetails._id":1,"BankDetails.user_name":1}}
                ]);
            }
            if (search == ''){
                let tdDate = new Date();
                let minusOneWeek = new Date();
                minusOneWeek.setDate(minusOneWeek.getDate() - 7);
                condition.createdAt = { $gte: convertToUTCNew(minusOneWeek), $lte: convertToUTCNew(tdDate)};
            }
            // console.log(89, condition);
            page = page - 1;
            const { limit, offset } = getPagination(page, size);
            /* {
                $match: {
                    $or: [
                        {
                            amount: { $eq: parseInt(search) }
                        },
                        {
                            'user_id.mobile_no': { $regex: new RegExp(search), $options: "i" }
                        }
                    ]
                }
            }, */
            var aggregate = Withdrawals.aggregate([
                { $match: condition },
                
                {$lookup: {
                    from: 'user_banks',
                    let:{'user_id':'$user_id'},
                    pipeline:[
                        {
                            "$match": {
                            "$expr": { "$eq": [ "$user_id", "$$user_id" ] },
                            },
                        },
                        { $project : { _id:1,bank_name:1,user_name:1 } }
                    ],
                    as: 'BankDetails',
                }},
                {$lookup: {
                    from: 'users',
                    let:{'user_id':'$user_id'},
                    pipeline:[
                        {
                            "$match":condition_lookup
                        },
                        { $project : { _id:1,mobile_no:1,country_code:1 } }
                    ],
                    as: 'user_id'
                }},
                {
                    $match: { 'user_id.mobile_no': { $regex: new RegExp(search), $options: "i" } }
                },
                {
                    $project:{
                        _id:1,
                        user_id:{ "$arrayElemAt": [ "$user_id", 0 ] },
                        amount:1,
                        charge:1,
                        charge_amount:1,
                        final_amount:1,
                        tnx:1,
                        status:1,
                        approved_at:1,
                        approved_by:1,
                        deleted:1,
                        createdAt:1,
                        updatedAt:1,
                        BankDetails:{ "$arrayElemAt": [ "$BankDetails", 0 ] },
                    }
                },
                { $unwind: '$user_id' },
                // { $match: {"$user_id":{$ne:[]}} },
                {
                    $sort: { createdAt:-1}
                }
            ]);
            await Withdrawals.aggregatePaginate(aggregate, {
                limit,
                offset,
            }).then((resopnse) => {
                resopnse.user_info = user_info;
                let sendd = getRespPagi(resopnse, 'Withdraw Found');
                return res.json(sendd);
            });
        } catch (error) {
            console.log(157, error);
            return res.json({ status: 0, message: error.message, data: error });
        }
    })();
}
exports.getSinWithdraw = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.params.id)) {
                return res.json({ status: 0, message: 'ID is required', data: {} });
            }
            
            let id = req.params.id;
            let data = await Withdrawals.findOne({ _id: id }).populate({
                path: 'user_id',
                select: 'firstname lastname country_code mobile_no'
            });
            if (data) {
                return res.json({ status: 1, message: 'Get Withdraw Detail Successfully', data: data });
            } else {
                return res.json({ status: 0, message: "No Withdraw Found", data: {} });
            }
        } catch (error) {
            return res.json({ status: 0, message: error || "Something Went Wrong", data: {} });
        }
    })();
}

exports.editWithdraw = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.params.id)) {
                return res.json({ status: 0, message: 'ID is required', data: {} });
            }
            let id = req.params.id;
            let data = await Withdrawals.findOne({ _id: id });
            if (data) {
                return res.json({ status: 1, message: 'Get Withdraw Detail Successfully', data: data });
            } else {
                return res.json({ status: 0, message: "No Withdraw Found", data: {} });
            }
        } catch (error) {
            return res.json({ status: 0, message: error || "Something Went Wrong", data: {} });
        }
    })();
}

exports.updateWithdraw = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.withdraw_id)) {
                return res.json({ status: 0, message: 'withdraw_id is required', data: {} });
            }
            if (!await isValid(req.body.charge)) {
                return res.json({ status: 0, message: 'charge is required', data: {} });
            }
            if (!await isValid(req.body.amount)) {
                return res.json({ status: 0, message: 'amount is required', data: {} });
            }
            let data = await Withdrawals.findOne({ _id: req.body.withdraw_id });
            if (data) {
                let charge_amount = (parseInt(req.body.amount) * parseInt(req.body.charge)) / 100  
                let final_amount = parseInt(req.body.amount) - parseInt(charge_amount);
                let withdrawal_update = await Withdrawals.updateOne({ _id: req.body.withdraw_id }, {
                    amount: req.body.amount,
                    charge_amount: charge_amount,
                    final_amount: final_amount,
                    charge: req.body.charge,
                    updatedAt: new Date(),
                });
                if(withdrawal_update.modifiedCount > 0){
                    return res.json({ status: 1, message: "Withdraw request update successfully."});    
                }
                return res.json({ status: 0, message: "Withdraw request update unsuccessfully."});    
            } else {
                return res.json({ status: 0, message: "No Withdraw Found", data: {} });
            }
        } catch (error) {
            return res.json({ status: 0, message: error || "Something Went Wrong", data: {} });
        }
    })();
}

exports.requestEnabledDisabled = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.status)) {
                return res.json({ status: 0, message: 'status is required', data: {} });
            }
            let status_text = (req.body.status == 1) ? 'enabled' : 'disabled';
            let setting_count = await Settings.find().countDocuments();
            if(setting_count > 0){
                let data = await Settings.updateMany({ widthraw_request: req.body.status });
                if(data.modifiedCount > 0){
                    return res.json({ status: 1, message: "Widthraw request "+status_text });
                }
            }else{
                return await new Settings({
                    widthraw_request: req.body.status,
                    minimum_deposit_amount: 0,
                    bonus_amount: 0,
                }).save(function (err, transaction) {
                    if (err) return res.json({ status: 0, message: err.message });
                    return res.json({ status: 1, message: "Widthraw request "+status_text });
                });
            }
            return res.json({ status: 0, message: "No Withdraw Found", data: {} });
        } catch (error) {
            return res.json({ status: 0, message: error || "Something Went Wrong", data: {} });
        }
    })();
}

exports.getSettingData = (req, res) => {
    (async () => {
        try {
            let setting = await Settings.findOne();
            setting.apk_file = `${process.env.IMG_BASE_URL}${setting.apk_file}`;
            return res.json({ status: 1, message: "Setting Data", data: setting });
        } catch (error) {
            return res.json({ status: 0, message: error.message || "Something Went Wrong", data: error });
        }
    })();
}

exports.approveRejectWithdraw = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.status)) {
                return res.json({ status: 0, message: 'status is required', data: {} });
            }
            let id = req.body.id;
            let status = req.body.status;
            //return res.json({ status: 0, message: "Withdraw Already Cancelled", data: req.body });
            let data = await Withdrawals.findOne({ _id: id }).populate('user_id');
            if (data){
                if(data.status == 1){
                    return res.json({ status: 0, message: "Withdraw Already Approved", data: {} });
                } else if (data.status == 3){
                    return res.json({ status: 0, message: "Withdraw Already Cancelled", data: {} });
                } else {
                    //Code For Bank Transfer
                    var txt = (status == 1)?'Approved':'Cancelled';
                    
                    //let resp = await verifyBankAccount(data.user_id._id);
                    /* let resp = await verifyBankAccount('61716eac4783028b62259db8');
                    return res.json(resp); */

                    let update = await Withdrawals.updateOne({ _id: id }, {
                        status: status,
                        approved_at: new Date(),
                        approved_by: req.userDet._id
                    });
                    if (update.modifiedCount > 0) {
                        if(status == 3){//cancelled request
                            return res.json({ status: 1, message: "Withdraw Request Cancelled", data: {} });
                            /* var post_balance = ((data.user_id) ? data.user_id.wallet_wining : 0) + data.amount;
                            var update_winning_wallet = await Users.updateOne({ _id: data.user_id._id }, { wallet_wining: post_balance });
                            if(update_winning_wallet.modifiedCount > 0){
                                await new Transactions({
                                    user_id: data.user_id,
                                    refe_id: data._id,
                                    amount: data.final_amount,
                                    charge_amount: data.charge_amount,
                                    final_amount: data.amount,
                                    post_balance: post_balance,
                                    tnx_type: 6,//withdraw
                                    wallet_type: 1,//winning wallet
                                    details: "Winnings Withdraw Cancelled Refund",
                                    entry_type: 1,//debit entry
                                    created_by: req.userDet._id
                                }).save(function (err, transaction) {
                                    if (err) return res.json({ status: 0, message: err.message, data: {} });
                                    return res.json({ status: 1, message: 'Withdraw ' + txt + ' Successfully', data: {} });
                                });
                            } */
                        } else {
                            let user_id = data.user_id._id;
                            if (parseFloat(data.amount) > parseFloat(data.user_id.wallet_wining)){
                                return res.json({ status: 0, message: 'Insufficient Amount In Wallet, Not Allwed To Approve', data: {} });
                            }
                            var post_balance = data.user_id.wallet_wining - data.amount;
                            var update_winning_wallet = await Users.updateOne({ _id: user_id }, {$set:{ wallet_wining: post_balance }});
                            // console.log('update_winning_wallet', update_winning_wallet);
                            if (update_winning_wallet.modifiedCount > 0) {
                                let refe_id = data._id;
                                return await new Transactions({
                                    user_id: user_id,
                                    refe_id: refe_id,
                                    amount: data.final_amount,
                                    charge_amount: data.charge_amount,
                                    final_amount: data.amount,
                                    post_balance: post_balance,
                                    tnx_type: 6,//withdraw
                                    wallet_type: 1,//winning wallet
                                    details: "Winnings Withdraw",
                                    entry_type: 2,//debit entry
                                    created_by: req.userDet._id
                                }).save(async function (err, transaction) {
                                    if (err) return res.json({ status: 0, message: err.message, data: {} });
                                    let resp = await doTransfer(data.final_amount, data.user_id._id, id);
                                    if(resp.status == 0){
                                        const update2 = { status: 2 };
                                        await Withdrawals.updateOne({ _id: id }, update2);
                                        if(user_id){
                                            const userDetail = await Users.findOne({ _id: user_id });
                                            if(userDetail && userDetail?.wallet_wining){
                                                const postBalance = userDetail.wallet_wining + data.amount;;
                                                await Users.updateOne({ _id: user_id }, {$set:{ wallet_wining: postBalance }});
                                                await Transactions.deleteMany({ _id: transaction?._id, user_id: user_id, refe_id: id });
                                            }
                                        }
                                    }
                                    //let resp = { status: 1, message: "Withdraw Request Approved Successfully", data: {} };
                                    return res.json(resp); 
                                });
                            }
                            //return res.json({ status: 1, message: 'Withdraw ' + txt + ' Successfully', data: {} });
                        }
                    } else {
                        return res.json({ status: 0, message: "Cannot Update Withdraw", data: {} });
                    }
                }
            } else {
                return res.json({ status: 0, message: "Withdraw Not Found", data: {} });
            }
        } catch (error) {
            return res.json({ status: 0, message: error || "Something Went Wrong", data: {} });
        }
    })();
}


/* Transaction Start 14-10-2021 */
exports.getTransactionList = (req, res) => {
    (async () => {
        try {
            var { page, size, searchFromDate,searchToDate, user_id,searchWalletType,searchTransactionType } = req.body;
            var user_id = req.body.user_id ? req.body.user_id:null;
            var user_info = {};
            var search_date = {};
            var condition = { deleted:false, pay_status:1 };
            var summCond = { deleted: false, pay_status:1 };
            var summTnxType = [];
            if(typeof searchFromDate !== 'undefined' && searchFromDate != ''){
                search_date.$gte = convertToUTCNew(searchFromDate + ' 00:00:00');
            }
            if(typeof searchFromDate !== 'undefined' && searchToDate != ''){
                search_date.$lte = convertToUTCNew(searchToDate + ' 23:59:59');
            }
            if(Object.keys(search_date).length > 0){
                condition.createdAt = search_date;
                summCond.createdAt = search_date;
            }
            if(typeof searchWalletType !== 'undefined' && searchWalletType != ''){
                condition.wallet_type = parseInt(searchWalletType);
                summCond.wallet_type = parseInt(searchWalletType);
            }
            if(typeof searchTransactionType !== 'undefined' && searchTransactionType.length > 0){
                condition.tnx_type = {$in:searchTransactionType};
                summTnxType = searchTransactionType;
            }
            if (user_id != null){
                condition.user_id = mongoose.Types.ObjectId(user_id);
                summCond.user_id = mongoose.Types.ObjectId(user_id);
                user_info = await Users.aggregate([
                    {$match:{ _id: mongoose.Types.ObjectId(user_id) }},
                    {$lookup: {
                        from: 'user_banks',
                        let:{'user_id':'$_id'},
                        pipeline:[
                            {
                                "$match": {
                                "$expr": { "$eq": [ "$user_id", "$$user_id" ] },
                                },
                            },
                            { $project : { _id:1,user_name:1,bank_name:1 } }
                        ],
                        as: 'BankDetails',
                    }},
                    {$project:{"_id":1,"mobile_no":1,"BankDetails._id":1,"BankDetails.user_name":1}}
                ]);
            }
            page = page - 1;
            const { limit, offset } = getPagination(page, size);
            var aggregate = Transactions.aggregate([
                { $match: condition },
                /* {$lookup: {
                    from: 'user_banks',
                    let:{'user_id':'$user_id'},
                    pipeline:[
                        {
                            "$match": {
                            "$expr": { "$eq": [ "$user_id", "$$user_id" ] },
                            },
                        },
                        { $project : { _id:1,bank_name:1,user_name:1 } }
                    ],
                    as: 'BankDetails',
                }}, */
                /* {$lookup: {
                    from: 'users',
                    let:{'user_id':'$user_id'},
                    pipeline:[
                        {
                            "$match": {
                            "$expr": { "$eq": [ "$_id", "$$user_id" ] },
                            },
                        },
                        { $project : { _id:1,mobile_no:1,country_code:1 } }
                    ],
                    as: 'user_id'
                }}, */
                {
                    $project:{
                        _id:1,
                        // user_id:{ "$arrayElemAt": [ "$user_id", 0 ] },
                        user_id:1,
                        refe_id:1,
                        amount:1,
                        charge_amount:1,
                        final_amount:{'$convert': { 'input': '$final_amount', 'to': 'int' }},
                        post_balance:1,
                        tnx_type:1,
                        tnx:1,
                        wallet_type:1,
                        details:1,
                        entry_type:1,
                        created_by:1,
                        updated_by:1,
                        deleted:1,
                        createdAt:1,
                        updatedAt:1,
                        // BankDetails:{ "$arrayElemAt": [ "$BankDetails", 0 ] },
                    }
                },
                {
                    $sort: { createdAt: -1 }
                }
            ], { allowDiskUse: true });
            await Transactions.aggregatePaginate(aggregate, {
                limit,
                offset,
            }).then(async (resopnse) => {
                resopnse.user_info = user_info;
                let sendd = getRespPagi(resopnse, 'Get Transactions List Successfully');
                const results = [...resopnse.docs];
                const userIds = results.map((val)=> val.user_id);
                if(userIds && userIds.length > 0){
                    const users = await Users.find({ _id: { $in: userIds } }).select('_id mobile_no country_code');
                    const userBanks = await UserBanks.find({ user_id: { $in: userIds } }).select('_id user_id bank_name user_name');
                    const newTrans = [];
                    for (const itm of sendd.data.docs) {
                        const userDoc = users.find((ij)=>ij._id.toString() == itm.user_id.toString());
                        const bankDetails = userBanks.find((ij)=>ij.user_id.toString() == itm.user_id.toString());
                        newTrans.push({
                            ...itm,
                            user_id: userDoc,
                            BankDetails: bankDetails || null
                        });
                    }
                    sendd.data.docs = newTrans;
                }
                let summCond = condition;
                
                let summaryData = {
                    addedSelf: 0, addedSelfAmt: 0,
                    addedAdmin: 0, addedAdminAmt: 0,
                    bonusCredit: 0, bonusCreditAmt: 0,
                    depoBonusCredit: 0, depoBonusCreditAmt: 0,
                    bankVerifBonus: 0, bankVerifBonusAmt: 0,
                    placedBid: 0, placedBidAmt: 0,
                    winningCredit: 0, winningCreditAmt: 0,
                    winningWithdraw: 0, winningWithdrawAmt: 0,
                    refund: 0, refundAmt: 0,
                };
                if(page > 0){
                    return res.json(sendd); 
                }
                const summaryDet = await Transactions.aggregate([
                    { $match: summCond },
                    { "$group": { "_id": "$tnx_type", "total": { "$sum": "$amount" }, "tot_tnx": { "$count": {} } } }
                ]);
                
                if(summaryDet && summaryDet.length > 0){
                    for (const itm of summaryDet) {
                        if(itm._id == 1){ //placedBid
                            summaryData.placedBid = itm.tot_tnx;
                            summaryData.placedBidAmt = itm.total;
                        } else if(itm._id == 2){ //refund
                            summaryData.refund = itm.tot_tnx;
                            summaryData.refundAmt = itm.total;
                        } else if(itm._id == 3){ //bonusCredit
                            summaryData.bonusCredit = itm.tot_tnx;
                            summaryData.bonusCreditAmt = itm.total;
                        } else if(itm._id == 4){ //addedAdmin
                            summaryData.addedAdmin = itm.tot_tnx;
                            summaryData.addedAdminAmt = itm.total;
                        } else if(itm._id == 5){ //addedSelf
                            summaryData.addedSelf = itm.tot_tnx;
                            summaryData.addedSelfAmt = itm.total;
                        } else if(itm._id == 6){ //winningWithdraw
                            summaryData.winningWithdraw = itm.tot_tnx;
                            summaryData.winningWithdrawAmt = itm.total;
                        } else if(itm._id == 7){ //winningCredit
                            summaryData.winningCredit = itm.tot_tnx;
                            summaryData.winningCreditAmt = itm.total;
                        } else if(itm._id == 9){ //depoBonusCredit
                            summaryData.depoBonusCredit = itm.tot_tnx;
                            summaryData.depoBonusCreditAmt = itm.total;
                        } else if(itm._id == 10){ //bankVerifBonus
                            summaryData.bankVerifBonus = itm.tot_tnx;
                            summaryData.bankVerifBonusAmt = itm.total;
                        }
                    }
                }
                /* if (summTnxType.length == 0 || summTnxType.indexOf(1) > -1){
                    summCond.tnx_type = 1;
                    var placedBid = await Transactions.aggregate([
                        { $match: summCond },
                        { "$group": { "_id": null, "total": { "$sum": "$amount" }, "tot_tnx": { "$count": {} } } }
                    ]);
                    if (placedBid.length > 0){
                        summaryData.placedBid = placedBid[0].tot_tnx;
                        summaryData.placedBidAmt = placedBid[0].total;
                    }
                }
                if (summTnxType.length == 0 || summTnxType.indexOf(2) > -1){
                    summCond.tnx_type = 2;
                    var refund = await Transactions.aggregate([
                        { $match: summCond },
                        { "$group": { "_id": null, "total": { "$sum": "$amount" }, "tot_tnx": { "$count": {} } } }
                    ]);
                    if (refund.length > 0){
                        summaryData.refund = refund[0].tot_tnx;
                        summaryData.refundAmt = refund[0].total;
                    }
                }
                if (summTnxType.length == 0 || summTnxType.indexOf(3) > -1){
                    summCond.tnx_type = 3;
                    var bonusCredit = await Transactions.aggregate([
                        { $match: summCond },
                        { "$group": { "_id": null, "total": { "$sum": "$amount" }, "tot_tnx": { "$count": {} } } }
                    ]);
                    if (bonusCredit.length > 0){
                        summaryData.bonusCredit = bonusCredit[0].tot_tnx;
                        summaryData.bonusCreditAmt = bonusCredit[0].total;
                    }
                }
                if (summTnxType.length == 0 || summTnxType.indexOf(4) > -1) {
                    summCond.tnx_type = 4;
                    var addedAdmin = await Transactions.aggregate([
                        { $match: summCond },
                        { "$group": { "_id": null, "total": { "$sum": "$amount" }, "tot_tnx": { "$count": {} } } }
                    ]);
                    if (addedAdmin.length > 0) {
                        summaryData.addedAdmin = addedAdmin[0].tot_tnx;
                        summaryData.addedAdminAmt = addedAdmin[0].total;
                    }
                }
                if (summTnxType.length == 0 || summTnxType.indexOf(5) > -1) {
                    summCond.tnx_type = 5;
                    var addedSelf = await Transactions.aggregate([
                        { $match: summCond },
                        { "$group": { "_id": null, "total": { "$sum": "$amount" }, "tot_tnx": { "$count": {} } } }
                    ]);
                    if (addedSelf.length > 0) {
                        summaryData.addedSelf = addedSelf[0].tot_tnx;
                        summaryData.addedSelfAmt = addedSelf[0].total;
                    }
                }
                if (summTnxType.length == 0 || summTnxType.indexOf(6) > -1) {
                    summCond.tnx_type = 6;
                    var winningWithdraw = await Transactions.aggregate([
                        { $match: summCond },
                        { "$group": { "_id": null, "total": { "$sum": "$amount" }, "tot_tnx": { "$count": {} } } }
                    ]);
                    if (winningWithdraw.length > 0) {
                        summaryData.winningWithdraw = winningWithdraw[0].tot_tnx;
                        summaryData.winningWithdrawAmt = winningWithdraw[0].total;
                    }
                }
                if (summTnxType.length == 0 || summTnxType.indexOf(7) > -1) {
                    summCond.tnx_type = 7;
                    var winningCredit = await Transactions.aggregate([
                        { $match: summCond },
                        { "$group": { "_id": null, "total": { "$sum": "$amount" }, "tot_tnx": { "$count": {} } } }
                    ]);
                    if (winningCredit.length > 0) {
                        summaryData.winningCredit = winningCredit[0].tot_tnx;
                        summaryData.winningCreditAmt = parseInt(winningCredit[0].total);
                    }
                }
                if (summTnxType.length == 0 || summTnxType.indexOf(9) > -1) {
                    summCond.tnx_type = 9;
                    var depoBonusCredit = await Transactions.aggregate([
                        { $match: summCond },
                        { "$group": { "_id": null, "total": { "$sum": "$amount" }, "tot_tnx": { "$count": {} } } }
                    ]);
                    if (depoBonusCredit.length > 0) {
                        summaryData.depoBonusCredit = depoBonusCredit[0].tot_tnx;
                        summaryData.depoBonusCreditAmt = depoBonusCredit[0].total;
                    }
                }
                if (summTnxType.length == 0 || summTnxType.indexOf(10) > -1) {
                    summCond.tnx_type = 10;
                    var bankVerifBonus = await Transactions.aggregate([
                        { $match: summCond },
                        { "$group": { "_id": null, "total": { "$sum": "$amount" }, "tot_tnx": { "$count": {} } } }
                    ]);
                    if (bankVerifBonus.length > 0) {
                        summaryData.bankVerifBonus = bankVerifBonus[0].tot_tnx;
                        summaryData.bankVerifBonusAmt = bankVerifBonus[0].total;
                    }
                } */
                sendd.summaryData = summaryData;
                return res.json(sendd);
            }).catch(function (err) {
                console.log(err);
            });
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error, data: {} });
        }
    })();
}
/* Transaction End */

/* 27-10-2021 */
exports.updateSetting = (req, res) => {
    (async () => {
        try {
            let pg_is_card = (req.body.pg_is_card) ? req.body.pg_is_card:0;
            let pg_is_net = (req.body.pg_is_net) ? req.body.pg_is_net:0;
            let pg_is_upi = (req.body.pg_is_upi) ? req.body.pg_is_upi:0;
            let pg_is_googlepay = (req.body.pg_is_googlepay) ? req.body.pg_is_googlepay:0;
            let pg_is_phonepay = (req.body.pg_is_phonepay) ? req.body.pg_is_phonepay:0;
            
            let update = { pg_is_card: pg_is_card, pg_is_net: pg_is_net, pg_is_upi: pg_is_upi, pg_is_googlepay: pg_is_googlepay, pg_is_phonepay: pg_is_phonepay };
            let setting_count = await Settings.find().countDocuments();
            if (setting_count > 0) {
                let data = await Settings.updateMany(update);
                if (data.modifiedCount > 0) {
                    return res.json({ status: 1, message: "Payment Setting Updated Successfully" });
                }
            } else {
                update.widthraw_request = 1;
                return await new Settings(update).save(function (err, transaction) {
                    if (err) return res.json({ status: 0, message: err.message });
                    return res.json({ status: 1, message: "Payment Setting Updated Successfully" });
                });
            }
            return res.json({ status: 0, message: "NoPayment  Setting Found", data: {} });
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error || "Something Went Wrong", data: {} });
        }
    })();
}

exports.updateSettingAmounts = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.bonus_amount)) {
                return res.json({ status: 0, message: 'bonus amount is required', data: {} });
            }
            if (!await isValid(req.body.minimum_deposit_amount)) {
                return res.json({ status: 0, message: 'minimum deposit amount is required', data: {} });
            }
            if (!await isValid(req.body.deposit_bonus_amount)) {
                return res.json({ status: 0, message: 'deposit bonus amount is required', data: {} });
            }
            if (!await isValid(req.body.auto_withd_min_amount)) {
                return res.json({ status: 0, message: 'auto withdraw amount is required', data: {} });
            }
            if (!await isValid(req.body.referral_bonus_amount)) {
                return res.json({ status: 0, message: 'referral bonus amount is required', data: {} });
            }
            if (!await isValid(req.body.min_deposit_amount_for_bonus)) {
                return res.json({ status: 0, message: 'minimum deposit amount for bonus is required', data: {} });
            }
            if (!await isValid(req.body.whatsapp_no)) {
                return res.json({ status: 0, message: 'whatsapp no is required', data: {} });
            }
            if (!await isValid(req.body.calling_phone_no)) {
                return res.json({ status: 0, message: 'calling phone no is required', data: {} });
            }
            if (!await isValid(req.body.email_id)) {
                return res.json({ status: 0, message: 'email id is required', data: {} });
            }
            const { bonus_amount, minimum_deposit_amount, deposit_bonus_amount, auto_withd_min_amount, referral_bonus_amount, min_deposit_amount_for_bonus, whatsapp_no, calling_phone_no, email_id } = req.body;
            
            let update = { 
                bonus_amount: bonus_amount,
                minimum_deposit_amount: minimum_deposit_amount,
                deposit_bonus_amount: deposit_bonus_amount,
                auto_withd_min_amount: auto_withd_min_amount,
                referral_bonus_amount: referral_bonus_amount,
                min_deposit_amount_for_bonus: min_deposit_amount_for_bonus,
                whatsapp_no: whatsapp_no,
                calling_phone_no: calling_phone_no,
                email_id: email_id,
            };
            let setting_count = await Settings.find().countDocuments();
            if (setting_count > 0) {
                let data = await Settings.updateMany(update);
                if (data.modifiedCount > 0) {
                    return res.json({ status: 1, message: "Setting Updated Successfully" });
                }
            } else {
                update.widthraw_request = 1;
                return await new Settings(update).save(function (err, transaction) {
                    if (err) return res.json({ status: 0, message: err.message });
                    return res.json({ status: 1, message: "Setting Updated Successfully", data: {} });
                });
            }
            return res.json({ status: 0, message: "No Setting Found", data: {} });
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error || "Something Went Wrong", data: {} });
        }
    })();
}

exports.transactionListGeneratePdf = (req, res) => {
    (async () => {
        try {
            var transaction = await Transactions.aggregate([
                // { $match: condition },
                {$lookup: {
                    from: 'user_banks',
                    let:{'user_id':'$user_id'},
                    pipeline:[
                        {
                            "$match": {
                            "$expr": { "$eq": [ "$user_id", "$$user_id" ] },
                            },
                        },
                        { $project : { _id:1,bank_name:1,user_name:1 } }
                    ],
                    as: 'BankDetails',
                }},
                {$lookup: {
                    from: 'users',
                    let:{'user_id':'$user_id'},
                    pipeline:[
                        {
                            "$match": {
                            "$expr": { "$eq": [ "$_id", "$$user_id" ] },
                            },
                        },
                        { $project : { _id:1,mobile_no:1,country_code:1 } }
                    ],
                    as: 'user_id'
                }},
                {
                    $project:{
                        _id:1,
                        user_id:{ "$arrayElemAt": [ "$user_id", 0 ] },
                        refe_id:1,
                        amount:1,
                        charge_amount:1,
                        final_amount:1,
                        post_balance:1,
                        tnx_type:1,
                        tnx:1,
                        wallet_type:1,
                        details:1,
                        entry_type:1,
                        created_by:1,
                        updated_by:1,
                        deleted:1,
                        createdAt:1,
                        updatedAt:1,
                        BankDetails:{ "$arrayElemAt": [ "$BankDetails", 0 ] },
                    }
                }
            ]);
            pdf.create(pdfTemplate(req.body), {}).toFile('rezultati.pdf', (err) => {
                if(err) {
                    return console.log('error');
                }
                res.send(Promise.resolve())
            });
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error || "Something Went Wrong", data: {} });
        }
    })();
}

/* 18-11-2021 */

exports.getWithdrawListAll = (req, res) => {
    (async () => {
        try {
            var {  search, date } = req.body;
            let condition = { deleted: false, status: { $eq: 2 } };
            //if (search != '' && search > 0){
                condition.amount = { $lte: parseInt(search) };
            //}
            
            if (typeof date !== 'undefined' && date != '') {
                condition.createdAt = {
                    $gte: convertToUTCNew(date + ' 00:00:00'),
                    $lte: convertToUTCNew(date + ' 23:59:59')
                };
            }
            console.log(775, condition);
            var aggregate = Withdrawals.aggregate([
                { $match: condition },
                {
                    $lookup: {
                        from: 'user_banks',
                        let: { 'user_id': '$user_id' },
                        pipeline: [
                            {
                                "$match": {
                                    "$expr": { "$eq": ["$user_id", "$$user_id"] },
                                },
                            },
                            { $project: { _id: 1, bank_name: 1, user_name: 1 } }
                        ],
                        as: 'BankDetails',
                    }
                },
                {
                    $lookup: {
                        from: 'users',
                        let: { 'user_id': '$user_id' },
                        pipeline: [
                            {
                                "$match": {
                                    "$expr": { "$eq": ["$_id", "$$user_id"] },
                                },
                            },
                            { $project: { _id: 1, mobile_no: 1, country_code: 1 } }
                        ],
                        as: 'user_id'
                    }
                },
                {
                    $project: {
                        _id: 1,
                        user_id: { "$arrayElemAt": ["$user_id", 0] },
                        amount: 1,
                        charge: 1,
                        charge_amount: 1,
                        final_amount: 1,
                        tnx: 1,
                        status: 1,
                        approved_at: 1,
                        approved_by: 1,
                        deleted: 1,
                        createdAt: 1,
                        updatedAt: 1,
                        BankDetails: { "$arrayElemAt": ["$BankDetails", 0] },
                    }
                },
                {
                    $sort: { createdAt: -1 }
                }
            ]);
            await aggregate.then(async (resopnse) => {
                let tot = 0; let tot_amt = 0; let withIds = [];
                let resp = await Promise.all(resopnse.map(async (row) => {
                    tot_amt += row.final_amount;
                    withIds.push(row._id);
                    tot++;
                    return row;
                }));
                return res.json({ status: 1, message: 'Get Withdraw List Success', data: { rows: resp, tot: tot, tot_amt: tot_amt, withIds: withIds} });
            });
        } catch (error) {
            return res.json({ status: 0, message: error, data: {} });
        }
    })();
}

exports.approveRejectWithdrawAll = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.withIds)) {
                return res.json({ status: 0, message: 'withIds is required', data: {} });
            }
            
            let withIds = req.body.withIds;
            let status = req.body.status;
            if (withIds.length == 0){
                return res.json({ status: 0, message: 'No data found', data: {} });
            }
            let rows = await Withdrawals.find({ _id: { $in: withIds} });
            if (rows.length > 0) {
                //return res.json({ status: 0, message: "Withdraw Already Approved", data: {} });
                var txt = (status == 1) ? 'Approved' : 'Rejected';
                if (rows[0].status == 1) {
                    return res.json({ status: 0, message: "Withdrawals Already Approved", data: {} });
                } else if (rows[0].status == 3) {
                    return res.json({ status: 0, message: "Withdrawals Already Rejected", data: {} });
                } else {
                    let resp = await Promise.all(rows.map(async (data) => {
                        let id = data._id;
                        let updateNew = {
                            approved_at: new Date(),
                            approved_by: req.userDet._id
                        };
                        if (status == 3){
                            updateNew.status = status;
                        }
                        let update = await Withdrawals.updateOne({ _id: id }, updateNew);
                        if (update.modifiedCount > 0) {
                            let user_id = data.user_id;
                            if (status == 3) {//cancelled request
                                return { status: 1, message: "Withdraw Request Cancelled", data: { } };
                                /* let userDet = await Users.findOne({ _id: data.user_id});
                                if (userDet){
                                    var post_balance = userDet.wallet_wining + data.amount;
                                    console.log(647, post_balance);
                                    var update_winning_wallet = await Users.updateOne({ _id: userDet._id }, { wallet_wining: post_balance });
                                    if (update_winning_wallet.modifiedCount > 0) {
                                        return await new Transactions({
                                            user_id: data.user_id,
                                            refe_id: data._id,
                                            amount: data.final_amount,
                                            charge_amount: data.charge_amount,
                                            final_amount: data.amount,
                                            post_balance: post_balance,
                                            tnx_type: 6,//withdraw
                                            wallet_type: 1,//winning wallet
                                            details: "Winnings Withdraw Cancelled Refund",
                                            entry_type: 1,//debit entry
                                            created_by: req.userDet._id
                                        }).save(function (err, transaction) {
                                            if (!err) return transaction;
                                        });
                                    }
                                } */
                            } else {
                                //return data;
                                let userDet = await Users.findOne({ _id: data.user_id });
                                if (userDet) {
                                    var post_balance = userDet.wallet_wining - data.amount;
                                    var update_winning_wallet = await Users.updateOne({ _id: user_id }, { $set: { wallet_wining: post_balance } });
                                    console.log('910 update_winning_wallet', update_winning_wallet);
                                    if (update_winning_wallet.modifiedCount > 0) {
                                        let refe_id = data._id;
                                        return await new Transactions({
                                            user_id: user_id,
                                            refe_id: refe_id,
                                            amount: data.final_amount,
                                            charge_amount: data.charge_amount,
                                            final_amount: data.amount,
                                            post_balance: post_balance,
                                            tnx_type: 6,//withdraw
                                            wallet_type: 1,//winning wallet
                                            details: "Winnings Withdraw",
                                            entry_type: 2,//debit entry
                                            created_by: req.userDet._id
                                        }).save(async function (err, transaction) {
                                            if (err) return { status: 0, message: err.message, data: {} };
                                            return await doTransfer(data.final_amount, data.user_id._id, id);
                                        });
                                    }
                                }
                                
                            }
                        }
                        return data;
                    }));
                    return res.json({ status: 1, message: 'Withdrawals Requests ' + txt + ' Successfully', data: resp });
                }
            } else {
                return res.json({ status: 0, message: "No Withdrawals Found", data: {} });
            }
        } catch (error) {
            return res.json({ status: 0, message: error.message || "Something Went Wrong", data: error });
        }
    })();
}
/* 09-11-2021 */
exports.checkBankStatus = (req, res) => {
    (async () => {
        try {
            let resp = await verifyBankAccount('61966fe9c655e7c616321ae3');
            if(resp.status == 1){
                let bankDet = await UserBanks.findOne({ user_id:'61966fe9c655e7c616321ae3'});
                if(bankDet){
                    let update2 = { is_verified:1, verified_at:new Date() };
                    await UserBanks.updateOne({ _id:bankDet._id},update2);
                    return res.json(resp);
                } else {
                    return res.json(resp);    
                }
            } else {
                return res.json(resp);
            }
            
            let merchant_reference_number = generateMerRefCode();
            let transfer_type = 'IMPS';/* IMPS OR NEFT(over 2 lakh) */
            let account_name = 'Mr. ABC XYZ PQR';
            let account_number = '01234567980';
            let ifsc_code = 'SBIN06154';
            let bank_branch = 'Ranitower Rajkot';
            let bank_name = 'SBI';

            let api_key = getInnoKey().API_KEY;
            let salt    = getInnoKey().SALT;

            let body = { api_key: api_key, account_name: account_name, account_number: account_number, ifsc_code: ifsc_code };
            let secure_hash = null;
            //let salt = 'b8b08569c41715fcb96bbc1e45fcd461283e6e8e';
            //let hash_string = salt + '|' + account_name + '|' + account_number + '|1.00|' + api_key + '|' + bank_branch + '|' + bank_name + '|' + ifsc_code + '|' + merchant_reference_number + '|' + transfer_type;
            let hash_string = salt + '|' + account_name + '|' + account_number + '|' + api_key + '|' + ifsc_code;
            
            /* Object.keys(body).forEach(val => {
                let value = body[val];
                if (value.length > 0) {
                    hash_string += '|' + value;
                }
            }); */
            //SALT | account_name | account_number | amount | api_key | bank_branch | bank_name | ifsc_code | merchant_reference_number | transfer_type

            if (hash_string.length > 0) {
                secure_hash = Crypto.createHash('sha512').update(hash_string).digest('hex').toUpperCase();
            }
            body.hash = secure_hash;
            return res.json({ status: 1, message: 'inside then', data: { hash_string: hash_string, body: body} });
            // body.api_key = "1c62f141-4be4-4671-9552-9b6f8e58ddfc";
            
           await Axios.post('https://api.innopaytech.com/v3/fundtransfer/validateaccount', body).
                then((res) => res.data).
                then(res => {
                    console.log(res);
                    return res.json({ status: 1, message: 'inside then', data: res });
                }).catch(error => {
                    return res.json({ status: 0, message: 'inside then error :: ' + error.message, data: error });
                    console.log(error.message);
                })
            return res.json({ status: 1, message: '' });

        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error });
        }
    })();
}
exports.fundTransfer = (req, res) => {
    (async () => {
        try {
            let amount = 2;
            let merchant_reference_number = generateMerRefCode();//'Mr. ABC XYZ PQR';
            //return res.json({ status: 0, message: 'merchant_reference_number', data: merchant_reference_number });
            amount = parseFloat(amount).toFixed(2);
            let transfer_type = 'IMPS';/* IMPS OR NEFT(over 2 lakh) */
            user_id = req.body.user_id;
            const userBank = await UserBanks.findOne({ user_id: user_id });
            if (userBank){
                if (userBank.is_verified == 1){
                    let account_name = userBank.user_name;//'Mr. ABC XYZ PQR';
                    let account_number = userBank.acc_no;//'01234567980';
                    let ifsc_code = userBank.ifsc_code;//'SBIN0060471';
                    let bank_name = userBank.bank_name;//'State Bank Of India';
                    let bank_branch = userBank.branch;//'Rani Tower Branch';
                    let upi_id = '';/* 123456@ybl */

                    let api_key = getInnoKey().API_KEY;
                    let salt = getInnoKey().SALT;

                    let body = { api_key: api_key, merchant_reference_number: merchant_reference_number, amount: amount, account_name: account_name, account_number: account_number, ifsc_code: ifsc_code, bank_name: bank_name, bank_branch: bank_branch, transfer_type: transfer_type };
                    // , upi_id: upi_id
                    let secure_hash = null;
                    let hash_string = salt + '|' + account_name + '|' + account_number + '|' + amount + '|' + api_key + '|' + bank_branch + '|' + bank_name + '|' + ifsc_code + '|' + merchant_reference_number + '|' + transfer_type;
                    //return res.json({ status: 1, message: 'Get Bank Successfully', data: body });
                    
                    if (hash_string.length > 0) {
                        secure_hash = Crypto.createHash('sha512').update(hash_string).digest('hex').toUpperCase();
                    }
                    body.hash = secure_hash;
                    await Axios.post('https://api.innopaytech.com/v3/fundtransfer', body).
                        then((resu) => resu.data).
                        then(resu => {
                            console.log(resu);
                            if (typeof resu.error !== 'undefined' && resu.error.code > 0) {
                                return res.json({ status: 0, message: resu.error.message, data: resu });
                            } else if (typeof resu.data !== 'undefined') {
                                if (resu.data.status == "SUCCESS"){
                                    let merRefNo = resu.data.merchant_reference_number;
                                    let transaction_id = resu.data.transaction_id;
                                    let params = { merRefNo: merRefNo, transaction_id: transaction_id };
                                    return res.json({ status: 1, message: 'Fund Transfer Successfully', data: { result: resu, params: params} });
                                } else if (resu.data.status == "PROCESSING"){
                                    /* merrefeno :: DYU47ZHRDJZVB4T, trxid :: IMPS728720211111174933460613 */
                                    let merRefNo = resu.data.merchant_reference_number;
                                    let transaction_id = resu.data.transaction_id;
                                    let params = { merRefNo: merRefNo, transaction_id: transaction_id };
                                    return res.json({ status: 1, message: 'Fund Transfer Processing', data: { result: resu, params: params } });
                                }
                            } else {
                                return res.json({ status: 0, message: "Something Went Wrong, Try Again", data: {} });
                            }
                        }).catch(error => {
                            return res.json({ status: 0, message: error.message, data: {} });
                        })
                } else {
                    return res.json({ status: 0, message: 'User Bank Is Not Verified, Not Allowed To Transfer', data: {} });
                }
            } else {
                return res.json({ status: 0, message: 'User Bank Not Found, Not Allowed To Transfer', data: {} });
            }
            return res.json({ status: 1, message: 'Fund Transfer Successfully ',data:{} });

        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error,data:{} });
        }
    })();
}

exports.checkTransferStatus = (req, res) => {
    (async () => {
        try {
            let merchant_reference_number = req.body.merchant_reference_number;
            
            let api_key = getInnoKey().API_KEY;
            let salt = getInnoKey().SALT;

            let body = { api_key: api_key, merchant_reference_number: merchant_reference_number };
            let secure_hash = null;
            let hash_string = salt + '|' + api_key + '|' + merchant_reference_number;

            if (hash_string.length > 0) {
                secure_hash = Crypto.createHash('sha512').update(hash_string).digest('hex').toUpperCase();
            }
            body.hash = secure_hash;
            let resp = await Axios.post('https://api.innopaytech.com/v3/fundtransferstatus', body).
                then((resu) => resu.data).
                then(resu => {
                    //return resu;
                    console.log(resu);
                    if (typeof resu.error !== 'undefined' && resu.error.code > 0) {
                        return { status: 0, message: resu.error.message ,data:resu.error};
                    } else if (typeof resu.data !== 'undefined') {
                        //return resu.data;
                        let merRefNo = resu.data.merchant_reference_number;
                        let transaction_id = resu.data.transaction_id;
                        let params = { merRefNo: merRefNo, transaction_id: transaction_id };
                        if (resu.data.status == "SUCCESS") {
                            return { status: 1, message: 'Fund Transfer Successfully', data: { result: resu, params: params } };
                        } else if (resu.data.status == "PROCESSING") {
                            /* merrefeno :: DYU47ZHRDJZVB4T, trxid :: IMPS728720211111174933460613 */
                            return { status: 1, message: 'Fund Transfer Processing', data: { result: resu, params: params } };
                            //return res.json({ status: 2, message: 'Fund Transfer Processing', data: { result: resu, params: params } });
                        }
                    } else {
                        return { status: 0,message:'Something Went Wrong', data: resu };
                    }
                }).catch(error => {
                    return { status: 0, message: error.message, data: {} };
                })
            console.log(resp);
            return res.json(resp);

        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error, data: {} });
        }
    })();
}
exports.getCurrentBalance = (req, res) => {
    (async () => {
        try {
            //user_id = '61fa1fb45c984c5a5f08593e';
            let user_id = mongoose.Types.ObjectId('61fa1fb45c984c5a5f08593e');

            let row = await UserBanks.find({'user_id':user_id});
            let resp = await verifyBankAccount(user_id);
            return res.json(resp);

            //let resp = await getBalance();
            /*let id = mongoose.Types.ObjectId('61fa22982855f92d26f920c8');
            let data = { final_amount:9, user_id:mongoose.Types.ObjectId('61a22894fbd77f9a920bbd3f') };
            let resp = await doTransfer(data.final_amount, data.user_id._id, id);
            return res.json(resp);*/
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error.message, data: error });
        }
    })();
}
function generateMerRefCode(length = 15) {
    var text = "";
    possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (var i = 0; i < length; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text.toUpperCase();
}

/* 23-11-2021 */
exports.uploadNewApk = (req, res) => {
    (async () => {
        try {
            const storage           = multer.diskStorage({
                destination: function(req, file, cb) {
                    cb(null, 'uploads/apk/');
                },

                // By default, multer removes file extensions so let's add them back
                filename: function(req, file, cb) {
                    cb(null, 'instant567.apk');
                }
            });
            const upload            = multer({ storage: storage,
                fileFilter: function (req, file, cb) {
                    // Accept images only
                    if (!file.originalname.match(/\.(apk)$/)) {
                        req.fileValidationError = 'Only apk file are allowed!';
                        return cb(new Error('Only apk file are allowed!'), false);
                    }
                    cb(null, true);
                }
            }).single('apk_file');
            upload(req, res, async function(err) {
                if (!await isValid(req.body.version)) {
                    return res.json({ status: 0, message: 'version is required', data: {} });
                }
                if (req.fileValidationError) {
                    return res.json({ status: 0, message: 'Only apk file is allowed!', data: {} });
                }
                if (!req.file) {
                    return res.json({ status: 0, message: 'apk_file is required', data: {} });
                }

                let version         = req.body.version;
                // let url             = process.env.IMG_BASE_URL + "apk/" +  req.file.filename;
                let url             = "apk/" +  req.file.filename;
                let update          = { version: version, apk_file :url };

                let setting_count   = await Settings.find().countDocuments();
                if (setting_count > 0) {
                let data            = await Settings.updateMany(update);
                if (data.modifiedCount > 0) {
                    return res.json({ status: 1, message: "Apk Uploaded Successfully" });
                }
                } else {
                update.widthraw_request = 1;
                return await new Settings(update).save(function (err, transaction) {
                    if (err) return res.json({ status: 0, message: err.message });
                    return res.json({ status: 1, message: "Apk Uploaded Successfully" });
                });
                }
                return res.json({ status: 0, message: "No Apk Found", data: {} });
            });
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error.message || "Something Went Wrong", data: {} });
        }
    })();
}

exports.checkAddedPaymentStatus = (req, res) => {
    (async () => {
        try {
            /* const { checkTransStatus } = require('../../services/cron');
            await checkTransStatus(); */
            const { with_id } = req.body;
            let resp = await checkTransferStatus(with_id);
            return res.json({ status: 0, message: "Test", data: resp });
            /* if (!await isValid(req.body.transaction_id)) {
                return res.json({ status: 0, message: 'transaction_id is required', data: {} });
            }
            let transaction_id = req.body.transaction_id;
            let resp = await checkPaymentStatus(transaction_id);
            if (resp.status == 1) {
                return res.json(resp);
            } else {
                return res.json(resp);
            } */
        } catch (error) {
            console.log(1054, error);
            return res.json({ status: 0, message: error, data: {} });
        }
    })();
}

/* Wallet Money Start 29-11-2021 */
exports.getWalletMoneyList = (req, res) => {
    (async () => {
        try {
            var { page, size, searchFromDate, searchToDate, searchMobileNo, status, user_id } = req.body;
            var user_id             = req.body.user_id ? req.body.user_id:null;
            var search_date         = {};
            var condition = { deleted: false, tnx_type: 5, entry_type: 1, wallet_type: 2};
            const condDate = { ...condition };
            if(typeof status !== 'undefined' && status.length > 0){
                condition.pay_status    = { $in: status };
            }
            if(typeof searchFromDate !== 'undefined' && searchFromDate != ''){
                search_date.$gte    = convertToUTCNew(searchFromDate + ' 00:00:00');
            }
            if(typeof searchToDate !== 'undefined' && searchToDate != ''){
                search_date.$lte    = convertToUTCNew(searchToDate + ' 23:59:59');
            }
            if(Object.keys(search_date).length > 0){
                condition.createdAt = search_date;
                condDate.createdAt = search_date;
            }
            page = page - 1;
            const { limit, offset } = getPagination(page, size);
            
            var aggregate           = Transactions.aggregate([
                { $match: condition },
                { $lookup: {
                    from: 'users',
                    let:{'user_id':'$user_id'},
                    pipeline:[
                        {
                            "$match": {
                            "$expr": { "$eq": [ "$_id", "$$user_id" ] },
                            },
                        },
                        { $project : { _id:1,mobile_no:1,country_code:1 } }
                    ],
                    as: 'user_id'
                }},
                {
                    $match: { 'user_id.mobile_no': { $regex: new RegExp(searchMobileNo), $options: "i" } }
                },
                {
                    $project:{
                        _id:1,
                        user_id:{ "$arrayElemAt": [ "$user_id", 0 ] },
                        refe_id:1,
                        internal_tnx:1,
                        amount:1,
                        pay_status:1,
                        check_inno_status:1,
                        tnx:1,
                        order_id:1,
                        created_by:1,
                        createdAt:1,
                    }
                },
                {
                    $sort: { internal_tnx: -1 }
                }
            ]);
            await Transactions.aggregatePaginate(aggregate, {
                limit,
                offset,
            }).then(async(resopnse) => {
                if(page > 0){
                    let sendd               = getRespPagi(resopnse, 'Get Wallet Money List Successfully');
                    return res.json(sendd);
                }
                const total_success       = await Transactions.aggregate([
                    { $match: condDate },
                    { $lookup: {
                        from: 'users',
                        let:{'user_id':'$user_id'},
                        pipeline:[
                            {
                                "$match": {
                                "$expr": { "$eq": [ "$_id", "$$user_id" ] },
                                },
                            },
                            { $project : { _id:1,mobile_no:1,country_code:1 } }
                        ],
                        as: 'user_id'
                    }},
                    {
                        $match: { 'user_id.mobile_no': { $regex: new RegExp(searchMobileNo), $options: "i" } }
                    },
                    {
                        "$group": {
                          "_id": "$pay_status",
                          "total": {
                            "$sum": 1
                          },
                          "totalAmount": {
                            "$sum": "$amount"
                          }
                        }
                    },
                ]);
                const totalDeposit = total_success.map(item => item.totalAmount).reduce((a,b)=> a+b ,0 );
                const totSuccess = total_success.find(x => x._id == 1)?.total || 0;
                const totPending = total_success.find(x => x._id == 0)?.total || 0;
                const totFail = total_success.find(x => x._id == 2)?.total || 0;

                resopnse.total_deposit  = totalDeposit;
                resopnse.total_success  = totSuccess;
                resopnse.total_pending  = totPending;
                resopnse.total_fail  = totFail;
                
                let sendd               = getRespPagi(resopnse, 'Get Wallet Money List Successfully');
                return res.json(sendd);
            }).catch(function (err) {
                console.log(err);
            });
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error, data: {} });
        }
    })();
}
/* Transaction End */
exports.updateGameSetting = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.game_duration)) {
                return res.json({ status: 0, message: 'Game duration is required' });
            }

            let game_duration = req.body.game_duration;
            let is_market = (req.body.is_market) ? req.body.is_market : 1;
            let is_colors = (req.body.is_colors) ? req.body.is_colors : 0;
            let update = { is_market: is_market, is_colors: is_colors, game_duration: game_duration };
            //let setting_count = await Settings.find().countDocuments();
            let setting_count = await Settings.findOne({});
            if (setting_count) {/* setting_count > 0 */
                let data = await Settings.updateMany(update);
                if (data.modifiedCount > 0) {
                    return res.json({ status: 1, message: "Game Setting Updated Successfully" });
                }
            } else {
                return await new Settings(update).save(function (err, transaction) {
                    if (err) return res.json({ status: 0, message: err.message });
                    return res.json({ status: 1, message: "Game Setting Updated Successfully" });
                });
            }
            return res.json({ status: 0, message: "No Game Setting Found" });
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error || "Something Went Wrong" });
        }
    })();
}
exports.updateColorProfitSetting = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.profit)) {
                return res.json({ status: 0, message: 'Profit is required', data: {} });
            }

            let color_pro_ratio = req.body.profit;
            let update = { color_pro_ratio: color_pro_ratio };
            let setting_count = await Settings.find().countDocuments();
            if (setting_count > 0) {
                let data = await Settings.updateMany(update);
                if (data.modifiedCount > 0) {
                    return res.json({ status: 1, message: "Color Game Profit Setting Updated Successfully", data: update });
                }
            } else {
                return await new Settings(update).save(function (err, transaction) {
                    if (err) return res.json({ status: 0, message: err.message });
                    return res.json({ status: 1, message: "Color Game Profit Setting Updated Successfully", data: update });
                });
            }
            return res.json({ status: 0, message: "No Color Game Profit Setting Found", data: {} });
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error.message || "Something Went Wrong", data: error });
        }
    })();
}
/* 07-01-2022 */
exports.approveRejectWalletMoney = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.status)) {
                return res.json({ status: 0, message: 'status is required', data: {} });
            }
            let id = req.body.id;
            let status = req.body.status;
            let row = await Transactions.findOne({ _id: id }).populate('user_id');
            if (row) {
                if (row.status == 1) {
                    return res.json({ status: 0, message: "Transaction Already Approved", data: {} });
                } else if (row.status == 3) {
                    return res.json({ status: 0, message: "Transaction Already Rejected", data: {} });
                } else {
                    var txt = (status == 1) ? 'Approved' : 'Rejected';
                    let amount = row.amount;
                    if (status == 1){
                        const userDet = await Users.findOne({ _id: row.user_id });
                        const totTrans = await Transactions.find({ user_id: row.user_id, tnx_type: { $in: [4,5]}, entry_type: 1, wallet_type: 2, _id: { $ne: row._id } });
                        if (row.pay_status != 1) {
                            let post_balance = parseInt(row.user_id.wallet) + parseInt(amount);
                            let isUpated = await Users.updateOne({ _id: row.user_id._id }, { $inc: { wallet: parseInt(amount) } } );
                            if (isUpated.modifiedCount > 0){
                                await Transactions.updateOne({ _id: row._id }, { post_balance: post_balance, check_inno_status: 1, pay_status: 1 });
                                await addBonusReferalAmount(1, amount, userDet, row._id, totTrans);
                                return res.json({ status: 1, message: 'Transaction ' + txt + ' Successfully', data: {} });
                            } else {
                                return res.json({ status: 0, message: 'Not Updated', data: {} });
                            }
                        } else {
                            await Transactions.updateOne({ _id: row._id }, { check_inno_status: 1 });
                            return res.json({ status: 1, message: 'Transaction ' + txt + ' Successfully', data: {} });
                        }
                    } else {
                        await Transactions.updateOne({ _id: row._id }, { check_inno_status: 2, pay_status: 2 });
                        return res.json({ status: 1, message: 'Transaction ' + txt + ' Successfully', data: {} });
                    }
                }
            } else {
                return res.json({ status: 0, message: "Transaction Not Found", data: {} });
            }
        } catch (error) {
            return res.json({ status: 0, message: error.message || "Something Went Wrong", data: error });
        }
    })();
}
/*  */
exports.approveRejectWalletMoneySelected = async (req, res) => {
    try {
        if (!await isValid(req.body.status)) {
            return res.json({ status: 0, message: 'status is required', data: {} });
        }
        const { ids, status } = req.body;
        if(!ids || ids.length == 0){
            return res.json({ status: 0, message: 'Provide record to update status', data: {} });
        }
        const txt = (status == 1) ? 'Approved' : 'Rejected';
        const rows = await Transactions.find({ _id: { $in: ids } }).populate('user_id');
        if(rows.length > 0){    
            for (const row of rows) {
                const amount = row.amount;
                if(row.pay_status == 0){
                    if (status == 1){
                        if (row.pay_status != 1) {
                            const post_balance = parseInt(row.user_id.wallet) + parseInt(amount);
                            let isUpated = await Users.updateOne({ _id: row.user_id._id }, { $inc: { wallet: parseInt(amount) } } );
                            if (isUpated.modifiedCount > 0){
                                await Transactions.updateOne({ _id: row._id }, { post_balance: post_balance, check_inno_status: 1, pay_status: 1 });
                            }
                        } else {
                            await Transactions.updateOne({ _id: row._id }, { check_inno_status: 1, pay_status: 1 });
                        }
                    } else {
                        await Transactions.updateOne({ _id: row._id }, { check_inno_status: 2, pay_status: 2 });
                    }
                }
            }
            return res.json({ status: 1, message: 'Transactions ' + txt + ' Successfully', data: {} });
        } else {
            return res.json({ status: 0, message: "Transactions Not Found", data: {} });
        }
    } catch (error) {
        return res.json({ status: 0, message: error.message || "Something Went Wrong", data: error });
    }
}
exports.bankDeductRecord = (req, res) => {
    (async () => {
        try {
            const condition = { tnx_type:13,entry_type:2,wallet_type:1 };
            const data = await Transactions.aggregate([
                {
                  $match: condition
                },
                {
					$lookup: {
						from: "users",
						let: { 'user_id': '$user_id' },
						pipeline: [
							{
								"$match": {
									"$expr": { "$eq": ["$_id", "$$user_id"] },
								},
							},
							{ $project: { _id: 1, firstname: 1, mobile_no: 1, wallet:1, wallet_wining: 1, country_code: 1 } }
						],
						as: "user_det"
					}
				},
                {
					$lookup: {
						from: "transactions",
						let: { 'user_id': '$user_id', 'checkdate': '$createdAt' },
						pipeline: [
							{
								"$match": {
									"$expr": { 
                                        $and:[
                                            { "$eq": ["$user_id", "$$user_id"]},
                                            // { "$eq": ["$wallet_type", 2]},
                                            { "$in": ["$tnx_type", [1,4,5,7]] },
                                            {"$gte": ["$createdAt", "$$checkdate"]},
                                        ]
                                    },
								},
							},
							{ $group: { _id: "$tnx_type", totalAmount: { $sum: "$amount" } } },
							// { $project: { _id: 1, totalAmount: { $sum: "$amount" }, } }
						],
						as: "transDet"
					}
				},
                { $project: { _id: 1, post_balance: 1, createdAt: 1, user_det:1, transDet: 1 } },
        
              ])

              return res.json({ status: 1, message: 'Transaction Successfully', data: data });
        } catch (error) {
            return res.json({ status: 0, message: error.message || "Something Went Wrong", data: error });
        }
    })();
}
