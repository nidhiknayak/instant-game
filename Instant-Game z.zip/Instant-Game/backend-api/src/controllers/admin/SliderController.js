var mongoose = require('mongoose');
const { locales } = require("moment");
const Slider = require("../../models/Slider");
const { isValid } = require('../../services/validation');
const { getPagination } = require('../../services/common');
const TokenGenerator = require('uuid-token-generator');
var tokgenGenerator = new TokenGenerator(256, TokenGenerator.BASE62);
var fs = require('fs');

exports.list = async (req, res) => {
    (async () => {
        try{
            const { page, size, search } = req.body;
            let type = req.body.type ? req.body.type : 'mobile';
            var condition = search ? { title: { $regex: new RegExp(search),type, $options: "i" },deleted:false } : {type,deleted:false};
            const { limit, offset } = getPagination(page, size);
            return await Slider.paginate(condition,{ offset, limit }).then((slider) => {
                // console.log("slider", slider);
                const resp = JSON.parse(JSON.stringify(slider));
                resp.docs = resp.docs.map((itm)=>{
                    return {
                        ...itm,
                        image_url:`${process.env.IMG_BASE_URL}${itm.image_url}`
                    };
                });
                // console.log("sliders", sliders);
                return res.json({status:1, message:'Slider data find successfully.', data:resp});
            });
        } catch (error) {
            console.log("error", error);
            return res.json({ status: 0, message: error });
        }
    })();
};

exports.save = async (req, res) => {
    (async () => {
        try{
            if (!await isValid(req.body.title)) {
				return res.json({ status: 0, message: 'title is required' });
			}
            // if (!await isValid(req.body.description)) {
			// 	return res.json({ status: 0, message: 'description is required' });
			// }
            if(!await isValid(req.body.status)){
                return res.json({ status: 0, message: 'status is required' });
            }
            // if(!await isValid(req.body.link)){
            //     return res.json({ status: 0, message: 'link is required' });
            // }
            var filename = "";
            var url = "";
            if(await isValid(req.body.image) && isValid(req.body.extension)){
                filename = tokgenGenerator.generate()+"."+req.body.extension;
                // url = process.env.IMG_BASE_URL+"slider/"+filename;
                url = "slider/"+filename;
                const dir = "uploads/slider/"
                if (!fs.existsSync(dir)) {
                    fs.mkdirSync(dir, 0744);
                }
                fs.writeFile(dir+filename, req.body.image, 'base64', function(err) {
                    if(err){
                        return res.json({ status: 0, message: 'image not proper' });
                    }
                });
            }
            return new Slider({
                title           : req.body.title,
                description     : (req.body.description) ? req.body.description : null,
                image_url       : url,
                image           : filename,
                link            : (req.body.link) ? req.body.link : null,
                status          : req.body.status,
                type          : (req.body.type) ? req.body.type : 'mobile',
                created_by : req.userDet._id
            }).save(function (err, slider) {
                if (err) return res.json({status:0, message:err.message});
                return res.json({status:1, message:'Slider created successfully', data : slider });
            });
        } catch (error) {
            return res.json({ status: 0, message: error });
        }
    })();
};

exports.status_change = async (req, res) => {
    (async () => {
        try{
            if (!await isValid(req.body.id)) {
				return res.json({ status: 0, message: 'ID is required' });
			}
            if(!await isValid(req.body.status)){
                return res.json({ status: 0, message: 'status is required' });
            }
            let slider_data = await Slider.findOne({_id:req.body.id});
            if(slider_data){
                let update_slider = await Slider.updateOne({ _id: req.body.id }, {
                    status          : req.body.status,
                    updated_by      : req.userDet._id
                });
                if(update_slider.modifiedCount > 0){
                    return res.json({status:1, message:'Slider status change successfully.'});
                }
                return res.json({status:0, message:'Please try again.' });
            }
            return res.json({status:0, message:'No slider data found.' });
        } catch (error) {
            return res.json({ status: 0, message: error });
        }
    })();
};

exports.edit = async (req, res) => {
    (async () => {
        try{
            if (!await isValid(req.params.id)) {
				return res.json({ status: 0, message: 'ID is required' });
			}
            let slider_data = await Slider.findOne({_id:req.params.id});
            if(slider_data){
                slider_data.image_url = `${process.env.IMG_BASE_URL}${slider_data.image_url}`;
                return res.json({status:1, message:'Slider data find successfully.',data:slider_data});
            }
            return res.json({status:0, message:'No slider data found.' });
        } catch (error) {
            return res.json({ status: 0, message: error });
        }
    })();
};

exports.update = async (req, res) => {
    (async () => {
        try{
            if (!await isValid(req.body.id)) {
				return res.json({ status: 0, message: 'ID is required' });
			}
            if (!await isValid(req.body.title)) {
				return res.json({ status: 0, message: 'title is required' });
			}
            // if (!await isValid(req.body.description)) {
			// 	return res.json({ status: 0, message: 'description is required' });
			// }
            if(!await isValid(req.body.status)){
                return res.json({ status: 0, message: 'status is required' });
            }
            // if(!await isValid(req.body.link)){
            //     return res.json({ status: 0, message: 'link is required' });
            // }
            let slider_data = await Slider.findOne({_id:req.body.id});
            if(slider_data){
                let filename = slider_data.image;
                let url = slider_data.image_url;
                if(req.body.image != '' && req.body.extension != ''){
                    filename = tokgenGenerator.generate()+"."+req.body.extension;
                    // url = process.env.IMG_BASE_URL+"slider/"+filename;
                    url = "slider/"+filename;
                    const dir = "uploads/slider/"
                    if (!fs.existsSync(dir)) {
                        fs.mkdirSync(dir, 0744);
                    }
                    fs.writeFile(dir+filename, req.body.image, 'base64', function(err) {
                        if(err){
                            return res.json({ status: 0, message: 'image not proper' });
                        }
                    });
                    if(slider_data.image != '' && fs.existsSync(dir+slider_data.image)){
                        fs.unlinkSync(dir+slider_data.image);
                    }
                }
                let update_slider = await Slider.updateOne({ _id: req.body.id }, {
                    title           : req.body.title,
                    description     : (req.body.description) ? req.body.description : '',
                    image_url       : url,
                    image           : filename,
                    link            : (req.body.link) ? req.body.link : '',
                    status          : req.body.status,
                    type          : req.body.type,
                    updated_by      : req.userDet._id
                });
                if(update_slider.modifiedCount > 0){
                    return res.json({status:1, message:'Slider updated successfully.'});
                }
                return res.json({status:0, message:'Please try again.' });
            }
            return res.json({status:0, message:'No slider data found.' });
        } catch (error) {
            return res.json({ status: 0, message: error });
        }
    })();
};

exports.delete = (req, res) => {
    (async () => {
        try{
            if (!await isValid(req.params.id)) {
				return res.json({ status: 0, message: 'ID is required' });
			}
            let slider_data = await Slider.findOne({_id:req.params.id});
            if(slider_data){
                let delete_slider = await Slider.delete({_id:req.params.id},req.userDet._id);
                if(delete_slider.modifiedCount > 0){
                    return res.json({status:1, message:'Slider data deleted successfully.'});
                }
                return res.json({status:0, message:'Slider data not deleted successfully.'});
            }
            return res.json({status:0, message:'No slider data found.' });
        } catch (error) {
            return res.json({ status: 0, message: error });
        }
    })();
};