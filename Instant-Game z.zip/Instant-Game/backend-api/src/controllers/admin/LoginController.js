const Admins = require('../../models/Admins');
const AdminDeviceTokens = require('../../models/AdminDeviceTokens');
const crypto = require("crypto");
const TokenGenerator = require('uuid-token-generator');
const { isValid } = require('../../services/validation');
let tokenGenerator = new TokenGenerator(256, TokenGenerator.BASE62);
var secret = "Test@123456";
exports.login = (req, res) => {
	(async () => {
		try {
			const email = req.body.email;
			const password = req.body.password;
			//const admQuery = Admins.where({ email: email });
			var user = await Admins.findOne({ email: email });
			// , async function (err, user) {
			// 	if (err) return res.json({ status: 0, message: err });
			// })
			
			//return res.json({ status: 0, message: "", data: hash });
			if (user) {
				const hash = crypto.createHmac('sha256', secret).update(password).digest('hex');
				if (hash != user.password){
					return res.json({ status: 0, message: "Password Not Matched", data: {} });
				}
				let auth_token = tokenGenerator.generate();
				await AdminDeviceTokens.deleteMany({ admin_id: user.id });
				return new AdminDeviceTokens({
					admin_id: user.id,
					auth_token: auth_token
				}).save(async function (err, token) {
					if (err) return res.json({ status: 0, message: err.message || "Cannot Login" });
					user.auth_token = auth_token;
					let resopnse = {
						_id: user._id,
						firstname: user.firstname,
						lastname: user.lastname,
						email: user.email,
						createdAt: user.createdAt,
						updatedAt: user.updatedAt,
						auth_token: auth_token,
					};
					return res.json({ status: 1, message: 'Admin Login Successfully', data: resopnse });
				})
			} else {
				return res.json({ status: 0, message:"Record Not Found", data:{} });
				/* var pass = password;
				var secret = "Test@123456";
				const hash = crypto.createHmac('sha256', secret).update(pass).digest('hex');
				//const hash = 123;
				return new Admins({
					firstname: "Admin",
					lastname: "User",
					email: email,
					password: hash
				}).save(async function (err, newuser) {
					if (err) return res.json({ status: 0, message: err.message || "Cannot Register" });
					let auth_token = tokenGenerator.generate();
					return new AdminDeviceTokens({
						admin_id: newuser._id,
						auth_token: auth_token
					}).save(async function (err, token) {
						if (err) return res.json({ status: 0, message: err.message || "Cannot Login" });
						let resopnse = {
							_id: newuser._id,
							firstname: newuser.firstname,
							lastname: newuser.lastname,
							email: newuser.email,
							createdAt: newuser.createdAt,
							updatedAt: newuser.updatedAt,
							auth_token: auth_token,
						};
						return res.json({ status: 1, message: 'Admin Register Successfully', data: resopnse });
					})
				}); */
			}
		} catch (error) {
			console.log(error);
			return res.json({ status: 0, message: error });
		}
	})();
}

exports.logout = (req, res) => {
	(async () => {
		try {
			var auth_token = req.authToken;
			var user= await AdminDeviceTokens.findOne({ auth_token: auth_token});
			if (user) {
				await AdminDeviceTokens.deleteMany({ auth_token: auth_token });
				res.json({ status: 1, message: "Logout Successfully", data: {} });
			} else {
				res.json({ status: 0, message: "Token Not Found", data: {} });
			}
		} catch (error) {
			return res.json({ status: 0, message: error });
		}
	})();
}
exports.changePassword = (req, res) => {
	(async () => {
		try {
			if (!await isValid(req.body.currentPassword)) {
				return res.json({ status: 0, message: 'Current password is required.' });
			}
			if (!await isValid(req.body.newPassword)) {
				return res.json({ status: 0, message: 'New password is required.' });
			}
			if (!await isValid(req.body.confirmPassword)) {
				return res.json({ status: 0, message: 'Confirm password is required.' });
			}
			var auth_token = req.authToken;
			var user = await AdminDeviceTokens.findOne({ auth_token: auth_token });
			if (user) {
				let adminData = await Admins.findOne({ _id: req.userDet._id });
				if (adminData) {
					const hash = crypto.createHmac('sha256', secret).update(req.body.newPassword).digest('hex');
					if (adminData.password == hash) {
						let updateAdmin = await Admins.updateOne({ _id: adminData._id }, {
							password: hash
						});
						if (updateAdmin.modifiedCount > 0) {
							return res.json({ status: 1, message: "Password changed successfully.", data:{} });
						}
						return res.json({ status: 0, message: 'Please try again.', data: {} });
					} else {
						res.json({ status: 0, message: "Please enter correct current password.", data: {} });
					}
				} else {
					res.json({ status: 0, message: "Oops! Something went wrong..", data: {} });
				}
			} else {
				res.json({ status: 0, message: "Oops! Something went wrong..", data: {} });
			}
		} catch (error) {
			return res.json({ status: 0, message: error.message, data: error });
		}
	})();
}