var mongoose            = require('mongoose');
const Notification      = require("../../models/Notification");
const UserNotifications      = require("../../models/UserNotifications");
const { UserDeviceTokens }  = require("../../models/UserDeviceTokens");
const { sendAndroid, getPagination }   = require('../../services/common');
const { isValid } = require('../../services/validation');
const TokenGenerator = require('uuid-token-generator');
var tokgenGenerator = new TokenGenerator(256, TokenGenerator.BASE62);
var fs = require('fs');
exports.list = async (req, res) => {
    (async () => {
        try {
            let { page, size, search } = req.body;
            var condition = search ? { title: { $regex: new RegExp(search), $options: "i" }, deleted: false } : { deleted: false };
            page = page - 1;
            const { limit, offset } = getPagination(page, size);
            return await Notification.paginate(condition, { offset, limit }).then((notifi) => {
                return res.json({ status: 1, message: 'Notification data find successfully.', data: notifi });
            });
        } catch (error) {
            return res.json({ status: 0, message: error, data:{} });
        }
    })();
};

exports.save = async (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.title)) {
                return res.json({ status: 0, message: 'title is required' });
            }
            if (!await isValid(req.body.message)) {
            	return res.json({ status: 0, message: 'message is required' });
            }
            
            // if(!await isValid(req.body.link)){
            //     return res.json({ status: 0, message: 'link is required' });
            // }
            var filename = "";
            var url = "";
            if (await isValid(req.body.image) && isValid(req.body.extension)) {
                filename = tokgenGenerator.generate() + "." + req.body.extension;
                url = process.env.IMG_BASE_URL + "notification/" + filename;
                const dir = "uploads/notification/"
                if (!fs.existsSync(dir)) {
                    fs.mkdirSync(dir, 0744);
                }
                fs.writeFile(dir + filename, req.body.image, 'base64', function (err) {
                    if (err) {
                        return res.json({ status: 0, message: 'image not proper',data:{} });
                    }
                });
            }

            return new Notification({
                title: req.body.title,
                message: (req.body.message) ? req.body.message : null,
                image_url: url,
                image: filename,
                created_by: req.userDet._id
            }).save(async function (err, notifi) {
                if (err) return res.json({ status: 0, message: err.message, data:{} });
                //let token = await sendNotiToUser(notifi._id);
                let notiData = await Notification.findOne({ _id: notifi._id });
                var sdata = {};
                sdata['title'] = notiData.title;
                sdata['body'] = notiData.message;
                sdata['image'] = (notiData.image_url) ? notiData.image_url:'';

                await sendAndroid(['619250231e9119998552d6b2'], sdata);
                return res.json({ status: 1, message: 'Notification sent successfully', data: notifi });
            });
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error, data:{} });
        }
    })();
};
function sendNotiToUser(noti_id) {
    (async () => {
        let condition = { deleted: false, device_token:{$ne:null} };
        let token = await UserDeviceTokens.aggregate([
            { $match: condition },
            { "$group": { "_id": "$user_id", "doc": { "$last": "$device_token" } } },
            { $sort: { createdAt: -1 } },
        ]);
        console.log(token);
        if (token && token.length > 0){
            let tokens = await Promise.all(token.map(async (row) => {
                return row.doc;
            }));
            let user_ids = await Promise.all(token.map(async (row) => {
                return row._id;
            }));
            let notiData = await Notification.findOne({ _id: noti_id });
            if (notiData) {
                var data = {};
                data['title'] = notiData.title;
                data['body'] = notiData.message;
                data['image'] = (notiData.image_url) ? notiData.image_url:'';
                //let resp = await sendAndroid(tokens, data);
                await Notification.updateOne({ _id: noti_id }, {
                    user_ids: user_ids
                });
                return tokens;
            } else {
                return tokens;
            }
        }
    })();
}
exports.send = async (req, res) => {
    (async () => {
        try{

            //var registration_ids    = ['eN0IeEZzSuay1Id6-cSOMg:APA91bECmj9kvpJLUt7xHjx1Sij6pKgBa7aHJgMItw9nmeaI-xP3ffzCtqJPja2vvl4lhMqpJu7_JL1G7uODn237jaZxeU4p4KHcs3GZL_JHKi6XXeKBS1vChnYzGkVC79BELNRCGdVl','fTLNxpk2StusWr_mbK6V56:APA91bGnwylIqyqwnS97l_BB2Qp0IAEh0agn45547N1Og7WtX2qt2_Rsw8pU7D6In1EZIV9t5YDfqdoa9gpiYSgSbiJDZDlfPWfF6HtmGznTOVzzvYwF7HjYcA6rWi1IL2pxg0H5EVn7'];
            var registration_ids = ['e_mYzur-TV28o9HtshvkhM:APA91bHtDkmfoTiZvTDaFt2jg1MGRv3c-Xgt1SJg2m1n1iraM2OXkqoASydhC-RZywgdd82l3dvyEyQBqeT8a-sWHjlveYxop2aeGV42y5UhIiULQDiUBMAVjGyFnvNPlcPpyi9ijWEZ'];
            var data                = {};
            data['title']           = 'Welcome To Idealgamez';
            data['body']            = 'Withdrawal Is Allowed After 7th Day Of Registration';
            data['image']           = '1.jpg';
            
            
            
            let token = await sendNotiToUser('619250231e9119998552d6b2');
            return res.json({ status: 1, message: 'Notification get', data: token });
            //let resp = await sendAndroid(registration_ids,data);
            //return res.json({ status: 0, message: 'Notification', data: { resp:resp} });
            return await new Notification({
                user_id : req.userDet._id,
                content : req.body.content,
                status : req.body.status,
            }).save(async function (err, notice_board) {
                if (err) return res.json({status:0, message:err.message});

                let token = await UserDeviceTokens.aggregate([
                    { $match: condition },
                    { "$group": { "_id": "$user_id", "doc": { "$last": "$auth_token" } } },
                    { $sort: { createdAt: -1 } },
                ]);

                return res.json({status:1, message:'Notification send successfully.'});
            });
        } catch (error) {
            console.log(103, error);
            return res.json({ status: 0, message: error });
        }
    })();
};