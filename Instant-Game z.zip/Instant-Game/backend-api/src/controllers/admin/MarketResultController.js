var mongoose = require('mongoose');
const { Markets, MarketTimeTable } = require("../../models/Markets");
const GameRatios = require("../../models/GameRatios");
const MarketResults = require("../../models/MarketResults");
const MarketRefunds = require("../../models/MarketRefunds");
const MarketBids = require("../../models/MarketBids");
const Transactions = require("../../models/Transactions");
const Users = require('../../models/Users');
const { isValid } = require("../../services/validation");
const { declareResult } = require("../../services/DeclareResult");
const { getDateFormat, allowPublishRes, getMinusOneDayDate } = require("../../services/common");

exports.updateMarketResultPartial = (req, res) => {
  (async () => {
    try {
      if (!(await isValid(req.body.market_name))) {
        return res.json({
          status: 0,
          message: "Market name is required",
          data: {},
        });
      }

      if (!(await isValid(req.body.week_day_type))) {
        return res.json({
          status: 0,
          message: "Week Day Type is required",
          data: {},
        });
      }

      const name = req.body.market_name;
      const market = await Markets.findOne({ name });

      if (market) {
        let market_id = market?._id;
        let week_day_type = req.body.week_day_type;
        let result_date = typeof req.body.date !== "undefined" && req.body.date != null ? req.body.date : getDateFormat();

        var isTimeExist = await MarketTimeTable.findOne({ market_id: market_id, week_day_type: week_day_type });
        if (!isTimeExist) {
          return res.json({
            status: 0,
            message: "Timetable Record Not Found",
            data: {},
          });
        }

        result_date = getMinusOneDayDate(
          result_date,
          isTimeExist.bid_open_time,
          isTimeExist.bid_close_time
        );

        let op_1 = null;
        let op_2 = null;
        let op_3 = null;
        let digit_1 = null;

        if (typeof req.body.digit_1 != "undefined" && req.body.digit_1 != "") {
          op_1 = req.body.op_1;
          op_2 = req.body.op_2;
          op_3 = req.body.op_3;
          digit_1 = req.body.digit_1;
        }

        let digit_2 = null;
        let cp_1 = null;
        let cp_2 = null;
        let cp_3 = null;

        if (typeof req.body.digit_2 != "undefined" && req.body.digit_2 != "") {
          digit_2 = req.body.digit_2;
          cp_1 = req.body.cp_1;
          cp_2 = req.body.cp_2;
          cp_3 = req.body.cp_3;
        }

        const marketResultExist = await MarketResults.findOne({ market_id: market_id, result_date: result_date });
        let id = marketResultExist?._id ? marketResultExist?._id : null;

        let update = {};

        if (digit_1) {
          update.digit_1 = digit_1;
          update.op_1 = op_1;
          update.op_2 = op_2;
          update.op_3 = op_3;
        }

        if (digit_2) {
          update.digit_2 = digit_2;
          update.cp_1 = cp_1;
          update.cp_2 = cp_2;
          update.cp_3 = cp_3;
        }

        if (id != null) {
          let data = await MarketResults.updateOne({ _id: id }, update);

          if (data.modifiedCount > 0) {
            return res.json({
              status: 1,
              message: "Market Result Updated Successfully",
              data: {},
            });
          } else {
            return res.json({
              status: 0,
              message: "Cannot Update Market Result",
              data: {},
            });
          }
        } else {
          update.market_id = market_id;
          update.week_day_type = week_day_type;
          update.declared_date = new Date();
          update.result_date = result_date;

          let msg = "Close Result Added Successfully";

          if (digit_2 == null) {
            msg = "Open Result Added Successfully";
          }

          return new MarketResults(update).save(async function (err, data) {
            if (err) {
              return res.json({
                status: 0,
                message: err.message || "Cannot Add Market Result",
              });
            }

            update._id = data._id;

            return res.json({
              status: 1,
              message: msg,
              data: update
            });
          });
        }
      } else {
        return res.json({
          status: 0,
          message: "Market Not Found",
          data: {},
        });
      }
    } catch (error) {
      return res.json({
        status: 0,
        message: error.message || "Something Went Wrong",
        data: error,
      });
    }
  })();
};

exports.declareMarketResultPartial = (req, res) => {
  (async () => {
    try {
      if (!(await isValid(req.body.market_name))) {
        return res.json({
          status: 0,
          message: "Market name is required",
          data: {},
        });
      }

      if (!(await isValid(req.body.result_type))) {
        return res.json({
          status: 0,
          message: "Result Type is required",
          data: {},
        });
      }

      let result_type = req.body.result_type;
      let result_date = typeof req.body.date !== "undefined" && req.body.date != null ? req.body.date : getDateFormat();

      const name = req.body.market_name;
      const market = await Markets.findOne({ name });

      if (market) {
        let market_id = market._id;

        let resData = await MarketResults.findOne({
          market_id: market_id,
          result_date: result_date,
        });

        if (resData) {
          let marketData = await MarketTimeTable.findOne({
            market_id: market_id,
            week_day_type: resData.week_day_type,
          });

          if (!marketData) {
            return res.json({
              status: 0,
              message: "Timetable Record Not Found",
              data: {},
            });
          }

          result_date = getDateFormat(resData.result_date);

          let todayDate = getDateFormat();
          let resDate = result_date;
          let ratios = await GameRatios.find({});

          let resp = {};
          // let created_by = req.userDet._id;
          let created_by = null;

          if (result_type == 1) { /* Open */
            if (todayDate == resDate) {
              if (!(await allowPublishRes(marketData.bid_open_time, marketData.bid_close_time))) {
                return res.json({
                  status: 0,
                  message:
                    "Not Allowed To Publish Result Before Bid Start Time",
                  data: {},
                });
              }
            }

            if (resData.is_open_published == 0) {
              let marketDet = await Markets.findOne({ _id: market_id });
              let detDesc = "Winnings Credited";

              if (marketDet) {
                detDesc = "Won - " + marketDet.name;
              }

              resp = await doPublishRes(resData.id, market_id, ratios, resData, 1, created_by, detDesc, result_date);

              return res.json({
                status: 1,
                message: "Market Result Published Successfully",
                data: resp,
              });
            } else {
              return res.json({
                status: 0,
                message: "Open Result Already Published, Not Allow Publish",
                data: resp,
              });
            }
          } else { /* Close */
            let marketDet = await Markets.findOne({ _id: market_id });
            let detDesc = "Winnings Credited";

            if (marketDet) {
              detDesc = "Won - " + marketDet.name;
            }

            if (todayDate == resDate) {
              if (!(await allowPublishRes(marketData.bid_open_time, marketData.bid_close_time, true))) {
                return res.json({
                  status: 0,
                  message: "Not Allowed To Publish Result Before Bid End Time",
                  data: {},
                });
              }
            }

            if (resData.is_open_published == 0) {
              resp = await doPublishRes(resData.id, market_id, ratios, resData, 3, created_by, detDesc, result_date);

              return res.json({
                status: 1,
                message: "Market Result Published Successfully",
                data: resp,
              });
            } else {
              resp = await doPublishRes(resData.id, market_id, ratios, resData, 2, created_by, detDesc, result_date);

              return res.json({
                status: 1,
                message: "Market Result Published Successfully",
                data: resp,
              });
            }
          }
        } else {
          return res.json({
            status: 0,
            message: "Result Not Found, Not Allowed To Publish Result",
            data: {},
          });
        }
      } else {
        return res.json({ status: 0, message: "Market Not Found", data: {} });
      }
    } catch (error) {
      return res.json({
        status: 0,
        message: error || "Something Went Wrong",
        data: {},
      });
    }
  })();
};

function doPublishRes(id, market_id, ratios, data, pubType = 1, created_by, detDesc, report_date = "") { /* pubType => 1=Open,2=Close,3=Both */
  (async () => {
    try {
      //let whe = { market_id: market_id, is_win: 0, dayOfWeek: { $dayOfWeek: "$createdAt" } };
      let whe = {
        market_id: market_id,
        is_win: 0,
        report_date: new Date(report_date),
      };

      if (pubType == 1) {
        whe.game_type_id = { $in: [0, 3, 4, 5] };
      } else if (pubType == 2) {
        whe.game_type_id = { $in: [1, 6, 7, 8, 2, 9, 10, 11] }; /*2, 9, 10, 11*/
      }

      let allBids = await MarketBids.find(whe);
      let result_id = data._id;

      if (allBids.length > 0) {
        var usersList = await getUserByBid(whe);

        let myResp = await Promise.all(
          allBids.map(async (bidDet) => {
            let game_type_id = bidDet.game_type_id;

            if (await declareResult(bidDet, data, game_type_id)) {
              let newArrInd = ratios.findIndex(getIndexByVal);

              function getIndexByVal(itm) {
                return itm.game_type_id.indexOf(game_type_id) > -1;
              }

              if (newArrInd >= 0) {
                let calRat = ratios[newArrInd];
                let amount = (bidDet.amount * calRat.ratio_per_amount) / calRat.ratio_per;

                var i = await usersList.findIndex((_element) => _element._id.toString() === bidDet.user_id.toString());

                if (i > -1) {
                  let post_balance =
                    usersList[i].wallet_wining + parseFloat(amount);
                  usersList[i].wallet_wining =
                    usersList[i].wallet_wining + parseFloat(amount);

                  return await new Transactions({
                    user_id: bidDet.user_id,
                    refe_id: bidDet._id,
                    amount: amount,
                    final_amount: amount,
                    post_balance: post_balance,
                    tnx_type: 7, //Winnings Credited
                    wallet_type: 1, //winning wallet
                    details: detDesc,
                    entry_type: 1, //credit entry
                    created_by: created_by,
                    report_date: bidDet.report_date,
                  }).save(async function (err, transaction) {
                    if (!err) {
                      console.log(932, "trx saved");
                      let isBidUpdated2 = await MarketBids.updateOne(
                        { _id: bidDet._id },
                        { is_win: 1, win_amount: amount, result_id: result_id }
                      );

                      if (isBidUpdated2.modifiedCount > 0) {
                        return {
                          bid_id: bidDet._id,
                          user_id: bidDet.user_id,
                          is_win: 1,
                          detDesc: detDesc,
                        };
                      }
                    }
                  });
                }
              }
            } else {
              let isBidUpdated = await MarketBids.updateOne(
                { _id: bidDet._id },
                { is_win: 2, result_id: result_id }
              );
              if (isBidUpdated.modifiedCount > 0) {
                return {
                  bid_id: bidDet._id,
                  user_id: bidDet.user_id,
                  is_win: 2,
                  detDesc: "Lose",
                };
              }
            }
          })
        ); /* for market */

        await Promise.all(
          usersList.map(async (user) => {
            let updateWallet = { $set: { wallet_wining: user.wallet_wining } };
            return await Users.updateOne({ _id: user._id }, updateWallet);
          })
        ); /* for usersList */

        if (pubType == 1) {
          await MarketResults.updateOne(
            { _id: id },
            { is_open_published: 1, open_published_date: new Date() }
          );
        } else if (pubType == 2) {
          await MarketResults.updateOne(
            { _id: id },
            { is_published: 1, published_date: new Date() }
          );
        } else {
          await MarketResults.updateOne(
            { _id: id },
            {
              is_open_published: 1,
              open_published_date: new Date(),
              is_published: 1,
              published_date: new Date(),
            }
          );
        }

        return myResp;
      } else {
        if (pubType == 1) {
          await MarketResults.updateOne(
            { _id: id },
            { is_open_published: 1, open_published_date: new Date() }
          );
        } else if (pubType == 2) {
          await MarketResults.updateOne(
            { _id: id },
            { is_published: 1, published_date: new Date() }
          );
        } else {
          await MarketResults.updateOne(
            { _id: id },
            {
              is_open_published: 1,
              open_published_date: new Date(),
              is_published: 1,
              published_date: new Date(),
            }
          );
        }

        return {};
      }
    } catch (error2) {
      console.log(324, error2);
    }
  })();
}

exports.rollbackMarketResultPartial = (req, res) => {
  (async () => {
    try {
      if (!(await isValid(req.body.market_name))) {
        return res.json({
          status: 0,
          message: "Market name is required",
          data: {},
        });
      }

      if (!(await isValid(req.body.date))) {
        return res.json({
          status: 0,
          message: "date is required",
          data: {}
        });
      }

      if (!(await isValid(req.body.type))) {
        return res.json({
          status: 0,
          message: "type is required",
          data: {}
        });
      }

      const name = req.body.market_name;
      const date = req.body.date;
      const type = req.body.type;

      // let created_by = req.userDet._id;
      let created_by = null;
      const market = await Markets.findOne({ name });
      const market_id = market._id;

      if (market) {
        let detDesc = "Rollback - " + market.name;
        let detDescWin = "Won - " + market.name;

        const marketResult = await MarketResults.findOne({
          market_id: market_id,
          result_date: date,
        });

        if (marketResult) {
          if (marketResult.is_rollback == 1) {
            return res.json({
              status: 0,
              message: "Result Already Rollbacked",
              data: {},
            });
          }

          if (type == "1") {
            if (marketResult.is_open_rollback == 1) {
              return res.json({
                status: 0,
                message: "Open Result Already Rollbacked",
                data: {},
              });
            }

            let updMarket = {
              is_open_rollback: 1,
              roll_cdate: new Date(),
              op_1: req.body.op_1,
              op_2: req.body.op_2,
              op_3: req.body.op_3,
              digit_1: req.body.digit_1,
            };

            if (marketResult.is_close_rollback == 1) {
              updMarket.is_rollback = 1;
            }

            let merged = marketResult;

            merged.is_open_rollback = updMarket.is_open_rollback;
            merged.op_1 = updMarket.op_1;
            merged.op_2 = updMarket.op_2;
            merged.op_3 = updMarket.op_3;
            merged.digit_1 = updMarket.digit_1;

            await MarketResults.updateOne({ _id: marketResult._id }, updMarket);

            let resp = await doResultRollback(market_id, date, 1, created_by, detDesc, detDescWin, merged);

            return res.json({
              status: 1,
              message: "Open Result Rollbacked Successfully",
              data: resp,
            });
          } else if (type == "2") {
            if (marketResult.is_close_rollback == 1) {
              return res.json({
                status: 0,
                message: "Close Result Already Rollbacked",
                data: {},
              });
            }

            let updMarket = {
              is_close_rollback: 1,
              roll_cdate: new Date(),
              cp_1: req.body.cp_1,
              cp_2: req.body.cp_2,
              cp_3: req.body.cp_3,
              digit_2: req.body.digit_2,
            };

            if (marketResult.is_open_rollback == 1) {
              updMarket.is_rollback = 1;
            }

            let merged = marketResult;

            merged.is_close_rollback = updMarket.is_close_rollback;
            merged.cp_1 = updMarket.cp_1;
            merged.cp_2 = updMarket.cp_2;
            merged.cp_3 = updMarket.cp_3;
            merged.digit_2 = updMarket.digit_2;

            await MarketResults.updateOne({ _id: marketResult._id }, updMarket);

            let resp = await doResultRollback(market_id, date, 2, created_by, detDesc, detDescWin, merged);

            return res.json({
              status: 1,
              message: "Close Result Rollbacked Successfully",
              data: resp,
            });
          } else {
            return res.json({
              status: 0,
              message: "Something Went Wrong",
              data: {},
            });
          }
        } else {
          return res.json({
            status: 1,
            message: "Result Not Found",
            data: {},
          });
        }
      } else {
        return res.json({ status: 0, message: "Market Not Found", data: {} });
      }
    } catch (error) {
      console.log(error);
      return res.json({ status: 0, message: error.message, data: error });
    }
  })();
};

async function doResultRollback(market_id, date, pubType = 1, created_by, detDesc, detDescWin, resData) {
  /* pubType => 1=Open,2=Close,3=Both */
  try { // is_win: 0
    let whe = {
      market_id: market_id,
      is_win: { $in: [0, 1, 2] },
      report_date: new Date(date),
    };

    if (pubType == 1) {
      whe.game_type_id = { $in: [0, 3, 4, 5] };
    } else if (pubType == 2) {
      whe.game_type_id = { $in: [1, 6, 7, 8, 2, 9, 10, 11] };
    }

    let allBids = await MarketBids.find(whe);

    if (allBids.length > 0) {
      allTrans = [];
      var usersList = await getUserByBid(whe);

      await Promise.all(
        allBids.map(async (bidDet) => {
          let user_id = bidDet.user_id.toString();
          let isBidUpdate = await MarketBids.updateOne(
            { _id: bidDet._id },
            { is_win: 0, updatedAt: new Date() }
          );

          if (isBidUpdate.modifiedCount > 0) {
            if (bidDet.is_win == 1) {
              let trans2 = await Transactions.findOne({
                refe_id: bidDet._id,
                user_id: bidDet.user_id,
                entry_type: 1,
                wallet_type: 1,
              });

              if (trans2) {
                amount = trans2.amount;

                let newTrans4 = {
                  user_id: trans2.user_id,
                  refe_id: trans2.refe_id,
                  amount: trans2.amount,
                  charge_amount: trans2.charge_amount,
                  final_amount: trans2.final_amount,
                  post_balance: 0,
                  tnx_type: 11,
                  wallet_type: 1,
                  details: "Pull Winning - " + detDesc,
                  entry_type: 2,
                  /*debit*/ report_date: trans2.report_date,
                  created_by: created_by,
                };

                var i = await usersList.findIndex(
                  (_element) => _element._id.toString() === user_id
                );

                if (i > -1) {
                  let post_balance = usersList[i].wallet_wining - parseFloat(amount);
                  usersList[i].wallet_wining = usersList[i].wallet_wining - parseFloat(amount);
                  newTrans4.post_balance = post_balance;
                  allTrans.push(newTrans4);

                  return newTrans4;
                } else {
                  allTrans.push(newTrans4);

                  return newTrans4;
                }
              }
            } else {
              return {};
            }
          } else {
            return {};
          }
        })
      ); /* for allBids */

      if (allTrans.length > 0) {
        let istransIns = await Transactions.insertMany(allTrans);

        if (istransIns) {
          if (usersList.length > 0) {
            /* Commented On 28-12-23 */
            /* await Promise.all(usersList.map(async (user) => {
                          let updateWallet = { wallet_wining: user.wallet_wining };
                          return await Users.updateOne({ _id: user._id }, updateWallet);
                      })); */
            /* for usersList */
          }
        }
      }

      let ratios = await GameRatios.find({});
      let resultId = resData._id;

      return await doPublishRes(resultId, market_id, ratios, resData, pubType, created_by, detDescWin, date);
    } else {
      return {};
    }
  } catch (error2) {
    console.log(1036, error2);
    return error2;
  }
}

async function getUserByBid(where) {
  where.market_id = mongoose.Types.ObjectId(where.market_id);

  let usersList = await MarketBids.aggregate([
    { $match: where },
    {
      $group: {
        _id: null,
        user_id: {
          $addToSet: "$user_id",
        },
      },
    },
    {
      $lookup: {
        from: "users",
        let: { user_id: "$user_id" },
        pipeline: [
          {
            $match: {
              //"$expr": { "$eq": ["$_id", "$$user_id"] },
              $expr: {
                $and: [{ $in: ["$_id", "$$user_id"] }],
              },
            },
          },
          { $project: { _id: 1, wallet: 1, wallet_wining: 1 } },
        ],
        as: "user_id",
      },
    },
    {
      $project: {
        _id: 0,
        users: "$user_id",
      },
    },
  ]);

  if (usersList.length > 0) {
    return usersList[0].users;
  } else {
    return [];
  }
}

exports.refundMarketResultPartial = (req, res) => {
  (async () => {
    try {
      let date = req.body.date;
      let refund_id = req.body.refund_id;
      let refund_type = req.body.refund_type;
      // let created_by = req.userDet._id;
      let created_by = null;
      let detDesc = "Market Refund";
      
      const name = req.body.market_name;
      const market = await Markets.findOne({ name });

      if (market) {
        const market_id = market._id;
        detDesc = "Refund - " + market.name;

        let refundBids = null;
        if (refund_id != "") {
          refundBids = await MarketRefunds.findOne({
            market_id: market_id,
            refund_date: date,
          });
        }

        if (typeof refund_type == "object" && refund_type.indexOf("1") > -1 && refund_type.indexOf("2") > -1) {
          /* open close both */
          if (refundBids) {
            if (refundBids.is_open_refunded == 1) {
              return res.json({ status: 0, message: "Open Panna Already Refunded, Not Allowed To Refund Again", data: {} });
            } else if (refundBids.is_close_refunded == 1) {
              return res.json({ status: 0, message: "Already Refunded, Not Allowed To Refund Again", data: {} });
            } else {
              let updateArr = {
                is_open_refunded: 1,
                is_close_refunded: 1,
                is_both_refund: 1,
                both_refunded_date: new Date(),
              };

              let updateRefund = await MarketRefunds.updateOne({ _id: refund_id }, updateArr);
              if (updateRefund.modifiedCount > 0) {
                let resp = await doRefundBids(market_id, date, 3, created_by, detDesc);
                return res.json({ status: 1, message: "Both Refunded Successfully", data: resp });
              } else {
                return res.json({ status: 0, message: "Something Went Wrong, Not Refunded", data: {} });
              }
            }
          } else {
            let insertArr = {
              refund_date: new Date(date),
              market_id: market_id,
              is_open_refunded: 1,
              is_close_refunded: 1,
              is_both_refund: 1,
              open_refunded_date: new Date(),
              close_refunded_date: new Date(),
              both_refunded_date: new Date(),
            };

            return new MarketRefunds(insertArr).save(async function (err, data) {
              if (err) return res.json({ status: 0, message: err.message || "Cannot Refunded", data: {} });
              let resp = await doRefundBids(market_id, date, 3, created_by, detDesc);
              return res.json({ status: 1, message: "Both Refunded Successfully", data: resp });
            });
          }
        } else if ((typeof refund_type == "object" && refund_type.indexOf("1") > -1) || (typeof refund_type == "string" && refund_type == "1")) {
          /* open */
          if (refundBids) {
            if (refundBids.is_open_refunded == 1) {
              return res.json({ status: 0, message: "Open Panna Already Refunded, Not Allowed To Refund Again", data: {} });
            } else {
              let updateArr = {
                is_open_refunded: 1,
                open_refunded_date: new Date(),
              };
              if (refundBids.is_close_refunded == 1) {
                updateArr.is_both_refund = 1;
                updateArr.both_refunded_date = new Date();
              }
              let updateRefund = await MarketRefunds.updateOne({ _id: refund_id }, updateArr);
              if (updateRefund.modifiedCount > 0) {
                let resp = await doRefundBids(market_id, date, 1, created_by, detDesc);
                return res.json({ status: 1, message: "Open Refunded Successfully", data: resp });
              } else {
                return res.json({ status: 0, message: "Something Went Wrong, Not Refunded", data: {} });
              }
            }
          } else {
            let insertArr = {
              refund_date: new Date(date),
              market_id: market_id,
              is_open_refunded: 1,
              open_refunded_date: new Date(),
            };
            return new MarketRefunds(insertArr).save(async function (err, data) {
              if (err) return res.json({ status: 0, message: err.message || "Cannot Refunded", data: {} });
              let resp = await doRefundBids(market_id, date, 1, created_by, detDesc);
              return res.json({ status: 1, message: "Open Refunded Successfully", data: resp });
            });
          }
        } else if ((typeof refund_type == "object" && refund_type.indexOf("2") > -1) || (typeof refund_type == "string" && refund_type == "2")) {
          /* close*/
          if (refundBids) {
            if (refundBids.is_close_refunded == 1) {
              return res.json({ status: 0, message: "Close Panna Already Refunded, Not Allowed To Refund Again", data: {} });
            } else {
              let updateArr = {
                is_close_refunded: 1,
                close_refunded_date: new Date(),
              };
              if (refundBids.is_open_refunded == 1) {
                updateArr.is_both_refund = 1;
                updateArr.both_refunded_date = new Date();
              }
              let updateRefund = await MarketRefunds.updateOne({ _id: refund_id }, updateArr);

              if (updateRefund.modifiedCount > 0) {
                let resp = await doRefundBids(market_id, date, 2, created_by, detDesc);
                return res.json({ status: 1, message: "Close Refunded Successfully", data: resp });
              } else {
                return res.json({ status: 0, message: "Something Went Wrong, Not Refunded", data: {} });
              }
            }
          } else {
            let insertArr = {
              refund_date: new Date(date),
              market_id: market_id,
              is_close_refunded: 1,
              close_refunded_date: new Date(),
            };
            return new MarketRefunds(insertArr).save(async function (err, data) {
              if (err) return res.json({ status: 0, message: err.message || "Cannot Refunded", data: {} });
              let resp = await doRefundBids(market_id, date, 2, created_by, detDesc);
              return res.json({ status: 1, message: "Close Refunded Successfully", data: resp });
            });
          }
        }
        return res.json({ status: 0, message: "Something Went Wrong", data: {} });
      } else {
        return res.json({ status: 0, message: "Market Not Found", data: {} });
      }
    } catch (error) {
      console.log(error);
      return res.json({ status: 0, message: error.message, data: error });
    }
  })();
};

async function doRefundBids(market_id, date, pubType = 1, created_by, detDesc) {
  /* pubType => 1=Open,2=Close,3=Both */
  try {
    //, is_win: 0
    let whe = { market_id: market_id, is_win: 0, report_date: new Date(date) };
    if (pubType == 1) {
      whe.game_type_id = { $in: [0, 3, 4, 5] };
    } else if (pubType == 2) {
      whe.game_type_id = { $in: [1, 6, 7, 8, 2, 9, 10, 11] };
    }

    let allBids = await MarketBids.find(whe);

    if (allBids.length > 0) {
      let users = [];
      let usersWinning = [];
      let allTrans = [];
      var usersList = await getUserByBid(whe);
      await Promise.all(
        allBids.map(async (bidDet) => {
          let game_type_id = bidDet.game_type_id;
          let user_id = bidDet.user_id.toString();
          let isBidUpdate = await MarketBids.updateOne(
            { _id: bidDet._id },
            { is_win: 3 }
          );
          if (isBidUpdate.modifiedCount > 0) {
            let trans = await Transactions.find({
              refe_id: bidDet._id,
              user_id: bidDet.user_id,
              entry_type: 2,
            }); //.select('user_id refe_id amount tnx_type wallet_type report_date');
            if (trans.length > 0) {
              let post_balance = 0;
              if (trans.length == 1) {
                trans = trans[0];
                let newTrans = {
                  user_id: trans.user_id,
                  refe_id: trans.refe_id,
                  amount: trans.amount,
                  charge_amount: trans.charge_amount,
                  final_amount: trans.final_amount,
                  post_balance: post_balance,
                  tnx_type: 2,
                  wallet_type: trans.wallet_type,
                  details: detDesc,
                  entry_type: 1,
                  /*creadit*/ report_date: trans.report_date,
                  created_by: created_by,
                };

                let amount = trans.amount;

                if (trans.wallet_type == 1) {
                  var i = await usersList.findIndex((_element) => _element._id.toString() === user_id);
                  if (i > -1) {
                    let post_balance = usersList[i].wallet_wining + parseFloat(amount);
                    usersList[i].wallet_wining = usersList[i].wallet_wining + parseFloat(amount);
                    newTrans.post_balance = post_balance;
                    allTrans.push(newTrans);
                    return newTrans;
                  } else {
                    return newTrans;
                  }
                } else {
                  var i = await usersList.findIndex((_element) => _element._id.toString() === user_id);
                  if (i > -1) {
                    let post_balance = usersList[i].wallet + parseFloat(amount);
                    usersList[i].wallet = usersList[i].wallet + parseFloat(amount);
                    newTrans.post_balance = post_balance;
                    allTrans.push(newTrans);
                    return newTrans;
                  } else {
                    return newTrans;
                  }
                }
              } else if (trans.length == 2) {
                let first = trans[0];
                let second = trans[1];
                let newTrans2 = {
                  user_id: first.user_id,
                  refe_id: first.refe_id,
                  amount: first.amount,
                  charge_amount: first.charge_amount,
                  final_amount: first.final_amount,
                  post_balance: post_balance,
                  tnx_type: 2,
                  wallet_type: first.wallet_type,
                  details: detDesc,
                  entry_type: 1,
                  /*creadit*/ report_date: first.report_date,
                  created_by: created_by,
                };
                let newTrans3 = {
                  user_id: second.user_id,
                  refe_id: second.refe_id,
                  amount: second.amount,
                  charge_amount: second.charge_amount,
                  final_amount: second.final_amount,
                  post_balance: post_balance,
                  tnx_type: 2,
                  wallet_type: second.wallet_type,
                  details: detDesc,
                  entry_type: 1,
                  /*creadit*/ report_date: second.report_date,
                  created_by: created_by,
                };
                //allTrans.push(newTrans2); allTrans.push(newTrans3);
                let amount = newTrans2.amount;

                if (newTrans2.wallet_type == 1) {
                  var i = await usersList.findIndex((_element) => _element._id.toString() === user_id);
                  if (i > -1) {
                    let post_balance = usersList[i].wallet_wining + parseFloat(amount);
                    usersList[i].wallet_wining = usersList[i].wallet_wining + parseFloat(amount);
                    newTrans2.post_balance = post_balance;
                    allTrans.push(newTrans2);
                  }
                } else {
                  var i = await usersList.findIndex((_element) => _element._id.toString() === user_id);
                  if (i > -1) {
                    let post_balance = usersList[i].wallet + parseFloat(amount);
                    usersList[i].wallet = usersList[i].wallet + parseFloat(amount);
                    newTrans2.post_balance = post_balance;
                    allTrans.push(newTrans2);
                  }
                }
                amount = newTrans3.amount;

                if (newTrans3.wallet_type == 1) {
                  var i = await usersList.findIndex((_element) => _element._id.toString() === user_id);
                  if (i > -1) {
                    let post_balance = usersList[i].wallet_wining + parseFloat(amount);
                    usersList[i].wallet_wining = usersList[i].wallet_wining + parseFloat(amount);
                    newTrans3.post_balance = post_balance;
                    allTrans.push(newTrans3);
                    return { newTrans2, newTrans3 };
                  } else {
                    return { newTrans2, newTrans3 };
                  }
                } else {
                  var i = await usersList.findIndex((_element) => _element._id.toString() === user_id);
                  if (i > -1) {
                    let post_balance = usersList[i].wallet + parseFloat(amount);
                    usersList[i].wallet = usersList[i].wallet + parseFloat(amount);
                    newTrans3.post_balance = post_balance;
                    allTrans.push(newTrans3);
                    return { newTrans2, newTrans3 };
                  } else {
                    return { newTrans2, newTrans3 };
                  }
                }
              }
            } else {
              return {};
            }
          } else {
            return {};
          }
        })
      ); /* for market */
      if (allTrans.length > 0) {
        let istransIns = await Transactions.insertMany(allTrans);
        if (istransIns) {
          if (usersList.length > 0) {
            await Promise.all(
              usersList.map(async (user) => {
                let updateWallet = {
                  $set: {
                    wallet: user.wallet,
                    wallet_wining: user.wallet_wining,
                  },
                };
                return await Users.updateOne({ _id: user._id }, updateWallet);
              })
            ); /* for users */
          }
        }
      }
      return {
        users,
        usersWinning,
        allTrans,
      };
    } else {
      return {};
    }
  } catch (error2) {
    console.log(1036, error2);
    return error2;
  }
}
