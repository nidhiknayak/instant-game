
const PaymentGateway = require('../../models/PaymentGateway');
const { isValid } = require('../../services/validation');

exports.getList = async (req, res) => {
  try {
    const resopnse = await PaymentGateway.find({});
    if (resopnse) {
      return res.json({ status: 1, message: 'Payment Gateway Found', data: resopnse });
    } else {
      return res.json({ status: 1, message: "Payment Gateway Not Found", data: {} });
    }
  } catch (error) {
    return res.json({ status: 0, message: error, data: {} });
  }
};

exports.addPaymenGateway = async (req, res) => {
  try {
      if (!await isValid(req.body.name)) {
          return res.json({ status: 0, message: 'Name is required', data: {} });
      }
      if (!await isValid(req.body.code)) {
          return res.json({ status: 0, message: 'Code is required', data: {} });
      }
      if (!await isValid(req.body.base_url)) {
          return res.json({ status: 0, message: 'Base url is required', data: {} });
      }
      if (!await isValid(req.body.client_id)) {
          return res.json({ status: 0, message: 'Client id is required', data: {} });
      }
      if (!await isValid(req.body.secret_key)) {
          return res.json({ status: 0, message: 'Secret Key is required', data: {} });
      }
      const { name, code, base_url, client_id, secret_key, status } = req.body;
      const insert = {
        name,
        code,
        base_url,
        client_id,
        secret_key,
        status
      };
      return new PaymentGateway(insert).save(async function (err, data) {
        if (err) return res.json({ status: 0, message: err.message || "Cannot Add Payment gateway", data: {} });
        const resopnse = {
          ...insert,
          createdAt: data.createdAt,
          updatedAt: data.updatedAt
        };
        return res.json({ status: 1, message: 'Payment gateway Added Successfully', data: resopnse });
      });
  } catch (error) {
      return res.json({ status: 0, message: error, data: {} });
  }
}
exports.changeStatusMarket = async (req, res) => {
  try {
    if (!await isValid(req.body.id)) {
        return res.json({ status: 0, message: 'ID is required', data: {} });
    }
    if (!await isValid(req.body.type)) {
        return res.json({ status: 0, message: 'Type is required', data: {} });
    }
    
    const { id, type = 'pay_in', status, method } = req.body;//pay_in, pay_out
    const data = await PaymentGateway.findOne({ _id: id });

    if (data) {
      let msg = "Payment Gateway Status Changed Successfully For Add Money";
      if(type == "pay_in"){
        if(method && data.code == "GENNIEPAY"){
          const update = { status: true };
          if(method == "INTENT"){
            update.is_intent = (status == "1");
          }
          if(method == "COLLECT"){
            update.is_collect = (status == "1");
          }
          if(!update.is_intent && !data.is_collect){
            update.is_collect = true;
          }
          if(!update.is_collect && !data.is_intent){
            update.is_intent = true;
          }
          await PaymentGateway.updateOne({ _id: id }, update);

          await PaymentGateway.updateMany({ _id: { $ne: id } }, { status: false });
        } else {
          const update = { status: true };
          await PaymentGateway.updateOne({ _id: id }, update);
          await PaymentGateway.updateMany({ _id: { $ne: id } }, { status: false, is_collect: false, is_intent: false });
        }
      } else {
        msg = "Payment Gateway Status Changed Successfully For Withdraw Money";
        const update = { withdraw: true };
        await PaymentGateway.updateOne({ _id: id }, update);
        await PaymentGateway.updateMany({ _id: { $ne: id } }, { withdraw: false });
      }
      
      return res.json({ status: 1, message: msg, data: {} });

    } else {
      return res.json({ status: 0, message: "No Record Found", data: {} });
    }
  } catch (error) {
    return res.json({ status: 0, message: error || "Something Went Wrong", data: {} });
  };
}