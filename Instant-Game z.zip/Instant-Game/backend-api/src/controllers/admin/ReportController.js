var mongoose 						= require('mongoose');
const ObjectId 						= mongoose.Types.ObjectId;
const { Markets, MarketTimeTable } 	= require('../../models/Markets');
const GameRatios 					= require('../../models/GameRatios');
const MarketResults 				= require('../../models/MarketResults');
const MarketBids 					= require('../../models/MarketBids');
const ColorBids 					= require('../../models/ColorBids');
const ColorResults 					= require('../../models/ColorResults');
const Draws 						= require('../../models/Draws');
const { isValid } 					= require('../../services/validation');
const { declareResult } 			= require('../../services/DeclareResult');
const { getPagination, getRespPagi, getDateFormat, getWeekDay, convertToUTC, getDayNameArr, allowPublishRes, convertToUTCNew } = require('../../services/common');
const pdfTemplate 					= require('../../view/pdf/dailyreport');
const pdf 							= require('html-pdf');

/* 16-11-2021 */
exports.getDailyReport = (req, res) => {
	(async () => {
		try {
			let date 		= req.body.date;
			let market 		= req.body.market;
			let main_type 	= req.body.main_type;

			let week_day 	= getWeekDay();
			let datesArr 	= [];
			let wd 			= 1;
			for (let j = week_day - 1; j >= 1; j--) {
				let yest 	= new Date(date);
				yest.setDate(yest.getDate() - j);
				let newDate = getDateFormat(yest);
				datesArr.push({
					date: newDate,
					week_day: wd
				});
				wd++;
			}
			var days 		= getDayNameArr();
			var d 			= new Date(date);
			var week_day_name = days[d.getDay()];
			var weekDayKey 	= d.getDay() + 1;

			let cdate 		= getDateFormat();
			//let wh 		= { market_id: market, report_date: date };
			let wh 			= { market_id: market };
			let isHalfFull = 0;
			if (main_type === "3") {
				wh.game_type_id = 2;
			}
			else if (main_type === "1") {
				//wh.game_type_id 	= { $in: [3, 4, 5] };
				wh.game_type_id = { $in: [0, 3, 4, 5] };
			}
			else if (main_type === "2") {
				//wh.game_type_id 	= { $in: [6, 7, 8] };
				wh.game_type_id = { $in: [1, 6, 7, 8] };
			}
			else if (main_type === "4") {
				isHalfFull = 1;
				//wh.game_type_id 	= { $in: [3, 4, 5, 6, 7, 8] };

				//wh.game_type_id 	= { $ne: 2 };
				
				//wh.game_type_id = { $in: [0, 3, 4, 5, 1, 6, 7, 8] };
				
				//wh.game_type_id = { $in: [9,10,11] };
			}
			if (date) wh.report_date = date;

			var resopnse 	= await MarketBids.find(wh);
			let resultData = await MarketResults.findOne({ market_id: market, result_date: new Date(date) });
			//return res.json({ status: 1, message: 'data', data: resopnse });
			if (resopnse) {
				var sendRes = {};

				let pannas 	= {
					0: { no: [{ 'no': 127, 'tot': 0 }, { 'no': 136, 'tot': 0 }, { 'no': 145, 'tot': 0 }, { 'no': 190, 'tot': 0 }, { 'no': 235, 'tot': 0 }, { 'no': 280, 'tot': 0 }, { 'no': 370, 'tot': 0 }, { 'no': 389, 'tot': 0 }, { 'no': 460, 'tot': 0 }, { 'no': 479, 'tot': 0 }, { 'no': 569, 'tot': 0 }, { 'no': 578, 'tot': 0 }, { 'no': 118, 'tot': 0 }, { 'no': 226, 'tot': 0 }, { 'no': 244, 'tot': 0 }, { 'no': 299, 'tot': 0 }, { 'no': 334, 'tot': 0 }, { 'no': 488, 'tot': 0 }, { 'no': 668, 'tot': 0 }, { 'no': 677, 'tot': 0 }, { 'no': 550, 'tot': 0 }, {'no':000,'tot':0}], total: 0 },
					1: { no: [{'no':137,'tot':0}, {'no':128,'tot':0}, {'no':146,'tot':0}, {'no':236,'tot':0}, {'no':245,'tot':0}, {'no':290,'tot':0}, {'no':380,'tot':0}, {'no':470,'tot':0}, {'no':489,'tot':0}, {'no':560,'tot':0}, {'no':678,'tot':0}, {'no':579,'tot':0}, {'no':119,'tot':0},{ 'no':155,'tot':0}, {'no':227,'tot':0}, {'no':335,'tot':0}, {'no':344,'tot':0}, {'no':399,'tot':0}, {'no':588,'tot':0}, {'no':669,'tot':0}, {'no':100,'tot':0}, {'no':777,'tot':0}], total: 0 },
					2: { no: [{'no':129,'tot':0}, {'no':138,'tot':0}, {'no':147,'tot':0}, {'no':156,'tot':0}, {'no':237,'tot':0}, {'no':246,'tot':0}, {'no':345,'tot':0}, {'no':390,'tot':0}, {'no':480,'tot':0}, {'no':570,'tot':0}, {'no':589,'tot':0}, {'no':679,'tot':0}, {'no':110,'tot':0}, {'no':228,'tot':0}, {'no':255,'tot':0}, {'no':336,'tot':0}, {'no':499,'tot':0}, {'no':660,'tot':0}, {'no':688,'tot':0}, {'no':778,'tot':0}, {'no':200,'tot':0}, {'no':444,'tot':0}], total: 0 },
					3: { no: [{'no':120,'tot':0}, {'no':139,'tot':0}, {'no':148,'tot':0}, {'no':157,'tot':0}, {'no':238,'tot':0}, {'no':247,'tot':0}, {'no':256,'tot':0}, {'no':346,'tot':0}, {'no':490,'tot':0}, {'no':580,'tot':0}, {'no':670,'tot':0}, {'no':689,'tot':0}, {'no':166,'tot':0}, {'no':229,'tot':0}, {'no':337,'tot':0}, {'no':355,'tot':0}, {'no':445,'tot':0}, {'no':599,'tot':0}, {'no':779,'tot':0}, {'no':788,'tot':0}, {'no':300,'tot':0}, {'no':111,'tot':0}], total: 0 },
					4: { no: [{'no':130,'tot':0}, {'no':149,'tot':0}, {'no':158,'tot':0}, {'no':167,'tot':0}, {'no':239,'tot':0}, {'no':248,'tot':0}, {'no':257,'tot':0}, {'no':347,'tot':0}, {'no':356,'tot':0}, {'no':590,'tot':0}, {'no':680,'tot':0}, {'no':789,'tot':0}, {'no':112,'tot':0}, {'no':220,'tot':0}, {'no':266,'tot':0}, {'no':338,'tot':0}, {'no':446,'tot':0}, {'no':455,'tot':0}, {'no':699,'tot':0}, {'no':770,'tot':0}, {'no':400,'tot':0}, {'no':888,'tot':0}], total: 0 },
					5: { no: [{'no':140,'tot':0}, {'no':159,'tot':0}, {'no':168,'tot':0}, {'no':230,'tot':0}, {'no':249,'tot':0}, {'no':258,'tot':0}, {'no':267,'tot':0}, {'no':348,'tot':0}, {'no':357,'tot':0}, {'no':456,'tot':0}, {'no':690,'tot':0}, {'no':780,'tot':0}, {'no':113,'tot':0}, {'no':122,'tot':0}, {'no':177,'tot':0}, {'no':339,'tot':0}, {'no':366,'tot':0}, {'no':447,'tot':0}, {'no':799,'tot':0}, {'no':889,'tot':0}, {'no':500,'tot':0}, {'no':555,'tot':0}], total: 0 },
					6: { no: [{'no':123,'tot':0}, {'no':150,'tot':0}, {'no':169,'tot':0}, {'no':178,'tot':0}, {'no':240,'tot':0}, {'no':259,'tot':0}, {'no':268,'tot':0}, {'no':349,'tot':0}, {'no':358,'tot':0}, {'no':367,'tot':0}, {'no':457,'tot':0}, {'no':790,'tot':0}, {'no':114,'tot':0}, {'no':277,'tot':0}, {'no':330,'tot':0}, {'no':448,'tot':0}, {'no':466,'tot':0}, {'no':556,'tot':0}, {'no':880,'tot':0}, {'no':899,'tot':0}, {'no':600,'tot':0}, {'no':222,'tot':0}], total: 0 },
					7: { no: [{'no':124,'tot':0}, {'no':160,'tot':0}, {'no':179,'tot':0}, {'no':250,'tot':0}, {'no':269,'tot':0}, {'no':278,'tot':0}, {'no':340,'tot':0}, {'no':359,'tot':0}, {'no':368,'tot':0}, {'no':458,'tot':0}, {'no':467,'tot':0}, {'no':890,'tot':0}, {'no':115,'tot':0}, {'no':133,'tot':0}, {'no':188,'tot':0}, {'no':223,'tot':0}, {'no':377,'tot':0}, {'no':449,'tot':0}, {'no':557,'tot':0}, {'no':566,'tot':0}, {'no':700,'tot':0}, {'no':999,'tot':0}], total: 0 },
					8: { no: [{'no':125,'tot':0}, {'no':134,'tot':0}, {'no':170,'tot':0}, {'no':189,'tot':0}, {'no':260,'tot':0}, {'no':279,'tot':0}, {'no':350,'tot':0}, {'no':369,'tot':0}, {'no':378,'tot':0}, {'no':459,'tot':0}, {'no':468,'tot':0}, {'no':567,'tot':0}, {'no':116,'tot':0}, {'no':224,'tot':0}, {'no':233,'tot':0}, {'no':288,'tot':0}, {'no':440,'tot':0}, {'no':477,'tot':0}, {'no':558,'tot':0}, {'no':990,'tot':0}, {'no':800,'tot':0}, {'no':666,'tot':0}], total: 0 },
					9: { no: [{'no':126,'tot':0}, {'no':135,'tot':0}, {'no':180,'tot':0}, {'no':234,'tot':0}, {'no':270,'tot':0}, {'no':289,'tot':0}, {'no':360,'tot':0}, {'no':379,'tot':0}, {'no':450,'tot':0}, {'no':469,'tot':0}, {'no':478,'tot':0}, {'no':568,'tot':0}, {'no':117,'tot':0}, {'no':144,'tot':0}, {'no':199,'tot':0}, {'no':225,'tot':0}, {'no':388,'tot':0}, {'no':559,'tot':0}, {'no':577,'tot':0}, {'no':667,'tot':0}, {'no':900,'tot':0}, {'no':333,'tot':0}], total: 0 },
				};
				let lastDig = 100;
				let htm 	= '<tr>';
				let htmJodi 	= '';
				let halfSangamOpen = [], halfSangamClose = [], fullSangam = [];
				let total_collection = 0,
					amount_to_pay = 0,
					is_profit = 0;
				if (main_type === "3") {
					for (let i = 1; i <= lastDig; i++) {
						if(i < 10){
							sendRes['0'+i] = 0;
						} else {
							sendRes[i] = 0;
						}
					}
					resopnse.map(async (bidDet) => {
						total_collection += bidDet.amount;
						if (bidDet.is_win === 1) {
							amount_to_pay += bidDet.win_amount;
						}
						if (bidDet.panna_1 == "00"){
							sendRes[100] += bidDet.amount
						} else {
							sendRes[bidDet.panna_1] += bidDet.amount
						}
					});
					let temp_html = '';
					for (let ind = 1; ind <= lastDig; ind++) {
						if (ind !== 1 && (ind - 1) % 10 === 0) {
							htm += '<tr>';
						}
						let elem = ind;
						elem = (elem < 10) ? '0' + ind : ind;
						elem = (ind == 100) ? '00' : elem;
						htm += '<td align="center" class="col-1">' + elem + '</td>';
						if (ind < 10 && sendRes[elem] > 0){
							temp_html += '<td align="center" class="text-danger"><strong>' + sendRes[elem] + ' ₹</strong></td>';
						} else if (sendRes[ind] > 0) {
							temp_html += '<td align="center" class="text-danger"><strong>' + sendRes[ind] + ' ₹</strong></td>';
						}
						else {
							temp_html += '<td></td>';
						}
						if (((ind) % 10) === 0) {
							htm += '</tr>';
							htm += '<tr>' + temp_html + '</tr>';
							temp_html = '';
						}
					}
				}
				else if (main_type === "1" || main_type === "2" || main_type === "4") {
					if (main_type === "4"){
						for (let i = 1; i <= lastDig; i++) {
							if (i < 10) {
								sendRes['0' + i] = 0;
							} else {
								sendRes[i] = 0;
							}
						}
					}
					await resopnse.map(async (bidDet) => {
						total_collection += bidDet.amount;
						if (bidDet.is_win === 1) {
							amount_to_pay += bidDet.win_amount;
						}
						/* let sum = 0;
						let val = bidDet.panna_1;
						
						while (val) {
							sum += val % 10;
							val = Math.floor(val / 10);
						} 
						sum = sum % 10;
						console.log('sum ::' + sum) */
						let valObj = getMainNo(bidDet.panna_1);
						let val = valObj.index;
						let subval = valObj.subindex;
						if (bidDet.amount){
							
							if (bidDet.panna_1.toString().length == 1 && (parseInt(bidDet.game_type_id) == 0 || parseInt(bidDet.game_type_id) == 1) &&  typeof pannas[bidDet.panna_1] !== 'undefined'){
								pannas[bidDet.panna_1].total += bidDet.amount;
							} else if (bidDet.panna_2 != null && bidDet.panna_2.toString().length == 1 && (parseInt(bidDet.game_type_id) == 9 || parseInt(bidDet.game_type_id) == 10) && typeof pannas[bidDet.panna_2] !== 'undefined') {

								//pannas[bidDet.panna_2].total += bidDet.amount;

								let elementIndex = subval;
								let value2 = bidDet.panna_1;
								if (elementIndex > -1) {

									//pannas[val].no[elementIndex].tot += bidDet.amount;

								}
								let opnPanna = bidDet.panna_1.toString();
								let clsDigit = bidDet.panna_2.toString();
								let legend = opnPanna + '-' + clsDigit;
								if (parseInt(bidDet.game_type_id) == 9){
									halfSangamOpen.push({ panna: opnPanna, digit: clsDigit, tot: bidDet.amount, legend: legend });
								} else {
									halfSangamClose.push({
										panna: opnPanna, digit: clsDigit, tot: bidDet.amount, legend: legend
									});
								}
							} else if (bidDet.panna_2 != null && parseInt(bidDet.game_type_id) == 11){
								let elementIndex = subval;
								if (elementIndex > -1) {

									//pannas[val].no[elementIndex].tot += bidDet.amount;

								}
								///
								let val2Obj = getMainNo(bidDet.panna_2);
								let val2 = val2Obj.index;
								let value3 = bidDet.panna_2;
								let elementIndex2 = val2Obj.subindex;
								if (elementIndex2 > -1) {

									//pannas[val2].no[elementIndex2].tot += bidDet.amount;

								}

								let open = bidDet.panna_1.toString();
								let close = bidDet.panna_2.toString();
								let legend = open + '-' + close;
								fullSangam.push({ open: open, close: close, tot: bidDet.amount, legend });
							} else {
								if (parseInt(bidDet.game_type_id) == 2){
									if (bidDet.panna_1 == "00") {
										sendRes[100] += bidDet.amount
									} else {
										sendRes[bidDet.panna_1] += bidDet.amount
									}
									//sendRes[bidDet.panna_1] += bidDet.amount
								} else {
									let elementIndex = subval;
									if (elementIndex > -1){
										pannas[val].no[elementIndex].tot += bidDet.amount;
									}
								}
							}
						}
					});
					let i = 0;
					let pannas_count = pannas.length;
					for (const pan in pannas) {
						htm += `<td>${pan}</td>`;
						pannas[pan].no.map((am, k) => {
							//console.log(138, am,k);
							if (am.no == 0) am.no = '000'
							htm += `<td>${am.no}</td>`;
						});
						htm += (pannas[pan].total > 0) ? `</tr><tr><td class="text-danger"><strong>${pannas[pan].total} ₹</strong></td>` : `</tr><tr><td></td>`;
						//htm += (pannas[pan].total > 0) ? `</tr><tr><td class="text-danger"><strong>${pannas[pan].total} ₹</strong></td>` : `</tr><tr><td></td>`;
						let no_len = pannas[pan].no.length;
						for (let e = 0; e < no_len; e++) {
							//htm += `<td></td>`;
							htm += (pannas[pan].no[e].tot > 0) ? `<td class="text-danger"><strong>${pannas[pan].no[e].tot}₹</strong></td>` :`<td></td>`;
						}
						htm += (i++ <= pannas_count) ? `</tr><tr>` : `</tr>`;
					}
					if (main_type === "4") {
						let temp_html = ''; htmJodi = '<tr>';
						for (let ind = 1; ind <= lastDig; ind++) {
							if (ind !== 1 && (ind - 1) % 10 === 0) {
								htmJodi += '<tr>';
							}
							let elem = ind;
							elem = (elem < 10) ? '0' + ind : ind;
							elem = (ind == 100) ? '00' : elem;
							htmJodi += '<td align="center" class="col-1">' + elem + '</td>';
							if (ind < 10 && sendRes[elem] > 0) {
								temp_html += '<td align="center" class="text-danger"><strong>' + sendRes[elem] + ' ₹</strong></td>';
							} else if (sendRes[ind] > 0) {
								temp_html += '<td align="center" class="text-danger"><strong>' + sendRes[ind] + ' ₹</strong></td>';
							}
							else {
								temp_html += '<td></td>';
							}
							if (((ind) % 10) === 0) {
								htmJodi += '</tr>';
								htmJodi += '<tr>' + temp_html + '</tr>';
								temp_html = '';
							}
						}
					}
				}
				else {
					for (let ind = 1; ind <= lastDig; ind++) {
						if ((ind % 10) === 0) {
							htm += '<tr>';
						}
						let elem = ind;
						elem = (elem < 10) ? '0' + ind : ind;
						elem = (ind == 100) ? '00' : elem;
						htm += '<td>' + elem + '</td>';
						if (((ind + 1) % 10) === 0) {
							htm += '</tr>';
						}
					}
					let myResp = await Promise.all(resopnse.map(async (bidDet) => {
						return bidDet
					}));
				}
				is_profit 	= (total_collection >= amount_to_pay) ? 'Profit' : 'Lose';
				//console.log(262, halfSangamOpen, halfSangamClose, fullSangam);

				let htmHalfOpenClose = '', htmHalfCloseOpen = '', htmHalfFull = '';
				let halfSangamCloseArr = [], halfSangamOpenArr = [], fullSangamArr = [];
				await Promise.all(halfSangamClose.map(async (im,key) => {
					let legendm = im.legend;
					var myInd = halfSangamCloseArr.map(function (e) { return e.legend; }).indexOf(legendm);
					if (myInd > -1) {
						halfSangamCloseArr[myInd].tot += im.tot;
					} else {
						halfSangamCloseArr.push(im);
					}
				}));
				await Promise.all(halfSangamCloseArr.map(async (im) => {
					htmHalfOpenClose += '<tr><td>' + im.digit + '</td><td>' + im.panna + '</td><td class="text-danger"><strong>₹' + im.tot + '</strong></td><tr>';
				}));
				await Promise.all(halfSangamOpen.map(async (im, key) => {
					let legendm = im.legend;
					var myInd = halfSangamOpenArr.map(function (e) { return e.legend; }).indexOf(legendm);
					if (myInd > -1) {
						halfSangamOpenArr[myInd].tot += im.tot;
					} else {
						halfSangamOpenArr.push(im);
					}
				}));
				await Promise.all(halfSangamOpenArr.map(async (im) => {
					htmHalfCloseOpen += '<tr><td>' + im.digit + '</td><td>' + im.panna + '</td><td><strong class="text-danger">₹' + im.tot + '</strong></td><tr>';
				}));
				await Promise.all(fullSangam.map(async (im, key) => {
					let legendm = im.legend;
					var myInd = fullSangamArr.map(function (e) { return e.legend; }).indexOf(legendm);
					if (myInd > -1) {
						fullSangamArr[myInd].tot += im.tot;
					} else {
						fullSangamArr.push(im);
					}
				}));
				await Promise.all(fullSangamArr.map(async (im) => {
					htmHalfFull += '<tr><td>' + im.open + '</td><td>' + im.close + '</td><td><strong class="text-danger">₹' + im.tot + '</strong></td><tr>';
				}));
				
				let data 	= {
					//resopnse: resopnse,
					sangam: { htmHalfOpenClose: htmHalfOpenClose, htmHalfCloseOpen: htmHalfCloseOpen, htmHalfFull: htmHalfFull },
					htm: htm,
					total_collection: parseInt(total_collection),
					amount_to_pay: parseInt(amount_to_pay),
					is_profit: is_profit,
					resultData: resultData,
					isHalfFull: isHalfFull,
					htmJodi: htmJodi
				};
				return res.json({ status: 1, message: 'Daily Report Found', data: data });
			} else {
				return res.json({ status: 0, message: "Record Not Found", data: {} });
			}
		} catch (error) {
			console.log(error);
			return res.json({ status: 0, message: error, data: {} });
		}
	})();
}
exports.dailyReportCreatePdf = (req, res) => {
	(async () => {
		try {
			pdf.create(pdfTemplate(req.body), { format: 'A4', 'orientation': 'landscape' }).toFile('uploads/pdf/dailyreport.pdf', (err) => {
				if (err) {
					return res.json({ status: 0, message: error });
				}
				return res.json({ status: 1, message: 'File created successfully', filepath: process.env.PDF_BASE_URL + 'dailyreport.pdf' });
			});
		} catch (error) {
			return res.json({ status: 0, message: error.message, data:error });
		}
	})();
}
exports.getBidReport = (req, res) => {
    (async () => {
        try {
			var { page, size, searchDate, searchGameType, bid_no, market, type, search } 	= req.body;
            page = page - 1;
            const { limit, offset } 		= getPagination(page, size);
            var condition 					= { deleted: false };
			var summCond 					= { deleted: false };
            if(typeof searchDate !== 'undefined' && searchDate != ''){
            	condition.report_date 		= new Date(searchDate);
				summCond.report_date 		= new Date(searchDate);
            }
            /* if(typeof searchGameType !== 'undefined' && searchGameType.length > 0){
                condition.game_type_id 		= {$in:searchGameType}
            } */
            if(typeof type !== 'undefined' && parseInt(type) > 0){
				type = parseInt(type);
				if (type == 1){/* placed bid */
					condition.is_win = 0;
				} else if (type == 2) {/* win */
					condition.is_win = 1;
				}
			}
            if(typeof market !== 'undefined' && market.length > 0){
                condition.market_id 		= ObjectId(market)
				summCond.market_id 		= ObjectId(market)
            }
			if (typeof bid_no !== 'undefined' && bid_no != ''){
				condition.panna_1 = bid_no.toString();
				summCond.panna_1  = bid_no.toString();
            }
            var aggregate           		= MarketBids.aggregate([
            	{ $match: condition },
            	{ $lookup: {
                    from: 'markets',
                    let:{'market_id':'$market_id'},
                    pipeline:[
                        {
                            "$match": {
                            "$expr": { "$eq": [ "$_id", "$$market_id" ] },
                            },
                        },
                        { $project : { _id:1,name:1 } }
                    ],
                    as: 'market_id',
                }},
            	{ $lookup: {
                    from: 'users',
                    let:{'user_id':'$user_id'},
                    pipeline:[
                        {
                            "$match": {
                            "$expr": { "$eq": [ "$_id", "$$user_id" ] },
                            },
                        },
                        { $project : { _id:1,mobile_no:1,country_code:1 } }
                    ],
                    as: 'user_id'
                }},

				{
					$match: { 'user_id.mobile_no': { $regex: new RegExp(search), $options: "i" } }
				},

                {
                    $project:{
                        _id:1,
                        user_id:{ "$arrayElemAt": [ "$user_id", 0 ] },
                        market_id:{ "$arrayElemAt": [ "$market_id", 0 ] },
                        game_type_id:1,
                        panna_1:1,
                        panna_2:1,
                        amount:1,
                        is_win:1,
                        win_amount:1,
                        createdAt:1,
                    }
                },
                {
                    $sort: { createdAt: -1 }
                }
            ]);
            await MarketBids.aggregatePaginate(aggregate, {
                limit,
                offset,
            }).then(async(resopnse) => {
                let sendd               = getRespPagi(resopnse, 'Get Bid List Successfully');

				let resultData = null;
				if (searchDate != ''){
					resultData = await MarketResults.findOne({ market_id: market, result_date: new Date(searchDate) });
					sendd.result = resultData;
				}
				let totPlacedBidAmt = 0, totWinAmt = 0, totTnx = 0;
				//summCond.is_win = 0;
				if (type == 1 || type == 3) {
					var placedBidAmt = await MarketBids.aggregate([
						{ $match: summCond },
						{
							$lookup: {
								from: 'users',
								let: { 'user_id': '$user_id' },
								pipeline: [
									{
										"$match": {
											"$expr": { "$eq": ["$_id", "$$user_id"] },
										},
									},
									{ $project: { _id: 1, mobile_no: 1, country_code: 1 } }
								],
								as: 'user_id'
							}
						},

						{
							$match: { 'user_id.mobile_no': { $regex: new RegExp(search), $options: "i" } }
						},
						{ "$group": { "_id": null, "total": { "$sum": "$amount" }, "tot_tnx": { "$count": {} } } }
					]);
					console.log(402, placedBidAmt);
					if (placedBidAmt.length > 0) {
						totTnx += placedBidAmt[0].tot_tnx;
						totPlacedBidAmt = placedBidAmt[0].total;
					}
				}
				if (type == 2 || type == 3){
					summCond.is_win = 1;
					var winAmt = await MarketBids.aggregate([
						{ $match: summCond },
						{
							$lookup: {
								from: 'users',
								let: { 'user_id': '$user_id' },
								pipeline: [
									{
										"$match": {
											"$expr": { "$eq": ["$_id", "$$user_id"] },
										},
									},
									{ $project: { _id: 1, mobile_no: 1, country_code: 1 } }
								],
								as: 'user_id'
							}
						},

						{
							$match: { 'user_id.mobile_no': { $regex: new RegExp(search), $options: "i" } }
						},
						{ "$group": { "_id": null, "total": { "$sum": "$win_amount" }, "tot_tnx": { "$count": {} } } }
					]);
					console.log(431, winAmt);
					if (winAmt.length > 0) {
						//totTnx += winAmt[0].tot_tnx;
						if (totTnx == 0){
							totTnx += winAmt[0].tot_tnx;
						}
						totWinAmt = winAmt[0].total;
					}
				}
				sendd.summTnx = { totTnx: totTnx, totPlacedBidAmt: totPlacedBidAmt, totWinAmt: totWinAmt };
                return res.json(sendd);
            }).catch(function (err) {
                console.log(err);
            });
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error, data: {} });
        }
    })();
}
exports.getColorGameReport = (req, res) => {
    (async () => {
        try {
			var { page, size, searchDate, searchDrawNo, searchType, searchMobileNo } 	= req.body;

			var condition 					= { deleted:false };
			var summCond 					= { deleted:false };
			if(typeof searchDate !== 'undefined' && searchDate != ''){
				let date1 					= convertToUTC(searchDate + ' 00:00:00');
				let date2 					= convertToUTC(searchDate + ' 23:59:59');
				condition.createdAt 		= { $gte: new Date(date1), $lte: new Date(date2) };
				summCond.createdAt 			= { $gte: new Date(date1), $lte: new Date(date2) };
            }
            if(typeof searchType !== 'undefined' && searchType != ''){
				type 						= parseInt(searchType);
				if (type == 1){ /* placed bid */
					condition.is_win 		= { $in: [0,2] };
					summCond.is_win 		= { $in: [0,2] };
				} else if (type == 2) { /* win */
					condition.is_win 		= 1;
					summCond.is_win 		= 1;
				}
			}
			if(typeof searchMobileNo === 'undefined' ){
            	searchMobileNo 				= '';
            }
            if(typeof searchDrawNo === 'undefined' ){
            	searchDrawNo 				= '';
            }

			page 							= page - 1;
            const { limit, offset } 		= getPagination(page, size);
            var aggregate           		= ColorBids.aggregate([
            	{ $match: condition },
            	{ $lookup: {
                    from: 'draws',
                    let:{'draw_id':'$draw_id'},
                    pipeline:[
                        {
                            "$match": {
                            "$expr": { "$eq": [ "$_id", "$$draw_id" ] },
                            },
                        },
                        { $project : { _id:1,draw_no:1 } }
                    ],
                    as: 'draw_id',
                }},
            	{ $lookup: {
                    from: 'users',
                    let:{'user_id':'$user_id'},
                    pipeline:[
                        {
                            "$match": {
                            "$expr": { "$eq": [ "$_id", "$$user_id" ] },
                            },
                        },
                        { $project : { _id:1,mobile_no:1,country_code:1 } }
                    ],
                    as: 'user_id'
                }},
                {
                    $match: { 'user_id.mobile_no': { $regex: new RegExp(searchMobileNo), $options: "i" } }
                },
                {
                    $match: { 'draw_id.draw_no': { $regex: new RegExp(searchDrawNo), $options: "i" } }
                },
                {
                    $project:{
                        _id:1,
                        draw_id:{ "$arrayElemAt": [ "$draw_id", 0 ] },
                        user_id:{ "$arrayElemAt": [ "$user_id", 0 ] },
                        bid_num:1,
                        amount:1,
                        is_win:1,
                        win_amount:1,
                        createdAt:1,
                    }
                },
                {
                    $sort: { createdAt: -1 }
                }
            ]);
            await ColorBids.aggregatePaginate(aggregate, {
                limit,
                offset,
            }).then(async(resopnse) => {
                let sendd               	= getRespPagi(resopnse, 'Get Color Bid List Successfully');

                let totPlacedBidAmt 		= 0;
                let totWinAmt 				= 0; 
                let totTnx 					= 0;

                if(typeof searchType !== 'undefined'){
                	if (searchType === '1' || searchType === '3') {
						var placedBidAmt 	= await ColorBids.aggregate([
							{ $match: summCond },
							{ 
								$lookup: {
			                    	from: 'draws',
			                    	let:{'draw_id':'$draw_id'},
			                    	pipeline:[
			                        	{
			                            	"$match": {
			                            		"$expr": { "$eq": [ "$_id", "$$draw_id" ] },
			                            	},
			                        	},
			                        	{ $project : { _id:1,draw_no:1 } }
			                    	],
			                    	as: 'draw_id',
			                	}
			                },
							{
								$lookup: {
									from: 'users',
									let: { 'user_id': '$user_id' },
									pipeline: [
										{
											"$match": {
												"$expr": { "$eq": ["$_id", "$$user_id"] },
											},
										},
										{ $project: { _id: 1, mobile_no: 1, country_code: 1 } }
									],
									as: 'user_id'
								}
							},
							{
								$match: { 'user_id.mobile_no': { $regex: new RegExp(searchMobileNo), $options: "i" } }
							},
							{
			                    $match: { 'draw_id.draw_no': { $regex: new RegExp(searchDrawNo), $options: "i" } }
			                },
							{ "$group": { "_id": null, "total": { "$sum": "$amount" }, "tot_tnx": { "$count": {} } } }
						]);
						if (placedBidAmt.length > 0) {
							totTnx 			+= placedBidAmt[0].tot_tnx;
							totPlacedBidAmt = placedBidAmt[0].total;
						}
					}
					if (searchType === '2' || searchType === '3'){
						var winAmt 			= await ColorBids.aggregate([
							{ $match: summCond },
							{ 
								$lookup: {
			                    	from: 'draws',
			                    	let:{'draw_id':'$draw_id'},
			                    	pipeline:[
			                        	{
			                            	"$match": {
			                            		"$expr": { "$eq": [ "$_id", "$$draw_id" ] },
			                            	},
			                        	},
			                        	{ $project : { _id:1,draw_no:1 } }
			                    	],
			                    	as: 'draw_id',
			                	}
			                },
							{
								$lookup: {
									from: 'users',
									let: { 'user_id': '$user_id' },
									pipeline: [
										{
											"$match": {
												"$expr": { "$eq": ["$_id", "$$user_id"] },
											},
										},
										{ $project: { _id: 1, mobile_no: 1, country_code: 1 } }
									],
									as: 'user_id'
								}
							},
							{
								$match: { 'user_id.mobile_no': { $regex: new RegExp(searchMobileNo), $options: "i" } }
							},
							{
			                    $match: { 'draw_id.draw_no': { $regex: new RegExp(searchDrawNo), $options: "i" } }
			                },
							{ "$group": { "_id": null, "total": { "$sum": "$win_amount" }, "tot_tnx": { "$count": {} } } }
						]);
						if (winAmt.length > 0) {
							if (totTnx == 0){
								totTnx 		+= winAmt[0].tot_tnx;
							}
							totWinAmt 		= winAmt[0].total;
						}
					}
                }

                let resultData 				= await Draws.aggregate([
				  		{ "$match": { "draw_no": searchDrawNo }},
					  	{ 
					  		"$lookup": {
						    	"from": "color_results",
						    	"let": { "color_results_id": "$_id" },
						    	"pipeline": [
						      		{ 
						      			"$match": {
						        			"$expr": { "$eq": ["$draw_id", "$$color_results_id" ] }
						      			}
						      		}
						    	],
						    	"as": "color_results"
					  		}
					  	},
				  		// { $unwind: '$color_results' },
				  		//{ "$project": { "draw_no": 1, "color_results":1 }}
				]);

                sendd.result 						= { draw_no: searchDrawNo, draw_result:'', draw_status:0 };
				if (resultData.length > 0){
					sendd.result.draw_no 			= resultData[0].draw_no;
					sendd.result.draw_status 		= 1;
					if(resultData[0].color_results.length > 0){
						sendd.result.draw_result 	= resultData[0].color_results[0];
						sendd.result.draw_status 	= 2;
					}
			    }

				sendd.summTnx 						= { totTnx: totTnx, totPlacedBidAmt: totPlacedBidAmt, totWinAmt: totWinAmt };
                return res.json(sendd);
            }).catch(function (err) {
                console.log(err);
            });
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error, data: {} });
        }
    })();
}
function getMainNo(bidNo) {
	let zeroArr = [127,136,145,190,235,280,370,389,460,479,569,578,118,226,244,299,334,488,668,677,550,0];
	let oneArr = [137,128,146,236,245,290,380,470,489,560,678,579,119,155,227,335,344,399,588,669,100,777];
	let twoArr = [129,138,147,156,237,246,345,390,480,570,589,679,110,228,255,336,499,660,688,778,200,444];
	let threeArr = [120,139,148,157,238,247,256,346,490,580,670,689,166,229,337,355,445,599,779,788,300,111];
	let fourArr = [130,149,158,167,239,248,257,347,356,590,680,789,112,220,266,338,446,455,699,770,400,888];
	let fiveArr = [140,159,168,230,249,258,267,348,357,456,690,780,113,122,177,339,366,447,799,889,500,555];
	let sixArr = [123,150,169,178,240,259,268,349,358,367,457,790,114,277,330,448,466,556,880,899,600,222];
	let sevenArr = [124,160,179,250,269,278,340,359,368,458,467,890,115,133,188,223,377,449,557,566,700,999];
	let eightArr = [125,134,170,189,260,279,350,369,378,459,468,567,116,224,233,288,440,477,558,990,800,666];
	let nineArr = [126,135,180,234,270,289,360,379,450,469,478,568,117,144,199,225,388,559,577,667,900,333];
	bidNo = parseInt(bidNo);
	if (zeroArr.indexOf(bidNo) > -1){
		return { index: 0, subindex: zeroArr.indexOf(bidNo)};
	} else if (oneArr.indexOf(bidNo) > -1){
		return { index: 1, subindex: oneArr.indexOf(bidNo) };
		//return 1;
	} else if (twoArr.indexOf(bidNo) > -1){
		return { index: 2, subindex: twoArr.indexOf(bidNo) };
		//return 2;
	} else if (threeArr.indexOf(bidNo) > -1) {
		return { index: 3, subindex: threeArr.indexOf(bidNo) };
		//return 3;
	} else if (fourArr.indexOf(bidNo) > -1) {
		return { index: 4, subindex: fourArr.indexOf(bidNo) };
		//return 4;
	} else if (fiveArr.indexOf(bidNo) > -1) {
		return { index: 5, subindex: fiveArr.indexOf(bidNo) };
		//return 5;
	} else if (sixArr.indexOf(bidNo) > -1) {
		return { index: 6, subindex: sixArr.indexOf(bidNo) };
		//return 6;
	} else if (sevenArr.indexOf(bidNo) > -1) {
		return { index: 7, subindex: sevenArr.indexOf(bidNo) };
		//return 7;
	} else if (eightArr.indexOf(bidNo) > -1) {
		return { index: 8, subindex: eightArr.indexOf(bidNo) };
		//return 8;
	} else if (nineArr.indexOf(bidNo) > -1) {
		return { index: 9, subindex: nineArr.indexOf(bidNo) };
		//return 9;
	} else {
		return { index: 0, subindex: 0 };
		return 0;
	}
}