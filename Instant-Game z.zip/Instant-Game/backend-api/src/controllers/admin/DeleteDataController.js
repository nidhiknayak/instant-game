const NoticeBoard = require('../../models/NoticeBoard');
const MarketBids = require('../../models/MarketBids');
const MarketResults = require('../../models/MarketResults');
const { Markets, MarketTimeTable } = require('../../models/Markets');
const Transactions = require('../../models/Transactions');
const {UserBanks} = require('../../models/UserBanks');
const {UserDeviceTokens} = require('../../models/UserDeviceTokens');
const Users = require('../../models/Users');
const Withdrawals = require('../../models/Withdraw');
const Notification = require('../../models/Notification');
exports.truncateData = (req, res) => {
	(async () => {
		try {
			//let resp = await NoticeBoard.deleteMany({});
			let resp2 = await MarketBids.deleteMany({});
			let resp3 = await MarketResults.deleteMany({});
			let resp4 = await Markets.deleteMany({});
			let resp5 = await MarketTimeTable.deleteMany({});
			let resp6 = await Transactions.deleteMany({});
			let resp7 = await UserBanks.deleteMany({});
			let resp8 = await UserDeviceTokens.deleteMany({});
			let resp9 = await Users.deleteMany({});
			let resp10 = await Withdrawals.deleteMany({});
			let resp11 = await Notification.deleteMany({});
			let data = {
				market_bids: resp2,
				market_results: resp3,
				markets: resp4,
				market_timetable: resp5,
				transactions: resp6,
				user_banks: resp7,
				user_device_token: resp8,
				users: resp9,
				withdraw: resp10,
				notification: resp11,
			};
			return res.json(data);
		} catch (error) {
			console.log(error);
			return res.json({ status: 0, message: error });
		}
	})();
}