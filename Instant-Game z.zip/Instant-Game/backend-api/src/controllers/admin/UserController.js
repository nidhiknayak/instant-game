var mongoose = require('mongoose');
const Users = require("../../models/Users");
var Transactions = require('../../models/Transactions');
const MarketBids = require("../../models/MarketBids");
const MarketResults = require("../../models/MarketResults");
const { MarketTimeTable  } = require("../../models/Markets");
var { UserBanks } = require('../../models/UserBanks');
const { getPagination, getRespPagi, getGameArray, getWeekDay, allowPlaceBid, isAllowToPlaceBid, getDateFormat, getMinusOneDayDate } = require('../../services/common');
const { isValid } = require('../../services/validation');
const { getMoneyList } = require('../../services/money_val');
const { addBonusReferalAmount } = require('../UserProfileController');

exports.list = async (req, res) => {
    (async () => {
        try{
            let { page, size, search, status, city, state, country } = req.body;
            var condition = search ? { $or :[ 
                {firstname: { $regex: new RegExp(search), $options: "i" }},
                {lastname: { $regex: new RegExp(search), $options: "i"}},
                {email: { $regex: new RegExp(search), $options: "i" }},
                {country_code: { $regex: new RegExp(search), $options: "i" }},
                {mobile_no: { $regex: new RegExp(search), $options: "i" }}
            ],deleted:false } : { deleted:false };
            //condition = {};
            page = page - 1;
            const { limit, offset } = getPagination(page, size);
            if (status != ''){
                condition.status = parseInt(status);
            }
            const cityStateArr = [];
            if(city){
                cityStateArr.push({ city: { $regex: new RegExp(city), $options: "i" }});
            }
            if(state){
                cityStateArr.push({ state: { $regex: new RegExp(state), $options: "i" }});
            }
            if(country){
                cityStateArr.push({ country: { $regex: new RegExp(country), $options: "i" }});
            }
            if(cityStateArr.length > 0){
                condition['$or']= cityStateArr;
            }
            var aggregate = Users.aggregate([
                    { $match: condition },
                    {
                        $lookup:
                        {
                            from: "user_banks",
                            localField: "_id",
                            foreignField: "user_id",
                            as: "bank_det"
                        }
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ]);
                await Users.aggregatePaginate(aggregate, {
                    limit,
                    offset,
                }).then((users) => {
                    let sendd = getRespPagi(users, 'User data find successfully');
                    return res.json(sendd);
                });
            } catch (error) {
                console.log(error);
                return res.json({ status: 0, message: error });
            }
    })();
};

exports.save = async (req, res) => {
    (async () => {
        try{
            if (!await isValid(req.body.mobile_no)) {
				return res.json({ status: 0, message: 'mobile_no is required' });
			}
            if (!await isValid(req.body.country_code)) {
				return res.json({ status: 0, message: 'country_code is required' });
			}
            if(!await isValid(req.body.status)){
                return res.json({ status: 0, message: 'status is required' });
            }
            let user_mobile_exist_count = await Users.find({mobile_no : req.body.mobile_no}).countDocuments();
            if(user_mobile_exist_count > 0){
                return res.json({status:0, message:'User already exist using this mobile number'});
            }
            let email = null;
            if (typeof req.body.email !== 'undefined' && req.body.email != '' && req.body.email != null){
                email = req.body.email;
                let user_email_exist_count = await Users.find({email : req.body.email}).countDocuments();
                if(user_email_exist_count > 0){
                    return res.json({status:0, message:'User already exist using this email.'});
                }
            }
            return new Users({
                firstname           : req.body.firstname,
                lastname            : null,//req.body.lastname,
                email               : email,
                country_code        : req.body.country_code,
                mobile_no           : req.body.mobile_no,
                status              : req.body.status,
                created_by          : req.userDet._id
            }).save(function (err, user) {
                if (err) return res.json({status:0, message:err.message});
                return res.json({status:1, message:'User created successfully', data : user });
            });
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error });
        }
    })();
};

exports.edit = async (req, res) => {
    (async () => {
        try{
            if (!await isValid(req.params.id)) {
				return res.json({ status: 0, message: 'ID is required' });
			}
            let user_data = await Users.findOne({_id:req.params.id});
            if(user_data){
                return res.json({status:1, message:'Slider data find successfully.',data:user_data});
            }
            return res.json({status:0, message:'No user data found.' });
        } catch (error) {
            return res.json({ status: 0, message: error });
        }
    })();
};

exports.update = async (req, res) => {
    (async () => {
        try{
            if (!await isValid(req.body.id)) {
				return res.json({ status: 0, message: 'ID is required' });
			}
            if (!await isValid(req.body.mobile_no)) {
				return res.json({ status: 0, message: 'mobile_no is required' });
			}
            if (!await isValid(req.body.country_code)) {
				return res.json({ status: 0, message: 'country_code is required' });
			}
            if(!await isValid(req.body.status)){
                return res.json({ status: 0, message: 'status is required' });
            }
            let user_data = await Users.findOne({_id:req.body.id});
            let user_mobile_exist_count = await Users.where({mobile_no : req.body.mobile_no,_id:{$ne:req.body.id}}).find().countDocuments();
            if(user_mobile_exist_count > 0){
                return res.json({status:0, message:'User already exist using this mobile number'});
            }
            let email = null;
            if (typeof req.body.email !== 'undefined' && req.body.email != '' && req.body.email != null) {
                email = req.body.email;
                let user_email_exist_count = await Users.where({email : req.body.email,_id:{$ne:req.body.id}}).find().countDocuments();
                if(user_email_exist_count > 0){
                    return res.json({status:0, message:'User already exist using this email.'});
                }
            }
            if(user_data){
                let update_user = await Users.updateOne({ _id: req.body.id }, {
                    firstname           : req.body.firstname,
                    lastname            : null,//req.body.lastname,
                    email               : email,
                    country_code        : req.body.country_code,
                    mobile_no           : req.body.mobile_no,
                    status              : req.body.status,
                    updated_by          : req.userDet._id
                });
                if(update_user.modifiedCount > 0){
                    return res.json({status:1, message:'User updated successfully.'});
                }
                return res.json({status:0, message:'Please try again.' });
            }
            return res.json({status:0, message:'No user data found.' });
        } catch (error) {
            return res.json({ status: 0, message: error });
        }
    })();
};

exports.delete = (req, res) => {
    (async () => {
        try{
            if (!await isValid(req.params.id)) {
				return res.json({ status: 0, message: 'ID is required' });
			}
            let user_data = await Users.findOne({_id:req.params.id});
            if(user_data){
                let user_slider = await Users.delete({_id:req.params.id},req.userDet._id);
                if(user_slider.modifiedCount > 0){
                    return res.json({status:1, message:'User data deleted successfully.'});
                }
                return res.json({status:0, message:'User data not deleted successfully.'});
            }
            return res.json({status:0, message:'No user data found.' });
        } catch (error) {
            return res.json({ status: 0, message: error });
        }
    })();
};

exports.status_change = async (req, res) => {
    (async () => {
        try{
            if (!await isValid(req.body.id)) {
				return res.json({ status: 0, message: 'ID is required' });
			}
            if(!await isValid(req.body.status)){
                return res.json({ status: 0, message: 'status is required' });
            }
            let user_data = await Users.findOne({_id:req.body.id});
            if(user_data){
                let update_record = {};
                let message = '';
                if(req.body.is_widthraw == 1){
                    update_record = {
                        is_withdraw_allow          : parseInt(req.body.status),
                        updated_by      : req.userDet._id
                    }
                    message = 'User withdrawal request change successfully.';
                }else{
                    update_record = {
                        status          : req.body.status,
                        updated_by      : req.userDet._id
                    };
                    message = 'User status change successfully.';
                }
                let update_user = await Users.updateOne({ _id: req.body.id }, update_record);
                if(update_user.modifiedCount > 0){
                    return res.json({status:1, message:message});
                }
                return res.json({status:0, message:'Please try again.' });
            }
            return res.json({status:0, message:'No user data found.' });
        } catch (error) {
            return res.json({ status: 0, message: error });
        }
    })();
};

exports.add_wallet_amount = async (req, res) => {
    (async () => {
        try{
            if (!await isValid(req.body.amount)) {
				return res.json({ status: 0, message: 'amount is required' });
			}
            if (!await isValid(req.body.user_id)) {
				return res.json({ status: 0, message: 'user_id is required' });
			}
            const userDet = await Users.findById(req.body.user_id);
            if(req.body.wallet_type!=1){
                const add_wallet = await Users.updateOne({ _id: req.body.user_id },{$inc:{wallet:parseInt(req.body.amount)}});
                if(add_wallet.modifiedCount > 0){
                    /* let total_sum = await Transactions.aggregate([
                        { 
                            $match: {
                                user_id:mongoose.Types.ObjectId(req.body.user_id)
                            }
                        },
                        { 
                            $group: {
                                _id : "$user_id", sum : { $sum: "$amount" } 
                            } 
                        }
                    ]);
                    let post_balance = 0;
                    if(total_sum.length > 0){
                        post_balance += parseFloat(total_sum[0].sum);
                        post_balance += parseFloat(req.body.amount);
                    }else{
                        post_balance = req.body.amount;
                    } */
                    let post_balance = 0;
                    if(userDet){
                        post_balance = parseInt(userDet.wallet) + parseFloat(req.body.amount);
                    }else{
                        post_balance = req.body.amount;
                    }
                    const totTrans = await Transactions.find({ user_id: userDet._id, tnx_type: { $in: [4,5]}, entry_type: 1, wallet_type: 2 });
                    return new Transactions({
                        user_id         : req.body.user_id,
                        amount          : req.body.amount,
                        final_amount    : req.body.amount,
                        post_balance    : post_balance,
                        tnx_type        : 4,//added by self
                        wallet_type     : 2,//simple wallet
                        details         : "Refund", //Added by admin
                        entry_type      : 1,//credit entry
                        created_by      : req.userDet._id
                    }).save(async function(err, transaction) {
                        if (err) return res.json({status:0, message:err.message});
                        /* Add 5% amount to bonus wallet 27-12-2023 start */
                        /* Referal User Will Get Amount to bonus wallet when user add amount to wallet first time 29-12-2023 Start */
                        //Added below line on 23-02-24
                        await addBonusReferalAmount(1, req.body.amount, userDet, transaction._id, totTrans);
                        /* Referal User Will Get Amount to bonus wallet when user add amount to wallet first time 29-12-2023 End */
                        /* Add 5% amount to bonus wallet 27-12-2023 End */
                        
                        return res.json({ status: 1, message: 'Amount added to wallet successfully.', data: {}});
                    });             
                }
                return res.json({ status: 0, message: 'No user found.' });
            }else{
                const add_wallet = await Users.updateOne({ _id: req.body.user_id },{$inc:{wallet_wining:parseInt(req.body.amount)}});
                if(add_wallet.modifiedCount > 0){
                    /* let total_sum = await Transactions.aggregate([
                        { 
                            $match: {
                                user_id:mongoose.Types.ObjectId(req.body.user_id)
                            }
                        },
                        { 
                            $group: {
                                _id : "$user_id", sum : { $sum: "$amount" } 
                            } 
                        }
                    ]);
                    let post_balance = 0;
                    if(total_sum.length > 0){
                        post_balance += parseFloat(total_sum[0].sum);
                        post_balance += parseFloat(req.body.amount);
                    }else{
                        post_balance = req.body.amount;
                    } */
                    let post_balance = 0;
                    if(userDet){
                        post_balance = parseInt(userDet.wallet_wining) + parseFloat(req.body.amount);
                    }else{
                        post_balance = req.body.amount;
                    }
                    return new Transactions({
                        user_id         : req.body.user_id,
                        amount          : req.body.amount,
                        final_amount    : req.body.amount,
                        post_balance    : post_balance,
                        tnx_type        : 4,//added by self
                        wallet_type     : 1,//winning wallet
                        details         : "Refund", //Added By Admin
                        entry_type      : 1,//credit entry
                        created_by      : req.userDet._id
                    }).save(function (err, transaction) {
                        if (err) return res.json({status:0, message:err.message});
                        return res.json({status:1, message:'Amount added to winning wallet successfully.'});
                    });             
                }
                return res.json({ status: 0, message: 'No user found.' });
            }
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error.message });
        }
    })();
};
exports.deduct_wallet_amount = async (req, res) => {
    (async () => {
        try{
            if (!await isValid(req.body.amount)) {
				return res.json({ status: 0, message: 'amount is required' });
			}
            if (!await isValid(req.body.user_id)) {
				return res.json({ status: 0, message: 'user_id is required' });
			}
            const userDet = await Users.findById(req.body.user_id);
            if(req.body.wallet_type!=1){
                const deduct_wallet = await Users.updateOne({ _id: req.body.user_id },{$inc:{wallet:'-'+parseInt(req.body.amount)}});
                if(deduct_wallet.modifiedCount > 0){
                    /* let total_sum   = await Transactions.aggregate([
                        { 
                            $match: {
                                user_id:mongoose.Types.ObjectId(req.body.user_id)
                            }
                        },
                        { 
                            $group: {
                                _id : "$user_id", sum : { $sum: "$amount" } 
                            } 
                        }
                    ]);
                    let post_balance = 0;
                    if(total_sum.length > 0){
                        post_balance += total_sum[0].sum;
                        post_balance += req.body.amount;
                    }else{
                        post_balance = req.body.amount;
                    } */
                    let post_balance = 0;
                    if(userDet){
                        post_balance = parseInt(userDet.wallet) - parseFloat(req.body.amount);
                    }else{
                        post_balance = req.body.amount;
                    }
                    return new Transactions({
                        user_id         : req.body.user_id,
                        amount          : req.body.amount,
                        final_amount    : req.body.amount,
                        post_balance    : post_balance,
                        tnx_type        : 8,//added by self
                        wallet_type     : 2,//simple wallet
                        details         : "Deduct by admin",
                        entry_type      : 2,//debit entry
                        created_by      : req.userDet._id
                    }).save(function (err, transaction) {
                        if (err) return res.json({status:0, message:err.message});
                        return res.json({status:1, message:'Amount deducted to wallet successfully.'});
                    });             
                }
                return res.json({ status: 0, message: 'No user found.' });
            }else{
                const deduct_wallet = await Users.updateOne({ _id: req.body.user_id },{$inc:{wallet_wining:'-'+parseInt(req.body.amount)}});
                if(deduct_wallet.modifiedCount > 0){
                    /* let total_sum   = await Transactions.aggregate([
                        { 
                            $match: {
                                user_id:mongoose.Types.ObjectId(req.body.user_id)
                            }
                        },
                        { 
                            $group: {
                                _id : "$user_id", sum : { $sum: "$amount" } 
                            } 
                        }
                    ]);
                    let post_balance = 0;
                    if(total_sum.length > 0){
                        post_balance += total_sum[0].sum;
                        post_balance += req.body.amount;
                    }else{
                        post_balance = req.body.amount;
                    } */
                    let post_balance = 0;
                    if(userDet){
                        post_balance = parseInt(userDet.wallet_wining) - parseFloat(req.body.amount);
                    }else{
                        post_balance = req.body.amount;
                    }
                    return new Transactions({
                        user_id         : req.body.user_id,
                        amount          : req.body.amount,
                        final_amount    : req.body.amount,
                        post_balance    : post_balance,
                        tnx_type        : 8,//added by self
                        wallet_type     : 1,//winning wallet
                        details         : "Deduct by admin",
                        entry_type      : 2,//debit entry
                        created_by      : req.userDet._id
                    }).save(function (err, transaction) {
                        if (err) return res.json({status:0, message:err.message});
                        return res.json({status:1, message:'Amount deducted to winning wallet successfully.'});
                    });             
                }
                return res.json({ status: 0, message: 'No user found.' });
            }
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error.message });
        }
    })();
};
/* 12-10-2021 */
exports.getUserBidList = async (req, res) => {
    (async () => {
        try {
            var { page, size, search, user_id } = req.body;
            /* var condition = search ? {
                $or: [
                    { firstname: { $regex: new RegExp(search), $options: "i" } },
                    { lastname: { $regex: new RegExp(search), $options: "i" } },
                    { email: { $regex: new RegExp(search), $options: "i" } },
                    { country_code: { $regex: new RegExp(search), $options: "i" } },
                    { mobile_no: { $regex: new RegExp(search), $options: "i" } }
                ], deleted: false 
            } : { deleted: false }; */
            var condition = { user_id: user_id };
            page = page - 1;
            const { limit, offset } = getPagination(page, size);
            let userDet = await Users.findOne({ _id: user_id});
            return await MarketBids.paginate(condition, { limit, offset, populate: { path: 'market_id', select: "_id name" },sort:{createdAt:-1} }).then((users) => {
                let page = users.page;
                let per_page = users.limit;
                let total = users.totalDocs;
                let total_pages = users.totalPages;
                let docs = [];
                //console.log(352, users.docs.length, (users.docs.length > 0));
                let openGames = getGameArray();
                let closeGames = getGameArray(true);
                if (users.docs.length > 0){
                    (async () => {
                        docs = await Promise.all(users.docs.map(async (row) => {
                            if (row.market_id != null) {
                                let week_day_type = new Date().getDay();
                                let cond = { market_id: row.market_id._id, week_day_type: week_day_type };
                                let newRes = await MarketTimeTable.findOne(cond).then(async (ress)=>{

                                    let whMar = { market_id: row.market_id._id };
                                    whMar.result_date = new Date(await getMinusOneDayDate(getDateFormat(), "10:00:00", "11:00:00", true));
                                    let resultDet = await MarketResults.findOne(whMar);
                                    return {
                                        _id: row._id,
                                        market_id: row.market_id,
                                        user_id: row.user_id,
                                        game_type_id: row.game_type_id,
                                        panna_1: row.panna_1,
                                        panna_2: row.panna_2,
                                        amount: row.amount,
                                        is_win: row.is_win,
                                        win_amount: row.win_amount,
                                        report_date: row.report_date,
                                        deleted: row.deleted,
                                        createdAt: row.createdAt,
                                        updatedAt: row.updatedAt,
                                        timeTbl: ress,
                                        result: resultDet,
                                    };
                                    //return row.timeTbl = ress;
                                });
                                //console.log(368, newRes);
                                return newRes;
                            }
                        }));
                        
                        users.docs = await docs.filter(v => {
                            return (v !== undefined && v !== null)
                        });
                        
                        return res.json({ page: page, per_page: per_page, total: total, total_pages: total_pages, status: 1, message: 'User bid data get successfully.', data: users, openGames: openGames, closeGames: closeGames, userDet: userDet });
                    })();
                } else {
                    return res.json({ page: page, per_page: per_page, total: total, total_pages: total_pages, status: 1, message: 'User bid data get successfully.', data: users, openGames: openGames, closeGames: closeGames, userDet: userDet });
                }
            });
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error });
        }
    })();
};

exports.getUserWalletHist = async (req, res) => {
    (async () => {
        try {
            const Transactions = require('../../models/Transactions');
            var { page, size, search, user_id } = req.body;
            var condition = { user_id: user_id, pay_status:1 };//, tnx_type: { $in: [4,5] }
            page = page - 1;
            const { limit, offset } = getPagination(page, size);
            return await Transactions.paginate(condition, { limit, offset, sort: { createdAt: -1 } }).then((users) => {
            //return await Transactions.find(condition).then((users) => {
                let page = users.page;
                let per_page = users.limit;
                let total = users.totalDocs;
                let total_pages = users.totalPages;
                return res.json({ page: page, per_page: per_page, total: total, total_pages: total_pages, status: 1, message: 'User wallet history data get successfully.', data: users });
            });
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error, data:{} });
        }
    })();
};

/* 12-11-2021 */
exports.updateUserBid = (req, res) => {
    //(0 = SingleOpenDigit, 1 SingleCloseDigit, 2 = Jodi, 3 SingleOpenPanna, 4 Double OpenPanna, 5 TripleopenPanna, 6 SingleClosePanna, 7 DoubleClosePanna 8 TripleClosePanna)
    (async () => {
        try {
            if (!await isValid(req.body._id)) {
                return res.json({ status: 0, message: 'Bid ID is required', data: {} });
            }
            if (!await isValid(req.body.market_id)) {
                return res.json({ status: 0, message: 'Market ID is required', data: {} });
            }
            if ((req.body.game_type_id == '' && req.body.game_type_id != 0) || req.body.game_type_id == null) {
                return res.json({ status: 0, message: 'Game Type Id is required', data: {} });
            }
            let _id = req.body._id;
            let market_id = req.body.market_id;
            let game_type_id = req.body.game_type_id;
            let panna_1 = req.body.panna_1;
            let panna_2 = (req.body.panna_2 != null)?req.body.panna_2:null;

            var week_day_type = getWeekDay();
            week_day_type = (week_day_type == 0) ? 7 : week_day_type;
            let isMarketTimTbl = await MarketTimeTable.findOne({ market_id: market_id, week_day_type: week_day_type });
            if (!isMarketTimTbl) {
                return res.json({ status: 0, message: 'Timetable Not Found, Not Allowed To Placed Bid', data: {} });
            }

            if (isMarketTimTbl.status == 0) {
                return res.json({ status: 0, message: 'Market Is In Active, Not Allowed To Placed Bid', data: {} });
            }
            
            let openGames = getGameArray();
            let closeGames = getGameArray(true);
            game_type_id = parseInt(game_type_id);
            console.log(108, (openGames.indexOf(game_type_id)), openGames);
            /* if (openGames.indexOf(game_type_id) > -1) {
                if (!await allowPlaceBid(isMarketTimTbl.bid_open_time, isMarketTimTbl.bid_close_time)) {
                    return res.json({ status: 0, message: 'Not Allow To Update Bid For Open Games When Current Time Greater Then Bid Start Time ', data: {} });
                }
            }
            
            if (closeGames.indexOf(game_type_id) > -1) {
                if (!await allowPlaceBid(isMarketTimTbl.bid_open_time, isMarketTimTbl.bid_close_time, true)) {
                    return res.json({ status: 0, message: 'Not Allow To Update Bid When Current Time Greater Then Bid End Time', data: {} });
                }
            } */

            var cdate = getDateFormat();
            let result_date = new Date(await getMinusOneDayDate(cdate, "10:00:00", "11:00:00", true));
            let wher = { market_id: mongoose.Types.ObjectId(market_id), result_date: result_date };
            let resData = await MarketResults.findOne(wher);

            if (resData != null) {
                openGames  = [0, 3, 4, 5];
                closeGames = [1, 2, 6, 7, 8, 9, 10, 11];
                if (openGames.indexOf(game_type_id) > -1 && resData.is_open_published == 1) {
                    return res.json({ status: 0, message: 'Result Decalred, Not Allow To Update Bid', data: {} });
                } else if (closeGames.indexOf(game_type_id) > -1 && resData.is_published == 1) {
                    return res.json({ status: 0, message: 'Result Decalred, Not Allow To Update Bid', data: {} });
                }
                /* if (!await isAllowToPlaceBid(resData, game_type_id)) {
                    return res.json({ status: 0, message: 'Result Decalred, Not Allow To Update Bid', data: {} });
                } */
            }
            let userBid = await MarketBids.findOne({_id:_id});
            if (userBid){
                let update = { panna_1: panna_1 };
                let findString = `${userBid.panna_1}`;
                let replaceString = `${panna_1}`;
                if (panna_2){
                    update.panna_2 = panna_2;
                    findString = `${userBid.panna_1}-${userBid.panna_2}`;
                    replaceString = `${panna_1}-${panna_2}`;
                }
                await MarketBids.updateOne({ _id: _id }, update);
                
                /* Update Transaction Detail Start 04-01-24 */
                const transDetail = await Transactions.findOne({ refe_id: _id });
                if(transDetail){
                    let stringToReplace = transDetail.details;
                    const finalString = stringToReplace.replace(findString, replaceString);
                    await Transactions.updateOne({ _id: transDetail._id }, { details: finalString });
                }
                /* Update Transaction Detail End 04-01-24 */
                return res.json({ status: 1, message: 'Bid Updated Successfully', data: update });
            } else {
                return res.json({ status: 0, message: "Bid Not Found", data: {} });
            }
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error.message || "Something Went Wrong", data: {} });
        }
    })();
}
/* 13-11-2021 */
exports.addMoneyToWallet = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.mobile_no)) {
                return res.json({ status: 0, message: 'mobile no is required' });
            }
            if (!await isValid(req.body.amount)) {
                return res.json({ status: 0, message: 'amount is required' });
            }
            if (!await isValid(req.body.show_not_show)) {
                return res.json({ status: 0, message: 'show to user is required' });
            }
            
            let mobile_no = req.body.mobile_no;
            let amount = req.body.amount;
            let show_not_show = req.body.show_not_show;
            let user = await Users.findOne({ mobile_no: mobile_no });
            if(user){
                const totTrans = await Transactions.count({ user_id: user._id, tnx_type: { $in: [4,5] }, entry_type: 1, wallet_type: 2 });
                let post_balance = user.wallet + parseFloat(amount);
                return new Transactions({
                    user_id: user._id,
                    amount: amount,
                    final_amount: amount,
                    post_balance: post_balance,
                    show_to_user: show_not_show,
                    tnx_type: 4,//added by self
                    wallet_type: 2,//simple wallet
                    details: "Refund", //Money Added by admin
                    entry_type: 1,//credit entry
                    created_by: req.userDet._id
                }).save(async function (err, transaction) {
                    if (err) return res.json({ status: 0, message: err.message, data:{} });
                    /* Add 5% amount to bonus wallet 27-12-2023 start */
                    let updBnsWalletAmt = user.wallet_bonus;
                    let isBonusWallUpdate = false;
                    const settingDet = await getMoneyList();
					const minDepoAmtForBonus = settingDet.MIN_DEPO_AMT_FOR_BONUS;
					const referralBonusAmount = settingDet.REFERRAL_BONUS_AMOUNT;
                    if(parseInt(req.body.amount) >= minDepoAmtForBonus){
                        isBonusWallUpdate = true;
                        let fivePerBonus = (req.body.amount * 5/100);
                        fivePerBonus = Math.floor(fivePerBonus);
                        updBnsWalletAmt = (user.wallet_bonus && user.wallet_bonus > 0)?(Math.floor(user.wallet_bonus) + fivePerBonus):fivePerBonus;
                        new Transactions({
                            user_id: user._id,
                            refe_id: transaction._id,
                            amount: fivePerBonus,
                            final_amount: fivePerBonus,
                            post_balance: updBnsWalletAmt,
                            tnx_type: 9,//deposit_bonus_credited
                            wallet_type: 3,//bonus wallet
                            details: "Deposit Bonus Credited",
                            entry_type: 1,//credit entry
                            created_by: req.userDet._id
                        }).save(async function (err1, trx) {
                            //5% Bonus Credited
                        });
                    }
                    /* Add 5% amount to bonus wallet 27-12-2023 End */

                    /* Referal User Will Get Amount to bonus wallet when user add amoun to wallet first time 29-12-2023 Start */
                    if(user.refer_by){
                        const refeUser = await Users.findOne({ _id: user.refer_by });
                        if (refeUser && totTrans == 0){
                            const depobamt = referralBonusAmount;
                            const post_balance2 = (refeUser.wallet_bonus && refeUser.wallet_bonus > 0)?(Math.floor(refeUser.wallet_bonus) + Math.floor(depobamt)):Math.floor(depobamt);
                            await new Transactions({
                                user_id: refeUser._id,
                                refe_id: user._id,
                                amount: depobamt,
                                final_amount: depobamt,
                                post_balance: post_balance2,
                                tnx_type: 12,//referral_bonus_credited
                                wallet_type: 3,//bonus wallet
                                details: "Referral Bonus Credited",
                                entry_type: 1,//credit entry
                                created_by: req.userDet._id
                            }).save(async function (err, transaction) {
                                if (!err){
                                    await Users.updateOne({ _id: refeUser._id }, { wallet_bonus: post_balance2 });
                                }
                            });
                        }
                    }
                    /* Referal User Will Get Amount to bonus wallet when user add amoun to wallet first time 29-12-2023 End */
                    const updateUserWallet = { wallet: post_balance };
                    if(isBonusWallUpdate){
                        updateUserWallet.wallet_bonus = updBnsWalletAmt;
                    }
                    await Users.updateOne({ _id: user._id }, updateUserWallet);
                    return res.json({ status: 1, message: 'Money Added To Wallet Successfully', data: { post_balance: post_balance} });
                });
            } else {
                return res.json({ status: 0, message: 'Mobile No. Not Exist', data:{} });
            }
            //return res.json({ status: 0, message: 'Please try again', data:{} });
        } catch (error) {
            return res.json({ status: 0, message: error.message, data:{} });
        }
    })();
}
/* 13-01-2022 */
exports.removeBankDetail = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.user_id)) {
                return res.json({ status: 0, message: 'user id is required', data:{} });
            }
            let user_id = req.body.user_id;
            const user_bank = await UserBanks.findOne({ user_id: mongoose.Types.ObjectId(user_id) });
            if (user_bank) {
                await UserBanks.deleteMany({ user_id: user_id });
                return res.json({ status: 1, message: 'Bank detail removed successfully', data: {  } });
            } else {
                return res.json({ status: 0, message: 'Bank detail not found', data: {  } });
            }
        } catch (error) {
            return res.json({ status: 0, message: error.message, data: error });
        }
    })();
}