var mongoose = require('mongoose');
const { locales } = require("moment");
const NoticeBoard = require("../../models/NoticeBoard");
const { isValid } = require('../../services/validation');
const { getPagination, getRespPagi } = require('../../services/common');

exports.list = async (req, res) => {
    (async () => {
        try{
            let { page, size, search } = req.body;
            var condition = search ? { $or :[
                {title: {  $regex: new RegExp(search), $options: "i" }},
                {description: { $regex: new RegExp(search), $options: "i" }}],
                deleted:false 
            } : {deleted:false};
            page = page - 1;
            const { limit, offset } = getPagination(page, size);
            var aggregate = NoticeBoard.aggregate([
                { $match: condition },
                {
                    $sort: { createdAt: -1 }
                }
            ]);
            return await NoticeBoard.aggregatePaginate(aggregate,{ offset, limit }).then((notice_board) => {
                let sendd = getRespPagi(notice_board, 'Notice data find successfully');
                return res.json(sendd);
            });
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error });
        }
    })();
};

exports.save = async (req, res) => {
    (async () => {
        try{
            if (!await isValid(req.body.title)) {
				return res.json({ status: 0, message: 'title is required' });
			}
            if (!await isValid(req.body.description)) {
				return res.json({ status: 0, message: 'description is required' });
			}
            if(!await isValid(req.body.status)){
                return res.json({ status: 0, message: 'status is required' });
            }
            return new NoticeBoard({
                title           : req.body.title,
                description     : (req.body.description) ? req.body.description : null,
                status          : req.body.status,
                created_by : req.userDet._id
            }).save(function (err, notice_board) {
                if (err) return res.json({status:0, message:err.message});
                return res.json({status:1, message:'Notice board created successfully.', data : notice_board });
            });
        } catch (error) {
            return res.json({ status: 0, message: error });
        }
    })();
};

exports.status_change = async (req, res) => {
    (async () => {
        try{
            if (!await isValid(req.body.id)) {
				return res.json({ status: 0, message: 'ID is required' });
			}
            if(!await isValid(req.body.status)){
                return res.json({ status: 0, message: 'status is required' });
            }
            let notice_board_data = await NoticeBoard.findOne({_id:req.body.id});
            if(notice_board_data){
                let update_notice_board = await NoticeBoard.updateOne({ _id: req.body.id }, {
                    status          : req.body.status,
                    updated_by      : req.userDet._id
                });
                if(update_notice_board.modifiedCount > 0){
                    return res.json({status:1, message:'Notice board status change successfully.'});
                }
                return res.json({status:0, message:'Please try again.' });
            }
            return res.json({status:0, message:'No notice data found.' });
        } catch (error) {
            return res.json({ status: 0, message: error });
        }
    })();
};

exports.edit = async (req, res) => {
    (async () => {
        try{
            if (!await isValid(req.params.id)) {
				return res.json({ status: 0, message: 'ID is required' });
			}
            let notice_board_data = await NoticeBoard.findOne({_id:req.params.id});
            if(notice_board_data){
                return res.json({status:1, message:'Notice board data find successfully.',data:notice_board_data});
            }
            return res.json({status:0, message:'No notice board data found.' });
        } catch (error) {
            return res.json({ status: 0, message: error });
        }
    })();
};

exports.update = async (req, res) => {
    (async () => {
        try{
            if (!await isValid(req.body.id)) {
				return res.json({ status: 0, message: 'ID is required' });
			}
            if (!await isValid(req.body.title)) {
				return res.json({ status: 0, message: 'title is required' });
			}
            if (!await isValid(req.body.description)) {
				return res.json({ status: 0, message: 'description is required' });
			}
            if(!await isValid(req.body.status)){
                return res.json({ status: 0, message: 'status is required' });
            }
            let notice_data = await NoticeBoard.findOne({_id:req.body.id});
            if(notice_data){
                let update_notice_data = await NoticeBoard.updateOne({ _id: req.body.id }, {
                    title           : req.body.title,
                    description     : (req.body.description) ? req.body.description : '',
                    status          : req.body.status,
                    updated_by      : req.userDet._id
                });
                if(update_notice_data.modifiedCount > 0){
                    return res.json({status:1, message:'Notice board updated successfully.'});
                }
                return res.json({status:0, message:'Please try again.' });
            }
            return res.json({status:0, message:'No notice board data found.' });
        } catch (error) {
            return res.json({ status: 0, message: error });
        }
    })();
};

exports.delete = (req, res) => {
    (async () => {
        try{
            if (!await isValid(req.params.id)) {
				return res.json({ status: 0, message: 'ID is required' });
			}
            let notice_board_data = await NoticeBoard.findOne({_id:req.params.id});
            if(notice_board_data){
                let delete_notice_board = await NoticeBoard.delete({_id:req.params.id},req.userDet._id);
                if(delete_notice_board.modifiedCount > 0){
                    return res.json({status:1, message:'Notice board data deleted successfully.'});
                }
                return res.json({status:0, message:'Notice board data not deleted successfully.'});
            }
            return res.json({status:0, message:'No notice board data found.' });
        } catch (error) {
            return res.json({ status: 0, message: error });
        }
    })();
};