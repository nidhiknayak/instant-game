var mongoose = require('mongoose');
const { Markets, MarketTimeTable } = require('../../models/Markets');
const GameRatios = require('../../models/GameRatios');
const MarketResults = require('../../models/MarketResults');
const MarketRefunds = require('../../models/MarketRefunds');
const MarketBids = require('../../models/MarketBids');
const Transactions = require('../../models/Transactions');
const Users = require('../../models/Users');
const { isValid } = require('../../services/validation');
const { declareResult } = require('../../services/DeclareResult');
const { getDateFormat, getWeekDay, convertToUTC, getDayNameArr, allowPublishRes, getMinusOneDayDate, sendAndroid, getWeekDayResult } = require('../../services/common');

exports.getMarketList = (req, res) => {
    (async () => {
        try {

            /* var resopnse = await Markets.aggregate([
                {
                    $lookup:
                    {
                        from: "MarketTimeTable",
                        localField: "_id",
                        foreignField: "market_id",
                        as: "time_tables"
                    }
                }
            ]).match({ status: 1 }); */
            var datet = '2020-10-07';
            datet = datet.split('-');
            let dd = datet[2]; let mm = datet[1]; let yy = datet[0];
            //status: 1
            var resopnse = await Markets.find({}).populate(
                {
                    path: 'timetables',
                });
            if (resopnse) {
                return res.json({ status: 1, message: 'Market Found', data: resopnse });
            } else {
                return res.json({ status: 1, message: "Record Not Found", data: {} });
            }
        } catch (error) {
            return res.json({ status: 0, message: error, data: {} });
        }
    })();
}
exports.addMarket = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.name)) {
                return res.json({ status: 0, message: 'Name is required', data: {} });
            }
            if (!await isValid(req.body.first_letter)) {
                return res.json({ status: 0, message: 'First letter is required', data: {} });
            }
            if (!await isValid(req.body.second_letter)) {
                return res.json({ status: 0, message: 'Second letter is required', data: {} });
            }
            const { name, first_letter, second_letter } = req.body;
            const status = (req.body.status) ? req.body.status : 0;
            return new Markets({
                name,
                first_letter,
                second_letter,
                status,
                created_by: req.userDet._id
            }).save(async function (err, data) {
                if (err) return res.json({ status: 0, message: err.message || "Cannot Add Market" });
                let resopnse = {
                    _id: data._id,
                    name: data.name,
                    first_letter: data.first_letter,
                    second_letter: data.second_letter,
                    status: data.status,
                    created_by: data.created_by,
                    createdAt: data.createdAt,
                    updatedAt: data.updatedAt
                };
                return res.json({ status: 1, message: 'Market Added Successfully', data: resopnse });

            });
        } catch (error) {
            return res.json({ status: 0, message: error, data: {} });
        }
    })();
}

exports.getSinMarket = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.params.id)) {
                return res.json({ status: 0, message: 'ID is required', data: {} });
            }

            let id = req.params.id;
            let data = await Markets.findOne({ _id: id });
            if (data) {
                return res.json({ status: 1, message: 'Get Market Detail Successfully', data: data });
            } else {
                return res.json({ status: 0, message: "No Market Found", data: {} });
            }
        } catch (error) {
            return res.json({ status: 0, message: error || "Something Went Wrong", data: {} });
        }
    })();
}

exports.updateMarket = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.name)) {
                return res.json({ status: 0, message: 'Name is required', data: {} });
            }
            if (!await isValid(req.body.first_letter)) {
                return res.json({ status: 0, message: 'First letter is required', data: {} });
            }
            if (!await isValid(req.body.second_letter)) {
                return res.json({ status: 0, message: 'Second letter is required', data: {} });
            }
            const { name, first_letter, second_letter } = req.body;
            const { id } = req.params;
            
            const status = (req.body.status) ? req.body.status : 0;
            let data = await Markets.updateOne({ _id: id }, {
                name,
                first_letter,
                second_letter,
                status,
                updated_by: req.userDet._id
            });
            if (data.modifiedCount > 0) {
                return res.json({ status: 1, message: 'Market Update Successfully', data: {} });
            } else {
                return res.json({ status: 0, message: "Cannot Update Market", data: {} });
            }
        } catch (error) {
            return res.json({ status: 0, message: error || "Something Went Wrong", data: {} });
        }
    })();
}

exports.deleteMarket = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.id)) {
                return res.json({ status: 0, message: 'ID is required', data: {} });
            }
            let id = req.body.id;
            let data = await Markets.findOne({ _id: id });
            if (data) {
                let isDelete = await Markets.delete({ _id: id }, req.userDet._id);
                if (isDelete.modifiedCount > 0) {
                    await MarketTimeTable.deleteMany({ market_id: id });
                    return res.json({ status: 1, message: 'Market Deleted Successfully', data: {} });
                } else {
                    return res.json({ status: 0, message: "Market Not Deleted", data: {} });
                }

            } else {
                return res.json({ status: 0, message: "No Market Found", data: {} });
            }
        } catch (error) {
            return res.json({ status: 0, message: error || "Something Went Wrong", data: {} });
        }
    })();
}
exports.changeStatusMarket = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.id)) {
                return res.json({ status: 0, message: 'ID is required', data: {} });
            }
            if (!await isValid(req.body.status)) {
                return res.json({ status: 0, message: 'Status is required', data: {} });
            }
            let id = req.body.id; let status = req.body.status;
            let mdlObj = Markets; let textS = 'Market';
            let update = { status: status, updated_by: req.userDet._id }
            if (typeof req.body.mode !== 'undefined' && req.body.mode != '' && req.body.mode == 'timetable') {
                mdlObj = MarketTimeTable;
                textS = 'Market TimeTable';
                update = { status: status }
            }
            let data = await mdlObj.findOne({ _id: id });

            if (data) {
                let isDelete = await mdlObj.updateOne({ _id: id }, update);
                if (isDelete.modifiedCount > 0) {
                    return res.json({ status: 1, message: textS + ' Status Changed Successfully', data: {} });
                } else {
                    return res.json({ status: 0, message: textS + " Not Deleted", data: {} });
                }

            } else {
                return res.json({ status: 0, message: "No " + textS + " Found", data: {} });
            }
        } catch (error) {
            return res.json({ status: 0, message: error || "Something Went Wrong", data: {} });
        }
    })();
}

exports.getMarketTimeTableList = (req, res) => {
    (async () => {
        try {
            let market_id = req.params.id;

            var cdate = getDateFormat();
            let week_day = getWeekDay();
            let datesArr = [];
            let wd = 1;
            for (let j = week_day - 1; j >= 1; j--) {
                let yest = new Date();
                yest.setDate(yest.getDate() - j);
                let newDate = getDateFormat(yest);
                datesArr.push({
                    date: newDate,
                    week_day: wd
                });
                wd++;
            }
            let marketDet = await Markets.findOne({ _id: market_id });
            //return res.json({ status: 1, message: 'Market Found', data: { week_day:week_day, datesArr:datesArr} });
            var resopnse = await MarketTimeTable.find({ market_id: market_id }).sort({ week_day_type: 1 }).populate({ path: 'market_id', select: 'name status' });
            if (resopnse.length) {
                var resp = []; console.log(202, datesArr);
                for (let i = 0; i < resopnse.length; i++) {
                    let myObj = resopnse[i];
                    //let whMar = { market_id: market_id, week_day_type: myObj.week_day_type, $date: { declared_date: cdate } };

                    let whMar = { market_id: market_id };

                    if (myObj.week_day_type == week_day) {
                        whMar.week_day_type = myObj.week_day_type;
                        //whMar.$date = { declared_date: cdate };
                        whMar.declared_date = { $gte: new Date(cdate + ' 00:00:00'), $lte: new Date(cdate + ' 23:59:59') };
                    } else if (myObj.week_day_type < week_day) {
                        //let newArrInd = (datesArr.indexOf(myObj.week_day_type));
                        var newArrInd = datesArr.findIndex(function (item) {
                            return item.week_day == myObj.week_day_type
                        });
                        console.log(214, myObj.week_day_type, newArrInd);
                        if (newArrInd >= 0) {
                            let myDate = datesArr[newArrInd];
                            whMar.week_day_type = myDate.week_day;
                            let date1 = convertToUTC(myDate.date + ' 00:00:00');
                            let date2 = convertToUTC(cdate + ' 23:59:59');
                            whMar.declared_date = { $gte: new Date(date1), $lte: new Date(date2) };
                        } else {
                            whMar.week_day_type = myObj.week_day_type;
                            //whMar.$date = { declared_date: cdate };
                            whMar.declared_date = { $gte: new Date(cdate + ' 00:00:00'), $lte: new Date(cdate + ' 23:59:59') };
                        }
                    } else {
                        whMar.week_day_type = myObj.week_day_type;
                        //whMar.$date = { declared_date: cdate };
                        whMar.declared_date = { $gte: new Date(cdate + ' 00:00:00'), $lte: new Date(cdate + ' 23:59:59') };
                    }

                    let merres = await MarketResults.findOne(whMar);
                    let result = merres;
                    var resp2 = {
                        _id: myObj._id,
                        market_id: myObj.market_id,
                        week_day_name: myObj.week_day_name,
                        week_day_type: myObj.week_day_type,
                        bid_open_time: myObj.bid_open_time,
                        bid_close_time: myObj.bid_close_time,
                        status: myObj.status,
                        markets: myObj.markets,
                        result: result
                    };
                    resp.push(resp2);
                }
                return res.json({ status: 1, message: 'Market TimeTable Found', data: resp, marketDet: marketDet });
            } else {
                return res.json({ status: 0, message: "Record Not Found", data: {}, marketDet: marketDet });
            }
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error, data: {} });
        }
    })();
}

exports.addMarketTimeTable = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.market_id)) {
                return res.json({ status: 0, message: 'Market id is required', data: {} });
            }
            if (!await isValid(req.body.week_day_name)) {
                return res.json({ status: 0, message: 'Week Day Name is required', data: {} });
            }
            if (!await isValid(req.body.week_day_type)) {
                return res.json({ status: 0, message: 'Week Day Type is required', data: {} });
            }
            let market_id = req.body.market_id;
            let week_day_name = req.body.week_day_name;
            let week_day_type = req.body.week_day_type;
            let bid_open_time = req.body.bid_open_time;
            let bid_close_time = req.body.bid_close_time;

            let status = (req.body.status) ? req.body.status : 1;
            let wh = { market_id: market_id, week_day_type: week_day_type };
            let isExist = await MarketTimeTable.findOne(wh);
            console.log(isExist);
            console.log(wh);
            if (isExist) {
                console.log({ _id: isExist._id });
                let update = { bid_open_time: bid_open_time, bid_close_time: bid_close_time, status: status, updated_by: req.userDet._id }
                let isDelete = await MarketTimeTable.updateOne({ _id: isExist._id }, update);
                console.log(isDelete);
                update._id = isExist._id;
                update.market_id = isExist.market_id;
                update.created_by = isExist.created_by;
                update.createdAt = isExist.createdAt;
                update.updatedAt = isExist.updatedAt;
                return res.json({ status: 1, message: 'Market Timetable Updated Successfully', data: update });
            } else {
                let wh2 = { _id: market_id };
                let isMarket = await Markets.findOne(wh2);
                return new MarketTimeTable({
                    market_id: market_id,
                    week_day_name: week_day_name,
                    week_day_type: week_day_type,
                    bid_open_time: bid_open_time,
                    bid_close_time: bid_close_time,
                    status: status,
                    markets: isMarket._id,
                    created_by: req.userDet._id
                }).save(async function (err, data) {
                    if (err) return res.json({ status: 0, message: err.message || "Cannot Add Market Timetable" });
                    let resopnse = {
                        _id: data._id,
                        market_id: market_id,
                        week_day_name: week_day_name,
                        week_day_type: week_day_type,
                        bid_open_time: bid_open_time,
                        bid_close_time: bid_close_time,
                        status: data.status,
                        created_by: data.created_by,
                        createdAt: data.createdAt,
                        updatedAt: data.updatedAt
                    };
                    return res.json({ status: 1, message: 'Timetable Added Successfully', data: resopnse });
                });
            }
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error, data: {} });
        }
    })();
}
exports.getSinMarketTimeTable = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.params.id)) {
                return res.json({ status: 0, message: 'Timetable id is required', data: {} });
            }
            let wh = { _id: req.params.id };
            let isExist = await MarketTimeTable.findOne(wh);
            if (isExist) {
                return res.json({ status: 1, message: 'Get Market Timetable Detail Successfully', data: isExist });
            } else {
                return res.json({ status: 0, message: 'Timetable Not Found', data: {} });
            }
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error, data: {} });
        }
    })();
}
exports.deleteMarketTimeTable = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.id)) {
                return res.json({ status: 0, message: 'ID is required', data: {} });
            }
            let id = req.body.id;
            let data = await MarketTimeTable.findOne({ _id: id });
            if (data) {

                let isDelete = await MarketTimeTable.delete({ _id: id }, req.userDet._id);
                if (isDelete.modifiedCount > 0) {
                    await Markets.updateOne({ _id: data.markets }, { $pullAll: { timetables: [id] } });
                    return res.json({ status: 1, message: 'Market TimeTable Deleted Successfully', data: {} });
                } else {
                    return res.json({ status: 0, message: "Market TimeTable Not Deleted", data: {} });
                }

            } else {
                return res.json({ status: 0, message: "No Market TimeTable Found", data: {} });
            }
        } catch (error) {
            return res.json({ status: 0, message: error || "Something Went Wrong", data: {} });
        }
    })();
}

exports.updateMarketTimeTableData = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.market_id)) {
                return res.json({ status: 0, message: 'Market Id is required', data: {} });
            }
            if (!await isValid(req.body.week_day_type)) {
                return res.json({ status: 0, message: 'Week Day Type is required', data: {} });
            }

            let market_id = req.body.market_id;
            let week_day_type = req.body.week_day_type;
            let op_1 = req.body.op_1; let op_2 = req.body.op_2; let op_3 = req.body.op_3;
            let digit_1 = req.body.digit_1; let digit_2 = req.body.digit_2;
            let cp_1 = req.body.cp_1; let cp_2 = req.body.cp_2; let cp_3 = req.body.cp_3;
            let id = (req.body.id != '') ? req.body.id : null;

            let update = {
                op_1: op_1, op_2: op_2, op_3: op_3,
                digit_1: digit_1, digit_2: digit_2,
                cp_1: cp_1, cp_2: cp_2, cp_3: cp_3
            };
            if (id != null) {
                let data = await MarketResults.updateOne({ _id: id }, update);
                console.log(data, { _id: id });
                if (data.modifiedCount > 0) {
                    return res.json({ status: 1, message: 'Market Result Updated Successfully', data: {} });
                } else {
                    return res.json({ status: 0, message: "Cannot Update Market Result", data: {} });
                }
            } else {
                update.market_id = market_id;
                update.week_day_type = week_day_type;
                update.declared_date = new Date();
                return new MarketResults(update).save(async function (err, data) {
                    if (err) return res.json({ status: 0, message: err.message || "Cannot Add Market Result" });
                    update._id = data._id;
                    return res.json({ status: 1, message: 'Market Result Added Successfully', data: update });
                });
            }

        } catch (error) {
            return res.json({ status: 0, message: error || "Something Went Wrong", data: {} });
        }
    })();
}
/* 12-10-2021 */
exports.addGameRatio = (req, res) => {
    (async () => {
        try {
            var inserts = [
                {
                    name: "Single",
                    game_type_id: [0, 1],
                    ratio_per: 10,
                    ratio_per_amount: 95
                },
                {
                    name: "Jodi",
                    game_type_id: [2],
                    ratio_per: 10,
                    ratio_per_amount: 950
                },
                {
                    name: "Single Panna",
                    game_type_id: [3, 6],
                    ratio_per: 10,
                    ratio_per_amount: 1450
                },
                {
                    name: "Double Panna",
                    game_type_id: [4, 7],
                    ratio_per: 10,
                    ratio_per_amount: 2900
                },
                {
                    name: "Triple Panna",
                    game_type_id: [5, 8],
                    ratio_per: 10,
                    ratio_per_amount: 10000
                },
                {
                    name: "Half Sangam",
                    game_type_id: [9, 10],
                    ratio_per: 10,
                    ratio_per_amount: 10000
                },
                {
                    name: "Full Sangam",
                    game_type_id: [11],
                    ratio_per: 10,
                    ratio_per_amount: 100000
                }
            ];

            let data = await GameRatios.insertMany(inserts);
            if (data) {
                return res.json({ status: 1, message: 'Game Ratios Added Successfully', data: data });
            } else {
                return res.json({ status: 0, message: "Game Ratios Not Added", data: {} });
            }
        } catch (error) {
            return res.json({ status: 0, message: error.message || "Something Went Wrong", data: {} });
        }
    })();
}
exports.getGameRatio = (req, res) => {
    (async () => {
        try {
            let data = await GameRatios.find({});
            if (data) {
                return res.json({ status: 1, message: 'Game Ratios Found Successfully', data: data });
            } else {
                return res.json({ status: 0, message: "Game Ratios Not Found", data: {} });
            }
        } catch (error) {
            return res.json({ status: 0, message: error.message || "Something Went Wrong", data: {} });
        }
    })();
}
exports.updateGameRatio = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.id)) {
                return res.json({ status: 0, message: 'ID is required', data: {} });
            }
            if (!await isValid(req.body.ratio_per)) {
                return res.json({ status: 0, message: 'Ratio Per is required', data: {} });
            }
            if (!await isValid(req.body.ratio_per_amount)) {
                return res.json({ status: 0, message: 'Ratio Per Amount is required', data: {} });
            }
            let id = req.body.id;
            let ratio_per = req.body.ratio_per;
            let ratio_per_amount = req.body.ratio_per_amount;
            let data = await GameRatios.updateOne({ _id: id }, {
                ratio_per: ratio_per,
                ratio_per_amount: ratio_per_amount
            });
            if (data.modifiedCount > 0) {
                return res.json({ status: 1, message: 'Game Ratio Update Successfully', data: {} });
            } else {
                return res.json({ status: 0, message: "Cannot Update Game Ratio", data: {} });
            }
        } catch (error) {
            return res.json({ status: 0, message: error || "Something Went Wrong", data: {} });
        }
    })();
}

/* 19-10-2021 */
exports.declareMarketResult = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.id)) {
                return res.json({ status: 0, message: 'Id is required', data: {} });
            }
            if (!await isValid(req.body.market_id)) {
                return res.json({ status: 0, message: 'Market Id is required', data: {} });
            }
            if (!await isValid(req.body.week_day_type)) {
                return res.json({ status: 0, message: 'Week Day Type is required', data: {} });
            }

            let market_id = req.body.market_id;
            let week_day_type = req.body.week_day_type;
            let id = req.body.id;
            let data = await MarketResults.findOne({ _id: id });
            //return res.json({ status: 1, message: 'Market Result Updated Successfully', data: data });
            if (data != null) {
                let ratios = await GameRatios.find({});

                let marketDet = await Markets.findOne({ _id: market_id });
                let detDesc = "Winnings Credited";
                if (marketDet) {
                    detDesc = "Won - " + marketDet.name;
                }
                let created_by = req.userDet._id;
                resp = await doPublishRes(id, market_id, ratios, data, 3, created_by, detDesc);
                return res.json({ status: 1, message: 'Market Result Published Successfully', data: resp });

                /* let allBids = await MarketBids.find({ market_id: market_id, is_win: 0, dayOfWeek: { $dayOfWeek: "$createdAt" } });
                //return res.json({ status: 1, message: 'allBids', data: allBids });
                if (allBids.length > 0){
                    for (let ij = 0; ij < allBids.length; ij++) {
                        var bidDet = allBids[ij];
                        let game_type_id = bidDet.game_type_id;
                        
                        let isWin = await declareResult(bidDet, data, game_type_id);
                        
                        if (isWin){
                            let newArrInd = ratios.findIndex(getIndexByVal);
                            function getIndexByVal(itm) {
                                return itm.game_type_id.indexOf(game_type_id) > -1;
                            }
                            if (newArrInd >= 0) {
                                let calRat = ratios[newArrInd];
                                let amount = ((bidDet.amount * calRat.ratio_per_amount) / calRat.ratio_per);
                                let bidUserDet = await Users.findOne({ _id: bidDet.user_id });
                                let post_balance = bidUserDet.wallet_wining + amount;
                                let marketDet = await Markets.findOne({ _id: bidDet.market_id});
                                let detDesc = "Winnings Credited";
                                if (marketDet){
                                    detDesc = "Won - " + marketDet.name;
                                }
                                await new Transactions({
                                    user_id: bidDet.user_id,
                                    refe_id: bidDet._id,
                                    amount: amount,
                                    final_amount: amount,
                                    post_balance: post_balance,
                                    tnx_type: 7,//Winnings Credited
                                    wallet_type: 1,//winning wallet
                                    details: detDesc,
                                    entry_type: 1,//credit entry
                                    created_by: req.userDet._id
                                }).save(function (err, transaction) {
                                    console.log(538, err);
                                    if (!err){
                                        (async () => {
                                            await MarketBids.updateOne({ _id: bidDet._id }, { is_win: 1, win_amount: amount });
                                            await Users.updateOne({ _id: bidDet.user_id }, { wallet_wining: post_balance });
                                        })();
                                    }
                                });
                            }
                        } else {
                            await MarketBids.updateOne({ _id: bidDet._id }, { is_win: 2 });
                        }
                    } 
                    await MarketResults.updateOne({ _id: id }, { is_published: 1, published_date:new Date() });
                    return res.json({ status: 1, message: 'Market Result Published Successfully', data: {} });
                } else {
                    return res.json({ status: 0, message: "No Bids Found", data: {} });
                } */
            } else {
                return res.json({ status: 0, message: 'Result Not Found, Not Allowed To Declare Result', data: {} });
            }
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error || "Something Went Wrong", data: {} });
        }
    })();
}

/* 29-10-2021 */
exports.getDashMarket = (req, res) => {
    (async () => {
        try {
            let date = req.body.date;
            /* let passDateArr = date.split('-');
            let passDate = new Date();
            passDate.setFullYear(parseInt(passDateArr[0]));
            passDate.setMonth(parseInt(passDateArr[1])+1);
            passDate.setDate(parseInt(passDateArr[2])); */
            /* return res.json({ status: 1, message: 'data', data: {
                open: allowPublishRes('11:35:00','00:30:00'),
                close: allowPublishRes('11:35:00','00:30:00', true),
            } }); */
            let week_day = getWeekDay();
            week_day = week_day == 0 ? 7 : week_day;
            /* let datesArr = [];
            let wd = 1;
            for (let j = week_day - 1; j >= 1; j--) {
                let yest = new Date(date);
                yest.setDate(yest.getDate() - j);
                let newDate = getDateFormat(yest);
                datesArr.push({
                    date: newDate,
                    week_day: wd
                });
                wd++;
            } */
            let datesArr = [];
            let passDate = getDateFormat();
            for (let j = 0; j < 6; j++) {
                let yest = new Date(passDate);
                if (j == 0) {
                    datesArr.push({
                        date: getDateFormat(yest),
                        week_day: ((yest.getDay() == 0) ? 7 : yest.getDay())
                    });
                }
                yest.setDate(yest.getDate() - 1);
                passDate = getDateFormat(yest);
                datesArr.push({
                    date: passDate,
                    week_day: ((yest.getDay() == 0) ? 7 : yest.getDay())
                });
            }
            //return res.json({ status: 1, message: 'data', data: datesArr });
            /* var days = getDayNameArr();
            var d = new Date(date);
            var week_day_name = days[d.getDay()]; */
            const { week_day_name/* , week_day */ } = getWeekDayResult(date);
            // week_day = getWeekDay();
            // var weekDayKey = d.getDay() + 1;

            let cdate = getDateFormat();
            var resopnse = await MarketTimeTable.find({ status: 1, week_day_name: week_day_name }).populate('market_id', '_id name status');
            //return res.json({ status: 1, message: 'data', data: resopnse });
            if (resopnse) {
                var sendRes = [];
                for (let i = 0; i < resopnse.length; i++) {

                    if (resopnse[i].market_id == null) {
                        continue;
                    }
                    /* if (resopnse[i].market_id.status == 0){
                        continue;
                    } */
                    var marketID = resopnse[i].market_id._id;
                    var firstFour = '****'; var lastFour = '';
                    var marketNumberCode = '***-**-***';
                    let result = null; let resultDet = null; let refundDet = null;

                    let whMar = { market_id: marketID };
                    let myObj = resopnse[i];
                    if (myObj.week_day_type == week_day) {
                        //whMar.week_day_type = myObj.week_day_type;
                        //whMar.$date = { declared_date: cdate };
                        /* let date1 = convertToUTC(cdate + ' 00:00:00');
                        let date2 = convertToUTC(cdate + ' 23:59:59');
                        whMar.declared_date = { $gte: new Date(date1), $lte: new Date(date2) }; */
                        let newDate = getMinusOneDayDate(cdate, resopnse[i].bid_open_time, resopnse[i].bid_close_time, true);
                        let whRef = whMar;
                        whRef.refund_date = new Date(newDate);
                        
                        whMar.result_date = new Date(newDate);
                        resultDet = await MarketResults.findOne(whMar);
                        refundDet = await MarketRefunds.findOne(whRef);
                        //} else if (myObj.week_day_type < week_day) {
                    } else {
                        //let newArrInd = (datesArr.indexOf(myObj.week_day_type));
                        var newArrInd = datesArr.findIndex(function (item) {
                            return item.week_day == myObj.week_day_type
                        });

                        if (newArrInd >= 0) {
                            let myDate = datesArr[newArrInd];
                            //whMar.week_day_type = myDate.week_day;
                            /* let date1 = convertToUTC(myDate.date + ' 00:00:00');
                            let date2 = convertToUTC(cdate + ' 23:59:59');
                            whMar.declared_date = { $gte: new Date(date1), $lte: new Date(date2) }; */
                            let newDate = myDate.date; //getMinusOneDayDate(myDate.date, resopnse[i].bid_open_time, resopnse[i].bid_close_time, true);
                            
                            let whRef = { market_id: marketID };
                            whRef.refund_date = new Date(newDate);

                            whMar.result_date = new Date(newDate);
                            //console.log(719, myDate.date, resopnse[i].bid_open_time, resopnse[i].bid_close_time);
                            //console.log(720, resopnse[i].market_id.name, whMar);
                            resultDet = await MarketResults.findOne(whMar);

                            refundDet = await MarketRefunds.findOne(whRef);
                        }
                    }

                    if (resultDet) {
                        firstFour = resultDet.op_1 + ' ' + resultDet.op_2 + ' ' + resultDet.op_3 + ' ' + resultDet.digit_1;
                        if (resultDet.digit_2 != null && resultDet.digit_2 >= 0) {
                            lastFour = resultDet.digit_2 + ' ' + resultDet.cp_1 + ' ' + resultDet.cp_2 + ' ' + resultDet.cp_3;
                        }
                        result = {
                            res_id: resultDet._id,
                            firstFour: firstFour,
                            lastFour: lastFour,
                            is_open_published: resultDet.is_open_published,
                            is_published: resultDet.is_published,
                            is_refunded: resultDet.is_refunded,
                            is_rollback: resultDet.is_rollback,
                            is_open_rollback: resultDet.is_open_rollback,
                            is_close_rollback: resultDet.is_close_rollback,
                            op_1: resultDet.op_1,
                            op_2: resultDet.op_2,
                            op_3: resultDet.op_3,
                            digit_1: resultDet.digit_1,
                            digit_2: resultDet.digit_2,
                            cp_1: resultDet.cp_1,
                            cp_2: resultDet.cp_2,
                            cp_3: resultDet.cp_3,
                        };
                    }
                    sendRes.push({
                        "_id": marketID,
                        "name": resopnse[i].market_id.name,
                        "time_table_id": resopnse[i]._id,
                        "status": resopnse[i].market_id.status,
                        "week_day_type": resopnse[i].week_day_type,
                        "bid_open_time": resopnse[i].bid_open_time,
                        "bid_close_time": resopnse[i].bid_close_time,
                        "marketNumberCode": marketNumberCode,
                        "result": result,
                        "refund": refundDet
                        //"weekDayKey": weekDayKey
                    });
                }
                sendRes = await sendRes.sort(function (a, b) {
                    return new Date(cdate + " " + a.bid_open_time) - new Date(cdate + " " + b.bid_open_time);
                });
                return res.json({ status: 1, message: 'Market Found', data: sendRes });
            } else {
                return res.json({ status: 0, message: "Record Not Found", data: {} });
            }
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error, data: {} });
        }
    })();
}

/* 30-10-2021 */
exports.updateMarketResultPartial = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.market_id)) {
                return res.json({ status: 0, message: 'Market Id is required', data: {} });
            }
            if (!await isValid(req.body.week_day_type)) {
                return res.json({ status: 0, message: 'Week Day Type is required', data: {} });
            }
            if (!await isValid(req.body.time_table_id)) {
                return res.json({ status: 0, message: 'time table id is required', data: {} });
            }
            let market_id = req.body.market_id;
            let week_day_type = req.body.week_day_type;
            let time_table_id = req.body.time_table_id;
            let result_date = (typeof req.body.date !== 'undefined' && req.body.date != null) ? req.body.date : getDateFormat();

            var isTimeExist = await MarketTimeTable.findOne({ _id: time_table_id });
            if (!isTimeExist) {
                return res.json({ status: 0, message: "Timetable Record Not Found", data: {} });
            }
            result_date = getMinusOneDayDate(result_date, isTimeExist.bid_open_time, isTimeExist.bid_close_time);
            let op_1 = null; let op_2 = null; let op_3 = null; let digit_1 = null;
            if (typeof req.body.digit_1 != 'undefined' && req.body.digit_1 != '') {
                op_1 = req.body.op_1; op_2 = req.body.op_2; op_3 = req.body.op_3; digit_1 = req.body.digit_1;
            }

            let digit_2 = null; let cp_1 = null; let cp_2 = null; let cp_3 = null;
            if (typeof req.body.digit_2 != 'undefined' && req.body.digit_2 != '') {
                digit_2 = req.body.digit_2;
                cp_1 = req.body.cp_1; cp_2 = req.body.cp_2; cp_3 = req.body.cp_3;
            }
            let id = (req.body.id != '') ? req.body.id : null;

            let update = {};
            if (digit_1) {
                update.digit_1 = digit_1; update.op_1 = op_1; update.op_2 = op_2; update.op_3 = op_3;
            }
            if (digit_2) {
                update.digit_2 = digit_2; update.cp_1 = cp_1; update.cp_2 = cp_2; update.cp_3 = cp_3;
            }
            console.log(768, update);
            if (id != null) {
                let data = await MarketResults.updateOne({ _id: id }, update);
                console.log(data, { _id: id });
                if (data.modifiedCount > 0) {
                    return res.json({ status: 1, message: 'Market Result Updated Successfully', data: {} });
                } else {
                    return res.json({ status: 0, message: "Cannot Update Market Result", data: {} });
                }
            } else {
                update.market_id = market_id;
                update.week_day_type = week_day_type;
                update.declared_date = new Date();
                update.result_date = result_date;
                let msg = 'Close Result Added Successfully';
                if (digit_2 == null) {
                    msg = 'Open Result Added Successfully';
                    /* update.is_open_published   = 1;
                    update.open_published_date = new Date(); */
                }
                return new MarketResults(update).save(async function (err, data) {
                    if (err) return res.json({ status: 0, message: err.message || "Cannot Add Market Result" });
                    update._id = data._id;
                    return res.json({ status: 1, message: msg, data: update });
                });
            }
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error.message || "Something Went Wrong", data: error });
        }
    })();
}

/* 01-11-2021 */
exports.declareMarketResultPartial = (req, res) => {
    (async () => {
        try {
            if (!await isValid(req.body.market_id)) {
                return res.json({ status: 0, message: 'Market Id is required', data: {} });
            }
            if (!await isValid(req.body.id)) {
                return res.json({ status: 0, message: 'Result id is required', data: {} });
            }
            if (!await isValid(req.body.result_type)) {
                return res.json({ status: 0, message: 'Result Type is required', data: {} });
            }

            let result_type = req.body.result_type;
            let market_id = req.body.market_id;
            let id = req.body.id; //result_id
            let result_date = (typeof req.body.date !== 'undefined' && req.body.date != null) ? req.body.date : getDateFormat();
            let resData = await MarketResults.findOne({ market_id: market_id, _id: id });
            if (resData) {
                let marketData = await MarketTimeTable.findOne({ market_id: market_id, week_day_type: resData.week_day_type });
                if (!marketData) {
                    return res.json({ status: 0, message: 'Timetable Record Not Found', data: {} });
                }
                //result_date = getMinusOneDayDate(result_date, marketData.bid_open_time, marketData.bid_close_time);
                result_date = getDateFormat(resData.result_date);
                console.log(marketData.bid_open_time, marketData.bid_close_time);
                let todayDate = getDateFormat(); let resDate = result_date;
                //return res.json({ status: 1, message: 'Check Result', data: { todayDate: todayDate, resDate: resDate } });
                let ratios = await GameRatios.find({});
                let resp = {};
                let created_by = req.userDet._id;
                if (result_type == 1) {/* Open */
                    if (todayDate == resDate) {
                        if (!await allowPublishRes(marketData.bid_open_time, marketData.bid_close_time)) {
                            return res.json({ status: 0, message: 'Not Allowed To Publish Result Before Bid Start Time', data: {} });
                        }
                    }
                    //return res.json({ status: 1, message: 'Check Result', data: {} });
                    if (resData.is_open_published == 0) {
                        let marketDet = await Markets.findOne({ _id: market_id });
                        let detDesc = "Winnings Credited";
                        if (marketDet) {
                            detDesc = "Won - " + marketDet.name;
                        }
                        resp = await doPublishRes(id, market_id, ratios, resData, 1, created_by, detDesc, result_date);
                        return res.json({ status: 1, message: 'Market Result Published Successfully', data: resp });
                    } else {
                        return res.json({ status: 0, message: 'Open Result Already Published, Not Allow Publish', data: resp });
                    }
                } else {/* Close */

                    let marketDet = await Markets.findOne({ _id: market_id });
                    let detDesc = "Winnings Credited";
                    if (marketDet) {
                        detDesc = "Won - " + marketDet.name;
                    }
                    if (todayDate == resDate) {
                        if (!await allowPublishRes(marketData.bid_open_time, marketData.bid_close_time, true)) {
                            return res.json({ status: 0, message: 'Not Allowed To Publish Result Before Bid End Time', data: {} });
                        }
                    }
                    if (resData.is_open_published == 0) {
                        resp = await doPublishRes(id, market_id, ratios, resData, 3, created_by, detDesc, result_date);
                        return res.json({ status: 1, message: 'Market Result Published Successfully', data: resp });
                    } else {
                        resp = await doPublishRes(id, market_id, ratios, resData, 2, created_by, detDesc, result_date);
                        return res.json({ status: 1, message: 'Market Result Published Successfully', data: resp });
                    }
                }
            } else {
                return res.json({ status: 0, message: 'Result Not Found, Not Allowed To Publish Result', data: {} });
            }
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error || "Something Went Wrong", data: {} });
        }
    })();
}

function doPublishRes(id, market_id, ratios, data, pubType = 1, created_by, detDesc, report_date = '') {/* pubType => 1=Open,2=Close,3=Both */
    (async () => {
        try {
            //let whe = { market_id: market_id, is_win: 0, dayOfWeek: { $dayOfWeek: "$createdAt" } };
            let whe = { market_id: market_id, is_win: 0, report_date: new Date(report_date) };
            if (pubType == 1) {
                whe.game_type_id = { $in: [0, 3, 4, 5] };
            } else if (pubType == 2) {
                whe.game_type_id = { $in: [1, 6, 7, 8, 2, 9, 10, 11] };/*2, 9, 10, 11*/
            }
            console.log(889, whe);
            let allBids = await MarketBids.find(whe);
            console.log(898, allBids.length);
            let result_id = data._id;
            if (allBids.length > 0) {
                var usersList = await getUserByBid(whe);
                
                let myResp = await Promise.all(allBids.map(async (bidDet) => {
                    let game_type_id = bidDet.game_type_id;
                    //let isWin = await declareResult(bidDet, data, game_type_id);
                    if (await declareResult(bidDet, data, game_type_id)) {
                        console.log(950, bidDet.panna_1, bidDet.panna_2, bidDet.game_type_id);
                        let newArrInd = ratios.findIndex(getIndexByVal);
                        function getIndexByVal(itm) {
                            return itm.game_type_id.indexOf(game_type_id) > -1;
                        }
                        if (newArrInd >= 0) {
                            let calRat = ratios[newArrInd];
                            let amount = ((bidDet.amount * calRat.ratio_per_amount) / calRat.ratio_per);

                            
                            var i = await usersList.findIndex(_element => _element._id.toString() === bidDet.user_id.toString());
                            if (i > -1) {
                                console.log(365, i, bidDet.user_id.toString());
                                console.log(963, 'Before :: ', usersList[i].wallet_wining);
                                let post_balance = (usersList[i].wallet_wining + parseFloat(amount));
                                usersList[i].wallet_wining = (usersList[i].wallet_wining + parseFloat(amount));
                            /* return await Users.findOneAndUpdate({ _id: bidDet.user_id }, { $set:{$inc: { wallet_wining: parseFloat(amount) }} }, async function (err, docs) { */
                                console.log(919, 'After :: ', post_balance);
                                return await new Transactions({
                                    user_id: bidDet.user_id,
                                    refe_id: bidDet._id,
                                    amount: amount,
                                    final_amount: amount,
                                    post_balance: post_balance,
                                    tnx_type: 7,//Winnings Credited
                                    wallet_type: 1,//winning wallet
                                    details: detDesc,
                                    entry_type: 1,//credit entry
                                    created_by: created_by,
                                    report_date: bidDet.report_date
                                }).save(async function (err, transaction) {
                                    if (!err) {
                                        console.log(932, 'trx saved');
                                        let isBidUpdated2 = await MarketBids.updateOne({ _id: bidDet._id }, { is_win: 1, win_amount: amount, result_id: result_id });
                                        if (isBidUpdated2.modifiedCount > 0) {
                                            return {
                                                bid_id: bidDet._id,
                                                user_id: bidDet.user_id,
                                                is_win: 1,
                                                detDesc: detDesc
                                            }
                                        }
                                    }
                                });
                            /* }); */
                            }
                        }
                    } else {
                        let isBidUpdated = await MarketBids.updateOne({ _id: bidDet._id }, { is_win: 2, result_id: result_id });
                        if (isBidUpdated.modifiedCount > 0) {
                            return {
                                bid_id: bidDet._id,
                                user_id: bidDet.user_id,
                                is_win: 2,
                                detDesc: 'Lose'
                            }
                        }
                    }
                }));/* for market */
                
                await Promise.all(usersList.map(async (user) => {
                    let updateWallet = { $set: { wallet_wining: user.wallet_wining } };
                    return await Users.updateOne({ _id: user._id }, updateWallet);
                }));/* for usersList */
                if (pubType == 1) {
                    await MarketResults.updateOne({ _id: id }, { is_open_published: 1, open_published_date: new Date() });
                } else if (pubType == 2) {
                    await MarketResults.updateOne({ _id: id }, { is_published: 1, published_date: new Date() });
                } else {
                    await MarketResults.updateOne({ _id: id }, { is_open_published: 1, open_published_date: new Date(), is_published: 1, published_date: new Date() });
                }
                sendMarketResultNotification(data, detDesc);
                return myResp;
            } else {
                if (pubType == 1) {
                    await MarketResults.updateOne({ _id: id }, { is_open_published: 1, open_published_date: new Date() });
                } else if (pubType == 2) {
                    await MarketResults.updateOne({ _id: id }, { is_published: 1, published_date: new Date() });
                } else {
                    await MarketResults.updateOne({ _id: id }, { is_open_published: 1, open_published_date: new Date(), is_published: 1, published_date: new Date() });
                }
                sendMarketResultNotification(data, detDesc);
                return {};
            }
        } catch (error2) {
            console.log(968, error2);
        }
    })();
}
async function getResultLegend(marRes) {
    let legend = '';
    legend = (marRes.is_open_published == 1 && marRes.op_1 != null) ? legend + marRes.op_1 : legend + '*';
    legend = (marRes.is_open_published == 1 && marRes.op_2 != null) ? legend + marRes.op_2 : legend + '*';
    legend = (marRes.is_open_published == 1 && marRes.op_3 != null) ? legend + marRes.op_3 + '-' : legend + '*-';
    legend = (marRes.is_open_published == 1 && marRes.digit_1 != null) ? legend + marRes.digit_1 : legend + '*';
    legend = (marRes.is_published == 1 && marRes.digit_2 != null) ? legend + marRes.digit_2 + '-' : legend + '*-';
    legend = (marRes.is_published == 1 && marRes.cp_1 != null) ? legend + marRes.cp_1 : legend + '*';
    legend = (marRes.is_published == 1 && marRes.cp_2 != null) ? legend + marRes.cp_2 : legend + '*';
    legend = (marRes.is_published == 1 && marRes.cp_3 != null) ? legend + marRes.cp_3 : legend + '*';
    return legend;
}
async function sendMarketResultNotification(marRes, detDesc) {
    const getRes = await MarketResults.findById(marRes._id);
    const legend = await getResultLegend(getRes);
    const title = detDesc.toString().replace("Won - ", "");
    var sdata = {};
    sdata['title'] = title;
    sdata['body'] = legend;
    sdata['image'] = '';
    console.log("notification sdata", sdata);
    await sendAndroid(['619250231e9119998552d6b2'], sdata);
}

/* 25-11-2021 */
/* 29-10-2021 */
exports.refundBids = (req, res) => {
    (async () => {
        try {
            let date = req.body.date;
            let market_id = req.body.market_id;
            let result_id = req.body.result_id;
            let refund_id = req.body.refund_id;
            let refund_type = req.body.refund_type;
            //console.log(typeof refund_type);
            //return res.json({ status: 0, message: "Already Refunded", data: req.body });
            let created_by = req.userDet._id;
            let marketDet = await Markets.findOne({ _id: market_id });
            let detDesc = "Market Refund";
            if (marketDet) {
                detDesc = "Refund - " + marketDet.name;
                /* let marketResult = await MarketResults.findOne({ market_id: market_id, result_date: new Date(date) });
                if (marketResult) {
                    if (marketResult.is_refunded == 1) {
                        return res.json({ status: 0, message: "Already Refunded", data: {} });
                    }
                    await MarketResults.updateOne({ _id: marketResult._id }, { is_refunded: 1 });
                } */
                let refundBids = null;
                if (refund_id != ''){
                    refundBids = await MarketRefunds.findOne({ _id: refund_id });
                }
                
                if (typeof refund_type == 'object' && refund_type.indexOf("1") > -1 && refund_type.indexOf("2") > -1){ /* open close both */
                    if (refundBids){
                        if (refundBids.is_open_refunded == 1){
                            return res.json({ status: 0, message: "Open Panna Already Refunded, Not Allowed To Refund Again", data: {} });
                        } else if (refundBids.is_close_refunded == 1){
                            return res.json({ status: 0, message: "Already Refunded, Not Allowed To Refund Again", data: {} });
                        } else {
                            let updateArr = {
                                is_open_refunded : 1, is_close_refunded : 1, is_both_refund : 1,
                                both_refunded_date : new Date()
                            };
                            let updateRefund = await MarketRefunds.updateOne({ _id: refund_id }, updateArr);
                            if (updateRefund.modifiedCount > 0){
                                let resp = await doRefundBids(market_id, date, 3, created_by, detDesc);
                                return res.json({ status: 1, message: 'Both Refunded Successfully', data: resp });
                            } else {
                                return res.json({ status: 0, message: "Something Went Wrong, Not Refunded", data: {} });
                            }
                        }
                    } else {
                        let insertArr = {
                            refund_date:new Date(date),
                            market_id:market_id, is_open_refunded: 1, is_close_refunded: 1, is_both_refund: 1,
                            open_refunded_date: new Date(), close_refunded_date: new Date(), both_refunded_date: new Date()
                        };
                        return new MarketRefunds(insertArr).save(async function (err, data) {
                            if (err) return res.json({ status: 0, message: err.message || "Cannot Refunded",data:{} });
                            let resp = await doRefundBids(market_id, date, 3, created_by, detDesc);
                            return res.json({ status: 1, message: 'Both Refunded Successfully', data: resp });
                        });
                    }
                } else if ((typeof refund_type == 'object' && refund_type.indexOf("1") > -1) || (typeof refund_type == 'string' && refund_type == "1")) { /* open */
                    if (refundBids) {
                        if (refundBids.is_open_refunded == 1) {
                            return res.json({ status: 0, message: "Open Panna Already Refunded, Not Allowed To Refund Again", data: {} });
                        } else {
                            let updateArr = { is_open_refunded: 1, open_refunded_date: new Date() };
                            if (refundBids.is_close_refunded == 1) {
                                updateArr.is_both_refund = 1;
                                updateArr.both_refunded_date = new Date();
                            }
                            let updateRefund = await MarketRefunds.updateOne({ _id: refund_id }, updateArr);
                            if (updateRefund.modifiedCount > 0) {
                                let resp = await doRefundBids(market_id, date, 1, created_by, detDesc);
                                return res.json({ status: 1, message: 'Open Refunded Successfully', data: resp });
                            } else {
                                return res.json({ status: 0, message: "Something Went Wrong, Not Refunded", data: {} });
                            }
                        }
                    } else {
                        let insertArr = {
                            refund_date: new Date(date),
                            market_id: market_id, is_open_refunded: 1, open_refunded_date: new Date()
                        };
                        return new MarketRefunds(insertArr).save(async function (err, data) {
                            if (err) return res.json({ status: 0, message: err.message || "Cannot Refunded", data: {} });
                            let resp = await doRefundBids(market_id, date, 1, created_by, detDesc);
                            return res.json({ status: 1, message: 'Open Refunded Successfully', data: resp });
                        });
                    }
                } else if ((typeof refund_type == 'object' && refund_type.indexOf("2") > -1) || (typeof refund_type == 'string' && refund_type == "2")) { /* close*/
                    if (refundBids) {
                        console.log(1142, refundBids);
                        if (refundBids.is_close_refunded == 1) {
                            return res.json({ status: 0, message: "Close Panna Already Refunded, Not Allowed To Refund Again", data: {} });
                        } else {
                            let updateArr = { is_close_refunded: 1, close_refunded_date: new Date() };
                            if (refundBids.is_open_refunded == 1) {
                                updateArr.is_both_refund = 1;
                                updateArr.both_refunded_date = new Date();
                            }
                            let updateRefund = await MarketRefunds.updateOne({ _id: refund_id }, updateArr);
                            if (updateRefund.modifiedCount > 0) {
                                let resp = await doRefundBids(market_id, date, 2, created_by, detDesc);
                                return res.json({ status: 1, message: 'Close Refunded Successfully', data: resp });
                            } else {
                                return res.json({ status: 0, message: "Something Went Wrong, Not Refunded", data: {} });
                            }
                        }
                    } else {
                        let insertArr = { refund_date: new Date(date), market_id: market_id, is_close_refunded: 1, close_refunded_date: new Date() };
                        return new MarketRefunds(insertArr).save(async function (err, data) {
                            if (err) return res.json({ status: 0, message: err.message || "Cannot Refunded", data: {} });
                            let resp = await doRefundBids(market_id, date, 2, created_by, detDesc);
                            return res.json({ status: 1, message: 'Close Refunded Successfully', data: resp });
                        });
                    }
                }
                return res.json({ status: 0, message: "Something Went Wrong", data: {} });
            } else {
                return res.json({ status: 0, message: "Market Not Found", data: {} });
            }
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error.message, data: error });
        }
    })();
}
async function doRefundBids(market_id, date, pubType = 1, created_by, detDesc) {
    /* pubType => 1=Open,2=Close,3=Both */
    try {//, is_win: 0
        let whe = { market_id: market_id, is_win: 0, report_date: new Date(date) };
        if (pubType == 1) {
            whe.game_type_id = { $in: [0, 3, 4, 5] };
        } else if (pubType == 2) {
            whe.game_type_id = { $in: [1, 6, 7, 8, 2, 9, 10, 11] };
        }
        let allBids = await MarketBids.find(whe);
        console.log(1179, whe);
        //return allBids;
        console.log(1012, allBids.length);
        if (allBids.length > 0) {
            let users = []; let usersWinning = []; let allTrans = [];
            var usersList = await getUserByBid(whe);
            await Promise.all(allBids.map(async (bidDet) => {
                let game_type_id = bidDet.game_type_id;
                let user_id = bidDet.user_id.toString();
                let isBidUpdate = await MarketBids.updateOne({ _id: bidDet._id }, { is_win: 3 });
                if (isBidUpdate.modifiedCount > 0) {
                    let trans = await Transactions.find({ refe_id: bidDet._id, user_id: bidDet.user_id, entry_type: 2 });//.select('user_id refe_id amount tnx_type wallet_type report_date');
                    if (trans.length > 0) {
                        let post_balance = 0;
                        if (trans.length == 1) {
                            trans = trans[0];
                            let newTrans = {
                                user_id: trans.user_id, refe_id: trans.refe_id,
                                amount: trans.amount, charge_amount: trans.charge_amount, final_amount: trans.final_amount, post_balance: post_balance, tnx_type: 2, wallet_type: trans.wallet_type,
                                details: detDesc, entry_type: 1,/*creadit*/ report_date: trans.report_date, created_by: created_by
                            };
                            
                            let amount = trans.amount;

                            if (trans.wallet_type == 1) {
                                var i = await usersList.findIndex(_element => _element._id.toString() === user_id);
                                if (i > -1){
                                    let post_balance = (usersList[i].wallet_wining + parseFloat(amount));
                                    usersList[i].wallet_wining = (usersList[i].wallet_wining + parseFloat(amount));
                                    newTrans.post_balance = post_balance;
                                    allTrans.push(newTrans);
                                    return newTrans;
                                } else {
                                    return newTrans;
                                }
                            } else {
                                var i = await usersList.findIndex(_element => _element._id.toString() === user_id);
                                if (i > -1) {
                                    let post_balance = (usersList[i].wallet + parseFloat(amount));
                                    usersList[i].wallet = (usersList[i].wallet + parseFloat(amount));
                                    newTrans.post_balance = post_balance;
                                    allTrans.push(newTrans);
                                    return newTrans;
                                } else {
                                    return newTrans;
                                }
                            }
                        } else if (trans.length == 2) {
                            let first = trans[0]; let second = trans[1];
                            let newTrans2 = {
                                user_id: first.user_id, refe_id: first.refe_id,
                                amount: first.amount, charge_amount: first.charge_amount, final_amount: first.final_amount, post_balance: post_balance, tnx_type: 2, wallet_type: first.wallet_type,
                                details: detDesc, entry_type: 1,/*creadit*/ report_date: first.report_date, created_by: created_by
                            };
                            let newTrans3 = {
                                user_id: second.user_id, refe_id: second.refe_id,
                                amount: second.amount, charge_amount: second.charge_amount, final_amount: second.final_amount, post_balance: post_balance, tnx_type: 2, wallet_type: second.wallet_type,
                                details: detDesc, entry_type: 1,/*creadit*/ report_date: second.report_date, created_by: created_by
                            };
                            //allTrans.push(newTrans2); allTrans.push(newTrans3);
                            let amount = newTrans2.amount;

                            if (newTrans2.wallet_type == 1) {
                                var i = await usersList.findIndex(_element => _element._id.toString() === user_id);
                                if (i > -1) {
                                    let post_balance = (usersList[i].wallet_wining + parseFloat(amount));
                                    usersList[i].wallet_wining = (usersList[i].wallet_wining + parseFloat(amount));
                                    newTrans2.post_balance = post_balance;
                                    allTrans.push(newTrans2);
                                }
                            } else {
                                var i = await usersList.findIndex(_element => _element._id.toString() === user_id);
                                if (i > -1) {
                                    let post_balance = (usersList[i].wallet + parseFloat(amount));
                                    usersList[i].wallet = (usersList[i].wallet + parseFloat(amount));
                                    newTrans2.post_balance = post_balance;
                                    allTrans.push(newTrans2);
                                }
                            }
                            amount = newTrans3.amount;

                            if (newTrans3.wallet_type == 1) {
                                var i = await usersList.findIndex(_element => _element._id.toString() === user_id);
                                if (i > -1) {
                                    let post_balance = (usersList[i].wallet_wining + parseFloat(amount));
                                    usersList[i].wallet_wining = (usersList[i].wallet_wining + parseFloat(amount));
                                    newTrans3.post_balance = post_balance;
                                    allTrans.push(newTrans3);
                                    return { newTrans2, newTrans3 };
                                } else {
                                    return { newTrans2, newTrans3 };
                                }
                            } else {
                                var i = await usersList.findIndex(_element => _element._id.toString() === user_id);
                                if (i > -1) {
                                    let post_balance = (usersList[i].wallet + parseFloat(amount));
                                    usersList[i].wallet = (usersList[i].wallet + parseFloat(amount));
                                    newTrans3.post_balance = post_balance;
                                    allTrans.push(newTrans3);
                                    return { newTrans2, newTrans3 };
                                } else {
                                    return { newTrans2, newTrans3 };
                                }
                            }
                        }
                    } else {
                        return {};
                    }
                } else {
                    return {};
                }
            }));/* for market */
            if (allTrans.length > 0) {
                let istransIns = await Transactions.insertMany(allTrans);
                if (istransIns) {
                    if (usersList.length > 0) {
                        await Promise.all(usersList.map(async (user) => {
                            let updateWallet = { $set: { wallet:user.wallet, wallet_wining:user.wallet_wining } };
                            return await Users.updateOne({ _id: user._id }, updateWallet);
                        }));/* for users */
                    }
                }
            }
            return {
                users,
                usersWinning,
                allTrans
            };
        } else {
            return {};
        }
    } catch (error2) {
        console.log(1036, error2);
        return error2;
    }
}
/* 16-12-2021 */
exports.resultRollback = (req, res) => {
    (async () => {
        try {

            if (!await isValid(req.body.market_id)) {
                return res.json({ status: 0, message: 'Market Id is required', data: {} });
            }
            if (!await isValid(req.body.date)) {
                return res.json({ status: 0, message: 'date is required', data: {} });
            }
            if (!await isValid(req.body.result_id)) {
                return res.json({ status: 0, message: 'result id is required', data: {} });
            }
            if (!await isValid(req.body.type)) {
                return res.json({ status: 0, message: 'type is required', data: {} });
            }
            let date = req.body.date;
            let market_id = req.body.market_id;
            let result_id = req.body.result_id;
            let type = req.body.type;

            let created_by = req.userDet._id;
            let marketDet = await Markets.findOne({ _id: market_id });
            if (marketDet) {
                let detDesc = "Rollback - " + marketDet.name;
                let detDescWin = "Won - " + marketDet.name;

                let marketResult = await MarketResults.findOne({ _id: result_id });
                if (marketResult) {
                    if (marketResult.is_rollback == 1) {
                        return res.json({ status: 0, message: "Result Already Rollbacked", data: {} });
                    }
                    if(type == "1"){
                        if (marketResult.is_open_rollback == 1) {
                            return res.json({ status: 0, message: "Open Result Already Rollbacked", data: {} });
                        }
                        let updMarket = {
                            is_open_rollback: 1, roll_cdate: new Date(),
                            op_1: req.body.op_1, op_2: req.body.op_2, op_3: req.body.op_3,
                            digit_1: req.body.digit_1
                        };
                        if (marketResult.is_close_rollback == 1){
                            updMarket.is_rollback = 1;
                        }
                        let merged = marketResult;
                        merged.is_open_rollback = updMarket.is_open_rollback; merged.op_1 = updMarket.op_1; merged.op_2 = updMarket.op_2; merged.op_3 = updMarket.op_3; merged.digit_1 = updMarket.digit_1;
                        await MarketResults.updateOne({ _id: result_id }, updMarket);
                        let resp = await doResultRollback(market_id, date, 1, created_by, detDesc, detDescWin, merged);
                        return res.json({ status: 1, message: 'Open Result Rollbacked Successfully', data: resp });
                    } else if (type == "2"){
                        if (marketResult.is_close_rollback == 1) {
                            return res.json({ status: 0, message: "Close Result Already Rollbacked", data: {} });
                        }
                        let updMarket = {
                            is_close_rollback: 1, roll_cdate: new Date(),
                            cp_1: req.body.cp_1, cp_2: req.body.cp_2, cp_3: req.body.cp_3,
                            digit_2: req.body.digit_2
                        };
                        if (marketResult.is_open_rollback == 1) {
                            updMarket.is_rollback = 1;
                        }
                        let merged = marketResult;
                        merged.is_close_rollback = updMarket.is_close_rollback; merged.cp_1 = updMarket.cp_1; merged.cp_2 = updMarket.cp_2; merged.cp_3 = updMarket.cp_3;
                        merged.digit_2 = updMarket.digit_2;
                        await MarketResults.updateOne({ _id: result_id }, updMarket);
                        let resp = await doResultRollback(market_id, date, 2, created_by, detDesc, detDescWin, merged);
                        return res.json({ status: 1, message: 'Close Result Rollbacked Successfully', data: resp });
                    } else {
                        return res.json({ status: 0, message: "Something Went Wrong", data: {} });
                    }
                } else {
                    return res.json({ status: 1, message: 'Result Not Found', data: resp });
                }
            } else {
                return res.json({ status: 0, message: "Market Not Found", data: {} });
            }
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error.message, data: error });
        }
    })();
}
async function doResultRollback(market_id, date, pubType = 1, created_by, detDesc, detDescWin, resData) {
    /* pubType => 1=Open,2=Close,3=Both */
    try {//, is_win: 0
        let whe = { market_id: market_id, is_win: { $in: [0, 1, 2] }, report_date: new Date(date) };
        if (pubType == 1) {
            whe.game_type_id = { $in: [0, 3, 4, 5] };
        } else if (pubType == 2) {
            whe.game_type_id = { $in: [1, 6, 7, 8, 2, 9, 10, 11] };
        }
        let allBids = await MarketBids.find(whe);
        //return allBids;
        console.log(1253, allBids.length);
        if (allBids.length > 0) {
            allTrans = [];
            var usersList = await getUserByBid(whe);
            await Promise.all(allBids.map(async (bidDet) => {
                let user_id = bidDet.user_id.toString();
                let isBidUpdate = await MarketBids.updateOne({ _id: bidDet._id }, { is_win: 0, updatedAt: new Date() });
                if (isBidUpdate.modifiedCount > 0) {
                    if (bidDet.is_win == 1) {
                        let trans2 = await Transactions.findOne({ refe_id: bidDet._id, user_id: bidDet.user_id, entry_type: 1, wallet_type: 1 });
                        if (trans2) {
                            amount = trans2.amount;
                            let newTrans4 = {
                                user_id: trans2.user_id, refe_id: trans2.refe_id,
                                amount: trans2.amount, charge_amount: trans2.charge_amount, final_amount: trans2.final_amount, post_balance: 0, tnx_type: 11, wallet_type: 1,
                                details: 'Pull Winning - ' + detDesc, entry_type: 2,/*debit*/ report_date: trans2.report_date, created_by: created_by
                            };

                            var i = await usersList.findIndex(_element => _element._id.toString() === user_id);
                            if (i > -1) {
                                let post_balance = (usersList[i].wallet_wining - parseFloat(amount));
                                usersList[i].wallet_wining = (usersList[i].wallet_wining - parseFloat(amount));
                                newTrans4.post_balance = post_balance;
                                allTrans.push(newTrans4);
                                return newTrans4;
                            } else {
                                allTrans.push(newTrans4);
                                return newTrans4;
                            }
                        }
                    } else {
                        return {};
                    }
                } else {
                    return {};
                }
            }));/* for allBids */
            
            if (allTrans.length > 0) {
                let istransIns = await Transactions.insertMany(allTrans);
                if (istransIns) {
                    if (usersList.length > 0) {
                        await Promise.all(usersList.map(async (user) => {
                            let updateWallet = { wallet_wining: user.wallet_wining };
                            return await Users.updateOne({ _id: user._id }, updateWallet);
                        }));/* for usersList */
                    }
                }
            }
            let ratios = await GameRatios.find({});
            let resultId = resData._id;
            return await doPublishRes(resultId, market_id, ratios, resData, pubType, created_by, detDescWin, date);
            /* return { users, usersWinning, allTrans }; */
        } else {
            return {};
        }
    } catch (error2) {
        console.log(1036, error2);
        return error2;
    }
}
async function getUserByBid(where) {
    where.market_id = mongoose.Types.ObjectId(where.market_id);
   let usersList = await MarketBids.aggregate([
        { $match: where },
        {
            $group: {
                _id: null,
                user_id: {
                    $addToSet: '$user_id',
                },
            },
        },
        {
            $lookup: {
                from: 'users',
                let: { 'user_id': '$user_id' },
                pipeline: [
                    {
                        "$match": {
                            //"$expr": { "$eq": ["$_id", "$$user_id"] },
                            "$expr": {
                                $and: [
                                    { $in: ['$_id', '$$user_id'] }
                                ],
                            }
                        },
                    },
                    { $project: { _id: 1, wallet: 1, wallet_wining: 1 } }
                ],
                as: 'user_id'
            }
        },
        {
            $project: {
                _id: 0,
                users: '$user_id',
            },
        }
    ]);
    if (usersList.length > 0){
        return usersList[0].users;
    } else {
        return [];
    }
}