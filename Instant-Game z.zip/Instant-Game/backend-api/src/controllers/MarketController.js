var mongoose = require('mongoose');
const { Markets, MarketTimeTable } = require('../models/Markets');
const MarketResults = require('../models/MarketResults');
const MarketBids = require('../models/MarketBids');
const Transactions = require('../models/Transactions');
const Users = require('../models/Users');
const { isValid } = require('../services/validation');
const { getDateFormat, getWeekDay, isAllowToPlaceBid, allowPlaceBid, getReportDate, getDayNameArr, getGameArray, convertToUTC, getPlaceBidStatus, convertToUTCNew, getMinusOneDayDate, getTimeFormat, getGameDet, getGameDetTrans } = require('../services/common');
const Withdrawals = require('../models/Withdraw');
const { addGetTransID, addLeadingZero } = require('../services/JsonOpr');

exports.getMarketList = (req, res) => {
    (async () => {
        try {
            let createdAt = req.body.date;//{ status: 1 }
            //let week_day_name = new Date(createdAt);

            var days = getDayNameArr();
            var d = new Date(createdAt);
            var week_day_name = days[d.getDay()];
            let weekDayKey = d.getDay();
            weekDayKey = (weekDayKey == 0) ? 7 : weekDayKey;
            
            let yestDate = getMinusOneDayDate(createdAt, "10:00:00", "11:00:00", true);
            if (createdAt != yestDate) {/* for 12:00 Am TO 03:00 Am */
                weekDayKey = (weekDayKey == 1) ? 7 : (weekDayKey - 1);
                wk = (weekDayKey == 7) ? 0 : weekDayKey;
                week_day_name = days[wk];
            }

            //return res.json({ status: 1, message: 'Market Found', data: { createdAt: createdAt, week_day_name: week_day_name, weekDayKey: weekDayKey, wk: wk} });

            /* var result = await new MarketResults({ declared_date: d, week_day_type: weekDayKey, market_id: '615eb88beb5c2221bfc25792', op_1:2, op_2:3, op_3:5, digit_1:6, digit_2:8, cp_1:2, cp_2:5,cp_3:9
            }).save(); */
            let myDate = getDateFormat(d);
            
            let date1 = convertToUTC(myDate + ' 00:00:00');
            let date2 = convertToUTC(myDate + ' 23:59:59');
            //whMar.declared_date = { $gte: new Date(date1), $lte: new Date(date2) };
            //status: 1, 
            var resopnse = await MarketTimeTable.find({ week_day_name: week_day_name}).populate('market_id','_id name status first_letter second_letter');
            if (resopnse) {
                var sendRes = [];
                //return res.json({ status: 1, message: 'Market Found', data: resopnse });
                // for (let i = 0; i < resopnse.length; i++) {
                var activeArr = [], inactiveArr = [];
                sendRes = await Promise.all(resopnse.map(async (row) => {
                    //console.log(36, row.market_id);
                    if(row.market_id != null){
                        var marketID = row.market_id._id;
                        var marketNumberCode = '***-**-***';
                        //console.log(30, { declared_date : { $gte: new Date(date1), $lte: new Date(date2) }, week_day_type: weekDayKey, market_id: marketID});
                        //{ declared_date : { $gte: new Date(date1), $lte: new Date(date2) }, week_day_type: weekDayKey, market_id: marketID}
                        let result_date = getMinusOneDayDate(createdAt, row.bid_open_time,row.bid_close_time, true);
                        if (createdAt != result_date){
                            //weekDayKey = (weekDayKey == 0) ? 7 : weekDayKey;
                        }
                        //, week_day_type: weekDayKey
                        var result = await MarketResults.findOne({ result_date: result_date, market_id: marketID});
                        
                        let allowOpen = 1; let allowClose = 1;
                        if (!await getPlaceBidStatus(row.bid_open_time, row.bid_close_time)) {
                            allowOpen = 0;
                        }
                        //console.log(48, await getPlaceBidStatus(row.bid_open_time, row.bid_close_time, true));
                        if (!await getPlaceBidStatus(row.bid_open_time, row.bid_close_time,true)) {
                            allowClose = 0;
                        }
                        //allowClose = await getPlaceBidStatus(row.bid_open_time, row.bid_close_time, true);

                        if (result){
                            //console.log(43, JSON.stringify(result));
                            if(result.is_open_published == 1){
                                allowOpen = 0;
                                marketNumberCode = result.op_1 +''+ result.op_2 +''+ result.op_3+'-'+result.digit_1+'*'+'-***';
                            }
                            if(result.is_published == 1){
                                allowClose = 0;
                                marketNumberCode = result.op_1 +''+ result.op_2 +''+ result.op_3+'-'+result.digit_1+''+result.digit_2+'-'+result.cp_1+''+result.cp_2+''+result.cp_3;
                            }
                        }
                        let pushArr = {
                            "_id": marketID,
                            "name": row.market_id.name,
                            "startTime": row.bid_open_time,
                            "endTime": row.bid_close_time,
                            "marketNumberCode": marketNumberCode,
                            "market_status": row.market_id.status,
                            "first_letter": row?.market_id?.first_letter,
                            "second_letter": row?.market_id?.second_letter,
                            "status": row.status,
                            "allowOpen": allowOpen,
                            "allowClose": allowClose,
                            //"weekDayKey": weekDayKey
                        };
                        if(row.market_id.status == 1 && row.status == 1){
                            activeArr.push(pushArr);
                        } else {
                            inactiveArr.push(pushArr);
                        }
                        return pushArr;
                    }
                }));/* for response */

                sendRes = await sendRes.filter(v =>{
                    return (v !== undefined && v !== null)
                });
                sendRes = await sendRes.sort(function(a,b){
                return new Date(myDate + " "+a.startTime) - new Date(myDate + " "+b.startTime);
                });

                /* active - inactive */

                /* commented on 25-11-2022 */
                /* activeArr = await activeArr.filter(v =>{
                    return (v !== undefined && v !== null)
                });
                inactiveArr = await inactiveArr.filter(v =>{
                    return (v !== undefined && v !== null)
                });
                activeArr = await activeArr.sort(function(a,b){
                    return new Date(myDate + " "+a.startTime) - new Date(myDate + " "+b.startTime);
                });
                inactiveArr = await inactiveArr.sort(function(a,b){
                    return new Date(myDate + " "+a.startTime) - new Date(myDate + " "+b.startTime);
                }); */
                /* commented on 25-11-2022 */

                /* active - inactive */

                var moment = require('moment');
                let currDate = new Date();
                let currTime =  moment(currDate).format('HH:mm:ss');
                
                let newArr = [], newArr2 = [];
                await Promise.all(sendRes.map(async (row) => {
                    if (new Date(myDate + " " + currTime) >= new Date(myDate + " " + row.endTime)){
                        newArr2.push(row);
                    } else {
                        newArr.push(row);
                    }
                }));
                newArr2.reverse();
                sendRes = await newArr.concat(newArr2); 

                //
                /* commented on 25-11-2022 */
                /* let newArrv2 = [], newArr2v2 = [];
                await Promise.all(activeArr.map(async (row) => {
                    if (new Date(myDate + " " + currTime) >= new Date(myDate + " " + row.endTime)){
                        newArr2v2.push(row);
                    } else {
                        newArrv2.push(row);
                    }
                }));
                newArr2v2.reverse();
                sendRes = await newArrv2.concat(newArr2v2); 
                sendRes = await sendRes.concat(inactiveArr); */ 
                /* commented on 25-11-2022 */
                //
                return res.json({ status: 1, message: 'Market Found', data: sendRes });
            } else {
                return res.json({ status: 0, message: "Record Not Found", data: {} });
            }
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error, data: {} });
        }
    })();
}
exports.getSimpleMarketListPagination = (req, res) => {
    (async () => {
        try {
            let page = (req.body.page) ? req.body.page:1;
            let perPage = 30;
            let offset = (perPage * (page-1));
            var resopnse = await Markets.find({ status: 1 },"_id name").limit(perPage)
            .skip(offset)
            .sort({
                createdAt: -1
            });
            if (resopnse.length > 0) {
                return res.json({ status: 1, message: "Market List", data: resopnse });
            } else {
                return res.json({ status: 0, message: "Record Not Found", data: {} });
            }
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error });
        }
    })();
}
exports.placeBid = (req, res) => {
    //(0 = SingleOpenDigit, 1 SingleCloseDigit, 2 = Jodi, 3 SingleOpenPanna, 4 Double OpenPanna, 5 TripleopenPanna, 6 SingleClosePanna, 7 DoubleClosePanna 8 TripleClosePanna)
    (async () => {
        try {
            if (!await isValid(req.body.market_id)) {
                return res.json({ status: 0, message: 'Market ID is required', data: {} });
            }
            if (req.body.game_type_id == '' || req.body.game_type_id == null) {
                return res.json({ status: 0, message: 'Game Type Id is required', data: {} });
            }
            /* if (!await isValid(req.body.game_type_id)) {
                return res.json({ status: 0, message: 'Game Type Id is required', data: {} });
            } */
            if (!await isValid(req.body.bid_details)) {
                return res.json({ status: 0, message: 'Bid details are required', data: {} });
            }
            let market_id = req.body.market_id;
            let game_type_id = req.body.game_type_id;
            let bid_details = req.body.bid_details;

            var week_day_type = getWeekDay();
            week_day_type = (week_day_type == 0) ? 7 : week_day_type;
            
            let marketDet = await Markets.findById(market_id);
            let isMarketTimTbl = await MarketTimeTable.findOne({ market_id: market_id, week_day_type: week_day_type });
            if (!isMarketTimTbl){
                return res.json({ status: 0, message: 'Timetable Not Found, Not Allowed To Placed Bid', data: {} });
            }

            //return res.json({ status: 0, message: 'Report Date', data: getReportDate(isMarketTimTbl.bid_open_time, isMarketTimTbl.bid_close_time) });
            if (isMarketTimTbl.status == 0){
                return res.json({ status: 0, message: 'Market Is In Active, Not Allowed To Placed Bid', data: {} });
            }
            
            let openGames = getGameArray();
            game_type_id = parseInt(game_type_id);
            
            if (openGames.indexOf(game_type_id) > -1) {
                if (!await allowPlaceBid(isMarketTimTbl.bid_open_time, isMarketTimTbl.bid_close_time)) {
                    return res.json({ status: 0, message: 'Time Up', data: {} });
                }
            }
            
            let closeGames = getGameArray(true);
            //return res.json({ status: 0, message: 'closeGames', data: { allow: allowPlaceBid(isMarketTimTbl.bid_open_time, isMarketTimTbl.bid_close_time, true),closeGames: closeGames, index: closeGames.indexOf(game_type_id)} });
            if (closeGames.indexOf(game_type_id) > -1) {
                if (!await allowPlaceBid(isMarketTimTbl.bid_open_time, isMarketTimTbl.bid_close_time,true)){
                    return res.json({ status: 0, message: 'Time Up', data: {} });
                }
            }
            //return res.json({ status: 0, message: 'stop execution', data: {} });
            var cdate = getDateFormat();
            let wher = { market_id: mongoose.Types.ObjectId(market_id), week_day_type: week_day_type, declared_date: { $gte: convertToUTCNew(cdate + ' 00:00:00'), $lte: convertToUTCNew(cdate + ' 23:59:59') } };
            let resData = await MarketResults.findOne(wher);
            
            if (resData != null){
                if (openGames.indexOf(game_type_id) > -1 && resData.is_open_published == 1){
                    return res.json({ status: 0, message: 'Result Decalred, Not Allow To Placed Bid', data: {} });
                }else if (closeGames.indexOf(game_type_id) > -1 && resData.is_published == 1){
                    return res.json({ status: 0, message: 'Result Decalred, Not Allow To Placed Bid', data: {} });
                }
                /* if (!await isAllowToPlaceBid(resData, game_type_id)){
                    return res.json({ status: 0, message: 'Result Decalred, Not Allow To Placed Bid', data: {} });
                } */
            }
            
            //return res.json({ status: 0, message: '1234567890', data: {} });
            /* 
                bid_details=>game_type_id = 0-8 => {bid_digit,bid_amount}
                bid_details=>game_type_id = 9,10 => {panna, digit,bid_amount}
                bid_details=>game_type_id = 11 => {open_panna, close_panna,bid_amount}
             */
            let report_date = getReportDate(isMarketTimTbl.bid_open_time, isMarketTimTbl.bid_close_time);
            var inserts = []; var amount = 0;
            //req.userDet = await Users.findOne({ _id: mongoose.Types.ObjectId('61a4d67efc1974e741ef2ce5')});
            var user_id = req.userDet.id;
            
            var tnx_id = await addGetTransID();

            if (bid_details.length > 0){
                let isNegative = false;
                let ijk = 4;//bid_details.length * 4;
                const addedBid = [];
                for (let i = 0; i < bid_details.length; i++) {
                    var inssub = { market_id: market_id, user_id: user_id, game_type_id: game_type_id, report_date: report_date };
                    inssub.amount = bid_details[i].bid_amount;
                    let currentDate = new Date();
                    currentDate.setSeconds(currentDate.getSeconds() - ijk);
                    ijk = ijk+4;
                    inssub.createdAt = currentDate;
                    // inssub.updatedAt = currentDate;
                    if(parseFloat(bid_details[i].bid_amount) < 0){
                        isNegative = true;
                    }
                    // amount = parseFloat(amount) + parseFloat(bid_details[i].bid_amount);
                    if (game_type_id == 11){
                        if(bid_details[i].open_panna.toString().length == 1 && bid_details[i].open_panna.toString() == "0"){
                            inssub.panna_1 = "000";
                        } else {
                            inssub.panna_1 = bid_details[i].open_panna;
                        }
                        if(bid_details[i].close_panna.toString().length == 1 && bid_details[i].close_panna.toString() == "0"){
                            inssub.panna_2 = "000";
                        } else {
                            inssub.panna_2 = bid_details[i].close_panna;
                        }
                    } else if (game_type_id == 9 || game_type_id == 10) {
                        if(bid_details[i].panna.toString().length == 1 && bid_details[i].panna.toString() == "0"){
                            inssub.panna_1 = "000";
                        } else {
                            inssub.panna_1 = bid_details[i].panna;
                        }
                        inssub.panna_2 = bid_details[i].digit;
                        inssub.game_type_id = bid_details[i].game_type_id;
                    } else {
                        if(game_type_id == 2 && bid_details[i].bid_digit.toString().length == 1){
                            inssub.panna_1 = `0${bid_details[i].bid_digit.toString()}`;
                        } else {
                            if(game_type_id == 5 || game_type_id == 8){
                                if(bid_details[i].bid_digit.toString().length == 1 && bid_details[i].bid_digit.toString() == "0"){
                                    inssub.panna_1 = "000";
                                } else {
                                    inssub.panna_1 = bid_details[i].bid_digit;
                                }
                            } else {
                                inssub.panna_1 = bid_details[i].bid_digit;
                            }
                        }
                    }
                    inssub.tnx_id = tnx_id;
                    
                    const bidNoToAdd = `${inssub.panna_1}_${inssub.panna_2}`;
                    if(addedBid.indexOf(bidNoToAdd) == -1){
                        tnx_id = (parseInt(tnx_id) + 1);
                        tnx_id = await addLeadingZero(tnx_id);

                        amount = parseFloat(amount) + parseFloat(bid_details[i].bid_amount);
                        addedBid.push(bidNoToAdd);
                        inserts.push(inssub);
                    }
                }
                if(isNegative){
                    return res.json({ status: 0, message: 'Not Allwed To Placed Bid.', data: {} });
                } else if(amount < 0){
                    return res.json({ status: 0, message: 'Not Allwed To Placed Bid', data: {} });
                }
            } else {
                return res.json({ status: 0, message: 'No Any Bid Data, Not Allwed To Placed Bid', data: {} });
            }
            //return res.json(inserts);          
            var walletAmount = req.userDet.wallet;
            var winningWalletAmount = req.userDet.wallet_wining;
            var withReqAmount = 0;
            /* Bonus Wallet Amount */
            let bonusWalletAmount = 0;
            const amtAddedTotTrans = await Transactions.find({ user_id: user_id, tnx_type: {$in: [4, 5]}, entry_type: 1, wallet_type: 2, pay_status: 1 });
            
            if(amtAddedTotTrans && amtAddedTotTrans.length > 0){
                bonusWalletAmount = req.userDet.wallet_bonus;
            }
            var curTotAmt = (walletAmount + winningWalletAmount + bonusWalletAmount);
            if (amount > curTotAmt) {
                const showMsg = req.userDet.wallet_bonus > 0 && req.userDet.wallet_bonus > amount? 'Add Money to wallet to Place Bid' : 'Insufficient Amount, Not Allwed To Placed Bid.';
                return res.json({ status: 0, message: showMsg, data: {} });
            } else {
                if (amount > walletAmount){
                    let today = getDateFormat();
                    let date1 = convertToUTCNew(today + ' 00:00:00');
                    let date2 = convertToUTCNew(today + ' 23:59:59');
                    
                    let tdWh = { user_id: user_id, status: 2, createdAt: { $gte: date1, $lte: date2 } };
                    let todayReq = await Withdrawals.findOne(tdWh);
                    if (todayReq) {
                        let penBidAmt = parseFloat(amount) - parseFloat(walletAmount);
                        withReqAmount = parseFloat(todayReq.amount);
                        let amtAftWith = winningWalletAmount - withReqAmount;
                        if (penBidAmt > amtAftWith){
                            let update = await Withdrawals.updateOne({ _id: todayReq._id }, {
                                status: 3,
                                approved_at: new Date(),
                                approved_by: req.userDet._id
                            });
                        }
                    }
                }
            }

            if (amount > walletAmount){
                //return res.json({ status: 0, message: 'Insufficient Amount In Wallet, Not Allwed To Placed Bid.', data: { wallet: walletAmount } });
            }
            /* get user amount again 20-02-24 start */
            const userBalance = await Users.findOne({ _id: user_id });
            if(userBalance){
                walletAmount = userBalance.wallet
                winningWalletAmount = userBalance.wallet_wining;
                if(amtAddedTotTrans && amtAddedTotTrans.length > 0){
                    bonusWalletAmount = userBalance.wallet_bonus;
                }
            }
            /* get user amount again 20-02-24 end */
            
            var actuwalletAmount = walletAmount;
            var actuwinningWalletAmount = winningWalletAmount;
            var actuBonunsWalletAmount = bonusWalletAmount;
            var post_balance = parseFloat(walletAmount) - parseFloat(amount);
            let isUpdateBonusWallet = false;
            if (post_balance < 0){
                winningWalletAmount = winningWalletAmount + post_balance;/* post_balance value in negative eg. -120  */
                post_balance = 0;
                if (winningWalletAmount < 0){
                    isUpdateBonusWallet = true;
                    bonusWalletAmount = bonusWalletAmount + winningWalletAmount;/* winningWalletAmount value in negative eg. -120  */
                    winningWalletAmount = 0;
                    if(bonusWalletAmount < 0){
                        bonusWalletAmount = 0;
                    }
                }
            }
            //return res.json({ status: 0, message: 'amount issue', data: { amount:amount, wallet: actuwalletAmount, post_balance: post_balance, winningWalletAmount: winningWalletAmount } });
            const updateWalletObj = { wallet: post_balance, wallet_wining: winningWalletAmount }
            if(isUpdateBonusWallet){
                updateWalletObj.wallet_bonus = bonusWalletAmount;
            }
            await Users.updateOne({ _id: user_id }, updateWalletObj);

            let data = await MarketBids.insertMany(inserts);
            if (data) {
                await addGetTransID('trans_id', tnx_id);
                var insTrans = []; let penAmount = 0;
                for (let i = 0; i < data.length; i++) {    
                    let currentDate = new Date();
                    currentDate.setSeconds(currentDate.getSeconds() - i);

                    var refe_id = data[i]._id;
                    let wallet_type = 2;/* 2 wallet, 1=winning wallet */
                    let postTransBal = actuwalletAmount;
                    let fnlAmount = data[i].amount;
                    let pnna = (data[i].panna_2 != null)?data[i].panna_1+'-'+data[i].panna_2:data[i].panna_1;
                    var trsDet = "Placed Bid ("+marketDet.name+"-"+pnna+")";
                    let gameDet = await getGameDetTrans(data[i].game_type_id);
                    trsDet = "Placed Bid ("+marketDet.name+"-"+gameDet+"-"+pnna+")";

                    let penAmount = parseFloat(data[i].amount);
                    if (actuwalletAmount > 0){
                        if (penAmount > actuwalletAmount){
                            postTransBal = 0;
                            fnlAmount = actuwalletAmount;
                            penAmount = penAmount - actuwalletAmount;
                            actuwalletAmount = 0;
                        } else {
                            actuwalletAmount = actuwalletAmount - data[i].amount;
                            penAmount = 0;
                        }
                        postTransBal = actuwalletAmount;
                    } else { 
                        if(actuwinningWalletAmount > 0){
                            wallet_type = 1;
                            if (penAmount > actuwinningWalletAmount){
                                postTransBal = 0;
                                fnlAmount = actuwinningWalletAmount;
                                penAmount = penAmount - actuwinningWalletAmount;
                                actuwinningWalletAmount = 0;
                            } else {
                                actuwinningWalletAmount = actuwinningWalletAmount - data[i].amount;
                                penAmount = 0;
                            }
                            postTransBal = actuwinningWalletAmount;
                        } else {
                            wallet_type = 3;
                            let didAmt = parseFloat(data[i].amount);
                            actuBonunsWalletAmount = actuBonunsWalletAmount - didAmt;
                            postTransBal = actuBonunsWalletAmount < 0 ? 0 : actuBonunsWalletAmount;
                            penAmount = 0;
                        }
                    }
                    
                    const insObj = {
                        user_id: user_id,
                        refe_id: refe_id,
                        // amount: fnlAmount,
                        charge_amount: 0,
                        // final_amount: fnlAmount,
                        // post_balance: postTransBal,//actuwalletAmount,
                        tnx_type: 1,//placed bid
                        // wallet_type: wallet_type,//wallet
                        details: trsDet,
                        entry_type: 2,//debit entry
                        tnx_id: data[i].tnx_id,
                        created_by: req.userDet._id,
                        createdAt: currentDate,
                        // updatedAt: currentDate
                    };
                    const subArr = { ...insObj, amount: fnlAmount, final_amount: fnlAmount, post_balance: postTransBal, wallet_type: wallet_type};
                    insTrans.push(subArr);
                    if (penAmount != 0) {
                        // actuwinningWalletAmount = actuwinningWalletAmount - penAmount;
                        let deductFromWinning = 0; let deductFromBonus = 0;
                        if(actuwinningWalletAmount > 0){
                            if(penAmount > actuwinningWalletAmount){
                                deductFromWinning = actuwinningWalletAmount;
                                penAmount = penAmount - actuwinningWalletAmount;
                                deductFromBonus = penAmount;
                                actuwinningWalletAmount = 0;
                                actuBonunsWalletAmount = actuBonunsWalletAmount - deductFromBonus;
                                actuBonunsWalletAmount = actuBonunsWalletAmount < 0 ? 0 : actuBonunsWalletAmount;
                                penAmount = 0;
                            } else {
                                deductFromWinning = penAmount;
                                actuwinningWalletAmount = actuwinningWalletAmount - penAmount;
                                penAmount = 0;
                            }
                        }
                        
                        if(penAmount > 0){
                            deductFromBonus = penAmount;
                            actuBonunsWalletAmount = actuBonunsWalletAmount - deductFromBonus;
                            actuBonunsWalletAmount = actuBonunsWalletAmount < 0 ? 0 : actuBonunsWalletAmount;
                            penAmount = 0;
                        }
                        
                        if(deductFromWinning > 0){
                            const subArr2 = {
                                ...insObj,
                                amount: deductFromWinning,
                                final_amount: deductFromWinning,
                                post_balance: actuwinningWalletAmount,
                                wallet_type: 1,//winnig wallet
                            };
                            insTrans.push(subArr2);
                        }
                        if(deductFromBonus > 0){
                            const subArr2 = {
                                ...insObj,
                                amount: deductFromBonus,
                                final_amount: deductFromBonus,
                                post_balance: actuBonunsWalletAmount,
                                wallet_type: 3,//bonus wallet
                            };
                            insTrans.push(subArr2);
                        }
                        penAmount = 0;
                    }
                    
                }
                
                let dataNew = await Transactions.insertMany(insTrans);
                if (dataNew){
                    return res.json({ status: 1, message: 'Bid Placed Successfully', data: { post_balance: post_balance } });
                } else {
                    return res.json({ status: 0, message: "Bid Not Placed", data: {} });
                }
            } else {
                return res.json({ status: 0, message: "Bid Not Placed", data: {} });
            }
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error.message || "Something Went Wrong", data: {} });
        }
    })();
}

exports.getMarketListWithResult = (req, res) => {
    (async () => {
        try {
            let createdAt = getDateFormat();//{ status: 1 }

            var days = getDayNameArr();
            var d = new Date(createdAt);
            var week_day_name = days[d.getDay()];
            let weekDayKey = d.getDay();
            weekDayKey = (weekDayKey == 0) ? 7 : weekDayKey;
            
            let yestDate = getMinusOneDayDate(createdAt, "10:00:00", "11:00:00", true);
            if (createdAt != yestDate) {/* for 12:00 Am TO 03:00 Am */
                weekDayKey = (weekDayKey == 1) ? 7 : (weekDayKey - 1);
                wk = (weekDayKey == 7) ? 0 : weekDayKey;
                week_day_name = days[wk];
            }

            var resopnse = await MarketTimeTable.find({ week_day_name: week_day_name}).populate('market_id','_id name status first_letter second_letter');
            if (resopnse) {
                var sendRes = [];
                var activeArr = [], inactiveArr = [];
                sendRes = await Promise.all(resopnse.map(async (row) => {
                    if(row.market_id != null){
                        var marketID = row.market_id._id;
                        var marketNumberCode = '***-**-***';
                        let result_date = getMinusOneDayDate(createdAt, row.bid_open_time,row.bid_close_time, true);
                        if (createdAt != result_date){
                            //weekDayKey = (weekDayKey == 0) ? 7 : weekDayKey;
                        }
                        //, week_day_type: weekDayKey
                        var result = await MarketResults.findOne({ result_date: result_date, market_id: marketID});
                        
                        let allowOpen = 1; let allowClose = 1;
                        if (!getPlaceBidStatus(row.bid_open_time, row.bid_close_time)) {
                            allowOpen = 0;
                        }
                        //console.log(48, await getPlaceBidStatus(row.bid_open_time, row.bid_close_time, true));
                        if (!getPlaceBidStatus(row.bid_open_time, row.bid_close_time,true)) {
                            allowClose = 0;
                        }

                        if (result){
                            //console.log(43, JSON.stringify(result));
                            if(result.is_open_published == 1){
                                allowOpen = 0;
                                marketNumberCode = result.op_1 +''+ result.op_2 +''+ result.op_3+'-'+result.digit_1+'*'+'-***';
                            }
                            if(result.is_published == 1){
                                allowClose = 0;
                                marketNumberCode = result.op_1 +''+ result.op_2 +''+ result.op_3+'-'+result.digit_1+''+result.digit_2+'-'+result.cp_1+''+result.cp_2+''+result.cp_3;
                            }
                        }
                        let pushArr = {
                            "id": marketID,
                            "name": row.market_id.name,
                            "result": marketNumberCode,
                        };
                        if(row.market_id.status == 1 && row.status == 1){
                            activeArr.push(pushArr);
                        } else {
                            inactiveArr.push(pushArr);
                        }
                        return pushArr;
                    }
                }));/* for response */

                sendRes = sendRes.filter(v =>{
                    return (v !== undefined && v !== null)
                });
                
                return res.json({ status: 1, message: 'Market Found', data: sendRes });
            } else {
                return res.json({ status: 0, message: "Record Not Found", data: {} });
            }
        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error, data: {} });
        }
    })();
}