const Crypto = require("crypto");
const Axios = require('axios');
const MagicPayCreateURLLogs = require("../models/MagicPayCreateURLLogs");
const { createTransaction } = require("../services/MagicPay");
const MagicPay = require("../services/MagicPay");
const { convertToUTCNew } = require("../services/common");

exports.payment_request = async (req, res) => {
    (async () => {
        try {
            let body = req.body;
            let secure_hash = null;
            let salt = 'b8b08569c41715fcb96bbc1e45fcd461283e6e8e';
            let hash_string = salt;
            Object.keys(body).forEach(val => {
                let key = val;
                let value = body[val];
                if(value.length > 0){
                    hash_string += '|'+value;
                }
            });
            if(hash_string.length > 0){
                secure_hash = Crypto.createHash('sha512').update(hash_string).digest('hex').toUpperCase();
            }
            body.hash = secure_hash;
            // body.api_key = "1c62f141-4be4-4671-9552-9b6f8e58ddfc";
            console.log(hash_string);
            Axios.post('https://api.innopaytech.com/v2/getpaymentrequesturl',body).
            then((res) => res.data).
            then(res => {
                console.log(res);
            }).catch(error => {
                console.log(error.message);
            })
            return res.json({ status: 1, message: '' });

        } catch (error) {
            console.log(error);
            return res.json({ status: 0, message: error });
        }
    })();
};
/* 09-08-2024 */
exports.magicPayRedirect = async (req, res) => {
    const { txnStatus: status, orderId, utr } = req.query;
    const today = new Date();
    today.setMinutes(today.getMinutes() - 5);
    const end   = convertToUTCNew(new Date());
    const start = convertToUTCNew(today);
    const row = await MagicPayCreateURLLogs.findOne({ transaction_id: orderId, createdAt: { $gte: start, $lte: end }});
    if(row){
        if(row.status == "PENDING"){
            const resp = await MagicPay.checkPaymentStatus(orderId);
            if(resp.status > 0){
                await createTransaction(row, resp?.data?.txnStatus, resp?.data?.utr, true);
            }
            // await createTransaction(row, status, utr);
        }
    }

    return res.render('magic-pay');
};
