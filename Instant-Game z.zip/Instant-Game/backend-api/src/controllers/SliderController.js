// const db = require("../models");
var mongoose = require('mongoose');
const Slider = require("../models/Slider");

exports.list = async (req, res) => {
    (async () => {
        try{
            // let slider_list = await Slider.where({ status: 1 }).find({ $orderby: { createdAt : -1 } }).limit(8);
            let type = req.body.type ? req.body.type : 'mobile';
            const slider_list = await Slider.find({type, status: 1 }).sort({createdAt:  -1}).limit(8);
            if(slider_list.length > 0){
                let sliders = JSON.parse(JSON.stringify(slider_list));
                sliders = sliders.map((itm)=>{
                    return {
                        ...itm,
                        image_url:`${process.env.IMG_BASE_URL}${itm.image_url}`
                    };
                });
                return res.json({status:1, message:'Slider data find successfully.',data: sliders});
            }
            return res.json({status:0, message:'No data found.'});
        } catch (error) {
            return res.json({ status: 0, message: error?.message, data: {} });
        }
    })();
};