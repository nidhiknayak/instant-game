const router = require('express').Router();
const PaymentController = require('../controllers/PaymentController');

router.get('/magic-pay/redirect', PaymentController.magicPayRedirect);

module.exports = router;