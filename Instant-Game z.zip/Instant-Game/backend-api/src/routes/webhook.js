const router = require('express').Router();
const multer = require('multer');
const WebhookController = require('../controllers/WebhookController');
const upload = multer({ dest: 'uploads/' });

router.post('/letspay/payin', upload.none(), WebhookController.letspayPayin);
router.post('/letspay/payout', upload.none(), WebhookController.letspayPayout);

router.post('/amez-world/payin', WebhookController.amezWorldPayin);
router.post('/amez-world/payout', WebhookController.amezWorldPayout);

router.post('/geckio-pay/payin', WebhookController.geckioPayin);
router.post('/geckio-pay/payout', WebhookController.geckioPayout);

router.post('/gennie-pay/payin', WebhookController.genniePayin);
router.post('/gennie-pay/payout', WebhookController.genniePayout);

/* 05-08-2024 */
router.post('/magic-pay/payin', WebhookController.magicPayin);

module.exports = router;