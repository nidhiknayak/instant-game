module.exports = (app, router) => {
    const marketResultContr = require('../controllers/admin/MarketResultController');
    const { check_token_admin } = require('../services/check_token');
    
    // router.post('/market-result/update-market-partial-result', check_token_admin, marketResultContr.updateMarketResultPartial);
    router.post('/market-result/update-market-partial-result', marketResultContr.updateMarketResultPartial);
    router.post('/market-result/declare-market-partial-result', marketResultContr.declareMarketResultPartial);
    router.post('/market-result/rollback-market-partial-result', marketResultContr.rollbackMarketResultPartial);
    router.post('/market-result/refund-market-partial-result', marketResultContr.refundMarketResultPartial);

    return router;
};