module.exports = app => {
	const UserController = require('../controllers/UserController.js');
	const UserProfileController = require('../controllers/UserProfileController.js');
	const SliderController = require('../controllers/SliderController');
	const marketContr = require('../controllers/MarketController');
	const paymentContr = require('../controllers/PaymentController');

	const UserInfoController = require('../controllers/UserInfoController.js');

	// const isvalid = require('../middleware.js');
	const {check_token} = require('../services/check_token');
	var router = require('express').Router();

	router.post('/login', UserController.login);
	/* 11-12-2021 Start */
	router.post('/get-otp', UserController.getOtp);
	router.post('/verify-otp', UserController.verifyOtp);
	/* 11-12-2021 End */

	router.post('/logout', check_token, UserController.logout);
	router.post('/upload-image', UserProfileController.uploadImage);
	router.post('/detail', check_token, UserController.getUser);
	/* 24-11-2021 */
	router.get('/get-withdraw-status', check_token, UserController.checkWithdrawAllow);
	router.post('/get-wallet-amount', check_token, UserController.getWalletAmount);
	router.post('/get-wallet-history', check_token, UserController.getWalletHistory);
	
	
	/* 22-11-2021 */
	router.post('/check-app-version', check_token, UserController.checkAppVersion);
	router.post('/innopay-callback', UserController.innoPayResp);
	/* 30-11-2021 */
	router.post('/get-payment-setting', UserController.getPaymentSetting);

	/* After Login */
	router.post('/save-bank', check_token, UserProfileController.addBank);
	router.post('/get-bank', check_token, UserProfileController.getBank);
	router.get('/get-slider', check_token, SliderController.list);
	router.post('/get-market-list', check_token, marketContr.getMarketList);
	router.post('/get-simple-market-list', check_token, marketContr.getSimpleMarketListPagination);
	router.post('/get-notice-board-list', check_token, UserProfileController.getNoticeBoardList);
	router.post('/place-bid', check_token, marketContr.placeBid);
	router.post('/payment-request',check_token, paymentContr.payment_request);
	router.post('/add-wallet-amount',check_token, UserProfileController.add_wallet_amount);
	router.post('/withdraw-request', check_token, UserProfileController.addWithdraw);
	router.post('/withdraw-history', check_token, UserProfileController.withdrawHistory);

	/* History */
	/* Bid */ 
	router.post('/get-bids', check_token, UserInfoController.getUserBidHist);
	router.post('/get-bids-v2', check_token, UserInfoController.getUserBidHistV2);
	router.post('/get-bids-v3', check_token, UserInfoController.getUserBidHistV3);
	router.post('/get-bids-v4', check_token, UserInfoController.getUserBidHistV4);
	router.post('/get-bids-v4-new', check_token, UserInfoController.getUserBidHistV4New);
	/* Winning */
	router.post('/get-winning-history', check_token, UserInfoController.getWinningHistory);
	
	/* Check Referral Code That Code IS Exist OR Not 27-11-23 */
	router.post('/check-referral', UserProfileController.checkReferralCode);
	/* Apply User Referral Code */
	router.post('/apply-referral', check_token, UserProfileController.applyReferralCode);

	router.get('/get-game-ratio', check_token, UserProfileController.getGameRatio);
	/* 16-11-2021 */
	router.post('/get-notification-list', check_token, UserInfoController.getNotificationList);
	
	/* 20-12-2021 Colors Game Route */
	router.post('/get-game-setting', UserController.getGameSetting);
	router.post('/get-game-duration', UserController.getGameDuration);

	router.post('/update-notification', check_token, UserProfileController.updateNotification);
	/*  */
	router.post('/get-bonus-wallet-history',check_token, UserProfileController.getBonusWalletHistory);
	/* 02-11-2022 */
	router.post('/get-passbook-history', check_token, UserProfileController.getPassbookHistory);
	router.post('/get-passbook-history-v2', check_token, UserProfileController.getPassbookHistoryV2);
	router.post('/get-hash-string', check_token, UserProfileController.getHashString);
	router.post('/get-payment-url', check_token, UserProfileController.getAnilexPaymentURL);
	router.post('/check-payment-status', check_token, UserProfileController.getAnilexPaymentStatus);

	router.post('/get-payment-url-amez-world', check_token, UserProfileController.getAmezWorldPaymentURL);
	router.post('/check-payment-status-amez-world', check_token, UserProfileController.getAmezWorldPaymentStatus);
	// router.get('/get-market-result', UserProfileController.getAllMarketResultByDate);
	router.get('/get-market-result', marketContr.getMarketListWithResult);
	app.use('/api/user', router);
	app.use('/api/webhook', require('./webhook'));
	app.use('/payment', require('./payment.routes'));
};