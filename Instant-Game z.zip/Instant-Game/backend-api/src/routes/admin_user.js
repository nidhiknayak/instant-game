const {check_token_admin} = require('../services/check_token');
module.exports = (app, router) => {
    const UserController = require('../controllers/admin/UserController');
    router.post('/user/list',check_token_admin, UserController.list);
    router.post('/user/save',check_token_admin, UserController.save);
    router.get('/user/edit/:id',check_token_admin, UserController.edit);
    router.post('/user/update',check_token_admin, UserController.update);
    router.get('/user/delete/:id?',check_token_admin, UserController.delete);
    router.post('/user/status_change',check_token_admin, UserController.status_change);
    router.post('/user/add_wallet_amount',check_token_admin, UserController.add_wallet_amount);
    router.post('/user/deduct_wallet_amount',check_token_admin, UserController.deduct_wallet_amount);
    router.post('/user/get-bid-list', check_token_admin, UserController.getUserBidList);
    router.post('/user/get-wallet-history', check_token_admin, UserController.getUserWalletHist);
    router.post('/user/update-user-bid', check_token_admin, UserController.updateUserBid);
    router.post('/user/add-money-to-wallet', check_token_admin, UserController.addMoneyToWallet);
    router.post('/user/remove-bank-detail', check_token_admin, UserController.removeBankDetail);
    return router;
};