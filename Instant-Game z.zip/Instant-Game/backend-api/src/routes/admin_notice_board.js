const {check_token_admin} = require('../services/check_token');
module.exports = (app, router) => {
    const noticeBoardController = require('../controllers/admin/NoticeBoardController.js');
    const DeleteDataController = require('../controllers/admin/DeleteDataController.js');
    router.post('/notice-board/save',check_token_admin, noticeBoardController.save);
    router.post('/notice-board/update',check_token_admin, noticeBoardController.update);
    router.post('/notice-board/status_change',check_token_admin, noticeBoardController.status_change);
    router.post('/notice-board/list',check_token_admin, noticeBoardController.list);
    router.get('/notice-board/edit/:id?',check_token_admin, noticeBoardController.edit);
    router.get('/notice-board/delete/:id?',check_token_admin, noticeBoardController.delete);
    router.get('/truncate-data', DeleteDataController.truncateData);
    return router;
};