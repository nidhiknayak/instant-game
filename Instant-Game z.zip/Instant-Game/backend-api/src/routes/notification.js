module.exports = (app, router) => {
    const NotificationController    = require('../controllers/admin/NotificationController');
    const { check_token_admin }     = require('../services/check_token');
    
    router.post('/notification/list', check_token_admin, NotificationController.list);
    router.post('/notification/save', check_token_admin, NotificationController.save);
    router.post('/notification/send',check_token_admin, NotificationController.send);

    return router;
};