const {check_token_admin} = require('../services/check_token');
module.exports = (app, router) => {
    const sliderContr = require('../controllers/admin/SliderController.js');
    router.post('/slider/save',check_token_admin, sliderContr.save);
    router.post('/slider/update',check_token_admin, sliderContr.update);
    router.post('/slider/status_change',check_token_admin, sliderContr.status_change);
    router.post('/slider/list',check_token_admin, sliderContr.list);
    router.get('/slider/edit/:id?',check_token_admin, sliderContr.edit);
    router.get('/slider/delete/:id?',check_token_admin, sliderContr.delete);
    return router;
};