module.exports = (app, router) => {
    const WithdrawController = require('../controllers/admin/WithdrawController');
    const { check_token_admin } = require('../services/check_token');
    
    router.post('/withdraws',check_token_admin, WithdrawController.getWithdrawList);
    router.get('/withdraw/view/:id', check_token_admin, WithdrawController.getSinWithdraw);
    router.post('/withdraw/approve_reject', check_token_admin, WithdrawController.approveRejectWithdraw);
    router.post('/withdraw/request_enabled_disabled', check_token_admin, WithdrawController.requestEnabledDisabled);
    router.post('/setting', check_token_admin, WithdrawController.getSettingData);
    router.get('/withdraw/edit/:id?', check_token_admin, WithdrawController.editWithdraw);
    router.post('/withdraw/update', check_token_admin, WithdrawController.updateWithdraw);
    /* 23-11-2021 */
    router.post('/upload-apk', check_token_admin, WithdrawController.uploadNewApk);
    
    /* tTransactions List */
    router.post('/transactions', check_token_admin, WithdrawController.getTransactionList);
    router.post('/bank-deduct-record', check_token_admin, WithdrawController.bankDeductRecord);
    router.post('/transactions/generate-pdf', check_token_admin, WithdrawController.transactionListGeneratePdf);
    /* 27-10-2021 */
    router.post('/update_setting', check_token_admin, WithdrawController.updateSetting);
    router.post('/update_setting_amount', check_token_admin, WithdrawController.updateSettingAmounts);
    router.post('/validate-bank-account', check_token_admin, WithdrawController.checkBankStatus);
    router.post('/fundtransfer', check_token_admin, WithdrawController.fundTransfer);
    router.post('/check-fundtransfer-status', check_token_admin, WithdrawController.checkTransferStatus);
    router.get('/get-balance', check_token_admin, WithdrawController.getCurrentBalance);
    /* 18-11-2021 */
    router.post('/withdraws/all', check_token_admin, WithdrawController.getWithdrawListAll);
    router.post('/withdraws/approve_reject_all', check_token_admin, WithdrawController.approveRejectWithdrawAll);
    /* 29-11-2021 */
    router.post('/payment/check-status', check_token_admin, WithdrawController.checkAddedPaymentStatus);
    router.post('/wallet-money', check_token_admin, WithdrawController.getWalletMoneyList);
    router.post('/wallet-money/approve_reject', check_token_admin, WithdrawController.approveRejectWalletMoney);
    router.post('/wallet-money/approve_reject_all', check_token_admin, WithdrawController.approveRejectWalletMoneySelected);

    router.post('/update_game_setting', check_token_admin, WithdrawController.updateGameSetting);
    router.post('/update-color-profit', check_token_admin, WithdrawController.updateColorProfitSetting);
    return router;
};