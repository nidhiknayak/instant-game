module.exports = (app, router) => {
    const ReportController    = require('../controllers/admin/ReportController');
    const { check_token_admin }     = require('../services/check_token');
    
    router.post('/report/daily-report', check_token_admin, ReportController.getDailyReport);
    router.post('/report/daily-report/create-pdf', check_token_admin, ReportController.dailyReportCreatePdf);
    router.post('/report/bid-list', check_token_admin, ReportController.getBidReport);
    router.post('/report/color-game-list', check_token_admin, ReportController.getColorGameReport);

    return router;
};