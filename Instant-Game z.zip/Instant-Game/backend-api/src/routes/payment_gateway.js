
const express = require('express');
const router = express.Router();
const PaymentGatewayController = require('../controllers/admin/PaymentGatewayController');
const { check_token_admin } = require('../services/check_token');

router.get('/', check_token_admin, PaymentGatewayController.getList);
router.post('/status', check_token_admin, PaymentGatewayController.changeStatusMarket);
router.post('/', check_token_admin, PaymentGatewayController.addPaymenGateway);

module.exports = router;