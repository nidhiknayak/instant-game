module.exports = app => {
	const adminContr = require('../controllers/admin/LoginController.js');
    const {check_token_admin} = require('../services/check_token');
	var router = require('express').Router();

	router.post('/login', adminContr.login);
    /* router.get('/forgot-password', adminContr.forgotPassword); */
    router.post('/change-password', check_token_admin, adminContr.changePassword);
    router.post('/logout', check_token_admin, adminContr.logout);
    
    router = require('./admin_slider')(app,router);
    router = require('./admin_notice_board')(app,router);
    router = require('./admin_user')(app,router);
    router = require('./market')(app,router);
    router = require('./withdraw')(app,router);
    
    router = require('./notification')(app,router);
    router = require('./report')(app,router);
    router = require('./market_result')(app,router);

    router.use('/payment-gateway', require('./payment_gateway'));

	app.use('/admin', router);
	
};