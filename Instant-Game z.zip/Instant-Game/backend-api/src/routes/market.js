module.exports = (app, router) => {
    const marketContr = require('../controllers/admin/MarketController');
    const { check_token_admin } = require('../services/check_token');
    /* Market */
    router.get('/markets',check_token_admin, marketContr.getMarketList); 
    router.get('/markets/edit/:id', check_token_admin, marketContr.getSinMarket);
    router.post('/market/add',check_token_admin, marketContr.addMarket);
    router.post('/market/update/:id',check_token_admin, marketContr.updateMarket);
    router.post('/market/delete',check_token_admin, marketContr.deleteMarket);
    router.post('/market/update-status', check_token_admin, marketContr.changeStatusMarket);

    /* MarketTimeTable */
    router.get('/market-timetable-list/:id', check_token_admin, marketContr.getMarketTimeTableList);
    router.post('/market-timetable/add', check_token_admin, marketContr.addMarketTimeTable);
    router.get('/market-timetable/update/:id', check_token_admin, marketContr.getSinMarketTimeTable);
    router.post('/market-timetable/delete', check_token_admin, marketContr.deleteMarketTimeTable);
    router.post('/market-timetable/save_result', check_token_admin, marketContr.updateMarketTimeTableData);

    router.post('/market-timetable/declare_result', check_token_admin, marketContr.declareMarketResult);

    router.get('/market/add-game-ratio', check_token_admin, marketContr.addGameRatio);
    router.get('/market/get-game-ratio', check_token_admin, marketContr.getGameRatio);
    router.post('/market/update-game-ratio', check_token_admin, marketContr.updateGameRatio);
    router.post('/market/get-dash-market', check_token_admin, marketContr.getDashMarket);
    router.post('/market/update-partial-result', check_token_admin, marketContr.updateMarketResultPartial);
    router.post('/market/declare-partial-result', check_token_admin, marketContr.declareMarketResultPartial);

    /* 25-11-2021 */
    router.post('/market/refund-bids', check_token_admin, marketContr.refundBids);
    /* 06-12-2021 */
    router.post('/market/result-rollback', check_token_admin, marketContr.resultRollback);

    /* 
    router.get('/market/add/:id?', marketContr.add);
    router.post('/market/delete', marketContr.delete); */

    return router;
};