var mongoose = require('mongoose');
var mongoose_delete = require('mongoose-delete');
const mongoosePaginate = require("mongoose-paginate-v2");
const mongooseAggregatePaginate = require("mongoose-aggregate-paginate-v2");

var withdrawalsSchema = new mongoose.Schema({
    user_id:{
        type: mongoose.Schema.ObjectId,
        ref:'Users',
        required:true
    },
    amount:{
        type: Number,
        default:0
    },
    charge:{
        type: Number,
        default:0/* Charge In Percentage(%) */
    },
    charge_amount:{
        type: Number,
        default:0
    },
    final_amount:{
        type: Number,
        default:0
    },
    tnx:{
        type: String,
        default:null,
    },
    merchant_ref_no:{
        type: String,
        default:null,
    },
    transaction_id:{
        type: String,
        default:null,
    },
    status:{
        type: Number,
        default:0,/* 1=success ,2=pending,3=cancel,4=processing */
    },
    approved_at:{
        type: Date,
        default:null
    },
    approved_by: {
        type: mongoose.Schema.ObjectId,
        ref: 'Admins',
        default: null
    },
},
{
    timestamps: true
}
);
withdrawalsSchema.plugin(mongoosePaginate);
withdrawalsSchema.plugin(mongooseAggregatePaginate);
withdrawalsSchema.plugin(mongoose_delete, {
    deletedAt : true,
    deletedBy: true,
    overrideMethods: ['find', 'findOne']
});
var Withdrawals = mongoose.model('Withdrawals', withdrawalsSchema, 'withdrawals');

module.exports = Withdrawals;

