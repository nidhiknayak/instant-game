var mongoose = require('mongoose');

var settingSchema = new mongoose.Schema({
    widthraw_request: {
        default:0,
        required: false,
        type: Number
    },
    bonus_amount: {
        required: false,
        type: Number,
        default: 0
    },
    minimum_deposit_amount: {
        required: false,
        type: Number,
        default: 0
    },
    deposit_bonus_amount: {
        required: false,
        type: Number,
        default: 0
    },
    auto_withd_min_amount: {
        required: false,
        type: Number,
        default: 0
    },
    auto_withd_max_amount: {
        required: false,
        type: Number,
        default: 0
    },
    version: {
        required: false,
        type: String,
        default: null
    },
    apk_file: {
        required: false,
        type: String,
        default: null
    },
    referral_bonus_amount: {
        required: false,
        type: Number,
        default: 0/* User will get this amount if referral code used by someone & they made first deposit */
    },
    min_deposit_amount_for_bonus: {
        required: false,
        type: Number,
        default: 0
    },
    whatsapp_no: {
        required: false,
        type: String,
        default: null
    },
    calling_phone_no: {
        required: false,
        type: String,
        default: null
    },
    email_id: {
        required: false,
        type: String,
        default: null
    },
    pg_is_card: {
        required: false,
        type: Number,
        default: 1
    },
    pg_is_net: {
        required: false,
        type: Number,
        default: 1
    },
    pg_is_upi: {
        required: false,
        type: Number,
        default: 1
    },
    pg_is_googlepay: {
        required: false,
        type: Number,
        default: 1
    },
    pg_is_phonepay: {
        required: false,
        type: Number,
        default: 1
    },
    is_market: {
        required: false,
        type: Number,
        default: 1
    },
    is_colors: {
        required: false,
        type: Number,
        default: 0
    },
    game_duration: {
        required: false,
        type: String,
        default: null
    },
    color_pro_ratio: {
        required: false,
        type: Number,
        default: 25
    },
},
{
    timestamps: true
}
);
var Settings = mongoose.model('Settings', settingSchema, 'settings');
module.exports = Settings;