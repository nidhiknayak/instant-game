var mongoose = require('mongoose');
var mongoose_delete = require('mongoose-delete');
const mongoosePaginate = require("mongoose-paginate-v2");
const mongooseAggregatePaginate = require("mongoose-aggregate-paginate-v2");

var userSchema = new mongoose.Schema({
    firstname: {
        required: false,
        type: String,
        default:null,
    },
    lastname: {
        required: false,
        type: String,
        default:null,
    },
    email: {
        required: false,
        type: String,
        default:null,
        //match: /.+\@.+\..+/
        unique: false
    },
    password: {
        required: false,
        type: String,
        default:null,
    },
    mobile_no: {
        required: true,
        type: String,
        default:null,
    },
    country_code: {
        required: false,
        type: String,
        default:null,
    },
    otp: {
        required: false,
        type: String,
        default:null,
    },
    otp_time: {
        required: false,
        type: Date,
        default: null
    },
    is_otp_verified: {
        type: Number,
        default: 0
    },
    referral_code: {
        required: false,
        type: String,
        default:null,
    },
	refer_by:{
        type: mongoose.Schema.ObjectId,
        ref:'Users',
        default:null
    },
    status: {
        type: Number,
        default:1
    },
    wallet: {
        default:0,
        type:Number
    },
    wallet_wining: {
        default:0,
        type:Number
    },
    wallet_bonus: {
        default:0,
        type:Number
    },
    city: {
        required: false,
        type: String,
        default:null,
    },
    state: {
        required: false,
        type: String,
        default:null,
    },
    country: {
        required: false,
        type: String,
        default:null,
    },
    is_withdraw_allow: {
        default:1,
        type:Number
    },
    noti_status: {
        default:1,
        type:Number
    },
    created_by:{
        type: mongoose.Schema.ObjectId,
        ref:'Users',
        default:null
    },
    updated_by:{
        type: mongoose.Schema.ObjectId,
        ref:'Users',
        default:null
    }
},
{
    timestamps: true
}
);
userSchema.plugin(mongoosePaginate);
userSchema.plugin(mongooseAggregatePaginate);
userSchema.plugin(mongoose_delete, {
    deletedAt : true,
    deletedBy: true,
    overrideMethods: ['find', 'findOne']
});
var Users = mongoose.model('Users', userSchema, 'users');
module.exports = Users;

