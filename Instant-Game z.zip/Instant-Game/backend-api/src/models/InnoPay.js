var mongoose = require('mongoose');
var innopaySchema = new mongoose.Schema({
    response: {
        required: false,
        type: String,
        default:null,
    },
    trx: {
        type: String,
        default:null,
    },
    mobile_no: {
        type: String,
        default:null,
    },
	user_id:{
        type: mongoose.Schema.ObjectId,
        ref:'Users',
        default:null
    },
    status: {
        type: Number,
        default:0
    },
},
{
    timestamps: true
});

var InnoPay = mongoose.model('InnoPay', innopaySchema, 'innopay');
module.exports = InnoPay;

