var mongoose = require('mongoose');

var drawsSchema = new mongoose.Schema({
    draw_no: {
        required: true,
        type: String
    },
    start_date: {
        required: true,
        type: Date
    },
    end_date: {
        required: true,
        type: Date
    },
    res_dec_date: {
        required: false,
        type: Date,
        default: null
    },
    is_complete: {
        default:0,
        type: Number // 0 running , 1 complete
    },
},
{
    timestamps: true
}
);
var Draws = mongoose.model('Draws', drawsSchema, 'draws');
module.exports = Draws;