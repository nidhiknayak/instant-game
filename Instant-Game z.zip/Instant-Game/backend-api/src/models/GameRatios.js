var mongoose = require('mongoose');
var mongoose_delete = require('mongoose-delete');

var gameRatiosSchema = new mongoose.Schema({
    
    name: {
        required: true,
        type: String/* (Single, Jodi, Single Panna, Double Panna, Triple Panna, Half Sangam, Full Sangam) */
    },
    game_type_id: {
        required: true,
        type: Array
        /* 
        (Single       => 0 = SingleOpenDigit, 1 SingleCloseDigit),
        (Jodi         => 2 = Jodi),
        (Single Panna => 3 SingleOpenPanna, 6 SingleClosePanna),
        (Double Panna => 4 DoubleOpenPanna, 7 DoubleClosePanna),
        (Triple Panna => 5 TripleopenPanna, 8 TripleClosePanna),
        (HalfSangam   => 9 HalfSangamOpenPannaCloseDigit, 10 HalfSangamClosePannaOpenDigit),
        (Full Sangam  => 11 Full Sangam)*/
    },
    ratio_per: {
        required: true,
        type: Number,
        default: 0
    },
    ratio_per_amount: {
        required: false,
        type: Number,
        default:0
    },
},
    {
        timestamps: true
    }
);

gameRatiosSchema.plugin(mongoose_delete, {
    deletedAt: true,
    /* deletedBy: true, */
    overrideMethods: ['find', 'findOne']
});
var GameRatios = mongoose.model('GameRatios', gameRatiosSchema, 'game_ratios');
module.exports = GameRatios;