var mongoose = require('mongoose');
var mongoose_delete = require('mongoose-delete');

var userDeviceTokenSchema = new mongoose.Schema({
	user_id:{
        type: mongoose.Schema.ObjectId,
        ref:'Users',
        default:null
    },
    auth_token: {
        required: true,
        type: String
    },
    device_token: {
        required: false,
        type: String,
        default: null
    },
    device_model_no: {
        required: false,
        type: String,
        default: null
    },
},
{
    timestamps: true
}
);
userDeviceTokenSchema.plugin(mongoose_delete, {
    deletedAt : true,
    deletedBy: true,
    overrideMethods: ['find', 'findOne']
});
var UserDeviceTokens = mongoose.model('UserDeviceTokens', userDeviceTokenSchema, 'user_device_tokens');
module.exports = {UserDeviceTokens};