var mongoose = require('mongoose');
var mongoose_delete = require('mongoose-delete');

var adminSchema = new mongoose.Schema({
	firstname: {
		required: false,
		type: String
	},
	lastname: {
		required: false,
		type: String
	},
	email: {
		required: true,
		type: String,
		match: /.+\@.+\..+/,
		unique: true
	},
	password: {
		required: true,
		type: String
	},
	status: {
		type: Number,
		default: 0
	}
},
	{
		timestamps: true
	}
);
adminSchema.plugin(mongoose_delete, {
	deletedAt: true,
	deletedBy: true,
	overrideMethods: ['find', 'findOne']
});
var Admins = mongoose.model('Admins', adminSchema, 'admins');

module.exports = Admins;