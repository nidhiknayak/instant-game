const mongoose = require('mongoose');
const mongoose_delete = require('mongoose-delete');

const paymentGatewaySchema = new mongoose.Schema({
  name:{
    type: String,
    required: true,
  },
  code:{
    type: String,
    default:""
  },
  base_url:{
    type: String,
    default:null,
  },
  client_id:{
    type: String,
    default:null,
  },
  secret_key:{
    type: String,
    default:null,
  },
  status:{
    type: Boolean,
    default: false,/* true=active ,false=in active */
  },
  withdraw:{
    type: Boolean,
    default: false,/* true=active ,false=in active */
  },
  is_intent:{
    type: Boolean,
    default: false,/* true=active ,false=in active */
  },
  is_collect:{
    type: Boolean,
    default: false,/* true=active ,false=in active */
  },
},
{
  timestamps: true
}
);

paymentGatewaySchema.plugin(mongoose_delete, {
  deletedAt : true,
  deletedBy: true,
  overrideMethods: ['find', 'findOne']
});
const PaymentGateway = mongoose.model('PaymentGateway', paymentGatewaySchema, 'payment_gateways');

module.exports = PaymentGateway;

