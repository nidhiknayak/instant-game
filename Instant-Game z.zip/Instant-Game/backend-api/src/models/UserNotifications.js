var mongoose        = require('mongoose');
var mongoose_delete = require('mongoose-delete');
const mongoosePaginate = require("mongoose-paginate-v2");

var userNotificationSchema = new mongoose.Schema({
    user_ids: { type: mongoose.Schema.ObjectId, ref: "Users", default:null },
    title: {
      type: String,
      default:null
    },
    message: {
      type: String,
      default:null
    },
    image: {
      required: false,
      type: String,
      default: null
    },
    image_url: {
      required: false,
      type: String,
      default: null
    },
  },
  {
    timestamps: true
  }
);

userNotificationSchema.plugin(mongoosePaginate);
userNotificationSchema.plugin(mongoose_delete, {
  deletedAt: true,
  deletedBy: true,
  overrideMethods: ['find', 'findOne', 'paginate']
});

var UserNotifications   = mongoose.model('UserNotifications', userNotificationSchema, 'user_notifications')
module.exports      = UserNotifications;

