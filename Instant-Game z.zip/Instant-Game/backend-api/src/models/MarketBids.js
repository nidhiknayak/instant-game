var mongoose = require('mongoose');
var mongoose_delete = require('mongoose-delete');
const mongoosePaginate = require("mongoose-paginate-v2");
const mongooseAggregatePaginate = require("mongoose-aggregate-paginate-v2");

var marketBidsSchema = new mongoose.Schema({
    market_id: {
        type: mongoose.Schema.ObjectId,
        ref: 'Markets',
        default: null
    },
    user_id: {
        type: mongoose.Schema.ObjectId,
        ref: 'Users',
        default: null
    },
    game_type_id: {
        required: true,
        type: Number/* (0 = SingleOpenDigit, 1 SingleCloseDigit, 2 = Jodi, 3 SingleOpenPanna, 4 Double OpenPanna, 5 TripleopenPanna, 6 SingleClosePanna, 7 DoubleClosePanna 8 TripleClosePanna, 9 HalfSangamOpenPannaCloseDigit, 10 HalfSangamClosePannaOpenDigit, 11 Full Sangam) */
    },
    panna_1: {
        required: true,
        type: String/* all gametype have panna1 */
    },
    panna_2: {
        required: false,
        type: String,/* (if game_type_id = 9 HalfSangamOpenPannaCloseDigit, 10 HalfSangamClosePannaOpenDigit, 11 Full Sangam)  */
        default:null
    },
    amount: {
        required: true,
        type: Number
    },
    is_win: {
        required: false,
        type: Number,
        default:0/* 0=Not win/bid applied, 1=win,2=lose,3=refund,4=rollback */
    },
    win_amount: {
        required: false,
        type: Number, 
        default: null/* is_win = 1 then winnig amount for bid else refund amount */
    },
    report_date: {/* calculated report date */
        required: false,
        type: Date,
        default: null
    },
    tnx_id: {/* Site Generated Transaction ID For Each Record, Used In By Bid 09-08-2022  */
        type: String,
        default: null
    },
    result_id: {
        type: mongoose.Schema.ObjectId,
        ref: 'MarketResults',
        default: null
    },
},
    {
        timestamps: true
    }
);
marketBidsSchema.plugin(mongoosePaginate);
marketBidsSchema.plugin(mongooseAggregatePaginate);
marketBidsSchema.plugin(mongoose_delete, {
    deletedAt: true,
    /* deletedBy: true, */
    overrideMethods: ['find', 'findOne']
});
var MarketBids = mongoose.model('MarketBids', marketBidsSchema, 'market_bids');
module.exports = MarketBids;