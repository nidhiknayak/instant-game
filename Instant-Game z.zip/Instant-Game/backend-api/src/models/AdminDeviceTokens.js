var mongoose = require('mongoose');
var mongoose_delete = require('mongoose-delete');

var adminDeviceTokenSchema = new mongoose.Schema({
	admin_id:{
        type: mongoose.Schema.ObjectId,
        ref:'Admins',
        default:null
    },
    auth_token: {
        required: true,
        type: String
    },
},
{
    timestamps: true
}
);
adminDeviceTokenSchema.plugin(mongoose_delete, {
    deletedAt : true,
    deletedBy: true,
    overrideMethods: ['find', 'findOne']
});
var AdminDeviceTokens = mongoose.model('AdminDeviceTokens', adminDeviceTokenSchema, 'admin_device_tokens');
module.exports = AdminDeviceTokens;