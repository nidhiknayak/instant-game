var mongoose = require('mongoose');
var mongoose_delete = require('mongoose-delete');
var relationship = require("mongoose-relationship");

var marketSchema = new mongoose.Schema({
    name: {
        required: true,
        type: String
    },
    first_letter: {
        type: String,
        default: null
    },
    second_letter: {
        type: String,
        default: null
    },
    status: {
        type: Number,
        default:1
    },
    timetables: [{ type: mongoose.Schema.ObjectId, ref: "MarketTimeTable" }],
    created_by:{
        type: mongoose.Schema.ObjectId,
        ref:'Users',
        default:null
    },
    updated_by:{
        type: mongoose.Schema.ObjectId,
        ref:'Users',
        default:null
    }
},
{
    timestamps: true
}
);
marketSchema.plugin(mongoose_delete, {
    deletedAt : true,
    deletedBy: true,
    overrideMethods: ['find', 'findOne']
});
var Markets = mongoose.model('Markets', marketSchema, 'markets');

var marketTimeSchema = new mongoose.Schema({
    market_id: {
        type: mongoose.Schema.ObjectId,
        ref: 'Markets',
        default: null
    },
    week_day_name: {
        required: false,
        type: String/* 1=Monday, 2=Tuesday, 3=Wednesday, 4=Thursday, 5=Friday, 6=Saturday, 7=Sunday */
    },
    week_day_type: {
        required: true,
        type: Number,/* 1=Monday, 2=Tuesday, 3=Wednesday, 4=Thursday, 5=Friday, 6=Saturday, 7=Sunday */
        default: 1
    },
    bid_open_time: {
        required: true,
        type: mongoose.Schema.Types.Mixed
    },
    bid_close_time: {
        required: true,
        type: mongoose.Schema.Types.Mixed
    },
    status: {
        type: Number,
        default: 1
    },
    markets: { type: mongoose.Schema.ObjectId, ref: "Markets", childPath: "timetables" }
},
    {
        timestamps: true
    }
);
marketTimeSchema.plugin(mongoose_delete, {
    deletedAt: true,
    deletedBy: true,
    overrideMethods: ['find', 'findOne']
});

marketTimeSchema.plugin(relationship, { relationshipPathName: 'markets' });
var MarketTimeTable = mongoose.model('MarketTimeTable', marketTimeSchema, 'market_timetables');

module.exports = { Markets, MarketTimeTable };

