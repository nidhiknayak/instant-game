const dbconfig = require('../db_config');
const Sequelize = require('sequelize');

const sequelize = new Sequelize(dbconfig.db, dbconfig.user, dbconfig.password,{
	host:dbconfig.host,
	dialect:dbconfig.dialect,
	operatorAliases:false,

	pool:{
		max:dbconfig.pool.max,
		min:dbconfig.pool.min,
		acquire:dbconfig.pool.acquire,
		idle:dbconfig.pool.idle,
	}
});

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.admin = require('./admin.modal')(sequelize,Sequelize);
db.slider = require('./slider.modal')(sequelize,Sequelize);
// db.user = require('./user.modal')(sequelize,Sequelize);
// db.user_device_token = require('./user_device_token.modal')(sequelize,Sequelize);
// db.user_banks = require('./user_banks.modal')(sequelize,Sequelize);

// require('./relations')(sequelize,Sequelize);

/* db.sequelize.sync().then(()=>{
	console.log('table created');
}); */
const getPagingData = (data, page, limit) => {
  const { count: totalItems, rows: rows } = data;
  const currentPage = page ? +page : 0;
  const totalPages = Math.ceil(totalItems / limit);

  return { totalItems, rows, totalPages, currentPage };
};
const getPagination = (page, size) => {
  const limit = size ? +size : 3;
  const offset = page ? page * limit : 0;

  return { limit, offset };
};

db.getPagingData = getPagingData;
db.getPagination = getPagination;
module.exports = db;