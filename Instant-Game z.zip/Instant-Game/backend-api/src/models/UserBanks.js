var mongoose = require('mongoose');
var mongoose_delete = require('mongoose-delete');

var userBanksSchema = new mongoose.Schema({
	user_id:{
        type: mongoose.Schema.ObjectId,
        ref:'Users',
        required: true,
    },
    bank_name: {
        required: true,
        type: String
    },
    user_name: {
        required: true,
        type: String
    },
    acc_no: {
        required: true,
        type: String
    },
    ifsc_code: {
        required: false,
        type: String
    },
    branch: {
        required: false,
        type: String,
        default:null
    },
    city: {
        required: false,
        type: String
    },
    is_verified: {
        required: false,
        type: Number,
        default:0
    },
    verified_at: {
        required: false,
        type: Date,
        default:null
    },
    isChange: {
        required: false,
        type: Number,
        default: 0
    },
    created_by:{
        type: mongoose.Schema.ObjectId,
        ref:'Users',
        default:null
    },
    updated_by:{
        type: mongoose.Schema.ObjectId,
        ref:'Users',
        default:null
    }
},
{
    timestamps: true
}
);
userBanksSchema.plugin(mongoose_delete, {
    deletedAt : true,
    deletedBy: true,
    overrideMethods: ['find', 'findOne']
});
var UserBanks = mongoose.model('UserBanks', userBanksSchema, 'user_banks');
module.exports = {UserBanks};



