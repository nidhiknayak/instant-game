var mongoose = require('mongoose');
var mongoose_delete = require('mongoose-delete');

var ColorResultsSchema = new mongoose.Schema({
    draw_id: {
        type: mongoose.Schema.ObjectId,
        ref: 'Draws',
        default: null
    },
    res_no: {
        required: true,
        type: String,
        default: null
    },
    res_colors: {
        required: false,
        type: Array,
        default: null
    },
    is_published: {
        required: false,
        type: Number, 
        default: 0/* 0=no published,1=published */
    },
    published_date: {
        required: false,
        type: Date,
        default: null
    },
    result_date: {/* calculated result date, if market date is 22-11-2021 and result declared on 24-11-2021 then result_date will be 22-11-2021 */
        required: false,
        type: Date,
        default: null
    },
},
    {
        timestamps: true
    }
);
ColorResultsSchema.plugin(mongoose_delete, {
    deletedAt: true,
    /* deletedBy: true, */
    overrideMethods: ['find', 'findOne']
});
var ColorResults = mongoose.model('ColorResults', ColorResultsSchema, 'color_results');
module.exports = ColorResults;