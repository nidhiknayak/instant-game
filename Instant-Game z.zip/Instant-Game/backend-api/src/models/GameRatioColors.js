var mongoose = require('mongoose');
var mongoose_delete = require('mongoose-delete');

var gameRatioColorsSchema = new mongoose.Schema({
    
    name: {
        required: true,
        type: String/* (Green and Red, Violet, Green + Violet, Red + Violet, All Numbers) */
    },
    setting:{
        required: false,
        type: Array,
        default: null
    },
    // possiblity: {
    //     required: false,
    //     type: Array,
    //     default: null
        /* 
        (is_combi = 2  => ["G", "R", "1", "2", "3", "4", "6", "7", "8", "9", "*", "#"]),
        (is_combi = 2  => [ "V","0","5", "@"]),
        (is_combi = 1  => ["5", "@"]),
        (is_combi = 1  => ["0", "@"]),
        (is_combi = 0  => [ "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "#", "@"]) */
    //},
    type: {
        required: true,
        type: Number,
        default: 0
        /* 1=General, 2=Red + Violet,3=Green + Violet, 4=All Colors */
    },
},
    {
        timestamps: true
    }
);

gameRatioColorsSchema.plugin(mongoose_delete, {
    deletedAt: true,
    /* deletedBy: true, */
    overrideMethods: ['find', 'findOne']
});
var GameRatioColors = mongoose.model('GameRatioColors', gameRatioColorsSchema, 'game_ratio_colors');
module.exports = GameRatioColors;