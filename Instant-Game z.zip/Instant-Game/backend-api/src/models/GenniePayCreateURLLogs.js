const mongoose = require('mongoose');
const mongoose_delete = require('mongoose-delete');
const mongoosePaginate = require("mongoose-paginate-v2");
const mongooseAggregatePaginate = require("mongoose-aggregate-paginate-v2");

const genniePayCreateURLLogs = new mongoose.Schema({
    user_id:{
      type: mongoose.Schema.ObjectId,
      ref:'Users',
      required:true
    },
    transaction_id:{
      type: String,
      default:null
    },
    amount:{
      type: Number,
      default:0
    },
    is_created:{
      type: Boolean,
      default: true
    },
    requestBody:{
      type: Object,
      default:{}
    },
    resp:{
      type: Object,
      default:{}
    },
    message: {
      type: String,
      default:null
    },
    status: {
      type: String,//PENDING,SUCCESS,FAILED
      default: "PENDING"
    },
    upi_txn_id: {
      type: String,
      default:null
    },
    webhook_resp:{
      type: Object,
      default: {}
    },
    upi_id: {
      type: String,
      default:null
    },
    used_method: {
      type: String,//INTENT,COLLECT
      default: "INTENT"
    },
},
{
  timestamps: true
}
);
genniePayCreateURLLogs.plugin(mongoosePaginate);
genniePayCreateURLLogs.plugin(mongooseAggregatePaginate);
genniePayCreateURLLogs.plugin(mongoose_delete, {
    deletedAt : true,
    deletedBy: true,
    overrideMethods: ['find', 'findOne']
});
const GenniePayCreateURLLogs = mongoose.model('GenniePayCreateURLLogs', genniePayCreateURLLogs, 'genniepay_create_url_logs');

module.exports = GenniePayCreateURLLogs;

