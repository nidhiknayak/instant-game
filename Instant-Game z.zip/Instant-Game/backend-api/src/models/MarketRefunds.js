var mongoose = require('mongoose');
var mongoose_delete = require('mongoose-delete');

var marketRefundSchema = new mongoose.Schema({
    market_id: {
        type: mongoose.Schema.ObjectId,
        ref: 'Markets',
        default: null
    },
    
    refund_date: {/* calculated refund date, if market date is 22-11-2021 and refund declared on 23-11-2021 then refund_date will be 22-11-2021 */
        required: false,
        type: Date,
        default: null
    },
    is_open_refunded: {
        required: false,
        type: Number, 
        default: 0/* 0=open not refunded,1=open refunded */
    },
    open_refunded_date: {
        required: false,
        type: Date,
        default: null
    },
    is_close_refunded: {
        required: false,
        type: Number, 
        default: 0/* 0=no close refunded,1=close refunded */
    },
    close_refunded_date: {
        required: false,
        type: Date,
        default: null
    },
    is_both_refund: {
        required: false,
        type: Number,
        default: 0/* 0=no both refunded,1=both refunded */
    },
    both_refunded_date: {
        required: false,
        type: Date,
        default: null
    },
},
    {
        timestamps: true
    }
);
marketRefundSchema.plugin(mongoose_delete, {
    deletedAt: true,
    /* deletedBy: true, */
    overrideMethods: ['find', 'findOne']
});
var MarketRefunds = mongoose.model('MarketRefunds', marketRefundSchema, 'market_refunds');
module.exports = MarketRefunds;