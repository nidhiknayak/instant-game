var mongoose = require('mongoose');
var mongoose_delete = require('mongoose-delete');
const mongoosePaginate = require("mongoose-paginate-v2");
const mongooseAggregatePaginate = require("mongoose-aggregate-paginate-v2");

var transactionHistorySchema = new mongoose.Schema({
    user_id:{
        type: mongoose.Schema.ObjectId,
        ref:'Users',
        required:true
    },
    refe_id:{
        type: mongoose.Schema.ObjectId,
        default:null
    },
    amount:{
        type: Number,
        default:0
    },
    charge_amount:{
        type: Number,
        default:0
    },
    final_amount:{
        type: Number,
        default:0
    },
    post_balance:{
        type: Number,
        default:0
    },
    tnx_type:{
        type: Number,
        default: 0,/* 1=place_bid,2=refund,3=bonus_credited,4=added_by_admin,5=added_by_self,6=winning_withdraw,7=winning_credited,8=deduct_by_admin,9=deposit_bonus_credited,10=bank valid bonus,11=result rollback,12=referral_bonus_credited,13=bank change penalty */
    },
    tnx:{
        type: String,
        default:null,
    },
    wallet_type:{
        type: Number,
        default:0,/* 1=winning wallet ,2=wallet ,3=bonus wallet */
    },
    details: {
        type: String,
        default:null
    },
    
    entry_type: {
        type: Number,
        default:0,/* 1-credit,2-debit */
    },
    internal_tnx: {/* wallet_type=2,tnx_type=5 if added using payment gateway */
        type: Number,
        default: null
    },
    tnx_id: {/* Site Generated Transaction ID For Each Record, Used In By Bid 05-08-2022  */
        type: String,
        default: null
    },
    order_id: {/* wallet_type=2,tnx_type=5 if added using payment gateway */
        type: String,
        default: null
    },
    payment_type: {/* when add paymnet from app the payment type get in that i.e.phonepe,googlepay,paytm */
        type: String,
        default:""
    },
    pay_status: {
        type: Number,
        default:1,/* 0-pending,1-complete,2=failed,3=cancelled */
    },
    check_inno_status: {/* check status in innopay */
        type: Number,
        default:1,/* 0-pending,1-complete,2=failed */
    },
    show_to_user: {
        type: Number,
        default: 1,/* 1-Transaction Show To User,0-Transaction Not Show To User */
    },
    report_date: {/* calculated report date tnx_type=7 */
        required: false,
        type: Date,
        default: null
    },
    created_by:{
        type: mongoose.Schema.ObjectId,
        ref:'Users',
        default:null
    },
    updated_by:{
        type: mongoose.Schema.ObjectId,
        ref:'Users',
        default:null
    }
},
{
    timestamps: true
}
);
transactionHistorySchema.plugin(mongoosePaginate);
transactionHistorySchema.plugin(mongooseAggregatePaginate);
transactionHistorySchema.plugin(mongoose_delete, {
    deletedAt : true,
    deletedBy: true,
    overrideMethods: ['find', 'findOne']
});
var Transactions = mongoose.model('Transactions', transactionHistorySchema, 'transactions');

module.exports = Transactions;

