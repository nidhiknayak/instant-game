var mongoose = require('mongoose');
var mongoose_delete = require('mongoose-delete');
const mongoosePaginate = require("mongoose-paginate-v2");
const mongooseAggregatePaginate = require("mongoose-aggregate-paginate-v2");

var colorBidsSchema = new mongoose.Schema({
    draw_id: {
        type: mongoose.Schema.ObjectId,
        ref: 'ColorDraws',
        default: null
    },
    user_id: {
        type: mongoose.Schema.ObjectId,
        ref: 'Users',
        default: null
    },
    bid_type: {
        required: true,
        type: Number/* (0 = Number, 1 = Color, 2 = Symbol) */
    },
    bid_num: {
        required: true,
        type: String/* number(0-9)/color(R,G,V).symbol(*,#,@) */
    },
    amount: {
        required: true,
        type: Number
    },
    is_win: {
        required: false,
        type: Number,
        default:0/* 0=Not win/bid applied, 1=win,2=lose */
    },
    win_amount: {
        required: false,
        type: Number, 
        default: null/* is_win = 1 then winnig amount for bid else refund amount */
    },
    result_id: {
        type: mongoose.Schema.ObjectId,
        ref: 'ColorDrawResults',
        default: null
    },
},
    {
        timestamps: true
    }
);
colorBidsSchema.plugin(mongoosePaginate);
colorBidsSchema.plugin(mongooseAggregatePaginate);
colorBidsSchema.plugin(mongoose_delete, {
    deletedAt: true,
    /* deletedBy: true, */
    overrideMethods: ['find', 'findOne']
});
var ColorBids = mongoose.model('ColorBids', colorBidsSchema, 'color_bids');
module.exports = ColorBids;