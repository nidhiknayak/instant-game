var mongoose = require('mongoose');
var mongoose_delete = require('mongoose-delete');
const mongoosePaginate = require("mongoose-paginate-v2");

var sliderSchema = new mongoose.Schema({
    title: {
        required: false,
        type: String
    },
    description: {
        required: false,
        type: String
    },
    image: {
        required: false,
        type: String
    },
    image_url: {
        required: false,
        type: String
    },
    link: {
        required: false,
        type: String
    },
    type: {
        required: true,
        type: String
    },
    status: {
        default:1,
        type: Boolean
    },
    created_by:{
        type: mongoose.Schema.ObjectId,
        ref:'Users',
        default:null
    },
    updated_by:{
        type: mongoose.Schema.ObjectId,
        ref:'Users',
        default:null
    }
},
{
    timestamps: true
}
);
sliderSchema.plugin(mongoosePaginate);
sliderSchema.plugin(mongoose_delete, {
    deletedAt : true,
    deletedBy: true,
    overrideMethods: ['find', 'findOne', 'paginate']
});
var Slider = mongoose.model('Slider', sliderSchema, 'sliders');
module.exports = Slider;