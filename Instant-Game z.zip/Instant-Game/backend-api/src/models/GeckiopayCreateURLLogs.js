const mongoose = require('mongoose');
const mongoose_delete = require('mongoose-delete');
const mongoosePaginate = require("mongoose-paginate-v2");
const mongooseAggregatePaginate = require("mongoose-aggregate-paginate-v2");

const geckiopayCreateURLLogs = new mongoose.Schema({
    user_id:{
      type: mongoose.Schema.ObjectId,
      ref:'Users',
      required:true
    },
    transaction_id:{
      type: String,
      default:null
    },
    amount:{
      type: Number,
      default:0
    },
    is_created:{
      type: Boolean,
      default: true
    },
    requestBody:{
      type: Object,
      default:{}
    },
    resp:{
      type: Object,
      default:{}
    },
    message: {
      type: String,
      default:null
    },
    status: {
      type: String,//PENDING,SUCCESS,FAILED
      default: "PENDING"
    },
    upi_txn_id: {
      type: String,
      default:null
    },
    webhook_resp:{
      type: Object,
      default: {}
    },
},
{
  timestamps: true
}
);
geckiopayCreateURLLogs.plugin(mongoosePaginate);
geckiopayCreateURLLogs.plugin(mongooseAggregatePaginate);
geckiopayCreateURLLogs.plugin(mongoose_delete, {
    deletedAt : true,
    deletedBy: true,
    overrideMethods: ['find', 'findOne']
});
const GeckiopayCreateURLLogs = mongoose.model('GeckiopayCreateURLLogs', geckiopayCreateURLLogs, 'geckiopay_create_url_logs');

module.exports = GeckiopayCreateURLLogs;

