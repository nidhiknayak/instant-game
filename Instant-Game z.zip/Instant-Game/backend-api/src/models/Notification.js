var mongoose        = require('mongoose');
var mongoose_delete = require('mongoose-delete');
const mongoosePaginate = require("mongoose-paginate-v2");
var notificationSchema = new mongoose.Schema({
        user_ids: [{ type: mongoose.Schema.ObjectId, ref: "Users", default:null }],
        title: {
            type: String,
            default:null
        },
        message: {
            type: String,
            default:null
        },
        image: {
            required: false,
            type: String,
            default: null
        },
        image_url: {
            required: false,
            type: String,
            default: null
        },
    },
    {
        timestamps: true
    }
);

notificationSchema.plugin(mongoosePaginate);
notificationSchema.plugin(mongoose_delete, {
    deletedAt: true,
    deletedBy: true,
    overrideMethods: ['find', 'findOne', 'paginate']
});

var Notification   = mongoose.model('Notification', notificationSchema, 'notifications')
module.exports      = Notification;

