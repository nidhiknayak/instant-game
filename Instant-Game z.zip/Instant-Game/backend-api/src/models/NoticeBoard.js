var mongoose = require('mongoose');
var mongoose_delete = require('mongoose-delete');
const mongoosePaginate = require("mongoose-paginate-v2");
const mongooseAggregatePaginate = require("mongoose-aggregate-paginate-v2");

var noticeBoardSchema = new mongoose.Schema({
    title: {
        required: false,
        type: String
    },
    description: {
        required: false,
        type: String
    },
    status: {
        default:1,
        type: Boolean
    },
    created_by:{
        type: mongoose.Schema.ObjectId,
        ref:'Users',
        default:null
    },
    updated_by:{
        type: mongoose.Schema.ObjectId,
        ref:'Users',
        default:null
    }
},
{
    timestamps: true
}
);
noticeBoardSchema.plugin(mongoosePaginate);
noticeBoardSchema.plugin(mongooseAggregatePaginate);
noticeBoardSchema.plugin(mongoose_delete, {
    deletedAt : true,
    deletedBy: true,
    overrideMethods: ['find', 'findOne', 'paginate']
});
var NoticeBoard = mongoose.model('NoticeBoard', noticeBoardSchema, 'notice_board');
module.exports = NoticeBoard;