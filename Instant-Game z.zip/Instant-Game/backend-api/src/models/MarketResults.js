var mongoose = require('mongoose');
var mongoose_delete = require('mongoose-delete');

var marketResultSchema = new mongoose.Schema({
    market_id: {
        type: mongoose.Schema.ObjectId,
        ref: 'Markets',
        default: null
    },
    week_day_type: {
        required: true,
        type: Number,/* 1=Monday, 2=Tuesday, 3=Wednesday, 4=Thursday, 5=Friday, 6=Saturday, 7=Sunday */
        default: 1
    },
    declared_date: {
        required: true,
        type: Date,
        default: null
    },
    op_1: {
        required: false,
        type: Number,
        default: null
    },
    op_2: {
        required: false,
        type: Number,
        default: null
    },
    op_3: {
        required: false,
        type: Number,
        default: null
    },
    digit_1: {
        required: false,
        type: Number,
        default: null
    },
    digit_2: {
        required: false,
        type: Number,
        default: null
    },
    cp_1: {
        required: false,
        type: Number,
        default: null
    },
    cp_2: {
        required: false,
        type: Number,
        default: null
    },
    cp_3: {
        required: false,
        type: Number,
        default: null
    }, 
    is_open_published: {
        required: false,
        type: Number, 
        default: 0/* 0=open not published,1=open published */
    },
    open_published_date: {
        required: false,
        type: Date,
        default: null
    },
    is_published: {
        required: false,
        type: Number, 
        default: 0/* 0=no published,1=published,2=rollback */
    },
    published_date: {
        required: false,
        type: Date,
        default: null
    },
    result_date: {/* calculated result date, if market date is 22-11-2021 and result declared on 24-11-2021 then result_date will be 22-11-2021 */
        required: false,
        type: Date,
        default: null
    },
    is_refunded: {
        required: false,
        type: Number,
        default: 0/* 0=no refunded,1=refunded */
    },
    is_open_rollback: {
        required: false,
        type: Number,
        default: 0/* 0=no open rollback,1=open rollback */
    },
    roll_odate: {
        required: false,
        type: Date,
        default: null
    },
    is_close_rollback: {
        required: false,
        type: Number,
        default: 0/* 0=no open rollback,1=open rollback */
    },
    roll_cdate: {
        required: false,
        type: Date,
        default: null
    },
    is_rollback: {
        required: false,
        type: Number,
        default: 0/* 0=no rollback,1=rollback */
    },
},
    {
        timestamps: true
    }
);
marketResultSchema.plugin(mongoose_delete, {
    deletedAt: true,
    /* deletedBy: true, */
    overrideMethods: ['find', 'findOne']
});
var MarketResults = mongoose.model('MarketResults', marketResultSchema, 'market_results');
module.exports = MarketResults;