import React, { useState } from 'react';
import {  withRouter, useHistory } from "react-router-dom";
import { useForm } from 'react-hook-form';
import { Button, Form} from 'react-bootstrap';
import NoticeBoard from '../../Services/NoticeBoard';
import Alert from '../../Services/Alert';

export const NoticeAdd = (props) => {
  const history = useHistory();
  const { register, handleSubmit, formState: { errors }, watch } = useForm();
  const onSubmit = async (data) => {
    NoticeBoard.save(data).then((res) => res.data).then(res => {
      if(res.status){
        Alert.success(res.message)
        history.push('/notice-board');
      }else{
        Alert.error(res.message)
      }
    }).catch(error => {
      Alert.error(error.message)
    })
  } 
  return (
    <>
      <section className="main-content">
        <div className="page-content">
          <div className="container-fluid">
            <div className="row">
              <div className="col-lg-12">
                <div className="card">
                  <div className="card-body">
                    <h4 className="card-title mb-4">Notice Add</h4>
                    <Form className="needs-validation" noValidate onSubmit={handleSubmit(onSubmit)}>
                      <div className="row">
                        <div className="col-lg-12">
                          <Form.Group className="mb-3" controlId="formTitle">
                            <Form.Label>Title</Form.Label>
                            <Form.Control type="text" placeholder="Enter title" className="form-control" {...register("title", {required: true, maxLength: 80})} />
                            <div className="error">
                                {errors.title?.type === 'required' && "Title is required"}
                            </div>
                          </Form.Group>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-lg-12">
                          <Form.Group className="mb-3" controlId="formTitle">
                            <Form.Label>Description</Form.Label>
                            <div className="col-lg-12">
                              <Form.Control as="textarea" rows={3} className="form-control" {...register("description", {required: true})} />
                              <div className="error">
                                  {errors.description?.type === 'required' && "Description is required"}
                              </div>
                            </div>
                          </Form.Group>
                        </div>
                        <div className="col-lg-12">
                          <Form.Group className="mb-3" controlId="formTitle">
                            <Form.Label>Status</Form.Label>
                            <div className="col-lg-12">
                              <Form.Check inline label="Active" value="1" id="active-status" type="radio" {...register("status", {required: true})} />
                              <Form.Check inline label="Inactive" id="inactive-status" type="radio" value="0" {...register("status", {required: true})} />
                              <div className="error">
                                  {errors.status?.type === 'required' && "Status is required"}
                              </div>
                            </div>
                          </Form.Group>
                        </div>
                      </div>
                      <div className="btn-submit">
                        <Button className="btn btn-primary w-md" type="submit">Submit</Button>
                      </div>
                    </Form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
export default withRouter(NoticeAdd);