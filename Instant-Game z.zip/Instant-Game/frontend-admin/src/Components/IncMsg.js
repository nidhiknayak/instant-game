export default function IncMsg(props){
    return (
        <>
            {props.fail ? <div className='alert alert-danger'>{props.fail}</div> : ''}
            {props.success ? <div className='alert alert-success'>{props.success}</div> : ''}
        </>
    )
}
