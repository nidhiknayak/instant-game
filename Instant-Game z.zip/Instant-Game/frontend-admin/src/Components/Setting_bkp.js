import React, { useEffect, useState, useParams } from 'react';
import { withRouter } from "react-router-dom";
import { useForm } from 'react-hook-form';
import { Button, Form } from 'react-bootstrap';
import Api from '../Services/Api';
import Alert from '../Services/Alert';

export const Setting = (props) => {

    const [settingInfo, setSettingInfo] = useState({
        bonus_amount: "",
        minimum_deposit_amount: "",
        deposit_bonus_amount: "",
        auto_withd_min_amount: "",
    });
    const { register, handleSubmit, reset, formState: { errors } } = useForm({ mode: "onChange", defaultValues: settingInfo });

    const onSubmit = async (data) => {
        var sdata = data;
        Api.post('update_setting', sdata).then((res) => res.data).then(res => {
            if (res.status) {
                Alert.success(res.message);
            } else {
                Alert.error(res.message)
            }
        }).catch(error => {
            Alert.error(error.message)
        })
    }

    useEffect(() => {

        Api.post('setting').then(resp => {
            var respData = resp.data;
            if (respData.status == 1) {
                let tempData = {
                    bonus_amount: respData.data.bonus_amount,
                    minimum_deposit_amount: respData.data.minimum_deposit_amount,
                    deposit_bonus_amount: respData.data.deposit_bonus_amount,
                    auto_withd_min_amount: respData.data.auto_withd_min_amount,
                }
                setSettingInfo(tempData)
                reset(tempData);
            } else {
                Alert.error(respData.message)
            }
        });
    }, []);

    return (
        <>
            <section className="main-content marketadd_main_sec">
                <div className="page-content">
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-lg-12">
                                <div className="card">
                                    <div className="card-body">
                                        <h4 className="card-title mb-4">Settings</h4>
                                        <Form className="needs-validation" noValidate onSubmit={handleSubmit(onSubmit)}>
                                            <div className="row">
                                                <div className="col-lg-6">
                                                    <Form.Group className="mb-3" controlId="formTitle">
                                                        <Form.Label>Bonus Amount</Form.Label>
                                                        <Form.Control type="text" pattern="[0-9]*" placeholder="Enter Bonus Amount" className="form-control" ref={register} {...register("bonus_amount", {
                                                            required: true, maxLength: 80, pattern: {
                                                                value: /^[0-9]*$/
                                                            }, })} />
                                                        <div className="error">
                                                            {errors.bonus_amount?.type === 'required' && "Bonus Amount is required"}
                                                            {errors.bonus_amount?.type === 'pattern' && "Only digits allowed"}
                                                        </div>
                                                    </Form.Group>
                                                </div>
                                                <div className="col-lg-6">
                                                    <Form.Group className="mb-3" controlId="formTitle">
                                                        <Form.Label>Minimum Deposit Amount</Form.Label>
                                                        <Form.Control type="text" placeholder="Enter Minimum Deposit Amount" className="form-control" ref={register} {...register("minimum_deposit_amount", {
                                                            required: true, maxLength: 80, pattern: {
                                                                value: /^[0-9]*$/
                                                            } })} />
                                                        <div className="error">
                                                            {errors.minimum_deposit_amount?.type === 'required' && "Minimum Deposit Amount is required"}
                                                            {errors.minimum_deposit_amount?.type === 'pattern' && "Only digits allowed"}
                                                        </div>
                                                    </Form.Group>
                                                </div>
                                            </div>
                                            <div className="row">
                                                <div className="col-lg-6">
                                                    <Form.Group className="mb-3" controlId="formTitle">
                                                        <Form.Label>Deposit Bonus Amount</Form.Label>
                                                        <Form.Control type="text" placeholder="Enter Deposit Bonus Amount" className="form-control" ref={register} {...register("deposit_bonus_amount", {
                                                            required: true, maxLength: 80, pattern: {
                                                                value: /^[0-9]*$/
                                                            } })} />
                                                        <div className="error">
                                                            {errors.deposit_bonus_amount?.type === 'required' && "Deposit Bonus Amount is required"}
                                                            {errors.deposit_bonus_amount?.type === 'pattern' && "Only digits allowed"}
                                                        </div>
                                                    </Form.Group>
                                                </div>
                                                <div className="col-lg-6">
                                                    <Form.Group className="mb-3" controlId="formTitle">
                                                        <Form.Label>Auto Withdraw Amount</Form.Label>
                                                        <Form.Control type="text" placeholder="Enter Auto Withdraw Amount" className="form-control" ref={register} {...register("auto_withd_min_amount", {
                                                            required: true, maxLength: 80, pattern: {
                                                                value: /^[0-9]*$/
                                                            } })} />
                                                        <div className="error">
                                                            {errors.auto_withd_min_amount?.type === 'required' && "Auto Withdraw Amount is required"}
                                                            {errors.auto_withd_min_amount?.type === 'pattern' && "Only digits allowed"}
                                                        </div>
                                                    </Form.Group>
                                                </div>
                                            </div>
                                            <div className="btn-submit">
                                                <Button className="btn btn-primary w-md" type="submit">Update Setting</Button>
                                            </div>
                                        </Form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default withRouter(Setting);