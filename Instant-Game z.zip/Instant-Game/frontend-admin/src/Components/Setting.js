import React, { useEffect, useState, useParams } from 'react';
import { withRouter } from "react-router-dom";
import { useForm } from 'react-hook-form';
import { Button, Form } from 'react-bootstrap';
import Api from '../Services/Api';
import Alert from '../Services/Alert';
import ViewGameRatioColor from './ViewGameRatioColor';
import UpdateColorRatioSetting from './UpdateColorRatioSetting';
import MoneySetting from './MoneySetting';

export const Setting = (props) => {
    const [settingInfo, setSettingInfo] = useState({
        pg_is_card: "",
        pg_is_net: "",
        pg_is_upi: "",
        pg_is_googlepay: "",
        pg_is_phonepay: "",
    });
    const {
        register,
        reset,
        formState: { errors },
        handleSubmit,
    } = useForm({
        mode: "onChange",
        defaultValues: settingInfo
    });

    const [gameSettingInfo, setGameSettingInfo] = useState({
        is_market: "",
        is_colors: "",
        game_duration: "",
    });
    const {
        register: register2,
        reset: reset2,
        formState: { errors: errors2 },
        handleSubmit: handleSubmit2,
    } = useForm({
        mode: "onChange",
        defaultValues: gameSettingInfo
    });

    const [profitRatio, setProfitRatio] = useState('');
    const [isMarket, setIsMarket] = useState('');
    const [isColors, setIsColors] = useState('');
    const [gameDuration, setGameDuration] = useState('');

    const onSubmit = (data) => {
        //console.log(JSON.stringify(data));
        Api.post('update_setting', data).then((res) => res.data).then(res => {
            if (res.status) {
                Alert.success(res.message);
            } else {
                Alert.error(res.message);
            }
        }).catch(error => {
            Alert.error(error.message);
        });
    };

    const onSubmitGame = (data) => {
        //console.log(JSON.stringify(data));
        Api.post('update_game_setting', data).then((res) => res.data).then(res => {
            if (res.status) {
                Alert.success(res.message);
            } else {
                Alert.error(res.message);
            }
        }).catch(error => {
            Alert.error(error.message)
        });
    };

    const handleChangeIsMarket = (e) => {
        let gameData = {};
        if (e.target.value == 0) {
            if (isColors == 0) {
                gameData = {
                    is_market: '0',
                    is_colors: '1' // change
                };
                setIsColors('1');
            } else {
                gameData = {
                    is_market: '0',
                    is_colors: isColors
                };
            }
        } else {
            gameData = {
                is_market: '1',
                is_colors: isColors
            };
        }
        gameData['game_duration'] = gameDuration;
        setIsMarket(e.target.value);
        setGameSettingInfo(gameData);
        reset2(gameData);
    };

    const handleChangeIsColor = (e) => {
        let gameData = {};
        if (e.target.value == 0) {
            if (isMarket == 0) {
                gameData = {
                    is_market: '1', //change
                    is_colors: '0'
                };
                setIsMarket('1');
            } else {
                gameData = {
                    is_market: isMarket,
                    is_colors: '0'
                };
            }
        } else {
            gameData = {
                is_market: isMarket,
                is_colors: '1'
            };
        }
        gameData['game_duration'] = gameDuration;
        setIsColors(e.target.value);
        setGameSettingInfo(gameData);
        reset2(gameData);
    };

    useEffect(() => {
        Api.post('setting').then(resp => {
            var respData = resp.data;
            if (respData.status == 1) {
                let paymentData = {
                    pg_is_card: respData.data.pg_is_card.toString(),
                    pg_is_net: respData.data.pg_is_net.toString(),
                    pg_is_upi: respData.data.pg_is_upi.toString(),
                    pg_is_googlepay: respData.data.pg_is_googlepay.toString(),
                    pg_is_phonepay: respData.data.pg_is_phonepay.toString(),
                }
                setSettingInfo(paymentData);
                setProfitRatio(respData.data.color_pro_ratio);
                reset(paymentData);

                let gameData = {
                    is_market: respData.data.is_market.toString(),
                    is_colors: respData.data.is_colors.toString(),
                    game_duration: (respData.data.game_duration ? respData.data.game_duration.toString():"1")
                };
                setIsMarket(gameData.is_market);
                setIsColors(gameData.is_colors);
                setGameDuration(gameData.game_duration);
                setGameSettingInfo(gameData);
                reset2(gameData);
            } else {
                Alert.error(respData.message)
            }
        });
    }, []);

    return (
        <>
            <section className="main-content marketadd_main_sec">
                <div className="page-content">
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-lg-12">
                                <MoneySetting />
                                <div className="card">
                                    <div className="card-body">
                                        <h4 className="card-title mb-4">Update Payment Setting</h4>
                                        <Form key={1} className="needs-validation" noValidate onSubmit={handleSubmit(onSubmit)}>
                                            <div className="row">
                                                <div className="col-lg-4">
                                                    <Form.Group className="mb-3">
                                                        <Form.Label>Debit/Credit</Form.Label>
                                                        <div className="col-lg-12">
                                                            <Form.Check inline label="ON" value="1" id="on-card" type="radio" {...register("pg_is_card", { required: true })} />
                                                            <Form.Check inline label="OFF" id="off-card" type="radio" value="0" {...register("pg_is_card", { required: true })} />
                                                            <div className="error">
                                                                {errors.pg_is_card?.type === 'required' && "Debit/Credit is required"}
                                                            </div>
                                                        </div>
                                                    </Form.Group>
                                                </div>
                                                <div className="col-lg-4">
                                                    <Form.Group className="mb-3">
                                                        <Form.Label>Net Banking</Form.Label>
                                                        <div className="col-lg-12">
                                                            <Form.Check inline label="ON" value="1" id="on-net" type="radio" {...register("pg_is_net", { required: true })} />
                                                            <Form.Check inline label="OFF" id="off-net" type="radio" value="0" {...register("pg_is_net", { required: true })} />
                                                            <div className="error">
                                                                {errors.pg_is_net?.type === 'required' && "Net Banking is required"}
                                                            </div>
                                                        </div>
                                                    </Form.Group>
                                                </div>
                                            </div>
                                            <div className="row">
                                                <div className="col-lg-4">
                                                    <Form.Group className="mb-3">
                                                        <Form.Label>UPI</Form.Label>
                                                        <div className="col-lg-12">
                                                            <Form.Check inline label="ON" value="1" id="on-upi" type="radio" {...register("pg_is_upi", { required: true })} />
                                                            <Form.Check inline label="OFF" id="off-upi" type="radio" value="0" {...register("pg_is_upi", { required: true })} />
                                                            <div className="error">
                                                                {errors.pg_is_upi?.type === 'required' && "UPI is required"}
                                                            </div>
                                                        </div>
                                                    </Form.Group>
                                                </div>
                                                <div className="col-lg-4">
                                                    <Form.Group className="mb-3">
                                                        <Form.Label>Google Pay</Form.Label>
                                                        <div className="col-lg-12">
                                                            <Form.Check inline label="ON" value="1" id="on-googlepay" type="radio" {...register("pg_is_googlepay", { required: true })} />
                                                            <Form.Check inline label="OFF" id="off-googlepay" type="radio" value="0" {...register("pg_is_googlepay", { required: true })} />
                                                            <div className="error">
                                                                {errors.pg_is_googlepay?.type === 'required' && "Google Pay is required"}
                                                            </div>
                                                        </div>
                                                    </Form.Group>
                                                </div>
                                                <div className="col-lg-4">
                                                    <Form.Group className="mb-3">
                                                        <Form.Label>Phone Pay</Form.Label>
                                                        <div className="col-lg-12">
                                                            <Form.Check inline label="ON" value="1" id="on-phonepay" type="radio" {...register("pg_is_phonepay", { required: true })} />
                                                            <Form.Check inline label="OFF" id="off-phonepay" type="radio" value="0" {...register("pg_is_phonepay", { required: true })} />
                                                            <div className="error">
                                                                {errors.pg_is_phonepay?.type === 'required' && "Phone Pay is required"}
                                                            </div>
                                                        </div>
                                                    </Form.Group>
                                                </div>
                                            </div>
                                            <div className="btn-submit">
                                                <Button className="btn btn-primary w-md" type="submit">Update Setting</Button>
                                            </div>
                                        </Form>
                                    </div>
                                </div>
                                <div className="card">
                                    <div className="card-body">
                                        <h4 className="card-title mb-4">App Home Setting</h4>
                                        <Form key={2} className="needs-validation" noValidate onSubmit={handleSubmit2(onSubmitGame)}>
                                            <div className="row">
                                                <div className="col-lg-3">
                                                    <Form.Group className="mb-3">
                                                        <Form.Label>Market</Form.Label>
                                                        <div className="col-lg-12">
                                                            <Form.Check inline label="ON" value="1" id="on-market" type="radio" {...register2("is_market", { required: true })} onChange={(e) => handleChangeIsMarket(e)} />
                                                            <Form.Check inline label="OFF" id="off-market" type="radio" value="0" {...register2("is_market", { required: true })} onChange={(e) => handleChangeIsMarket(e)} />
                                                            <div className="error">
                                                                {errors2.is_market?.type === 'required' && "Market is required"}
                                                            </div>
                                                        </div>
                                                    </Form.Group>
                                                </div>
                                                <div className="col-lg-3">
                                                    <Form.Group className="mb-3">
                                                        <Form.Label>Color</Form.Label>
                                                        <div className="col-lg-12">
                                                            <Form.Check inline label="ON" value="1" id="on-colors" type="radio" {...register2("is_colors", { required: true })} onChange={(e) => handleChangeIsColor(e)} />
                                                            <Form.Check inline label="OFF" id="off-colors" type="radio" value="0" {...register2("is_colors", { required: true })} onChange={(e) => handleChangeIsColor(e)} />
                                                            <div className="error">
                                                                {errors2.is_colors?.type === 'required' && "Color is required"}
                                                            </div>
                                                        </div>
                                                    </Form.Group>
                                                </div>
                                                <div className="col-lg-6">
                                                    <Form.Group className="mb-3">
                                                        <Form.Label>Draw Time</Form.Label>
                                                        <div className="row">
                                                            <div className="col-lg-8">
                                                                <Form.Control type="number" id="game_duration" placeholder="Enter game duration" {...register2("game_duration", { required: true })} />
                                                                <div className="error">
                                                                    {errors2.game_duration?.type === 'required' && "Game duration is required"}
                                                                </div>
                                                            </div>
                                                            <div className="col-lg-4">
                                                                Minutes
                                                            </div>
                                                        </div>
                                                    </Form.Group>
                                                </div>
                                            </div>
                                            <div className="btn-submit">
                                                <Button className="btn btn-primary w-md" type="submit">Update Setting</Button>
                                            </div>
                                        </Form>
                                    </div>
                                </div>
                                <UpdateColorRatioSetting setting={profitRatio} />
                                <ViewGameRatioColor />
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default withRouter(Setting);