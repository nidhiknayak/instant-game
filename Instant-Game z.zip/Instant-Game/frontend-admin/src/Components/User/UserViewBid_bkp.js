import React, { useEffect, useState } from 'react';
import { Link, withRouter, useHistory, useParams } from "react-router-dom";
import Alert from '../../Services/Alert';
import User from '../../Services/User';
import { getGameTypeName } from '../../Services/Custom';
import moment from 'moment';

export const UserViewBid = (props) => {
    var {user_id} = useParams();
  const [bidList, setBidList] = useState({});
    const getBidList = () => {
        User.getBidList({ page: 0, size: 1000, search: '', user_id: user_id})
    .then((res) => res.data)
    .then((res) => {
        setBidList(res.data.docs);
        console.log(bidList);
    })
    .catch((err) => console.log(err))
  }

  useEffect(() => {
      getBidList();
  }, []);

  
  return (
    <>
      <section className="main-content userlist_main_sec">
        <div className="page-content">
          <div className="container-fluid">
            <div className="row">
              <div className="col-lg-12">
                  <div className="card">
                      <div className="card-body">
                        <div className="header-text">
                          <h4 className="card-title mb-4">User Bid List</h4>
                            <div className="edit-btn">
                            
                            </div>
                        </div>
                          <div className="table-responsive">
                              <table className="table align-middle table-nowrap mb-0">
                                  <thead className="table-light">
                                      <tr>
                                          {/* <th className="align-middle">Order ID</th> */}
                                          <th className="align-middle">Market</th>
                                          <th className="align-middle">Game Type</th>
                                          <th className="align-middle">Legend</th>
                                          <th className="align-middle">Bid Amount</th>
                                          <th className="align-middle">Status</th>
                                          <th className="align-middle">Winning Amount</th>
                                          <th className="align-middle">Bid Date</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                    {bidList&& bidList.length>0 && bidList.map((val, index)=>(
                                      <tr key={index}>
                                        <td>
                                                {val.market_id.name}
                                        </td>
                                        <td>{ getGameTypeName(val.game_type_id) }</td>
                                            <td>{(val.panna_2 != '' && val.panna_2 != null) ? val.panna_1 + '-' + val.panna_2 : val.panna_1 }</td>
                                        <td>{val.amount}</td>
                                        <td>
                                            {val.is_win == 1 && val.win_amount &&
                                                <label className="text-success" >Win</label>
                                            }
                                            {val.is_win == 0 && val.win_amount==null &&
                                                <div>-</div>
                                            }
                                            {val.is_win == 0 && val.win_amount != null &&
                                                <label className="text-danger" >Lose</label>
                                            }
                                        </td>
                                        <td>
                                            {val.is_win == 1 && val.win_amount &&
                                                <label>{val.win_amount}</label>
                                            }
                                            {val.is_win == 0 && val.win_amount == null &&
                                                <div>-</div>
                                            }
                                        </td>
                                            <td>{moment(val.createdAt).format('DD MMM, YY hh:mm A')}</td>
                                    </tr>
                                    ))}
                                  </tbody>
                              </table>
                          </div>
                          {/* end table-responsive  */}
                      </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

export default withRouter(UserViewBid);