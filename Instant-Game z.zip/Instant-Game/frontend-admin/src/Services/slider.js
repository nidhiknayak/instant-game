import Api from './Api';

class Slider {
    constructor(props){}

    save(obj) {
        return Api.post('slider/save', obj)
    }

    list(obj) {
        return Api.post('slider/list', obj)
    }

    edit(id) {
        return Api.get('slider/edit/'+id)
    }

    update(obj) {
        return Api.post('slider/update', obj)
    }
    
    delete(id) {
        return Api.get('slider/delete/'+id)
    }
    update_status(obj) {
        return Api.post('slider/status_change', obj)
    }
}
export default new Slider();